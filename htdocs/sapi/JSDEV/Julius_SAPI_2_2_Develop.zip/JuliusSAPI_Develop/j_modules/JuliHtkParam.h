//====================================================================
// JuliHtkParam.h: 
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIHTKPARAM_H__4E0B6584_8B72_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIHTKPARAM_H__4E0B6584_8B72_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDefines.h"
class CJuliHmmInfo;

// --- from htk_defs.h

enum parameter_type {
  F_WAVEFORM,
  F_LPC,			/* LPC --- linear prediction coef. */
  F_LPREFC,			/* linear prediction refrection coef. */
  F_LPCEPSTRA,			/* LPC cepstrum */
  F_LPDELCEP,
  F_IREFC,
  F_MFCC,			/* mel-frequency cepstral coef. */
  F_FBANK,			/* log-scale filterbank parameter */
  F_MELSPEC,			/* mel-scale filterbank parameter */
  F_USER,
  F_DISCRETE,			/* discrete */
  F_ERR_INVALID			/* ERROR */
};
/* additional parameter qualifier */
#define F_ENERGY     0x0040	/* _E log energy coef. */
#define F_ENERGY_SUP 0x0080	/* _N (with _E) suppress absolute energy */
#define F_DELTA      0x0100 	/* _D delta (first-order regression) coef. */
#define F_ACCL       0x0200	/* _A (with _D) acceleration (second-order) coef. */
#define F_COMPRESS   0x0400	/* _C compressed */
#define F_CEPNORM    0x0800	/* _Z cepstral mean normalization */
#define F_CHECKSUM   0x1000	/* _K CRC checksum added */
#define F_ZEROTH     0x2000	/* _0 (with MFCC) 0'th cepstral parameter */
#define F_BASEMASK   0x003f
/* covariance matrix type: only C_INV_DIAG supported */
enum{
  C_DIAG_C,
  C_INV_DIAG,
  C_FULL,
  C_LLT,
  C_XFORM};
/* duration type: only D_NULL is supported */
enum{
  D_NULL,
  D_POISSON,
  D_GAMMA,
  D_GEN};
/* HMM Type structure */
typedef struct {
  char *name;			/* name in hmmdefs */
  short type;			/* type id */
  char *desc;			/* description */
  boolean supported;		/* TRUE if can use */
} OptionStr;

typedef struct {
  unsigned int samplenum;	/* num of samples */
  unsigned int wshift;		/* window shift (unit=100ns) */
  unsigned short sampsize;	/* bytes per sample */
  short samptype;		/* sample type */
} HTK_Param_Header;

class CJuliHtkParam  
{
public:
	CJuliHtkParam();
	virtual ~CJuliHtkParam();

	void OutputInfo() const;	// put_param_info

	HTK_Param_Header header;	/* parameter header */
	unsigned int samplenum;	/* num of sample (same in header) */
	short veclen;			/* parameter vector length */
	VECT **parvec;		/* pattern(parameter) vector */

	void ExecExcludeOneVector(VECT *vec, int len); // exec_exclude_one_vector
	boolean SelectParamVmark(short dst_type_arg); // select_param_vmark
	CJuliHtkParam * NewSelectParamKind(short dst_type_arg); // new_select_param_kind
	CJuliHtkParam * NewParamCheckAndAdjust(CJuliHmmInfo *hmminfo, boolean vflag); // new_param_check_and_adjust
private:
	void InitMark(); // init_mark
	void FreeMark(); // free_mark
	void MarkExcludeVector(int loc, int len); // mark_exclude_vector
	void ExecExcludeVectors(CJuliHtkParam *_new); // exec_exclude_vectors
	int GuessBasenum(short qualtype); // guess_basenum
	short src_type;

	/* vector mark & delete */
	int *vmark;		/* mark vector */
	int vlen;		/* length of above */
	int vnewlen;		/* selected new length */
};

#endif // !defined(AFX_JULIHTKPARAM_H__4E0B6584_8B72_11D5_9AFA_008098E80572__INCLUDED_)
