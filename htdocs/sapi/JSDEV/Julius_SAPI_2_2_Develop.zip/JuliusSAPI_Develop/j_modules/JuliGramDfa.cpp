//====================================================================
// JuliGramDfa.cpp: DFA ���@�Ǘ��N���X (DFA_INFO)
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliGramDfa.h"

CJuliGramDfa::CJuliGramDfa()
{
	m_iStateNum = 0;
	m_iArcNum = 0;
	m_iTermNum = 0;
	cp = NULL;
	cp_begin = NULL;
	cp_end = NULL;
	sp_cid = 0;
	sp_id = 0;
	term.term_num =0;
	term.tw = NULL;
	term.wnum = NULL;
}

CJuliGramDfa::~CJuliGramDfa()
{
	if (term.wnum != NULL) delete [] term.wnum;
	if (term.tw != NULL)
	{
		for (int i=0;i<term.term_num;i++)
		{
			delete [] term.tw[i];
		}
		delete [] term.tw;
	}
	if (cp_begin != NULL) delete [] cp_begin;
	if (cp_end != NULL) delete [] cp_end;
	if (cp != NULL)
	{
		for (int i=0;i<m_iTermNum;i++)
		{
			delete [] cp[i];
		}
		delete [] cp;
	}
}


int CJuliGramDfa::ReadFromFile(const char *filename)	// (init_dfa)
 /* DFA file -> dinfo */
{
	CJuliFile file;
	
	J_MESSAGE("Reading in DFA grammar...");
	if (file.OpenRead(filename))
	{
		J_ERROR("failed to open %s\n",filename);
		return 1;
	}
	/* voca�ǂݍ���(HTK dict�t�H�[�}�b�g�p) */
	if (!ReadDfa(file))
	{
		J_ERROR("error in reading %s\n",filename);
		return 1;
	}
	if (file.CloseRead() == -1)
	{
		J_ERROR("close error\n");
		return 1;
	}
	J_MESSAGE("done\n");
	return 0;
}

/* ��b�����̑�1�t�B�[���h��DFA��Terminal�V���{���Ƃ̑Ή��Â����s�Ȃ� */
int CJuliGramDfa::MakeVocaRef(CJuliDictionary *winfo)	// (make_dfa_voca_ref)
{
	int i;
	boolean okflag = TRUE;
	J_MESSAGE("Mapping dict item <-> DFA terminal (category)...");
	/* word -> terminal symbol */
	for (i = 0; i < winfo->GetNumWords(); i++) {
		winfo->SetWordID(i,SymbolLookup(winfo->GetWordName(i)));
		if (winfo->GetWordID(i) == WORD_INVALID) {
			/* error: not found */
			J_ERROR("Error: no such terminal symbol \"%s\" in DFA grammar:\n",
				winfo->GetWordName(i));
//			put_voca(winfo, i);
			okflag = FALSE;
		}
	}
	if (!okflag) return 1;
	/* terminal symbol -> word */
	MakeTerminfo(winfo);
	
	J_MESSAGE("done\n");
	return 0;
}

void CJuliGramDfa::MakeTerminfo(CJuliDictionary *winfo) // (make_terminfo)
{
	// term.tw[t] �͒P��ID��t�ł���C���f�b�N�X�̔z�� (term.wnum[t] ��)
	int i,w,t;
	int tnum;
	
	tnum = term.term_num = m_iTermNum;
	term.wnum = new int[tnum];
	for(i=0;i<tnum;i++) term.wnum[i]=0;
	for(w=0;w<winfo->GetNumWords();w++) {
		term.wnum[winfo->GetWordID(w)]++;
	}
	term.tw = new WORD_ID * [tnum];
	for(i=0;i<tnum;i++) {
		term.tw[i] = new WORD_ID[term.wnum[i]];
	}
	for(i=0;i<tnum;i++) term.wnum[i]=0;
	for(w=0;w<winfo->GetNumWords();w++) {
		t = winfo->GetWordID(w);
		term.tw[t][term.wnum[t]] = w;
		term.wnum[t]++;
	}
}


#define MAXLINELEN 8192

boolean CJuliGramDfa::ReadDfa(CJuliFile &file)	// (rddfa)
{
	char buf[MAXLINELEN];
	int state, terminal, next_state;
	unsigned int status;
	int state_max, arc_num, terminal_max;
	DFA_ARC *newarc;
	int i;
    /* ������ */
	for(i=0; i<DFA_MAXSTATENUM; i++){
		st[i].number = i;
		st[i].status = 0;
		st[i].arc = NULL;
	}
	state_max = 0;
	arc_num = 0;
	terminal_max = 0;
	while (file.GetLine(buf, MAXLINELEN) != NULL) {
		// ============================================================================
		// Julian DFA �`�� ( mkfa �̏o�͌`�� ) �̃t�H�[�}�b�g ����
		// ----------------------------------------------------------------------------
		// ��s��J��
		// [��Ԕԍ�] [�J�ڋL���ԍ�] [����Ԕԍ�] [�X�e�[�^�X(16�i)] [?(16�i)]
		// ������Ԃ͏�Ԕԍ� 0 �ŌŒ�
		// �󗝏�Ԃ� status & ACCEPT_S(=1) ���^
		// ============================================================================

		state = atoi(file.GetFirstToken(buf));
		terminal = atoi(file.GetNextToken());
		next_state = atoi(file.GetNextToken());
		sscanf(file.GetNextToken(), "%x", &status);
		if (state >= DFA_MAXSTATENUM) {
			J_ERROR("maximum state number exceeded: %d > %d (= DFA_MAXSTATENUM)\n",
				state, DFA_MAXSTATENUM);
			return(FALSE);
		}
		if (next_state >= DFA_MAXSTATENUM) {
			J_ERROR("maximum next_state number exceeded: %d > %d (= DFA_MAXSTATENUM)\n",
				next_state, DFA_MAXSTATENUM);
			return(FALSE);
		}
		/* terminal�ɂ͐������� */
		/* ��Ԃ̃p�����[�^�� OR �Œǉ� */
		/* ������ mkfa �̒l��ύX */
		if (status & ACCEPT_S) {
			st[state].status |= ACCEPT_S;
		}
		/* ������ԃt���O�� mkfa �o�͂ɂ͂Ȃ� */
		/* ��Ԕԍ� 0 �ɌŒ� */
		if (state == 0) {
			st[state].status |= INITIAL_S;
		}
		/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
		/* !! ���͔ԍ�(����ю���Ԕԍ�)������������C!! */
		/* !! ���ꂾ��                                !! */
		/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
		if (terminal < 0 && next_state < 0) continue;
		/* add new arc to state */
		newarc = new DFA_ARC;
		newarc->label = terminal;
		newarc->to    = &(st[next_state]);
		newarc->next  = st[state].arc;
		st[state].arc = newarc;
		arc_num++;
		
		if (state_max < state) state_max = state;
		if (terminal_max < terminal) terminal_max = terminal;
	}
	m_iStateNum = state_max + 1;
	m_iArcNum = arc_num;
	m_iTermNum = terminal_max + 1;
	return(TRUE);
}

// SAPI�p
boolean CJuliGramDfa::ReadDfa_forSAPI(vector<int> stat, vector<int> term, vector<int> next, vector<int> accept)
{
//	char buf[MAXLINELEN];
	int state, terminal, next_state;
	unsigned int status;
	int state_max, arc_num, terminal_max;
	DFA_ARC *newarc;
	int i;
    /* ������ */
	for(i=0; i<DFA_MAXSTATENUM; i++){
		st[i].number = i;
		st[i].status = 0;
		st[i].arc = NULL;
	}
	state_max = 0;
	arc_num = 0;
	terminal_max = 0;
	for (int line=0;line<(int ) stat.size();line++) {
		state = stat[line];
		terminal = term[line];
		next_state = next[line];
		status = accept[line];
		if (state >= DFA_MAXSTATENUM) {
			J_ERROR("maximum state number exceeded: %d > %d (= DFA_MAXSTATENUM)\n",
				state, DFA_MAXSTATENUM);
			return(FALSE);
		}
		if (next_state >= DFA_MAXSTATENUM) {
			J_ERROR("maximum next_state number exceeded: %d > %d (= DFA_MAXSTATENUM)\n",
				next_state, DFA_MAXSTATENUM);
			return(FALSE);
		}
		/* terminal�ɂ͐������� */
		/* ��Ԃ̃p�����[�^�� OR �Œǉ� */
		/* ������ mkfa �̒l��ύX */
		if (status & ACCEPT_S) {
			st[state].status |= ACCEPT_S;
		}
		/* ������ԃt���O�� mkfa �o�͂ɂ͂Ȃ� */
		/* ��Ԕԍ� 0 �ɌŒ� */
		if (state == 0) {
			st[state].status |= INITIAL_S;
		}
		/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
		/* !! ���͔ԍ�(����ю���Ԕԍ�)������������C!! */
		/* !! ���ꂾ��                                !! */
		/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
		if (terminal < 0 && next_state < 0) continue;
		/* add new arc to state */
		newarc = new DFA_ARC;
		newarc->label = terminal;
		newarc->to    = &(st[next_state]);
		newarc->next  = st[state].arc;
		st[state].arc = newarc;
		arc_num++;
		
		if (state_max < state) state_max = state;
		if (terminal_max < terminal) terminal_max = terminal;
	}
	m_iStateNum = state_max + 1;
	m_iArcNum = arc_num;
	m_iTermNum = terminal_max + 1;
	return(TRUE);
}


WORD_ID CJuliGramDfa::SymbolLookup(const char *terminalname)	// (dfa_symbol_lookup)
{
	WORD_ID id;
	/* dict����terminal���w��́C���݂̂Ƃ����ID�𐔒l�ōs�Ȃ� */
	/* ���̂��߁C�P����atoi�����l��Ԃ��΂悢 */
	id = atoi(terminalname);
	if (id >= m_iTermNum) return(WORD_INVALID); /* error */
	else return(id);
}

/* DFA�͋t�����ł��炤. cp_{begin,end} �͑�1�p�X�Ŏg���̂�,��������
���. ���Ȃ킿 */
/* arc from initial state <-> end */
/* arc  to  accept  state <-> begin */
/* �����̊ȕւ���D�悵��, skip�\�� sp ��
�����C�����ɂ͌���Ă͂Ȃ�Ȃ��Ƃ��� (silB, silE�Ȃǂ��g��) */
void CJuliGramDfa::ExtractCategoryPair()	// (extract_cpair)
{
	int i,j;
	DFA_ARC *arc_l, *arc_r, *arc_r2;
	int left, right;
	/* ������ */
	cp = new boolean *[m_iTermNum];
	for(i=0;i<m_iTermNum;i++) {
		cp[i] = new boolean[m_iTermNum];
		for(j=0;j<m_iTermNum;j++) {
			cp[i][j] = FALSE;
		}
	}
	cp_begin = new boolean[m_iTermNum];
	cp_end = new boolean[m_iTermNum];
	for(i=0;i<m_iTermNum;i++) {
		cp_begin[i] = FALSE;
		cp_end[i] = FALSE;
	}
	for (i=0;i<m_iStateNum;i++) {
		if ((st[i].status & INITIAL_S) != 0) { /* ������Ԃ��� */
			for (arc_r = st[i].arc; arc_r; arc_r = arc_r->next) {
				if (arc_r->label == sp_cid) {
					J_ERROR("Error: skipable sp should not appear at end of sentence\n");
					exit(1);
				}
				cp_end[arc_r->label] = TRUE;
			}
		}
		for(arc_l = st[i].arc; arc_l; arc_l = arc_l->next) {
			left = arc_l->label;
			if (((arc_l->to)->status & ACCEPT_S) != 0) {/* �󗝏�Ԃ� */
				if (left == sp_cid) {
					J_ERROR("Error: skipable sp should not appear at beginning of sentence\n");
					exit(1);
				}
				cp_begin[left] = TRUE;
			}
			/* ����ȊO */
			for (arc_r = (arc_l->to)->arc; arc_r; arc_r = arc_r->next) {
				right = arc_r->label;
				cp[right][left] = TRUE;
				if (right == sp_cid) {
					for (arc_r2 = (arc_r->to)->arc; arc_r2; arc_r2 = arc_r2->next) {
						if (arc_r2->label == sp_cid) { /* 2�񑱂� */
							J_ERROR("Error: skipable sp should not repeat\n");
							exit(1);
						}
						cp[arc_r2->label][left] = TRUE;
					}
				}
			}
		}
	}
}

void CJuliGramDfa::OutputDebug()
{
	J_DEBUGMESSAGE("States=%d, Terms=%d, Arcs=%d, sp_id=%d, sp_cid=%d\n",
		m_iStateNum, m_iTermNum, m_iArcNum, sp_id, sp_cid);
	
}
