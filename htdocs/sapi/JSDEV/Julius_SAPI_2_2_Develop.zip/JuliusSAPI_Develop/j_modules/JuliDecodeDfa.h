// JuliDecodeDfa.h: CJuliDecodeDfa �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JULIDECODEDFA_H__C9CE2065_1F07_4845_AB31_F9BE1A3C7CF2__INCLUDED_)
#define AFX_JULIDECODEDFA_H__C9CE2065_1F07_4845_AB31_F9BE1A3C7CF2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDecode.h"

class CJuliDecodeDfa : public CJuliDecode
{
public:
	CJuliDecodeDfa();
	virtual ~CJuliDecodeDfa();

	virtual int FirstWords(NEXTWORD **nw, int peseqlen, int maxnw);	// *_firstwords
	virtual int NextWords(NODE *hypo, NEXTWORD **nw, int maxnw);	// *_nextwords
	virtual boolean Acceptable(NODE *hypo);	// *_acceptable
	virtual LOGPROB EosScore(NODE *hypo);	// *_eosscore

	boolean DfaLookAround(NEXTWORD *nword, NODE *hypo); // dfa_look_around
};

#endif // !defined(AFX_JULIDECODEDFA_H__C9CE2065_1F07_4845_AB31_F9BE1A3C7CF2__INCLUDED_)
