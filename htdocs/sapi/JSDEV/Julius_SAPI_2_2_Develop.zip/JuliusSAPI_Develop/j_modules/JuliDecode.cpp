//====================================================================
// JuliDecode.cpp: CJuliDecode �N���X�̃C���v�������e�[�V����
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// All rights reserved
//====================================================================

#include "JuliDecode.h"

CJuliDecode::CJuliDecode()
{

}

CJuliDecode::~CJuliDecode()
{

}

