//====================================================================
// JuliHmmInfo.h: hmm �t�@�C���̃�������̎��� (HMM_INFO)
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIHMMINFO_H__28868FC1_62A9_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIHMMINFO_H__28868FC1_62A9_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning ( disable : 4786 )

#include "JuliUtil.h"
#include "JuliDefines.h"
#include "JuliFile.h"
#include "JuliHtkHmmSegment.h"
#include "JuliHtkHmmTrans.h"
#include "JuliHtkHmmVar.h"
#include "JuliHtkHmmDens.h"
#include "JuliHtkHmmState.h"
#include "JuliHtkHmmData.h"
#include "JuliHtkHmmLogical.h"
#include "JuliHtkHmmCodebook.h"
#include "JuliHtkHmmOption.h"

// --- from htk_hmm.h

#define MAX_STATE_NUM 65535	/* allowed maximum state id = unsigned short */
/* delimiters to access logical triphones */
#define HMM_RC_DLIM "+"		/* right-context delimiter */
#define HMM_LC_DLIM "-"		/* right-context delimiter */
#define HMM_RC_DLIM_C '+'		/* right-context delimiter */
#define HMM_LC_DLIM_C '-'		/* right-context delimiter */

/* state sets for Gaussian(codebook) Selection (define HMM_GS)*/
typedef struct {
	CJuliHtkHmmState *state;		/* pointer to states in HMM_GS */
	/*  GCODEBOOK *book;*/		/* pointer to the corresponding codebook in hmminfo */
} GS_SET;

class CJuliHmmCDSetInfo	// HMM_CDSET_INFO
{	/* total LC_* info */
private:
	CD_Set *	cdroot;		/* sequencial list of LC_Set */
	CJuliPatriciaTreeNode<CD_Set *> *	cdtree;		/* LC_Set name index for lookup  */

public:
	CD_Set * GetCDRoot() { return cdroot; }
	void SetCDTree(CJuliPatriciaTreeNode<CD_Set *> * t) { cdtree = t; }
	CJuliPatriciaTreeNode<CD_Set *> * GetCDTree() { return cdtree; }
	CJuliPatriciaTreeNode<CD_Set *> ** GetCDTree_p() { return &cdtree; }
	// ������
	void Init() // cdset_init
	{
		cdroot = NULL;
		cdtree = NULL;	// MEMO: ���������Ă��Ȃ������̂Œǉ�
	}

	// CD_Set �����X�g�ɒǉ�
    void Add(CD_Set *_new) // cdset_add
	{
		_new->next = cdroot;
		cdroot = _new;
	}
	/* main lookup function */
	const CD_Set * Lookup(const char *cdstr) const	// cdset_lookup
	{
		const CD_Set *cd;
		cd = CJuliPatriciaTree<CD_Set *>::Search(cdstr, cdtree);
		if (strmatch(cdstr, cd->name)) {
			return cd;
		} else {
			return NULL;
		}
	}
	/* find cdset of same left-context for given HMM name */
	const CD_Set * LookupLCDSetByHmmname(const char *hmmname) const	// lcdset_lookup_by_hmmname
	{
		char *buf;
		const CD_Set *ret;
		
		buf = strcpy((char *)J_MALLOC((int)strlen(hmmname)+1), hmmname);
		ret = Lookup(CJuliUtil::GetLeftCenterName(hmmname, buf));
		J_FREE(buf);
		return(ret);
	}

	/* find cdset of same right context for given HMM name */
	const CD_Set * LookupRCDSetByHmmname(const char *hmmname) const	// rcdset_lookup_by_hmmname
	{
		char *buf;
		const CD_Set *ret;
		
		buf = strcpy((char *)J_MALLOC((int)strlen(hmmname)+1), hmmname);
		ret = Lookup(CJuliUtil::GetRightCenterName(hmmname, buf));
		J_FREE(buf);
		return(ret);
	}
};

class CJuliHmmInfo  
{
public:
	CJuliHmmInfo();
	virtual ~CJuliHmmInfo();
	
	// �t�@�C������ǂݍ���(�e�L�X�g�`��)
	int ReadFromFile(const char *hmmfilename, const char *namemapfile);	// (init_hmminfo)

	// �o�C�i���`���Ńt�@�C���ɏ�������
	int WriteToFileBinary(const char *bhmmfilename);
	void ReadTmix(CJuliFile &file,CJuliHtkHmmState *state);

	CJuliHtkHmmTrans *	ReadTransSegment(CJuliFile &file);	// get_trans_data
	CJuliHtkHmmVar *	ReadVarSegment(CJuliFile &file);		// get_var_data
	CJuliHtkHmmDens *	ReadDensSegment(CJuliFile &file);		// get_dens_data
	CJuliHtkHmmState *	ReadStateSegment(CJuliFile &file);	// get_state_data
	void SkipRegTreeSegment(CJuliFile &file);	// (regtree_read)

	boolean CheckHmmLimit(CJuliHtkHmmData *dt); // check_hmm_limit
	boolean CheckAllHmmLimit(); // check_all_hmm_limit
	
	boolean MakeCDSet(); // make_cdset

	const CJuliHtkHmmData * LookupPhysical(const char *keyname) const; // (htk_hmmdata_lookup_physical)
	const CJuliHtkHmmLogical * LookupLogical(const char *keyname) const; // (htk_hmmdata_lookup_logical)
	
	// �R�[�h�u�b�N�֌W
	int GetCodeBookNum() const { return codebooknum; }
	
	// �A�N�Z�b�T
	CJuliHtkHmmOption & GetOption() { return m_opt; }
	const CJuliHtkHmmOption & GetOption() const { return m_opt; }
	
	const CJuliHtkHmmSegmentDatabase<CJuliHtkHmmTrans> &	GetTransDB() const { return m_sdbTrans; }
	const CJuliHtkHmmSegmentDatabase<CJuliHtkHmmVar> &		GetVarDB() const { return m_sdbVar; }
	const CJuliHtkHmmSegmentDatabase<CJuliHtkHmmDens> &		GetDensDB() const { return m_sdbDens; }
	const CJuliHtkHmmSegmentDatabase<CJuliHtkHmmState> &	GetStateDB() const { return m_sdbState; }
	const CJuliHtkHmmSegmentDatabase<CJuliHtkHmmData> &		GetDataDB() const { return m_sdbData; }
	const CJuliHtkHmmSegmentDatabase<CJuliHtkHmmLogical> &	GetLogicalDB() const { return m_sdbLogical; }
	
	boolean IsTriphone() const { return m_bIsTriphone; }
	boolean IsTiedMixture() const { return m_bIsTiedMixture; }
	boolean IsPreferCdsetAvg() const { return prefer_cdset_avg; }
	void SetPreferCdsetAvg(bool p) { prefer_cdset_avg = p; }
	
	int GetTotalStateNum() const { return totalstatenum; }
	int GetMaxMixtureNum() const { return maxmixturenum; }

	const CJuliHtkHmmLogical * GetRightContextHMM(const CJuliHtkHmmLogical *base, const char *rc_name) const;	// get_right_context_HMM
	const CJuliHtkHmmLogical * GetLeftContextHMM(const CJuliHtkHmmLogical *base, const char *lc_name) const;	// get_left_context_HMM

	int GetDefaultBeamWidth() const;

	const CJuliHmmCDSetInfo * GetCDSetInfo_const() const { return &cdset_info; }

private:
	// ********** private methods **********

	// �������A�t�@�C�����[�h�֌W
	void Init();
	boolean ReadHmmList(CJuliFile &file);	// rdhmmlist
	boolean ReadHmmDef(CJuliFile &file);	// (rdhmmdef)
	boolean ReadHmmDef_Binary(CJuliFile &file);
	boolean GuessIfCDHmm(); //guess_if_cd_hmm
	void SetGlobalOption(CJuliFile &file);	// set_global_opt
	void ConvLogArc();						// (conv_log_arc)
	void DefTransMacro(const char *name, CJuliFile &file);	// def_trans_macro
	void DefVarMacro(const char *name, CJuliFile &file);	// def_var_macro
	void DefDensMacro(const char *name, CJuliFile &file);	// def_dens_macro
	void DefStateMacro(const char *name, CJuliFile &file);	// def_state_macro
	void DefHMMMacro(const char *name, CJuliFile &file);	// def_HMM_macro
	void DefRegTreeMacro(const char *name, CJuliFile &file);	// def_var_macro
	
	void CodebookAdd(CJuliHtkHmmCodebook *_new);
	void CreateCodebookIndex(CJuliHtkHmmCodebook *book);	// tmix_create_codebook_index
	CJuliHtkHmmCodebook * CodebookLookup(char *keyname);

	//
	void AddPhysicalToLogical(); // hmm_add_physical_to_logical
	void AddPseudoPhones(); // hmm_add_pseudo_phones
	void AddPseudoPhonesSub(const char *name); // hmm_add_pseudo_phones_sub
	void CountLogicalNum(); // hmm_count_logical_num
	
	CJuliHmmCDSetInfo * GetCDSetInfo() { return &cdset_info; }
	CD_Set * NewCDSet();// cdset_new
	void PutCDSet(const CD_Set *a); // put_cdset
	void PutAllCDInfo(); // put_all_cdinfo
	boolean RegistCDSet(const CJuliHtkHmmData *d, const char *cdname); // regist_cdset

	// ********** private variables **********

	/* codebook for TM models */
	CJuliPatriciaTreeNode<CJuliHtkHmmCodebook *> *m_ptreeCodebook;	/* (tied mixture) gaussian codebook */ // codebook_root
																	/* name->pointer index tree */
	// �e�Z�O�����g�̎��̂��Ǘ�����f�[�^�x�[�X�N���X
	CJuliHtkHmmSegmentDatabase<CJuliHtkHmmTrans>	m_sdbTrans;
	CJuliHtkHmmSegmentDatabase<CJuliHtkHmmVar>		m_sdbVar;
	CJuliHtkHmmSegmentDatabase<CJuliHtkHmmDens>		m_sdbDens;
	CJuliHtkHmmSegmentDatabase<CJuliHtkHmmState>	m_sdbState;
	CJuliHtkHmmSegmentDatabase<CJuliHtkHmmData>		m_sdbData;
	CJuliHtkHmmSegmentDatabase<CJuliHtkHmmLogical>	m_sdbLogical;
	
	CJuliHtkHmmOption	m_opt;		// �I�v�V����
	CJuliHmmCDSetInfo	cdset_info;	/* context-wise state set info */
									/* for inter-word triphone handling */
	/* misc. model info */
	boolean m_bIsTriphone;		/* TRUE if this is triphone model */	// is_triphone
	boolean m_bIsTiedMixture;	/* TRUE if this is tied-mixture model */	// is_tied_mixture
	boolean prefer_cdset_avg;	/* compute average of lcdset instead of maximum */
	
	int totalmixnum;		/* total mixture num */
	int totalstatenum;		/* total state num */
	int totalhmmnum;		/* physical HMM num */

	int totallogicalnum;	/* logical HMM num */
	int totalpseudonum;		/* pseudo HMM num in logical */
	int codebooknum;		/* total num of codebook */
	int maxcodebooksize;	/* maximum size of codebook */

	int maxmixturenum;		/* maximum size of mixture */

	int add_count;
};

#endif // !defined(AFX_JULIHMMINFO_H__28868FC1_62A9_11D5_9AFA_008098E80572__INCLUDED_)
