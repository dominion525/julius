//====================================================================
// JuliHtkHmmData.h: Htk HMM: Transition �I�u�W�F�N�g (HTK_HMM_Trans)
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIHTKHMMTRANS_H__C2F03B11_7AC4_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIHTKHMMTRANS_H__C2F03B11_7AC4_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <assert.h>
#include "JuliHtkHmmSegment.h"
#include "JuliDefines.h"

class CJuliHtkHmmTrans : public CJuliHtkHmmSegment
{
public:
	CJuliHtkHmmTrans();
	virtual ~CJuliHtkHmmTrans();

	void ReadFromFile(CJuliFile &file, CJuliHmmInfo &info);
	// �A�N�Z�b�T
	short GetStateNum() const { return m_siStateNum;}
	void SetArcTransProb(int a, int b, PROB p)
	{ assert(a>=0 && a<m_siStateNum); assert(b>=0 && b<m_siStateNum); m_probArcTransition[a][b] = p; }
	PROB GetArcTransProb(int a, int b) const
	{ assert(a>=0 && a<m_siStateNum); assert(b>=0 && b<m_siStateNum); return m_probArcTransition[a][b]; }
private:
	short		m_siStateNum;			/* num of state */
	PROB **		m_probArcTransition;	/* arc transition prob */
	PROB *		atmp;		// m_siStateNum*m_siStateNum �̔z��Bm_probArcTransition �����p
};

#endif // !defined(AFX_JULIHTKHMMTRANS_H__C2F03B11_7AC4_11D5_9AFA_008098E80572__INCLUDED_)
