//====================================================================
// JuliDictionary.cpp: �����Ǘ��N���X (WORD_INFO)
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliDictionary.h"
#include "JuliFile.h"
#include "JuliHmmInfo.h"

/* original from ~speech/src/sent/hmm.h */
#define	MAXWSTEP 4000		/* step size of vocabulary */


CJuliDictionary::CJuliDictionary()
: m_word(NULL),
num(0), maxnum(0), maxwlen(0), head_silwid(0), tail_silwid(0)
{
}

CJuliDictionary::~CJuliDictionary()
{
	if (m_word)
	{
		for (int i=0;i<num;i++)
		{
			if (m_word[i] != NULL)
			{
				delete m_word[i];
			}
		}
		delete [] m_word;
	}
}

void CJuliDictionary::Init()	/* initial malloc */
{
	int n = MAXWSTEP;
	maxnum = n;
	num = 0;
	m_word = new CJuliWord *[n];
}

int CJuliDictionary::Expand()	/* expand alloced area */
{
	int n;

	n = maxnum;
	if (n >= MAX_WORD_NUM)
	{
		J_ERROR("Error: maximum dict size exceeded limit (%d)\n", MAX_WORD_NUM);
		return 1;
	}
	n += MAXWSTEP;
	if (n > MAX_WORD_NUM) n = MAX_WORD_NUM;

	{
		// REALLOC �݂����Ȃ�
		CJuliWord **tmp = new CJuliWord *[n];	// �V�����|�C���^�̔z����Q�b�g
		for(int i=0;i<maxnum;i++) tmp[i]=m_word[i];		// �|�C���^���������ƃR�s�[
		delete [] m_word;	// �̂̂͗p�ς�
		m_word = tmp;
	}
	maxnum = n;
	return 0;
}

/* read & initialize dict */
int CJuliDictionary::ReadFromFile(const char *filename, CJuliHmmInfo *hmminfo, boolean not_conv_tri, boolean force_dict)	// (init_voca)
{
	CJuliFile dictfile;

	J_MESSAGE("Reading in dictionary...");
	/* read voca file */
	if (dictfile.OpenRead(filename))
	{
		J_ERROR("failed to open %s\n",filename);
		return 1;
	}
	/* voca.$BFI$_9~$_.(B(HTK dict.$B%U%)!<%^%C%HMQ.(B) */
	if (!LoadHtkDict(dictfile, hmminfo, not_conv_tri))
	{
		if (force_dict) {
			J_MESSAGE("errors are ignored\n");
		} else {
			J_ERROR("error in reading %s\n",filename);
			return 1;
		}
	}
	if (dictfile.CloseRead()) {
		J_ERROR("close error\n");
		return 1;
	}

	J_MESSAGE("%d words...done\n", GetNumWords());
	return 0;
}

/* voca_load_htkdict.c --- read in vocabulary data */
/* format is HTK Dictionary format */

#include <string.h>
//#include <sent/stddefs.h>
//#include <sent/vocabulary.h>
//#include <sent/htk_hmm.h>

/* 
* �������̎d�l
* 
* �E��s���Ƃ�1���R�[�h(1�P��)�D
* 
* �t�B�[���h�F ���@�G���g�� [�o�͕�����] ���f ���f ...
* 
* ���e�t�B�[���h�̐���
*         ���@�G���g��
*		   (N-gram�̏ꍇ)
*		   �P���N-gram�ł̃G���g����
*	            (���{��)[+(�ꊲ)]+(�`�ԑf���ID) �̌`
*                 N-gram�̃G���g���Ƃ̑Ή������̂ɗp����
*
* 	   [�o�͕�����]
*		   �F�����ʏo�͎��ɏo�͂��镶����D
* 	           {�o�͕�����}�Ȃ�Transparent word
* 
*	   ���f�\�L...
*		   ���f���f���ɏ��������f�\�L(HTK format)
*		   �ꉹ�f���� ' ' �ŋ�؂��ĕ\�L(HTK .dict �ɏ�����)
*/

static char trbuf[3][20];
static char chbuf[30];
static char nophone[1];
static int  trp_l, trp, trp_r;

/* return string of triphone name composed from last 3 call */
static char *
cycle_triphone(const char *p)
{
	int i;

	if (p == NULL) {		/* initialize */
		nophone[0]='\0';
		for(i=0;i<3;i++) trbuf[i][0] = '\0';
		trp_l = 0;
		trp   = 1;
		trp_r = 2;
		return NULL;
	}

	strcpy(trbuf[trp_r],p);

	chbuf[0]='\0';
	if (trbuf[trp_l][0] != '\0') {
		strcat(chbuf,trbuf[trp_l]);
		strcat(chbuf,HMM_LC_DLIM);
	}
	if (trbuf[trp][0] == '\0') {
		i = trp_l;
		trp_l = trp;
		trp = trp_r;
		trp_r = i;
		return NULL;
	}
	strcat(chbuf, trbuf[trp]);
	if (trbuf[trp_r][0] != '\0') {
		strcat(chbuf,HMM_RC_DLIM);
		strcat(chbuf,trbuf[trp_r]);
	}
	i = trp_l;
	trp_l = trp;
	trp = trp_r;
	trp_r = i;

	return(chbuf);
}

/* ������Ԑ��̍ő�l */
void CJuliDictionary::SetMaxWn()
{
	int w,p,n;
	maxwn = 0;
	for (w=0;w<GetNumWords();w++) {
		n = 0;
		for (p=0;p<GetWordLen(w);p++) {
			n += (m_word[w]->wseq[p])->GetPhysicalHmm()->GetStateNum() - 2;
		}
		if (maxwn < n) maxwn = n;
	}
}

/* parse winfo and set maximum word length */
void CJuliDictionary::SetMaxWordLength()
{
	WORD_ID w;
	maxwlen = 0;
	for(w=0;w<GetNumWords();w++) {
		if (maxwlen < GetWordLen(w)) maxwlen = GetWordLen(w);
	}
}

#define PHONEMELEN_STEP  5	/* malloc base */

/* read in vocabulary file */
boolean	CJuliDictionary::LoadHtkDict( /* TRUE on success */
									 CJuliFile &dictfile,
									 CJuliHmmInfo *hmminfo,	/* if NULL, phonemes are ignored */
									 boolean ignore_tri_conv)	/* TRUE if convert to triphone should be ignored */
{
	boolean ok_flag = TRUE;
	WORD_ID vnum;
	char buf[800], tmpbuf[800];
	int j,len,tmpmaxlen;
	const CJuliHtkHmmLogical *tmplg;
	const CJuliHtkHmmLogical **tmpwseq;
	char *p, *lp = NULL, *ptmp;
	boolean do_conv = FALSE;
	boolean is_trans = FALSE;

	if (hmminfo != NULL && hmminfo->IsTriphone() && (! ignore_tri_conv))
		do_conv = TRUE;

	Init();

	vnum = 0;
	while (dictfile.GetLine(buf, sizeof(buf)) != NULL) {
		m_word[vnum] = new CJuliWord;
		/* ���@�G���g�� */
		ptmp = dictfile.GetFirstToken(buf);
		m_word[vnum]->SetWordName(ptmp);

		/* �o�͕����� */

		// �g�[�N���̑傫���`�F�b�N
		char *tkn = dictfile.GetNextToken();
		if (tkn == NULL) return FALSE;
		if (strlen(tkn)>=800)
		{
			J_ERROR("Too long token is found.\n");
			return FALSE;
		}
		strcpy(tmpbuf, tkn);
		switch(tmpbuf[0]) {
		case '[':
			is_trans = FALSE;
			break;
		case '{':
			is_trans = TRUE;
			break;
		default:
			J_ERROR("line %d: word %s has no output string\n", vnum+1, GetWordName(vnum));
			ok_flag = FALSE;
			continue;
		}
		m_word[vnum]->is_transparent = is_trans;
		j = strlen(tmpbuf);
		tmpbuf[j-1] = '\0';
		ptmp = &(tmpbuf[1]);
		m_word[vnum]->SetWordOutput(ptmp);

		/* ���f�\�L */
		if (hmminfo == NULL) {
			/* �ǂݍ��܂Ȃ� */
			m_word[vnum]->wseq = NULL;
			m_word[vnum]->wlen = 0;
		} else {
			tmpmaxlen = PHONEMELEN_STEP;
			tmpwseq = (const CJuliHtkHmmLogical **)J_MALLOC(sizeof(CJuliHtkHmmLogical *) * tmpmaxlen);
			len = 0;

			/* �g�p���f���� triphone �̏ꍇ�́Ctriphone�����Ȃ���i�[ */
			if (do_conv) {
				cycle_triphone(NULL);
				lp = dictfile.GetNextTokenIfAny();
				if (lp == NULL) {
					J_ERROR("line %d: word %s has no phoneme.\n", vnum+1, GetWordName(vnum));
					ok_flag = FALSE;
					goto end_word;
				}
				cycle_triphone(lp);
			}

			for (;;) {
				if (do_conv) {
					/*	  if (lp != NULL) j_printf(" %d%s",len,lp);*/
					if (lp != NULL) lp = dictfile.GetNextTokenIfAny();
					if (lp != NULL) p = cycle_triphone(lp);
					else p = cycle_triphone(nophone);
				} else {
					p = dictfile.GetNextTokenIfAny();
				}
				if (p == NULL) break;
#if 1		// FALLBACK
				/* both defined/pseudo phone is allowed */
				tmplg = hmminfo->LookupLogical(p);
				char cbuf[50];
				if (tmplg == NULL && do_conv) {
					/* fall to (pseudo-)monophone */
					tmplg = hmminfo->LookupLogical(CJuliUtil::GetCenterName(p,cbuf));
					if (tmplg != NULL) {
						/* use monophone instead */
						if (len == 0) {
							J_WARNING("Warning: line %d: no triphone matches \"*-%s\",", vnum+1, p);
						} else if (lp == NULL) {
							J_WARNING("Warning: line %d: no triphone matches \"%s+*\",", vnum+1, p);
						} else {
							J_WARNING("Warning: line %d: word-internal triphone \"%s\" is missing,\n", vnum+1, p);
						}
						if (tmplg->IsPseudo()) {
							J_WARNING(" use pseudo monophone \"%s\"\n", cbuf);
						} else {
							J_WARNING(" use monophone \"%s\"\n", cbuf);
						}
					}
				}
				if (tmplg == NULL) {      /* not found */
					if (do_conv) {
						J_ERROR("line %d: logical phone for both \"%s\" and \"%s\" is missing\n", vnum+1, p, cbuf);
					} else {
						J_ERROR("line %d: logical phone \"%s\" not found\n", vnum+1, p);
					}
					ok_flag = FALSE;
					continue;
//					free(winfo->wname[vnum]);
//					free(winfo->woutput[vnum]);
//					return TRUE;
				}
#else
				if ((tmplg = hmminfo->LookupLogical(p)) == NULL) {
					/* not found */
					if (do_conv) {
						J_ERROR("line %d: logical triphone \"%s\" not found in logical / defined HMM\n", vnum+1, p);
					} else {
						J_ERROR("line %d: HMM \"%s\" not found\n", vnum+1, p);
					}
					ok_flag = FALSE;
					continue;
				}
#endif
				tmpwseq[len] = tmplg;
				len++;
				if (len >= tmpmaxlen) {
					/* expand wseq area by PHONEMELEN_STEP */
					tmpmaxlen += PHONEMELEN_STEP;
					tmpwseq = (const CJuliHtkHmmLogical **)J_REALLOC(tmpwseq, sizeof(CJuliHtkHmmLogical *) * tmpmaxlen);
				}
			}
			if (len == 0) {
				J_ERROR("line %d: no phone specified.\n", vnum+1);
				ok_flag = FALSE;
			}
			m_word[vnum]->wseq = tmpwseq;
			m_word[vnum]->wlen = len;
		}

end_word:
		// �G���g�����P���₷
		vnum++;
		// �������̈悪����Ȃ���Α��₷
		if (vnum >= maxnum)
			Expand();

	}

	num = vnum;

	/* maxwn ���𒊏o���Ċi�[ */
	SetMaxWn();
	SetMaxWordLength();

	return(ok_flag);
}

// SAPI �p�̎����ǂݍ��� �t�@�C���̕ς���vector<string>
/* read in vocabulary file */
boolean	CJuliDictionary::LoadHtkDict_forSAPI( /* TRUE on success */
											 vector<string> &data,
											 CJuliHmmInfo *hmminfo,	/* if NULL, phonemes are ignored */
											 boolean ignore_tri_conv)	/* TRUE if convert to triphone should be ignored */
{
	CJuliFile dictfile;	// ���݁[

	boolean ok_flag = TRUE;
	WORD_ID vnum;
	char buf[800], tmpbuf[800];
	int j,len,tmpmaxlen;
	const CJuliHtkHmmLogical *tmplg;
	const CJuliHtkHmmLogical **tmpwseq;
	char *p, *lp = NULL, *ptmp;
	boolean do_conv = FALSE;
	boolean is_trans = FALSE;

	if (hmminfo != NULL && hmminfo->IsTriphone() && (! ignore_tri_conv))
		do_conv = TRUE;

	Init();

	vnum = 0;
	for (int line=0;line<(int ) data.size();line++) {
		strcpy(buf,data[line].c_str());
		m_word[vnum] = new CJuliWord;
		/* ���@�G���g�� */
		ptmp = dictfile.GetFirstToken(buf);
		m_word[vnum]->SetWordName(ptmp);

		/* �o�͕����� */
		strcpy(tmpbuf, dictfile.GetNextToken());
		switch(tmpbuf[0]) {
		case '[':
			is_trans = FALSE;
			break;
		case '{':
			is_trans = TRUE;
			break;
		default:
			J_ERROR("line %d: word %s has no output string\n", vnum+1, GetWordName(vnum));
			ok_flag = FALSE;
			continue;
		}
		m_word[vnum]->is_transparent = is_trans;
		j = strlen(tmpbuf);
		tmpbuf[j-1] = '\0';
		ptmp = &(tmpbuf[1]);
		m_word[vnum]->SetWordOutput(ptmp);

		/* ���f�\�L */
		if (hmminfo == NULL) {
			/* �ǂݍ��܂Ȃ� */
			m_word[vnum]->wseq = NULL;
			m_word[vnum]->wlen = 0;
		} else {
			tmpmaxlen = PHONEMELEN_STEP;
			tmpwseq = (const CJuliHtkHmmLogical **)J_MALLOC(sizeof(CJuliHtkHmmLogical *) * tmpmaxlen);
			len = 0;

			/* �g�p���f���� triphone �̏ꍇ�́Ctriphone�����Ȃ���i�[ */
			if (do_conv) {
				cycle_triphone(NULL);
				lp = dictfile.GetNextTokenIfAny();
				if (lp == NULL) {
					J_ERROR("line %d: word %s has no phoneme.\n", vnum+1, GetWordName(vnum));
					ok_flag = FALSE;
					goto end_word;
				}
				cycle_triphone(lp);
			}

			for (;;) {
				if (do_conv) {
					/*	  if (lp != NULL) j_printf(" %d%s",len,lp);*/
					if (lp != NULL) lp = dictfile.GetNextTokenIfAny();
					if (lp != NULL) p = cycle_triphone(lp);
					else p = cycle_triphone(nophone);
				} else {
					p = dictfile.GetNextTokenIfAny();
				}
				if (p == NULL) break;

				if ((tmplg = hmminfo->LookupLogical(p)) == NULL) {
					/* not found */
					if (do_conv) {
						J_ERROR("line %d: logical triphone \"%s\" not found in logical / defined HMM\n", vnum+1, p);
					} else {
						J_ERROR("line %d: HMM \"%s\" not found\n", vnum+1, p);
					}
					ok_flag = FALSE;
					continue;
				}

				tmpwseq[len] = tmplg;
				len++;
				if (len >= tmpmaxlen) {
					/* expand wseq area by PHONEMELEN_STEP */
					tmpmaxlen += PHONEMELEN_STEP;
					tmpwseq = (const CJuliHtkHmmLogical **)J_REALLOC(tmpwseq, sizeof(CJuliHtkHmmLogical *) * tmpmaxlen);
				}
			}
			if (len == 0) {
				J_ERROR("line %d: no phone specified.\n", vnum+1);
				ok_flag = FALSE;
			}
			m_word[vnum]->wseq = tmpwseq;
			m_word[vnum]->wlen = len;
		}

end_word:
		// �G���g�����P���₷
		vnum++;
		// �������̈悪����Ȃ���Α��₷
		if (vnum >= maxnum)
			Expand();

	}

	num = vnum;

	/* maxwn ���𒊏o���Ċi�[ */
	SetMaxWn();
	SetMaxWordLength();

	return(ok_flag);
}
/* convert monophone dictionary to word-internal triphone */
boolean CJuliDictionary::Mono2Tri(CJuliHmmInfo *hmminfo)
{
	WORD_ID w;
	int ph;
	char *p;
	const CJuliHtkHmmLogical *tmplg;
	boolean ok_flag = TRUE;

	for (w=0;w<GetNumWords();w++) {
		cycle_triphone(NULL);
		cycle_triphone(m_word[w]->wseq[0]->GetName());

		for (ph = 0; ph < GetWordLen(w) ; ph++) {
			if (ph == GetWordLen(w) - 1) {
				p = cycle_triphone(nophone);
			} else {
				p = cycle_triphone(m_word[w]->wseq[ph + 1]->GetName());
			}
			if ((tmplg = hmminfo->LookupLogical(p)) == NULL) {
				J_ERROR("voca_mono2tri: word \"%s[%s]\"(id=%d): HMM \"%s\" not found\n",
					GetWordName(w), GetWordOutput(w), w, p);
				ok_flag = FALSE;
				continue;
			}
			m_word[w]->wseq[ph] = tmplg;
		}
	}
	return (ok_flag);
}


/* voca_lookup.c --- vocabulary lookup function for reading transcriptions */

/* search for word */
/* keyword: "wname" or "wname[woutput]" or "#num" */
/* returns WORD_INVALID if not found */
WORD_ID CJuliDictionary::LookupWordID(const char *keyword) // voca_lookup_wid
{
	WORD_ID i, found;
	int plen,totallen;
	boolean numflag = TRUE;
	int wid;
	char *c;

	if (keyword == NULL) return WORD_INVALID;

	if (keyword[0] == '#') {

		for(i=1;i<strlen(keyword);i++) {
			if (keyword[i] < '0' || keyword[i] > '9') {
				numflag = FALSE;
				break;
			}
		}
		if (numflag) {
			wid = atoi(&(keyword[1]));
			if (wid < 0 || wid >= num) {
				return(WORD_INVALID);
			} else {
				return(wid);
			}
		} else {
			return(WORD_INVALID);
		}
	}

	found = WORD_INVALID;
	totallen = strlen(keyword);
	if ((c = strchr(keyword, '[')) != NULL) {
		plen = c - keyword;
		for (i=0;i<num;i++) {
			if (strnmatch(keyword,GetWordName(i), plen)
				&& strnmatch(c+1, GetWordOutput(i), totallen-plen-2)) {
					if (found == WORD_INVALID) {
						found = i;
					} else {
						J_WARNING("Warning: several \"%s\" found in dictionary, use the first one..\n");
						break;
					}
				}
		}
	} else {
		for (i=0;i<num;i++) {
			if (strmatch(keyword,GetWordName(i))) {
				if (found == WORD_INVALID) {
					found = i;
				} else {
					J_WARNING("Warning: several \"%s\" found in dictionary, use the first one..\n");
					break;
				}
			}
		}
	}
	return found;
}

/* convert space-separated words string -> array of wid */
/* return malloced array */
#define WSSTEP 10

WORD_ID *CJuliDictionary::NewStr2WordSeq(char *s, int *len_return) // new_str2wordseq
{
	char *p;
	int num;
	int maxnum;
	WORD_ID *wseq;

	maxnum = WSSTEP;
	wseq = (WORD_ID *)J_MALLOC(sizeof(WORD_ID)*maxnum);
	num = 0;
	for (p = strtok(s, " "); p != NULL; p = strtok(NULL, " ")) {
		if (num >= maxnum) {
			maxnum += WSSTEP;
			wseq = (WORD_ID *)J_REALLOC(wseq, sizeof(WORD_ID) * maxnum);
		}
		if ((wseq[num] = LookupWordID(p)) == WORD_INVALID) {
			/* not found */
			J_MESSAGE("word \"%s\" not found in dict\n", p);
			J_FREE(wseq);
			return NULL;
		}
		num++;
	}

	*len_return = num;
	return(wseq);
}



void CJuliDictionary::OutputDebug()
{
	J_DEBUGMESSAGE("Words = %d / %d, maxwn = %d, maxwlen = %d\n", num, maxnum, maxwn, maxwlen);
	J_DEBUGMESSAGE("Head_silwid = %d, Tail_silwid = %d\n", head_silwid, tail_silwid);
	for (int w=0;w<num;w++)
		m_word[w]->OutputDebug();
}
