//====================================================================
// JuliGrammar.cpp: ���@�Ǘ��N���X�̊��N���X
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// All rights reserved
//====================================================================

#include "JuliGrammar.h"

CJuliGrammar::CJuliGrammar()
{

}

CJuliGrammar::~CJuliGrammar()
{

}
