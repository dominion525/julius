//====================================================================
// JuliGramNgramArpa.cpp: Ngram ���@�Ǘ��N���X (Arpa �`���ǂݍ���)
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2002 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

/* ngram_read_arpa.c --- read in N-gram data in ARPA standard format */

/* $Id: JuliGramNgramArpa.cpp,v 1.3 2003/03/16 14:36:01 sumiyosi Exp $ */

/* format: LR 2-gram and RL 3-gram in ARPA-standard format */
/* words should be alphabetically sorted */
/* order: LR 2-gram -> RL 3-gram (!! order is important !!) */

#include "JuliGramNgram.h"
#include "JuliFile.h"

static char buf[800];			/* buffer for read */
static char pbuf[800];			/* buffer for error string */

/* sub functions */
WORD_ID CJuliGramNgram::LkupWord(const char *str)	// lookup_word
{
	WORD_ID wid;

	if ((wid = LookupWord(str)) == WORD_INVALID) {
		J_ERROR("word %s not in N-gram vocabulary.\n",str);
	}
	return wid;
}

/* read in total info (LR) */
/* \data\ */
void CJuliGramNgram::SetTotalInfo(CJuliFile &fp) // set_total_info 
{
	char *_p;
	int n;

	while (fp.GetLine(buf, sizeof(buf)) != NULL && buf[0] != '\\') {
		if (strnmatch(buf, "ngram", 5)) { /* n-gram num */
			_p = strtok(buf, "=");
			n = _p[strlen(_p)-1] - '0' - 1;
			_p = strtok(NULL, "=");
			ngram_num[n] = atoi(_p);
		}
	}
}

/* read total info and check it with LR data (RL) */
void CJuliGramNgram::SetAndCheckTotalInfo(CJuliFile &fp) // set_and_check_total_info
{
	char *_p;
	int n;

	while (fp.GetLine(buf, sizeof(buf)) != NULL && buf[0] != '\\') {
		if (strnmatch(buf, "ngram", 5)) { /* n-gram num */
			_p = strtok(buf, "=");
			n = _p[strlen(_p)-1] - '0' - 1;
			_p = strtok(NULL, "=");
			/* 
			*	 if (n <= 2 && this->ngram_num[n] != atoi(_p)) {
			*	   j_printerr("LR and RL don't match at ngram_num!\n");
			*	   J_ERROR("cut-off value when building LM differ?\n");
			*	 }
			*/
			if (n == 2) {		/* 3-gram */
				ngram_num[n] = atoi(_p);
			} else {
				if (n <= 1 && ngram_num[n] != atoi(_p)) {
					J_WARNING("Warning: %d-gram total num differ! may cause read error\n",n+1);
				}
			}
		}
	}
}

/* read in 1-gram (LR)*/
void CJuliGramNgram::SetUnigram(CJuliFile &fp) // set_unigram
{
	WORD_ID read_word_num;	/* # of words already read */
	WORD_ID nid, resid;
	LOGPROB prob, bo_wt;
	char *name, *_p;

	/* malloc area */
	this->wname = (char **)J_MALLOC(sizeof(char *)*this->ngram_num[0]);
	this->p = (LOGPROB *)J_MALLOC(sizeof(LOGPROB)*this->ngram_num[0]);
	this->bo_wt_lr = (LOGPROB *)J_MALLOC(sizeof(LOGPROB)*this->ngram_num[0]);
	this->bo_wt_rl = (LOGPROB *)J_MALLOC(sizeof(LOGPROB)*this->ngram_num[0]);
	this->n2_bgn = (NNID *)J_MALLOC(sizeof(NNID)*this->ngram_num[0]);
	this->n2_num = (WORD_ID *)J_MALLOC(sizeof(WORD_ID)*this->ngram_num[0]);
	read_word_num = 0;

	while (fp.GetLine(buf, sizeof(buf)) != NULL && buf[0] != '\\') {
		prob = atof(fp.GetFirstToken(buf));
		_p = fp.GetNextToken();
		name = strcpy((char *)J_MALLOC(strlen(_p)+1), _p);
		bo_wt = atof(fp.GetNextToken());

		/* register unigram */
		nid = read_word_num;
		this->wname[nid] = name;
		/* add entry name to index tree */
		if (this->root == NULL) {
			this->root = CJuliPatriciaTree<int>::MakeRootNode(nid);
		} else {
			resid = CJuliPatriciaTree<int>::Search(name, this->root);
			if (strmatch(name, this->wname[resid])) { /* already exist */
				J_ERROR("Error: word \"%s\" multiply defined at (#%d and #%d)\n",
					name, resid, nid);
			} else {
				CJuliPatriciaTree<int>::AddEntry(name, nid, this->wname[resid], &(this->root));
			}
		}
		this->p[nid] = prob;
		this->bo_wt_lr[nid] = bo_wt;
		this->n2_bgn[nid] = NNID_INVALID;
		this->n2_num[nid] = 0;

		read_word_num++;
		if (read_word_num > this->max_word_num) {
			J_ERROR("Error: actual n-gram word num exceeded header value\n");
			J_ERROR("%d > %d\n", read_word_num, this->max_word_num);
		}
	}

	if (read_word_num != this->ngram_num[0]) {
		J_ERROR("Error: actual n-gram word num not match the header value\n");
		J_ERROR("%d != %d ?\n", read_word_num, this->ngram_num[0]);
	}
	J_MESSAGE("  1-gram read %d end\n", read_word_num);
}

/* read-in 1-gram (RL) --- only add back-off weight */
void CJuliGramNgram::AddUnigram(CJuliFile &fp) // add_unigram
{
	WORD_ID read_word_num;
	WORD_ID nid;
	LOGPROB prob, bo_wt;
	char *name, *_p;

	read_word_num = 0;
	while (fp.GetLine(buf, sizeof(buf)) != NULL && buf[0] != '\\') {
		prob = atof(fp.GetFirstToken(buf));
		_p = fp.GetNextToken();
		name = strcpy((char *)J_MALLOC(strlen(_p)+1), _p);
		bo_wt = atof(fp.GetNextToken());

		/* add bo_wt_rl to existing 1-gram entry */
		nid = LkupWord(name);
		if (nid == WORD_INVALID) {
			J_WARNING("Warning: n-gram word \"%s\" in RL not exist in LR (ignored)\n", name);
		} else {
			this->bo_wt_rl[nid] = bo_wt;
		}

		read_word_num++;
		if (read_word_num > this->max_word_num) {
			J_ERROR("Error: actual n-gram word num exceeded header value\n");
			J_ERROR("%d > %d\n", read_word_num, this->max_word_num);
		}
		free(name);
	}
	J_MESSAGE("  1-gram read %d end\n", read_word_num);

}

/* read in 2-gram (LR) */
void CJuliGramNgram::SetBigram(CJuliFile &fp) // set_bigram
{
	int w_l, w_r;
	int w_last, w_r_last;
	LOGPROB _p;
	NNID n2;

	this->n2tonid = (WORD_ID *)J_MALLOC(sizeof(WORD_ID)*this->ngram_num[1]);
	this->p_lr = (LOGPROB *)J_MALLOC(sizeof(LOGPROB)*this->ngram_num[1]);
	this->p_rl = (LOGPROB *)J_MALLOC(sizeof(LOGPROB)*this->ngram_num[1]);
	this->bo_wt_rrl = (LOGPROB *)J_MALLOC(sizeof(LOGPROB)*this->ngram_num[1]);
	this->n3_bgn = (NNID *)J_MALLOC(sizeof(NNID)*this->ngram_num[1]);
	this->n3_num = (WORD_ID *)J_MALLOC(sizeof(WORD_ID)*this->ngram_num[1]);
	n2 = 0;

	/* read in LR 2-gram */
	w_last = -1; w_r_last = -1;
	for (;;) {
		if (fp.GetLine(buf, sizeof(buf)) == NULL || buf[0] == '\\') break;
		strcpy(pbuf, buf);
		if ( n2 % 100000 == 0) {
			J_MESSAGE("  2-gram read %d (%d%%)\n", n2, n2 * 100 / this->ngram_num[1]);
		}

		/* 2-gram probability */
		_p = atof(fp.GetFirstToken(buf));
		/* read in left (context) word and lookup the ID */
		w_l = LkupWord(fp.GetNextToken());
		/* increment n2_bgn and n2_num if context word changed */
		if (w_l != w_last) {
			if (w_last != -1) this->n2_num[w_last] = n2 - this->n2_bgn[w_last];
			/* the next context word should be an new entry */
			if (this->n2_bgn[w_l] != NNID_INVALID) {
				J_ERROR("Error: entry not sorted (same left context not sequenced)\n");
				J_ERROR("at 2-gram #%d: \"%s\"\n", n2+1, pbuf);
			}
			this->n2_bgn[w_l] = n2;
			w_r_last = -1;
		}
		/* read in right word and set */
		w_r = LkupWord(fp.GetNextToken());
		if (w_r == w_r_last) {
			J_ERROR("Error: duplicated entry\n");
			J_ERROR("at 2-gram #%d: \"%s\"\n", n2+1, pbuf);
		} else if (w_r < w_r_last) {
			J_ERROR("Error: entry not sorted downward\n");
			J_ERROR("at 2-gram #%d: \"%s\"\n", n2+1, pbuf);
		}
		this->n2tonid[n2] = w_r;
		this->p_lr[n2] = _p;
		this->n3_bgn[n2] = NNID_INVALID;
		this->n3_num[n2] = 0;

		n2++;
		w_last = w_l;
		w_r_last = w_r;

		/* check total num */
		if (n2 > this->ngram_num[1]) {
			J_ERROR("Error: actual 2-gram num not match the header value\n");
			J_ERROR("%d != %d ?\n", n2, this->ngram_num[1]);
		}
	}

	/* set the last entry */
	this->n2_num[w_last] = n2 - this->n2_bgn[w_last];

	J_MESSAGE("  2-gram read %d end\n", n2);

}

/* add RL 2-gram info to existing LR 2-gram data (RL) */
void CJuliGramNgram::AddBigramRL(CJuliFile &fp) // add_bigram_rl
{
	WORD_ID w_l, w_r;
	LOGPROB prob, bo_wt;
	int bi_count = 0;
	NNID n2;

	while (fp.GetLine(buf, sizeof(buf)) != NULL && buf[0] != '\\') {
		/* _p(w_l|w_r) w_r w_l bo_wt_rl */
		if ( ++bi_count % 100000 == 0) {
			J_MESSAGE("  2-gram read %d (%d%%)\n", bi_count, bi_count * 100 / this->ngram_num[1]);
		}
		prob = atof(fp.GetFirstToken(buf));
		w_r = LkupWord(fp.GetNextToken());
		w_l = LkupWord(fp.GetNextToken());
		bo_wt = atof(fp.GetNextToken());
		n2 = SearchBigram(w_l, w_r);
		if (n2 == NNID_INVALID) {
			J_WARNING("Warning: (%s,%s) not exist in LR 2-gram (ignored)\n",
				this->wname[w_l], this->wname[w_r]);
		} else {
			this->p_rl[n2] = prob;
			this->bo_wt_rrl[n2] = bo_wt;
		}
	}
	J_MESSAGE("  2-gram read %d end\n", bi_count);

}


/* read in RL 3-gram (RL) */
void CJuliGramNgram::SetTrigram(CJuliFile &fp) // set_trigram
{
	int w_l, w_m, w_r;
	LOGPROB p_rl;
	int w_r_last, w_m_last, w_l_last;
	NNID n2, n2_last;
	NNID n3;

	this->n3tonid = (WORD_ID *)J_MALLOC(sizeof(WORD_ID)*this->ngram_num[2]);
	this->p_rrl = (LOGPROB *)J_MALLOC(sizeof(LOGPROB)*this->ngram_num[2]);
	n3 = 0;

	n2 = n2_last = NNID_INVALID;
	w_r_last = w_m_last = w_l_last = -1;
	for (;;) {

		if (fp.GetLine(buf, sizeof(buf)) == NULL || buf[0] == '\\') break;
		strcpy(pbuf, buf);
		if (n3 % 100000 == 0) {
			J_MESSAGE("  3-gram read %d (%d%%)\n", n3, n3 * 100 / this->ngram_num[2]);
		}

		/* N-gram probability */
		p_rl = atof(fp.GetFirstToken(buf));
		/* read in right (first) word and lookup its ID */
		w_r = LkupWord(fp.GetNextToken());
		/* read in middle word and lookup its ID */
		w_m = LkupWord(fp.GetNextToken());

		/* if context changed, create the next structure */
		if (w_r != w_r_last || w_m != w_m_last) {
			n2 = SearchBigram(w_m, w_r);
			if (n2 == NNID_INVALID) {	/* no context */
				J_WARNING("Warning: context (%s,%s) not exist in LR 2-gram (ignored)\n",
					this->wname[w_m], this->wname[w_r]);
				continue;
			}
			if (n2_last != NNID_INVALID) this->n3_num[n2_last] = n3 - this->n3_bgn[n2_last];
			/* check: the next 'n2' should be an new entry */
			if (this->n3_bgn[n2] != NNID_INVALID) {
				J_ERROR("Error: entry not sorted (same left context not sequenced)\n");
				J_ERROR("at 3-gram #%d: \"%s\"\n", n3+1, pbuf);
			}
			this->n3_bgn[n2] = n3;
			n2_last = n2;
			w_l_last = -1;
		} else {
			if (n2 == NNID_INVALID) continue;
		}

		/* read in left (last) word and store */
		w_l = LkupWord(fp.GetNextToken());
		if (w_l == w_l_last) {
			J_ERROR("Error: duplicated entry\n");
			J_ERROR("at 3-gram #%d: \"%s\"\n", n3+1, pbuf);
		} else if (w_l < w_l_last) {
			J_ERROR("Error: entry not sorted downward\n");
			J_ERROR("at 3-gram #%d: \"%s\"\n", n3+1, pbuf);
		}
		this->n3tonid[n3] = w_l;
		this->p_rrl[n3] = p_rl;

		n3++;
		w_m_last = w_m;
		w_r_last = w_r;
		w_l_last = w_l;

		/* check the 3-gram num */
		if (n3 > this->ngram_num[2]) {
			J_ERROR("Error: actual 3-gram num not match the header value\n");
			J_ERROR("%d != %d ?\n", n3, this->ngram_num[2]);
		}
	}

	/* store the last n3_num */
	this->n3_num[n2_last] = n3 - this->n3_bgn[n2_last];

	J_MESSAGE("  3-gram read %d end\n", n3);
}


/* read in N-gram data from fp to this */
boolean				/* return value :TRUE on success */
CJuliGramNgram::NgramReadArpa(CJuliFile &fp, int direction) // ngram_read_arpa
{
	int n;

	this->from_bin = FALSE;

	if (!LR_2gram_read && direction == DIR_RL) {
		J_ERROR("you should first read LR 2-gram\n");
		return FALSE;
	}


	if (direction == DIR_LR) {
		n = 2;
	} else {
		n = 3;
	}

	/* read until `\data\' found */
	while (fp.GetLine(buf, sizeof(buf)) != NULL && strncmp(buf,"\\data\\",6) != 0);

	/* read n-gram total info */
	if (direction == DIR_LR) {
		SetTotalInfo(fp);
	} else {
		SetAndCheckTotalInfo(fp);
	}
	if (this->ngram_num[0] > MAX_WORD_NUM) {
		J_ERROR("Error: vocabulary size exceeded limit (%d)\n", MAX_WORD_NUM);
	}
	this->max_word_num = this->ngram_num[0];

	/* read 1-gram data */
	if (!strnmatch(buf,"\\1-grams",8)) {
		J_ERROR("data format error: 1-gram not found\n");
	}
	J_MESSAGE("  reading 1-gram part...\n");
	if (direction == DIR_LR) {
		SetUnigram(fp);
	} else {
		AddUnigram(fp);
	}

	if (n >= 2) {
		/* read 2-gram data */
		if (!strnmatch(buf,"\\2-grams", 8)) {
			J_ERROR("data format error: 2-gram not found\n");
		}
		J_MESSAGE("  reading 2-gram part...\n");
		if (direction == DIR_LR) {
			SetBigram(fp);
		} else {
			AddBigramRL(fp);
		}
	}

	if (n >= 3) {
		/* read 3-gram data */
		if (!strnmatch(buf,"\\3-grams", 8)) {
			J_ERROR("data format error: 3-gram not found\n");
		}
		if ( direction == DIR_LR) {
			J_ERROR("should not happen..\n");
		} else {
			J_MESSAGE("  reading 3-gram part...\n");
			SetTrigram(fp);
		}
	}

	/* finished */

	/* set unknown (=OOV) word id */
	SetUnknownID();

	if (direction == DIR_LR) {
		LR_2gram_read = TRUE;
	}

	return TRUE;
}
