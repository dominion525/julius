//====================================================================
// JuliBeamSearch.h: 
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIBEAMSEARCH_H__4F825661_8746_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIBEAMSEARCH_H__4F825661_8746_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDefines.h"
#include "JuliContextObject.h"
#include "JuliTrellisAtom.h"
#include "JuliHtkParam.h"
#include "JuliWordConjHmm.h"

typedef int TOKENID;
#define TOKENID_UNDEFINED -1


typedef struct
{
	CJuliTrellisAtom *last_tre;	/* ���O�̃g�����X�P�� */
#ifdef USE_NGRAM
	WORD_ID last_cword;		/* �Ō�� context aware �ȒP�� */
	LOGPROB last_lscore;		/* ���݊��蓖�Ă��Ă��� LM score */
#endif
	LOGPROB score;		/* ���X�R�A */
	int node;			/* ���蓖�Ă��Ă���؍\���������̃m�[�h�ԍ� */
#ifdef WPAIR
	TOKENID next;			/* �����m�[�h�̑��̃g�[�N���ւ̃|�C���^ */
#endif
} TOKEN2;

//#define FILLWIDTH 70		/* �܂�Ԃ��� for -progout*/

class CJuliBeamSearch : public CJuliContextObject
{
public:
	CJuliBeamSearch();
	virtual ~CJuliBeamSearch();
	
	/* �ŏ��̃t���[�� */
	void GetBackTrellisInit(CJuliHtkParam *param);	// (get_back_trellis_init)
	boolean GetBackTrellisProceed(int t,CJuliHtkParam *param);	// (get_back_trellis_proceed)
	/* �Ō�̃t���[���I����̌㏈�� */
	void GetBackTrellisEnd(CJuliHtkParam *param);	// (get_back_trellis_end)
	LOGPROB Finalize1stPass(int len);	// (finalize_1st_pass)
#ifdef SP_BREAK_CURRENT_FRAME
	void FinalizeSegment(CJuliHtkParam *param, int len);	// (finalize_segment)
#endif
	void GetBackTrellisMain(CJuliHtkParam *param,LOGPROB *backmax);	// (get_back_trellis)
	
private:
	void BtCurrentMaxWord(int t);	// bt_current_max_word
	void BtCurrentMax(int t); // bt_current_max
	LOGPROB Print1PassResult(int framelen		/* length of above */); // print_1pass_result
	LOGPROB TraceBackPtr(WORD_ID wordseq_rt[MAXSEQNUM], /* return */
			  int *rt_wordlen,
			  CJuliTrellisAtom *atom /* start BACKTRELLIS atom */
			  );	/* backward trellis (return value) */ // trace_backptr
	void PutAtom(CJuliTrellisAtom *atom); // put_atom
	void GenerateLattice(int endtime, WORD_ID wid); // generate_lattice

	void MallocNodes();	// (malloc_nodes)
	void ExpandTList();	// (expand_tlist)
	void FreeNodes();	// (free_nodes)
	void ClearTList(int tt);	// (clear_tlist) reset token buffer
	void ClearTokens(int tt);	// (clear_tokens) clear node-token for viterbi
	TOKENID CreateToken();	// (create_token)
	void NodeAssignToken(int node, TOKENID tkid);	// (node_assign_token)
	TOKENID NodeExistToken(int tt, int node, WORD_ID wid);	// (node_exist_token)
	
	void SortTokenUpward(int neednum, int totalnum);	// (sort_token_upward) 
	void SortTokenDownward(int neednum, int totalnum);	// (sort_token_downward)
	void SortTokenNoOrder(int neednum, int *start, int *end);	// (sort_token_no_order)
	
	void InitNodeScore(CJuliHtkParam *param);	// (init_nodescore)

	/* tlist[] ��token�{�̂��z��Ƃ��Ċm�ۂ��Ă��� */
	/*         �K�v�ɉ�����1�Âg���D�z��ԍ��ŃA�N�Z�X */
	/* token[] �̓m�[�h�ɑ΂���tlist���token�ւ̃|�C���^(�z��ԍ�) */
	TOKEN2 *	tlist[2];	/* sequencial list of all tokens */
	TOKENID *	tindex[2];	/* index for sort */
	int			tnum[2];		/* number of tokens used in tlist */
	int			maxtnum;		/* maximum number of tokens */
	TOKENID *	token;		/* sequencial list per tree node */
	int			totalnodenum;	/* allocated node num of above */
	int			tl,tn;		/* node id flip/flop */
	int			n_start, n_end;
	CJuliTrellisAtom bos;	/* trellis temporary buffer */
	
#ifdef SP_BREAK_CURRENT_FRAME
	boolean		in_sparea;	/* within a pause area */
	int			sparea_start;	/* start frame of pause area */
	int			tmp_sparea_start;
# ifdef SP_BREAK_RESUME_WORD_BEGIN
	WORD_ID		tmp_sp_break_last_word;
# else
	WORD_ID		last_tre_word;
# endif
	boolean		first_sparea;	/* TRUE if this is the first pause segment in a input stream */
	int			sp_duration;		/* number of sp frame to be durated */
	
	boolean DetectEndOfSegment(int time);	// (detect_end_of_segment)
#endif
	
	boolean		idc_on;
#ifdef FANCY_INDICATOR
	int			idc_interval;
	char *		idc_p;
	int			idc_count;
#endif
	int			progout_interval_frame;

	WORD_ID		wordseq_TraceBackPtr[MAXSEQNUM];	/* in reversed order */
	WORD_ID		wordseq_BtCurrentMax[MAXSEQNUM];

	int glevel;		/* generate_lattice�̌Ăяo���̐[�� */
	int gnodes;		/* node�̐� */
	int garcs;		/* arc(=�P��)�̐� */
};

#endif // !defined(AFX_JULIBEAMSEARCH_H__4F825661_8746_11D5_9AFA_008098E80572__INCLUDED_)
