// JuliHtkHmmSegment.h: CJuliHtkHmmSegment �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JULIHTKHMMSEGMENT_H__C2F03B2D_7AC4_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIHTKHMMSEGMENT_H__C2F03B2D_7AC4_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <string>
#include <list>
using namespace std;

#include "JuliFile.h"
#include "JuliPatriciaTree.h"

template <class T> class CJuliHtkHmmSegmentDatabase
{
public:
	CJuliHtkHmmSegmentDatabase() { m_ptreeNameNode = NULL;}
	~CJuliHtkHmmSegmentDatabase() {
		list<T *>::iterator i;
		for (i=m_listPointer.begin();i!=m_listPointer.end();i++)
			delete (*i);
		CJuliPatriciaTree<T *>::Clean(&m_ptreeNameNode);
	}

	int Add(T * segm);		// (***_add) ���̂�ǉ�����
	int AddTree(T * segm);	// ���̂�؂ɒǉ�����
	void InsertHead(T *a) { m_listPointer.push_front(a);} // ���̂����X�g�̐擪�ɒǉ�����
	const T * Lookup (const char *name) const;	// (***_lookup) ���̖̂��O������̂�����
	T * Lookup (const char *name);	// (***_lookup) ���̖̂��O������̂�����
	const list<T *> & GetList() const { return m_listPointer; }
	list<T *> & GetList() { return m_listPointer; }
	T * Search(const char *name);
	int IsEmpty() { return (m_ptreeNameNode == NULL); }

	void SetRoot(CJuliPatriciaTreeNode<T *> *p) { m_ptreeNameNode = p; }
	CJuliPatriciaTreeNode<T *> *GetRoot() { return m_ptreeNameNode; }
	CJuliPatriciaTreeNode<T *> **GetRootP() { return &m_ptreeNameNode; }
private:
	list<T *> m_listPointer;			// ���̂̃|�C���^�̃��X�g
	CJuliPatriciaTreeNode<T *> * m_ptreeNameNode;	// ���̖̂��O������̂��������߂̃c���[
};

template <class T>
T * CJuliHtkHmmSegmentDatabase<T>::Search(const char *name)
{
	return CJuliPatriciaTree<T *>::Search(name,m_ptreeNameNode);
}

template <class T>
int CJuliHtkHmmSegmentDatabase<T>::Add(T * segm)
{
	InsertHead(segm);
	if (segm->GetName()[0] != NULL)
	{
		if (AddTree(segm))
		{
			J_ERROR("Error: \"%s\" is already defined\n", segm->GetName());
			return 1;
		}
	}
	return 0;
}

template <class T>
int CJuliHtkHmmSegmentDatabase<T>::AddTree(T * segm)
{
	// ���O���c���[�ɓo�^
	if (m_ptreeNameNode == NULL)
	{
		m_ptreeNameNode = CJuliPatriciaTree<T *>::MakeRootNode(segm);
	} else {
		T * match = CJuliPatriciaTree<T *>::Search(segm->GetName(),m_ptreeNameNode);
		if (strmatch(match->GetName(), segm->GetName()))
			return 1;
		CJuliPatriciaTree<T *>::AddEntry(segm->GetName(), segm, match->GetName(),&m_ptreeNameNode);
	}
	return 0;
}

template <class T>
const T * CJuliHtkHmmSegmentDatabase<T>::Lookup(const char *name) const
{
	const T *s;
	s = CJuliPatriciaTree<T *>::Search(name,m_ptreeNameNode);
	if (strmatch(s->GetName(), name))
	{
		return s;
	} else {
		return NULL;
	}
}

template <class T>
T * CJuliHtkHmmSegmentDatabase<T>::Lookup(const char *name)
{
	T *s;
	s = CJuliPatriciaTree<T *>::Search(name,m_ptreeNameNode);
	if (strmatch(s->GetName(), name))
	{
		return s;
	} else {
		return NULL;
	}
}

class CJuliHmmInfo;

class CJuliHtkHmmSegment  
{
public:
	CJuliHtkHmmSegment();
	virtual ~CJuliHtkHmmSegment();

	virtual void ReadFromFile(CJuliFile &file,CJuliHmmInfo &info);

	void SetName(const char *name) { m_strName = name; }
	const char * GetName() const { return m_strName.c_str(); }
private:
	string		m_strName;				/* macro name */

};

#endif // !defined(AFX_JULIHTKHMMSEGMENT_H__C2F03B2D_7AC4_11D5_9AFA_008098E80572__INCLUDED_)
