//====================================================================
// JuliFile.h: ZLIB�Ή��t�@�C���N���X
//--------------------------------------------------------------------
// Copyright (c) 1991-2000 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIFILE_H__71BEDA28_624B_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIFILE_H__71BEDA28_624B_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <stdio.h>
// ZLIB �K�{
#include "../zlib-1.1.4/zlib.h"

class CJuliFile  
{
public:
	CJuliFile() : fp(NULL), gp(NULL), m_buf(NULL) , rdhmmdef_token(NULL) {}
	~CJuliFile();

	int OpenRead(const char *filename);				// (fopen_readfile)
	int CloseRead();								// (fclose_readfile)
	size_t Read(void *ptr, size_t size, size_t n);	// (myfread)

	int OpenWrite(const char *filename);			// (fopen_writefile)
	int CloseWrite();								// (fclose_writefile)
	size_t Write(void *ptr, size_t size, size_t n);	// (myfwrite)

	char * GetLine(char *buf, int maxlen);	// (getl) from readfile.c
	char * GetFirstToken(char *buf);		// (first_token) from readfile.c
	char * GetNextToken();					// (next_token) from readfile.c
	char * GetNextTokenIfAny();				// (next_token_if_any) from readfile.c
	char * GetRestToken();					// (rest_token) from readfile.c

	char * Strtok_quote(char *str);	// mystrtok_quote
	// for hmm
	void NoTokenError(const char *str);
	int CurrentTokenIs(const char *str);
	void HmmError(const char *str);	// (rderr)
	char * CurrentToken();	// (rdhmm_token)
	char * GetHmmToken();
	int line;
	char *m_buf;
	char *rdhmmdef_token;	// (rdhmm_token)

private:
	FILE *fp;
	gzFile gp;

	char *buf;		/* target string buffer */
	char *pos;		/* current pointer position */
};

#endif // !defined(AFX_JULIFILE_H__71BEDA28_624B_11D5_9AFA_008098E80572__INCLUDED_)
