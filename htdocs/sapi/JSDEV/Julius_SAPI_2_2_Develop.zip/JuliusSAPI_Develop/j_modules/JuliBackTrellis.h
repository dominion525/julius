//====================================================================
// JuliBackTrellis.h: 
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIBACKTRELLIS_H__FD73AAC1_81D9_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIBACKTRELLIS_H__FD73AAC1_81D9_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliContextObject.h"
#include "JuliTrellisAtom.h"
#include "JuliHmmInfo.h"
#include "JuliWordConjHmm.h"

class CJuliBackTrellis : public CJuliContextObject
{
public:
	CJuliBackTrellis();
	virtual ~CJuliBackTrellis();
	
	void Prepare();	// (bt_prepare)
	void Store(CJuliTrellisAtom *tatom);	// (bt_store)
	void Relocate();	// (bt_relocate_rw)
	void SetTerminalWords();	// (set_terminal_words)
	void DiscountPEScore(CJuliHtkParam *param, CJuliWordConjHMM &wchmm);	// (bt_discount_pescore)
	void Sort();	// (bt_sort_rw)
	CJuliTrellisAtom * BinsearchAtom(int t, WORD_ID wkey);	// (bt_binsearch_atom)
	
	void SetFrameLen(int l) { framelen = l; }
	int GetFrameLen() const { return framelen; }
	int GetNum(int i) const { return num[i]; }
	CJuliTrellisAtom * GetRW(int i, int j) { return rw[i][j]; }
	CJuliTrellisAtom * GetList() { return list; }
private:
	int framelen;			/* ���t���[����(��peseqlen�ɓ���) */
	int *num;				/* �t���[�����Ƃ̊i�[�� */
	CJuliTrellisAtom ***rw;		/* �t���[�����ƂɃr�[�����Ɏc�����P���� */
	CJuliTrellisAtom *list;		/* �ꎞ�I��TRELLIS���i�[���Ă��� */
};

#endif // !defined(AFX_JULIBACKTRELLIS_H__FD73AAC1_81D9_11D5_9AFA_008098E80572__INCLUDED_)
