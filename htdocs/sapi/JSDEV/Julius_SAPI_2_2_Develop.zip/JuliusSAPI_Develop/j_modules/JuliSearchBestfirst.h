// JuliSearchBestfirst.h: CJuliSearchBestfirst �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JULISEARCHBESTFIRST_H__257E87BC_E93A_47D3_88D8_CAF54B2310BF__INCLUDED_)
#define AFX_JULISEARCHBESTFIRST_H__257E87BC_E93A_47D3_88D8_CAF54B2310BF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDefines.h"
#include "JuliContextObject.h"
#include "JuliDecode.h"

class CJuliHtkParam;
class CJuliHMM;

class CJuliSearchBestfirst : public CJuliContextObject
{
public:
	CJuliSearchBestfirst();
	virtual ~CJuliSearchBestfirst();
	
	/* �T�����s���C���֐� */
	void Start(CJuliHtkParam *param, LOGPROB backmax, int stacksize, int ncan, int maxhypo); // wchmm_fbs
	
private:
	/* ���P��i�[�̈�̊��蓖�� */
	NEXTWORD **NwMalloc(int *maxlen, NEXTWORD **root); // nw_malloc
	void NwFree(NEXTWORD **nw, NEXTWORD *root); // nw_free
#ifdef USE_DFA
	NEXTWORD ** NwExpand(NEXTWORD **nwold, int *maxlen, NEXTWORD **root); // nw_expand
#endif
	
	/* �������X�^�b�N���� */
	NODE *GetBestFromStack(NODE **start, int *stacknum); // get_best_from_stack
	int PutToStack(NODE *_new, NODE **start, NODE **bottom, int *stacknum, int stacksize); // put_to_stack
	void PutAllInStack(NODE **start, int *stacknum); // put_all_in_stack
	void FreeAllNodes(NODE *node); // free_all_nodes
	
	/* enveloped best-first */
	int hypo_len_count[MAXSEQNUM+1];
	void WbInit(); // wb_init
	boolean WbOk(NODE *now); // wb_ok
	
	/* score-based envelope */
#ifdef SCAN_BEAM
public:
	void EnvlInit(int framenum); // envl_init
private:
	void EnvlUpdate(NODE *n, int framenum); // envl_update
#endif /* SCAN_BEAM */
	
#ifdef USE_DFA
	NEXTWORD fornoise;		/* noise dummy */
#endif
	
	/* sp segment restart */
#ifdef SP_BREAK_CURRENT_FRAME
	void SpSegmentSetLastNword(NODE *hypo); // sp_segment_set_last_nword
#endif
	/* �������̏o�͊֐� */
	CJuliHtkParam *tparam;	/* for "-walign" and "-palign" option */
	void PutHypoOutput(NODE *hypo); // put_hypo_woutput
	void PutHypoWordName(NODE *hypo); // put_hypo_wname
	void PutHypoPhoneme(NODE *hypo); // put_hypo_phoneme
	void ReorderAndOutputResult(NODE **r_start, NODE **r_bottom, int *r_stacknum, int ncan); // result_reorder_and_output
	
	
	/* �����m�[�h�̊�{���� */
	void FreeNode(NODE *node); // free_node
	NODE * CopyNode(NODE *dst, NODE *src); // cpy_node
	NODE * NewNode(); // newnode
	/* �O�����ޓx�v�Z�p�G���A */
	LOGPROB **wordtrellis;
	LOGPROB *g;
	const CJuliHtkHmmLogical **phmmseq;
	int phmmlen_max;
	
	void MallocWordTrellis(); // malloc_wordtrellis
	void FreeWordTrellis(); // free_wordtrellis
	
	/* �����̖ޓx�v�Z */
	void ScanWord(NODE *now, CJuliHtkParam *param); // scan_word
	void NextWord(NODE *now, NODE *_new,	NEXTWORD *nword, CJuliHtkParam *param); // next_word
	/* ���������𐶐� --- �T���̍ŏ��ɂ̂݌Ă΂�� */
	void StartWord(NODE *_new, NEXTWORD *nword, CJuliHtkParam *param); // start_word
	void CJuliSearchBestfirst::LastNextWord(NODE *now, NODE *_new, CJuliHtkParam *param); // last_next_word
	
private:
	int OutputResult(NODE *node, int rank);
	void WordAlign(WORD_ID *words, short wnum, CJuliHtkParam *param, ALIGNRESULT *ar); // word_align
	void WordAlign_Rev(WORD_ID *revwords, short wnum, CJuliHtkParam *param, ALIGNRESULT *ar); // word_rev_align
	void PhonemeAlign(WORD_ID *words, short wnum, CJuliHtkParam *param, ALIGNRESULT *ar); // phoneme_align
	void PhonemeAlign_Rev(WORD_ID *revwords, short wnum, CJuliHtkParam *param, ALIGNRESULT *ar); // phoneme_rev_align
	
private:
	const CJuliHtkHmmLogical ** MakePhSeq(WORD_ID *wseq, short num, int *num_ret, int **end_ret, boolean per_phoneme); // make_phseq
	void DoAlign(WORD_ID *words, short wnum, CJuliHtkParam *param, boolean per_phoneme, ALIGNRESULT *ar); // do_align
	LOGPROB ViterbiSegment(CJuliHMM *hmm, CJuliHtkParam *param,	int *endstates,	int ulen, int *seg_ret,	LOGPROB *uscore_ret); // viterbi_segment
};

#endif // !defined(AFX_JULISEARCHBESTFIRST_H__257E87BC_E93A_47D3_88D8_CAF54B2310BF__INCLUDED_)
