//====================================================================
// JuliHtkHmmData.cpp: Htk HMM: Physical Data �I�u�W�F�N�g (HTK_HMM_Data)
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliHmmInfo.h"

CJuliHtkHmmData::CJuliHtkHmmData()
{
	m_siStateNum = 0;
	m_states = NULL;
	m_trans = NULL;
}

CJuliHtkHmmData::~CJuliHtkHmmData()
{
	// ReadFromFile �Ŋm�ۂ����|�C���^�̔z����J��
	if (m_states != NULL)
	{
		delete m_states;
	}
	// ��: m_states[0], m_trans ���͉�����Ȃ�
}

void CJuliHtkHmmData::ReadFromFile(CJuliFile &file,CJuliHmmInfo &info)
{
	int i;
	short sid;
	/* begin tag */
	if (!file.CurrentTokenIs("BEGINHMM")) file.HmmError("<BEGINHMM> not found");
	file.GetHmmToken();
	/* read global opt if any */
	/* read_global_opt(fp, &(opt)); */
	/* num of state */
	if (!file.CurrentTokenIs("NUMSTATES")) file.HmmError("<NUMSTATES> not found");
	file.GetHmmToken();
	file.NoTokenError("state num not found\n");
	m_siStateNum = atoi(file.CurrentToken());
	file.GetHmmToken();
	/* malloc */
	m_states = new CJuliHtkHmmState * [m_siStateNum];
	for(i=0;i<m_siStateNum;i++) {
		m_states[i] = NULL;
	}
	/* read/set each state info */
	for (;;) {
		if (!file.CurrentTokenIs("STATE")) break;
		file.GetHmmToken(); file.NoTokenError("STATE id not found");
		sid = atoi(file.CurrentToken()) - 1;
		file.GetHmmToken();
		m_states[sid] = info.ReadStateSegment(file);	// new ���ꂽ���̂��Ԃ�
	}
	/* read/set transition info */
	m_trans = info.ReadTransSegment(file);	// new ���ꂽ���̂��Ԃ�
	if ((m_trans)->GetStateNum() != m_siStateNum) {
		file.HmmError("# of transition != # of state");
	}
	/* read/set duration */
	/* end tag */
	if (!file.CurrentTokenIs("ENDHMM")) file.HmmError("<ENDHMM> not found");
	file.GetHmmToken();
}
