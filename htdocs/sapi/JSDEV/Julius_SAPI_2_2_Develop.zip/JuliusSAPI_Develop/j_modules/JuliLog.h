//====================================================================
// JuliLog.h: �G���[���O�Ǘ��N���X(���C�u����)
//--------------------------------------------------------------------
// Copyright (c) 1991-2000 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULILOG_H__71BEDA23_624B_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULILOG_H__71BEDA23_624B_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <wchar.h>
#include <stdarg.h>

//#include <iostream>
//using namespace std;

enum { LOG_OUTPUT = 1, LOG_ERROR = 2, LOG_WARNING = 4 };

class CJuliLog
{
public:
	CJuliLog()
		: LogHandler(NULL)
//		: m_bFileOpened(0)
	{}
//	int OpenFile(const char *filename);

	void SetLogHandler(int (*lhandle)(const char *str, void *p, int opt), void *param=NULL)
	{
		LogHandler = lhandle;
		m_pHandlerParam = param;
	}
	int Output(const char *fmt,...);
	int Warning(const char *fmt,...);
	int Message(const char *fmt,...);
	int Error(const char *fmt,...);
	int Debug(const char *fmt,...);
	int Vermes(const char *fmt,...);
	int MessageW(const wchar_t *fmt,...);

private:
	int (*LogHandler)(const char *str, void *p, int opt);
	void * m_pHandlerParam;
//	int		m_bFileOpened;
//	FILE *	fplog;
};

extern CJuliLog theJuliLog;

#endif // !defined(AFX_JULILOG_H__71BEDA23_624B_11D5_9AFA_008098E80572__INCLUDED_)
