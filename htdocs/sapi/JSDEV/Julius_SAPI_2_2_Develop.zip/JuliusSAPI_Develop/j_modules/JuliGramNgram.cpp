//====================================================================
// JuliGramNgram.cpp: Ngram ���@�Ǘ��N���X (NGRAM_INFO)
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliGramNgram.h"
#include "JuliUtil.h"
#include "JuliFile.h"
#include <math.h>

// ngram2.h   NGRAM_INFO

/* MACROs */
#define UTT_END 3		/* ���̏I��(��؂�)�L��(�u�B�v) */
#define UNK 0			/* ���m�� */
#define LOGPROB_INVALID 1.0;	/* N-gram������Ȃ��ꍇ�̃G���[�l */
/* logprob = log10(prob) <= 0 */
/*#define FLOOR 0.00003*/ /* flooring�̂������l(1/(��b���{���肷�関�m�ꐔ)) */
#define LOGFLOOR -4.522879	/* FLOOR�̑ΐ��l */
#define BIGRAM_UNITSIZE 10	/* unit size of bigram malloc */
#define TRIGRAM_UNITSIZE 3	/* unit size of trigram malloc */

#define BINGRAM_IDSTR "julius_bingram_v3"
#define BINGRAM_HDSIZE 512

#ifdef UNIQUE_NGRAM
CJuliGramNgram * CJuliGramNgram::m_theInstance = NULL;

// ���̂��Ȃ��ꍇ�͍쐬������������
// ���̂�����ꍇ�͂��̃|�C���^��Ԃ�
void * CJuliGramNgram::operator new(size_t c)
{
	J_DEBUGMESSAGE("operator new (size=%d): ", c);
	if (m_theInstance == NULL)
	{
		J_DEBUGMESSAGE("Create Instance");
		m_theInstance = (CJuliGramNgram *) malloc(c);
		// �������������ł��(�R���X�g���N�^�ł��Ə㏑�����Ă��܂�)
		m_theInstance->root = NULL;
		m_theInstance->from_bin = FALSE;
		m_theInstance->LR_2gram_read = FALSE;
		m_theInstance->wname = NULL;
		m_theInstance->wname_buffer = NULL;
		m_theInstance->p = NULL;
		m_theInstance->bo_wt_lr = NULL;
		m_theInstance->bo_wt_rl = NULL;
		m_theInstance->n2_bgn = NULL;
		m_theInstance->n2_num = NULL;
		m_theInstance->n2tonid = NULL;
		m_theInstance->p_lr = NULL;
		m_theInstance->p_rl = NULL;
		m_theInstance->bo_wt_rrl = NULL;
		m_theInstance->n3_bgn = NULL;
		m_theInstance->n3_num = NULL;
		m_theInstance->n3tonid = NULL;
		m_theInstance->p_rrl = NULL;
		m_theInstance->m_bLoaded = FALSE;

	}
	J_DEBUGMESSAGE("[%p]\n", m_theInstance);
	return (void *)m_theInstance;
	// ���̂��ƂŃR���X�g���N�^���Ă΂��
}

void CJuliGramNgram::operator delete(void *o)
{
	// �����I�ɉ�����Ȃ�(1��������Ȃ�&�v���Z�X�I�����ɉ�������)
	return;
}
#endif

CJuliGramNgram::CJuliGramNgram()
#ifndef UNIQUE_NGRAM
// UNIQUE_NGRAM �w�莞�͏��������Ȃ�
: root(NULL),
from_bin(FALSE),
LR_2gram_read(FALSE),
wname(NULL),
wname_buffer(NULL),
p(NULL),
bo_wt_lr(NULL),
bo_wt_rl(NULL),
n2_bgn(NULL),
n2_num(NULL),
n2tonid(NULL),
p_lr(NULL),
p_rl(NULL),
bo_wt_rrl(NULL),
n3_bgn(NULL),
n3_num(NULL),
n3tonid(NULL),
p_rrl(NULL),
m_bLoaded(FALSE)
#endif
{
	//	J_DEBUGMESSAGE("Constructor is called[%p]\n",this);
}

CJuliGramNgram::~CJuliGramNgram()
{
	CJuliPatriciaTree<int>::Clean(&root);
	/* bin test only */
	/* free word names */
	if (from_bin) {
		J_FREE(wname[0]);	//or wname_buffer
		J_FREE(wname);
	} else {
		WORD_ID w;
		for(w=0;w<max_word_num;w++) {
			J_FREE(wname[w]);
		}
		J_FREE(wname);
	}

	J_FREE(p);
	J_FREE(bo_wt_lr);
	J_FREE(bo_wt_rl);
	J_FREE(n2_bgn);
	J_FREE(n2_num);
	J_FREE(n2tonid);
	J_FREE(p_lr);
	J_FREE(p_rl);
	J_FREE(bo_wt_rrl);
	J_FREE(n3_bgn);
	J_FREE(n3_num);
	J_FREE(n3tonid);
	J_FREE(p_rrl);
}

/* read & initialize n-gram data from binary */
int CJuliGramNgram::ReadFromFile_Binary(const char *bin_ngram_file)	// (init_ngram_bin)
{
	CJuliFile file;

	J_MESSAGE("Reading in word n-gram...");
	if (file.OpenRead(bin_ngram_file)) {
		J_ERROR("open error for %s\n", bin_ngram_file);
		return 1;
	}
	if (NgramReadBin(file) == FALSE) {
		J_ERROR("read error for %s\n", bin_ngram_file);
		return 1;
	}
	if (file.CloseRead() == -1) {
		J_ERROR("close error\n");
		return 1;
	}
	m_bLoaded = TRUE;
	J_MESSAGE("done\n");
	return 0;
}

/* for ARPA standard format with Back-off */
int CJuliGramNgram::ReadFromFile_Arpa(	// (init_ngram_arpa)
									  const char *ngram_lr_file, /* filename of LR 2-gram data */
									  const char *ngram_rl_file) /* filename of RL 3-gram data */
{
	CJuliFile file;
	root = NULL;
	J_MESSAGE("Reading in LR 2-gram...\n");
	/* read LR 2-gram */
	if (file.OpenRead(ngram_lr_file)) {
		J_ERROR("open error for %s\n", ngram_lr_file);
		return 1;
	}
	if (NgramReadArpa(file, DIR_LR) == FALSE) {
		J_ERROR("read error for %s\n", ngram_lr_file);
		return 1;
	}
	if (file.CloseRead() == -1) {
		J_ERROR("close error\n");
		return 1;
	}
	if (ngram_rl_file != NULL) {
		J_MESSAGE("done\nReading in RL 3-gram...\n");
		/* read RL 3-gram */
		if (file.OpenRead(ngram_rl_file)) {
			J_ERROR("open error for %s\n", ngram_rl_file);
			return 1;
		}
		if (NgramReadArpa(file, DIR_RL) == FALSE) {
			J_ERROR("read error for %s\n", ngram_rl_file);
			return 1;
		}
		if (file.CloseRead() == -1) {
			J_ERROR("close error\n");
			return 1;
		}
	}
	J_MESSAGE("done\n");
	return 0;
}

/* ��b������N-gram�G���g����mapping */
void CJuliGramNgram::MakeVocaRef(CJuliDictionary *winfo)
{
	int i;
	/* ������N-gram�G���g���̑Ή������ */
	J_MESSAGE("Mapping dictonary words to n-gram entries...");
	/* UNK�̐��������� */
	unk_num = 0;
	for (i = 0; i < winfo->GetNumWords(); i++) {
		winfo->SetWordID(i,MakeRef(winfo->GetWordName(i)));
		if (winfo->GetWordID(i) == unk_id) {
			(unk_num)++;
		}
	}
	if (unk_num == 0) {
		unk_num_log = 0.0;	/* for safe */
	} else {
		unk_num_log = (float)log10(unk_num);
	}
	J_MESSAGE("done\n");
}



/* search for wkey at (bigrams) */
/* return NULL if not found */
NNID CJuliGramNgram::SearchBigram(WORD_ID w_l, WORD_ID w_r)	const	// (search_bigram)
{
	/* do binary search */
	/* assume that data in (bigrams) are ordered by wid */
	NNID left,right,mid;		/* n2 */
	if ((left = n2_bgn[w_l]) == NNID_INVALID) 	/* has no bigram */
		return (NNID_INVALID);
	right = left + n2_num[w_l] - 1;
	while(left < right) {
		mid = (left + right) / 2;
		if (n2tonid[mid] < w_r) {
			left = mid + 1;
		} else {
			right = mid;
		}
	}
	if (n2tonid[left] == w_r) {
		return (left);
	} else {
		return (NNID_INVALID);
	}
}

/* search for wkey at (trigrams) */
/* return NULL if not found */
NNID CJuliGramNgram::SearchTrigram(NNID n2, WORD_ID wkey) const	// (search_trigram)
{
	/* do binary search */
	/* assume that data in (trigrams) are ordered by wid */
	int left,right,mid;
	if ((left = n3_bgn[n2]) == NNID_INVALID) 	/* has no bigram */
		return (NNID_INVALID);
	right = left + n3_num[n2] - 1;
	while(left < right) {
		mid = (left + right) / 2;
		if (n3tonid[mid] < wkey) {
			left = mid + 1;
		} else {
			right = mid;
		}
	}
	if (n3tonid[left] == wkey) {
		return (left);
	} else {
		return (NNID_INVALID);
	}
}

/* ---------------------------------------------------------------------- */
/* These are merely simple functions for backward compatibility. */
/* You may write your own to customize them for your own purpose and
achieve higher performance. */ 
/* for 1-gram */
/* return unigram prob  p(w) */
LOGPROB CJuliGramNgram::UniProb(WORD_ID w) const	// (uni_prob)
{
	if (w != unk_id) {
		return(p[w]);
	} else {
		return(p[w] - unk_num_log);
	}
}

/* for 2-gram */
/* return bigram prob  p(w2|w1) */
LOGPROB CJuliGramNgram::BiProb_LR(WORD_ID w1, WORD_ID w2) const	// (bi_prob_lr)
{
	NNID n2;
	LOGPROB prob;
	if ((n2 = SearchBigram(w1, w2)) != NNID_INVALID) {
		/* bigram exist */
		prob = p_lr[n2];
	} else {
		/* bigram not exist, return back-off prob */
		/* bo_wt_lr(w1) * p(w2) */
		prob = bo_wt_lr[w1] + p[w2];
	}
	if (w2 != unk_id) {
		return(prob);
	} else {
		return(prob - unk_num_log);
	}
}

/* return bigram prob  p(w1|w2) */
LOGPROB CJuliGramNgram::BiProb_RL(WORD_ID w1, WORD_ID w2) const	// (bi_prob_rl)
{
	NNID n2;
	LOGPROB prob;
	if ((n2 = SearchBigram(w1, w2)) != NNID_INVALID) {
		/* bigram exist */
		prob = p_rl[n2];
	} else {
		/* bigram not exist, return back-off prob */
		/* bo_wt_rl(w2) * p(w1) */
		prob = bo_wt_rl[w2] + p[w1];
	}
	if (w1 != unk_id) {
		return(prob);
	} else {
		return(prob - unk_num_log);
	}
}

/* for 3-gram */
/* return trigram prob p(w1|w2,w3) */
LOGPROB CJuliGramNgram::TriProb_RL(WORD_ID w1, WORD_ID w2, WORD_ID w3) const	// (tri_prob_rl)
{
	NNID n2, n3;

	if ((n2 = SearchBigram(w2, w3)) != NNID_INVALID) {
		if ((n3 = SearchTrigram(n2, w1)) != NNID_INVALID) {
			/* trigram exist */
			if (w1 != unk_id) {
				return(p_rrl[n3]);
			} else {
				return(p_rrl[n3] - unk_num_log);
			}
		} else {
			/* return back-off prob */
			/* bo_wt_rl(w2,w3) * p(w1|w2) */
			return(bo_wt_rrl[n2] + BiProb_RL(w1, w2)); /* unk already discounted at bi-gram*/
		}
	} else {
		/* context not exist, so return bigram prob */
		return(BiProb_RL(w1, w2));
	}
}




/* wname ����C�P�ꖼ -> id �����p�c���[����� */
void CJuliGramNgram::MakeLookupTree()	// (ngram_make_lookup_tree)
{
	int i;
	int *windex;
	char **wnameindex;

	windex = (int *)J_MALLOC(sizeof(int)*max_word_num);
	for (i=0;i<max_word_num;i++) {
		windex[i] = i;
	}
	wnameindex = (char **)J_MALLOC(sizeof(char *)*max_word_num);
	for (i=0;i<max_word_num;i++) {
		wnameindex[i] = wname[i];
	}
	root = CJuliPatriciaTree<int>::Make(wnameindex, windex, max_word_num, 0);
	J_FREE(windex);
	J_FREE(wnameindex);
}

WORD_ID CJuliGramNgram::LookupWord(const char *wordstr)	// (ngram_lookup_word)
{
	int data;
	data = CJuliPatriciaTree<int>::Search(wordstr, root);
	if (strcmp(wordstr, wname[data]) != 0) {
		return WORD_INVALID;
	} else {
		return(data);
	}
}

/* word name -> word id ��Ԃ�(�\�[�g����Ă�K�v�Ȃ��C�x�����m��) */
WORD_ID CJuliGramNgram::MakeRef(const char *wstr)	// (make_ngram_ref)
{
	WORD_ID nw;
	nw = LookupWord(wstr);
	if (nw == WORD_INVALID) {
		/* not found */
		/* treat as unknown word */
		J_OUTPUT("word %s not exist in N-gram, treat as <UNK>\n", wstr);
		return(unk_id);
	} else {
		return(nw);
	}
}



/* return N-gram size */
int CJuliGramNgram::GetUnigramSize()
{
	int unitsize;
	unitsize = sizeof(LOGPROB) * 3 + sizeof(NNID) + sizeof(WORD_ID);
	return(unitsize * ngram_num[0]);
}
int CJuliGramNgram::GetBigramSize()
{
	int unitsize;
	unitsize = sizeof(WORD_ID) * 2 + sizeof(LOGPROB) * 3 + sizeof(NNID);
	return(unitsize * ngram_num[1]);
}

int CJuliGramNgram::GetTrigramSize()
{
	int unitsize;
	unitsize = sizeof(WORD_ID) + sizeof(LOGPROB);
	return(unitsize * ngram_num[2]);
}

/* print ngram information */
void CJuliGramNgram::PrintNgramInfo()
{
	J_OUTPUT("N-gram info:\n");
	if (isopen) {
		J_OUTPUT("\t        OOV word = %s(id=%d)\n", wname[unk_id],unk_id);
		J_OUTPUT("\t        OOV size = %d words in dict\n", unk_num);
	} else {
		J_OUTPUT("\t        OOV word = none\n");
	}
	J_OUTPUT("\t   wordset size  = %8d\n", max_word_num);
	J_OUTPUT("\tuni-gram entries = %8d (%8d bytes)\n", ngram_num[0], GetUnigramSize());
	J_OUTPUT("\t  bi-gram tuples = %8d (%8d bytes)\n", ngram_num[1], GetBigramSize());
	J_OUTPUT("\t tri-gram tuples = %8d (%8d bytes)\n", ngram_num[2], GetTrigramSize());
}


void CJuliGramNgram::SetUnknownID()	// set_unknown_id
{
#if 0
	ndata->unk_id = ngram_lookup_word(ndata, unkword);
	if (ndata->unk_id == WORD_INVALID) {
		j_printerr("word %s not found, so assume this is a closed vocabulary model\n",
			unkword);
		ndata->isopen = FALSE;
	} else {
		ndata->isopen = TRUE;
	}
#endif
	isopen = TRUE;
	unk_id = 0;		/* unknown (OOV) words are always mapped to
					the number 0 (by CMU-TK)*/
}



void CJuliGramNgram::Read_Endianing(CJuliFile &file, void *buf, size_t unitbyte, int unitnum)
{
	size_t tmp;
	if ((tmp = file.Read(buf, unitbyte, unitnum)) < (size_t ) unitnum) {
		perror("ngram_read_bin");
	}
#ifndef WORDS_BIGENDIAN
	if (unitbyte != 1)	CJuliUtil::swap_bytes(buf, unitbyte, unitnum);
#endif
}

int CJuliGramNgram::CheckHeader(CJuliFile &file)
{
	char buf[512];
	Read_Endianing(file, buf, 1, 512);
	if (! strnmatch(buf, BINGRAM_IDSTR, strlen(BINGRAM_IDSTR))) {
		/* not a v3 bingram file */
		J_ERROR("Error: invalid header, you probably use old bingram\n");
		J_ERROR("Error: if so, please re-make with newer mkbingram that comes with Julius-2.0 or later\n");
		return 1;
	}
	/*J_OUTPUT("%s",buf);*/
	return 0;
}

boolean CJuliGramNgram::NgramReadBin(CJuliFile &file)
{
	int i,n,len;
	char *_p;

	from_bin = TRUE;

	/* check initial header */
	if (CheckHeader(file)) return FALSE;

	/* read total info and set max_word_num */
	for(n=0;n<MAX_N;n++) {
		Read_Endianing(file, &(ngram_num[n]), sizeof(NNID), 1);
	}
	max_word_num = ngram_num[0];

	/* read wname */
	Read_Endianing(file, &len, sizeof(int), 1);
	wname_buffer = (char *)J_BMALLOC(len);
	Read_Endianing(file, wname_buffer, 1, len);
	/* assign... */
	wname = (char **)J_BMALLOC(sizeof(char *)*ngram_num[0]);
	_p = wname_buffer; i = 0;
	while (_p < wname_buffer + len) {
		wname[i++] = _p;
		while(*_p != '\0') _p++;
		_p++;
	}
	if (i != ngram_num[0]) {
		J_ERROR("wname error??\n");
		return FALSE;
	}
	/* malloc all */
	p = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * ngram_num[0]);
	bo_wt_lr = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * ngram_num[0]);
	bo_wt_rl = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * ngram_num[0]);
	n2_bgn = (NNID *)J_MALLOC(sizeof(NNID) * ngram_num[0]);
	n2_num = (WORD_ID *)J_MALLOC(sizeof(WORD_ID) * ngram_num[0]);
	n2tonid = (WORD_ID *)J_MALLOC(sizeof(WORD_ID) * ngram_num[1]);
	p_lr = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * ngram_num[1]);
	p_rl = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * ngram_num[1]);
	bo_wt_rrl = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * ngram_num[1]);
	n3_bgn = (NNID *)J_MALLOC(sizeof(NNID) * ngram_num[1]);
	n3_num = (WORD_ID *)J_MALLOC(sizeof(WORD_ID) * ngram_num[1]);
	n3tonid = (WORD_ID *)J_MALLOC(sizeof(WORD_ID) * ngram_num[2]);
	p_rrl = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * ngram_num[2]);

	/* read 1-gram */
	J_MESSAGE("1-gram.");
	Read_Endianing(file, p, sizeof(LOGPROB), ngram_num[0]);
	J_MESSAGE(".");
	Read_Endianing(file, bo_wt_lr, sizeof(LOGPROB), ngram_num[0]);
	J_MESSAGE(".");
	Read_Endianing(file, bo_wt_rl, sizeof(LOGPROB), ngram_num[0]);
	J_MESSAGE(".");
	Read_Endianing(file, n2_bgn, sizeof(NNID), ngram_num[0]);
	J_MESSAGE(".");
	Read_Endianing(file, n2_num, sizeof(WORD_ID), ngram_num[0]);

	/* read 2-gram*/
	J_MESSAGE("2-gram.");
	Read_Endianing(file, n2tonid, sizeof(WORD_ID), ngram_num[1]);
	J_MESSAGE(".");
	Read_Endianing(file, p_lr, sizeof(LOGPROB), ngram_num[1]);
	J_MESSAGE(".");
	Read_Endianing(file, p_rl, sizeof(LOGPROB), ngram_num[1]);
	J_MESSAGE(".");
	Read_Endianing(file, bo_wt_rrl, sizeof(LOGPROB), ngram_num[1]);
	J_MESSAGE(".");
	Read_Endianing(file, n3_bgn, sizeof(NNID), ngram_num[1]);
	J_MESSAGE(".");
	Read_Endianing(file, n3_num, sizeof(WORD_ID), ngram_num[1]);

	/* read 3-gram*/
	J_MESSAGE("3-gram.");
	Read_Endianing(file, n3tonid, sizeof(WORD_ID), ngram_num[2]);
	J_MESSAGE(".");
	Read_Endianing(file, p_rrl, sizeof(LOGPROB), ngram_num[2]);

	/* make word search tree for later lookup */
	J_MESSAGE("indexing...");
	MakeLookupTree();

	/* unknown id .$B$r%;%C%H.(B*/
	SetUnknownID();

	return TRUE;
}

/* write BIG-ENDIAN binary */
void CJuliGramNgram::Write_Endianing(CJuliFile &file, void *buf, size_t unitbyte, int unitnum)
{
#ifndef WORDS_BIGENDIAN
	if (unitbyte != 1) CJuliUtil::swap_bytes(buf, unitbyte, unitnum);
#endif
	if (file.Write(buf, unitbyte, unitnum) < (size_t )unitnum) {
		perror("write_ngram_bin: Write_Endianing");
	}
#ifndef WORDS_BIGENDIAN
	if (unitbyte != 1) CJuliUtil::swap_bytes(buf, unitbyte, unitnum);
#endif
}

/* write header with identifier string */
void CJuliGramNgram::WriteHeader(CJuliFile &file, char *str)
{
	char buf[BINGRAM_HDSIZE];
	int i, totallen;
	for(i=0;i<BINGRAM_HDSIZE;i++) buf[i] = EOF;
	totallen = strlen(BINGRAM_IDSTR) + 1 + strlen(str);
	if (totallen >= 512) {
		J_WARNING("Warning: header too long, will be truncated\n");
		i = strlen(str) - (totallen - 512);
		str[i] = '\0';
	}
	sprintf(buf, "%s\n%s", BINGRAM_IDSTR, str);
	Write_Endianing(file, buf, 1, 512);
}

boolean CJuliGramNgram::NgramWriteBin(CJuliFile &file, char *headerstr)
{
	int i,n,len;
	/* write initial header */
	WriteHeader(file, headerstr);
	/* write total info */
	for(n=0;n<MAX_N;n++) {
		Write_Endianing(file, &(ngram_num[n]), sizeof(NNID), 1);
		/*J_OUTPUT("ngram %d=%d\n",n+1,ngram_num[n]);*/
	}
	J_OUTPUT("wrote total info\n");
	/* total_ngram_num is now bogus */
	/* unk_*, isopen, max_word_num are set after read, so need not save */
	/* write wname */
	len = 0;
	for(i=0;i<ngram_num[0];i++) {
		len += strlen(wname[i]) + 1;
	}
	Write_Endianing(file, &len, sizeof(int), 1);
	for(i=0;i<ngram_num[0];i++) {
		Write_Endianing(file, wname[i], 1, strlen(wname[i]) + 1); /* include \0 */
	}
	J_OUTPUT("wrote wnames (%d bytes)\n", len + sizeof(int));

	/* write 1-gram */
	Write_Endianing(file, p, sizeof(LOGPROB), ngram_num[0]);
	Write_Endianing(file, bo_wt_lr, sizeof(LOGPROB), ngram_num[0]);
	Write_Endianing(file, bo_wt_rl, sizeof(LOGPROB), ngram_num[0]);
	Write_Endianing(file, n2_bgn, sizeof(NNID), ngram_num[0]);
	Write_Endianing(file, n2_num, sizeof(WORD_ID), ngram_num[0]);
	J_OUTPUT("wrote 1-gram (%d KB)\n",
		((sizeof(LOGPROB)*3 + sizeof(NNID) + sizeof(WORD_ID)) * ngram_num[0]) / 1024);

	/* write 2-gram*/
	Write_Endianing(file, n2tonid, sizeof(WORD_ID), ngram_num[1]);
	Write_Endianing(file, p_lr, sizeof(LOGPROB), ngram_num[1]);
	Write_Endianing(file, p_rl, sizeof(LOGPROB), ngram_num[1]);
	Write_Endianing(file, bo_wt_rrl, sizeof(LOGPROB), ngram_num[1]);
	Write_Endianing(file, n3_bgn, sizeof(NNID), ngram_num[1]);
	Write_Endianing(file, n3_num, sizeof(WORD_ID), ngram_num[1]);
	J_OUTPUT("wrote 2-gram (%d KB)\n",
		((sizeof(LOGPROB)*3 + sizeof(NNID) + sizeof(WORD_ID)*2) * ngram_num[1]) / 1024);

	/* write 3-gram*/
	Write_Endianing(file, n3tonid, sizeof(WORD_ID), ngram_num[2]);
	Write_Endianing(file, p_rrl, sizeof(LOGPROB), ngram_num[2]);
	J_OUTPUT("wrote 3-gram (%d KB)\n",
		((sizeof(LOGPROB) + sizeof(WORD_ID)) * ngram_num[2]) / 1024);
	return TRUE;
}
