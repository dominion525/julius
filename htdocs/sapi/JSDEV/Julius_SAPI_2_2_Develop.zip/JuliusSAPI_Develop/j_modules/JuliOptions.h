//====================================================================
// JuliOptions.h: �R���e�L�X�g�Ɉˑ�����I�v�V����
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================


#if !defined(AFX_JULIOPTIONS_H__28D35501_64BE_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIOPTIONS_H__28D35501_64BE_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDefines.h"
#include "JuliContextObject.h"
#include <string>
using namespace std;

// �����l���p�����[�^
template <class T> class TJuliParameter
{
public:
	void Init(const T d) { value = def = d; }
	void SetValueToDefault() { value = def; }
	void SetDefault(const T d) { def = d; }
	T GetDefault() const { return def; }
	bool IsDefault() const { return value == def; }
	operator T() const { return value; } 
	T operator=(const T v) { return value = v; } 
	T GetValue() const { return value; }
private:
	T value;	// ���݂̐ݒ�l
	T def;	// �f�t�H���g�l
};

typedef TJuliParameter<int> CJuliParameterInt;
typedef TJuliParameter<boolean> CJuliParameterBoolean;
typedef TJuliParameter<LOGPROB> CJuliParameterLOGPROB;
typedef TJuliParameter<float> CJuliParameterFloat;
typedef TJuliParameter<string> CJuliParameterString;

class CJuliOptions : public CJuliContextObject
{
public:
	void Clear();
	CJuliOptions();
	virtual ~CJuliOptions();
	
	/* -------- models ------------------------------------- */
	string m_strNgramFile;
	string m_strNgramArpaLRFile;
	string m_strNgramArpaRLFile;
//	string m_strDfaFile;
	string m_strDictFile;
	int m_bUseArpaFile;	// 0: bingram 1: arpa file

#ifdef USE_NGRAM
//	char *ngram_filename_lr_arpa; /* n-gram file in ARPA format(LR)*/
//	char *ngram_filename_rl_arpa; /* n-gram file in ARPA format(LR)*/
	LOGPROB def_lm_weight_mono; /* default LM weights and penalties */
	LOGPROB def_lm_penalty_mono;
	LOGPROB def_lm_weight2_mono;
	LOGPROB def_lm_penalty2_mono;
	LOGPROB def_lm_weight_tri;
	LOGPROB def_lm_penalty_tri;
	LOGPROB def_lm_weight2_tri;
	LOGPROB def_lm_penalty2_tri;
	boolean lmp_specified; /* true if -lmp explicitly specified */
	boolean lmp2_specified; /* true if -lmp2 explicitly specified */
	LOGPROB lm_weight; /* language model weight */
	LOGPROB lm_penalty; /* language model logscore penalty */
	LOGPROB lm_weight2; /* language model weight */
	LOGPROB lm_penalty2; /* language model logscore penalty */
	LOGPROB lm_penalty_trans; /* insertion penalty for transparent word */
#ifdef CLASS_NGRAM
	char *class_bingram_file;
	LOGPROB class_weight;
	WORD_ID true_max_num;
#endif
#endif  /* USE_NGRAM */
#ifdef USE_DFA
	char *dfa_filename; /* dfa file */
	LOGPROB penalty1; /* insertion penalty for 1st pass */
	LOGPROB penalty2; /* insertion penalty for 2nd pass */

#endif
#ifdef USE_NGRAM
	int m_bUseHeadSilName;		// m_strHeadSilentName ���g�p���邩
	int m_bUseTailSilName;		// m_strTailSilentName ���g�p���邩
	string m_strHeadSilentName;		// ��������
	string m_strTailSilentName;		// ��������
	const char * GetHeadSilentName() { return (m_bUseHeadSilName)?m_strHeadSilentName.c_str():BEGIN_WORD_DEFAULT; }
	const char * GetTailSilentName() { return (m_bUseTailSilName)?m_strTailSilentName.c_str():END_WORD_DEFAULT; }
#endif  /* USE_NGRAM */
#ifdef USE_DFA
//	char *sp_name; /* sp model name that can skip in search */
	string m_strSpName;
	string m_strBeginSilentPhone;	// �J�n Sil (default: silB)
	string m_strEndSilentPhone;		// �I�� Sil (default: silE)
	const char * GetSpName() { return m_strSpName.c_str(); }
	const char * GetBeginSilentPhone() { return m_strBeginSilentPhone.c_str(); }
	const char * GetEndSilentPhone() { return m_strEndSilentPhone.c_str(); }

#endif
	/* -------- search parameters ----------------------------------------- */
	int trellis_beam_width; /* trellis beam width */
	int gprune_method; /* Gaussian pruning method*/
	int mixnum_thres;	/* Gaussian pruning value */
	int gs_statenum;	/* GMS value */
#define DEFAULT_STACK_SIZE 500	/* default stack size for search */
	CJuliParameterInt stack_size; /* -s */
	CJuliParameterInt hypo_overflow; /* -m */
//	int nbest;		/* search till candidate reaches this number */
	int output_hypo_maxnum; /* max num of hypo to output */
	CJuliParameterInt enveloped_bestfirst_width; /* -1 means no beam-lize */
	CJuliParameterInt lookup_range; /* lookup range of word expansion in 2nd pass */
#ifdef SCAN_BEAM
	CJuliParameterLOGPROB scan_beam_thres; /* beam threshold rate in 2nd pass */
#endif
#ifdef SEPARATE_BY_UNIGRAM
	int separate_wnum; /* word num from best freq. to separate from tree */
#endif
#ifdef WPAIR
# ifdef WPAIR_KEEP_NLIMIT
	int wpair_keep_nlimit; /* keeps only N token on wpair */
# endif
#endif
#ifdef HASH_CACHE_IW
	int iw_cache_rate;	/* inter-word LM cache size rate for vocabulary size */
#endif
	
	/* -------- work area ------------------------------------------------- */

	/* for internal use */
//	boolean beam_token_is_expanded;
	/* abbrev for 2nd pass routines */
	int peseqlen;	// TODO: JuliContext �Ɉړ��H
#ifdef SCAN_BEAM
	LOGPROB *framemaxscore;/* maximum score of each frame on 2nd pass */	// TODO: JuliContext �Ɉړ��H
#endif
};

#endif // !defined(AFX_JULIOPTIONS_H__28D35501_64BE_11D5_9AFA_008098E80572__INCLUDED_)
