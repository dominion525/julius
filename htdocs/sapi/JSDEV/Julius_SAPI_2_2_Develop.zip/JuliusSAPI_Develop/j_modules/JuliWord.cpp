//====================================================================
// JuliWord.cpp: 1�̒P��Ɋւ������ێ�����N���X (WORD_INFO)
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliWord.h"
#include "JuliHmmInfo.h"

CJuliWord::CJuliWord() : wlen(0), wname(""), woutput(""), wseq(NULL), wton(0), is_transparent(FALSE)
{}

CJuliWord::~CJuliWord()
{
	// wseq �͊O���� MALLOC ����Ă���̂ł����ŉ������
	J_FREE(wseq);
}

void CJuliWord::OutputDebug()
{
	J_DEBUGMESSAGE("ID=%d, Nm=[%s], Out=[%s], Tr=%s,", wton, wname.c_str(), woutput.c_str(),
		is_transparent?"Yes":"No");
	for (int i=0;i<wlen;i++)
	{
		if (wseq[i]->IsPseudo())
		{
			J_DEBUGMESSAGE(" %s[%s]",wseq[i]->GetName(), wseq[i]->GetPseudo()->name);
		} else {
			J_DEBUGMESSAGE(" %s",wseq[i]->GetName());
		}
	}
	J_DEBUGMESSAGE("\n");
}
