// JuliDecodeNgram.h: CJuliDecodeNgram �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JULIDECODENGRAM_H__18278410_7831_442C_97A3_78F214872023__INCLUDED_)
#define AFX_JULIDECODENGRAM_H__18278410_7831_442C_97A3_78F214872023__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDecode.h"

class CJuliDecodeNgram : public CJuliDecode
{
public:
	CJuliDecodeNgram();
	virtual ~CJuliDecodeNgram();

	virtual int FirstWords(NEXTWORD **nw, int peseqlen, int maxnw);	// *_firstwords
	virtual int NextWords(NODE *hypo, NEXTWORD **nw, int maxnw);	// *_nextwords
	virtual boolean Acceptable(NODE *hypo);	// *_acceptable
	virtual LOGPROB EosScore(NODE *hypo);	// *_eosscore

private:
	void SetWordContext(WORD_ID *cseq, int n); // set_word_context
	int PickBacktrellisWords(NEXTWORD **nw, int oldnum, NODE *hypo, short t); // pick_backtrellis_words
	int GetBacktrellisWords(NEXTWORD **nw, NODE *hypo, short tm, short t_end); // get_backtrellis_words
	int LimitNw(NEXTWORD **nw, NODE *hypo, int num); // limit_nw

	WORD_ID cnword[2];		/* context words */
	int cnnum;
	int last_trans;
};

#endif // !defined(AFX_JULIDECODENGRAM_H__18278410_7831_442C_97A3_78F214872023__INCLUDED_)
