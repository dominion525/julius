//====================================================================
// JuliGlobalOption.h: �O���[�o����(�R���e�L�X�g�Ɉˑ����Ȃ�)�I�v�V�������Ǘ�����N���X
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIGLOBALOPTION_H__B96927D9_D51E_43D1_B845_38C786BAB8E4__INCLUDED_)
#define AFX_JULIGLOBALOPTION_H__B96927D9_D51E_43D1_B845_38C786BAB8E4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDefines.h"
#include "JuliOptions.h"
#include <string>
using namespace std;

class CJuliGlobalOption  
{
public:
	CJuliGlobalOption();
	virtual ~CJuliGlobalOption();
	
	void Clear();
	void SetWaveType(int type);

	int ReadJConf(const char *jconffilename);
	int ReadCommandLine(const char *cmdline);
	int ReadArgs(int argc,char * const argv[], const char *cwd);

	int m_iWaveType;	// 0: 16MHz 16bit Mono 1: 8MHz 16bit Mono
	CJuliParameterBoolean m_bAddNoize;

	boolean m_bCMNCycle;	// CMN�p�����[�^���g���܂킷
	boolean m_bCMNLoad;
	string m_strCMNLoadFile;	/* load CMN parameter from */ // (cmnload_filename)
	boolean m_bCMNSave;
	string m_strCMNSaveFile;	/* save CMN parameter to */	// (cmnsave_filename)
	string m_strSSLoadFile;		/* load SS parameter from */

	/* spectral subtraction */
	CJuliParameterInt		m_iSSMode;	// 0: nothing 1: sscalc 2: ssload
//	CJuliParameterBoolean	sscalc; /* compute SS using head silence for file input */
	CJuliParameterInt		sscalc_len; /* head silence length used to compute SS(in msec) */
	CJuliParameterFloat		ssalpha; /* alpha coef. for SS */
	CJuliParameterFloat		ssfloor; /* spectral floor for SS */

	CJuliParameterFloat		m_fCMAlpha;	// �M���x�W��

	/* spectral subtraction */
	float *m_ssbuf;/* noise spectrum */
	int m_sslen;               /* length of above */


	// �������f��
	string m_strHmmFile;

	boolean m_bUseMapFile;		string m_strMapFile;
	boolean m_bUseGsHmmFile;	string m_strGsHmmFile;


	// ���ꃂ�f��
	boolean m_bNoUseSLM;	// SLM ���܂������g�p���Ȃ�

	// ���O�t�@�C��
	// ErrLog: J_ERROR �̂�
	boolean m_bUseErrLogFile;	string m_strErrLogFile;
	// OutLog: J_OUTPUT �̂�
	boolean m_bUseOutLogFile;	string m_strOutLogFile;
	// DebugLog: ���ׂ�
	boolean m_bUseDebugLogFile;	string m_strDebugLogFile;
	// WAVE���o�̓t�@�C��
	boolean m_bUseWaveOutFile;	string m_strWaveOutFile;

	// IME
	boolean m_bUseIME;				// �ǂ݂����߂�̂� IME ���g����
	boolean m_bUseIMEDllFile;		// �w�肵�� IME DLL �t�@�C�����g�����ǂ���
	string m_strIMEDllFile;			// IME DLL �t�@�C��

	// �g���@�\
	// ���f�A���C�����g���o�̓t�@�C��
	boolean m_bUsePhonemeAlignFile;	string m_strPhonemeAlignFile;
	// MFCC���o�̓t�@�C��
	boolean m_bUseMfccFile;			string m_strMfccFile;

	// �f�R�[�h
	boolean m_bUseNbest;	// nbest ���v�Z���邩
	int		m_iNbest;		// nbest �̒l
	boolean m_bUseCM;		// �X�R�A�� CM �ŏo��

	// �F�����s����
	boolean m_bUseFalseRecognition;	// FalseRecognition 臒l���g�p���邩
	boolean m_bUseFRScore;		// ���M���x���g�p���邩
	boolean m_bUseFRMinLength;	// ������ԉ������g�p���邩
	boolean m_bUseFRMaxLength;	// ������ԏ�����g�p���邩
	boolean m_bUseFRFiller;		// �t�B���[���f�����g�p���邩
	CJuliParameterLOGPROB m_probFRScore;	// FalseRecognition 臒l
	CJuliParameterInt m_iFRMinLength;	// ������ԉ���
	CJuliParameterInt m_iFRMaxLength;	// ������ԏ��

	float m_fScoreThresHigh;	// �X�R�A��臒l�A�����ق�
	float m_fScoreThresLow;		// �X�R�A��臒l�A�Ⴂ�ق�

public:
	int IsGsHmmFileUse() { return m_bUseGsHmmFile; }
	const char * GetMapFilename() { return (m_bUseMapFile)?m_strMapFile.c_str():NULL; }
	const char * GetGsHmmFilename() { return (m_bUseGsHmmFile)?m_strGsHmmFile.c_str():NULL; }
	const char * GetHmmFilename() { return m_strHmmFile.c_str(); }


	/* -------- switches -------------------------------------------------- */
	boolean verbose_flag; /* verbose output */
	boolean debug2_flag; /* debug2 output (numerous)*/
	boolean paramtype_check_flag; /* with "-notypecheck", don't check param type */
	boolean force_realtime_flag; /* whether to force */
	boolean forced_realtime;	/* forced value */
	boolean compute_only_1pass; /* if TRUE, compute only 1pass */
	boolean forcedict_flag; /* if TRUE, ignore error words and keep going */
#ifdef USE_NGRAM
	boolean separate_score_flag; /* output score in AM/LM */
#endif
	boolean wchmm_check_flag; /* wchmm interactive check */
	boolean trellis_check_flag; /* trellis interactive check */
	boolean result_reorder_flag; /* re-order result by score */
	boolean realtime_flag;
	boolean ccd_flag;
	boolean ccd_flag_force;
	boolean progout_flag;
	boolean align_result_word_flag;
	boolean align_result_phoneme_flag;
	boolean catch_intr_flag; /* TRUE when catch SIGINT */
	int progout_interval; /* output interval in msec */
#ifdef USE_DFA
	boolean looktrellis_flag;
#endif
#ifdef CATEGORY_TREE
	boolean old_tree_function_flag; /* use build_wchmm() */
#ifdef PASS1_IWCD
	boolean old_iwcd_flag; /* use full lcdset */
#endif
#endif
	boolean iwcdavg_flag;

	int speech_input; /* speech input */
	int result_output;
	
	CJuliParameterInt level_thres;
	CJuliParameterInt zero_cross_num;
	CJuliParameterInt head_margin_msec;
	CJuliParameterInt tail_margin_msec;
	int pause_segment; /* 0..off 1.. on 2..not specified by user */
	int pause_duration; /* silence length */
	boolean strip_zero_sample; /* strip off zero samples */
	boolean adin_cut_on;	/* the result of adin_init() */
	int adinnet_port;


	/* speech analysis param */
	int smpPeriod; /* sample period (16kHz: 625ns) */	// �P�ʂ� 100ns! (=0.0001ms)
	int smpFreq; /* sample freq.  (16kHz: 625ns) */
	CJuliParameterInt fshift; /* Frame shift (160sample = 10ms in 16kHz) */
	CJuliParameterInt fsize; /* Window size (400sample = 25ms in 16kHz) */

	/* lo-pass/hi-pass filter */
	CJuliParameterInt hipass; /* frequency of hi pass filter. -1 means no use hi pass filter */
	CJuliParameterInt lopass; /* frequency of lo pass filter. -1 means no use hi pass filter */
	boolean c0_required; /* TRUE when 0'th Cepstral parameter is used instead of energy in hmmdefs */

public:
	void GetOptionString(string &str);
	CJuliOptions & GetOption() { return m_opt;}
	const CJuliOptions & GetOption() const { return m_opt;}
private:
	CJuliOptions m_opt;
};

extern CJuliGlobalOption theOpt;

#endif // !defined(AFX_JULIGLOBALOPTION_H__B96927D9_D51E_43D1_B845_38C786BAB8E4__INCLUDED_)
