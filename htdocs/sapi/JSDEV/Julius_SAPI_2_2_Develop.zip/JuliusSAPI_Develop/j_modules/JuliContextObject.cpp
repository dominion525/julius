//====================================================================
// JuliContextObject.cpp: �R���e�L�X�g�ˑ��I�u�W�F�N�g�̊��N���X
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// All rights reserved
//====================================================================

#include "JuliContextObject.h"

CJuliContextObject::~CJuliContextObject()
{

}
