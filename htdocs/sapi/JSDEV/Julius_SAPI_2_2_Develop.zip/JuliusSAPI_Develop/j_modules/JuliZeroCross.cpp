//====================================================================
// JuliZeroCross.cpp: ��������𐔂���N���X(���C�u����)
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

/**check no sound in monoral input data **/
/* Sat Feb 19 13:48:00 JST 1994 */
/*  Kawahara 1986 */
/*  Munetsugu 1991 */
/*  shinohara 1993 */
/*  mikik 1993 */
/*  ri 1997 for cycle buffer */

#include "JuliGlobalOption.h"
#include "JuliZeroCross.h"
#include "JuliDefines.h"

#define	abs(X)		((X)>0?(X):-(X))
#define UNDEF 2
#define POSITIVE 1
#define NEGATIVE -1

CJuliZeroCross::CJuliZeroCross()
: is_zc(NULL), data(NULL)
{
}

CJuliZeroCross::~CJuliZeroCross()
{
	J_FREE(is_zc);
	J_FREE(data);
}

/* initialize all parameter and buffer */
void CJuliZeroCross::Init(int c_trigger, int c_length, int c_offset)
{
	int i;

	trigger = c_trigger;
	length = c_length;
	offset = c_offset;

	zero_cross = 0;
	is_trig = FALSE;
	sign = POSITIVE;
	top = 0;

	/* data spool for header-margin */
	data = (SP16 *)J_MALLOC(length * sizeof(SP16));
	/* zero-cross location */
	is_zc = (int *)J_MALLOC(length * sizeof(int));
	for (i=0; i<length; i++){
		is_zc[i] = UNDEF;
	}
}

/* free all buffer */
void CJuliZeroCross::Release()
{
	J_FREE(is_zc);	is_zc = NULL;
	J_FREE(data);	data = NULL;
}

/* count zerocross and level for 'buf[0..step-1]' */
/* the contents are swapped by cycle-buffer */
/* returns number of zero-crosses on the (swapped) buffer */
int CJuliZeroCross::Count(SP16 *buf,int step)
{
	int i;
	SP16 tmp;

	for (i=0; i<step; i++) {
		if (is_zc[top]==TRUE) {
			--zero_cross;
		}
		is_zc[top] = FALSE;
		/* exchange old data and buf */
		tmp = buf[i] + offset;
		if (is_trig) {
			if (sign==POSITIVE && tmp<0) {
				++zero_cross;
				is_zc[top] = TRUE;
				is_trig = FALSE;
				sign = NEGATIVE;
			} else if (sign==NEGATIVE && tmp>0) {
				++zero_cross;
				is_zc[top] = TRUE;
				is_trig = FALSE;
				sign = POSITIVE;
			}
		}
		if (abs(tmp)>trigger) {
			is_trig = TRUE;
		}
		tmp = data[top];
		data[top] = buf[i];
		buf[i] = tmp;
		if (++top==length) {
			top = 0;
		}
	}
	return (zero_cross);
}

/* count zerocross and level for 'buf[0..step-1]' */
/* also calculates max level and store to '*levelp' */
/* the contents are swapped by cycle-buffer */
/* returns number of zero-crosses on the (swapped) buffer */
int CJuliZeroCross::CountLevel(SP16 *buf,int step,int *levelp)
{
	int i;
	SP16 tmp;
	SP16 level;

	level = 0;
	for (i=0; i<step; i++) {
		if (is_zc[top]==TRUE) {
			--zero_cross;
		}
		is_zc[top] = FALSE;
		/* exchange old data and buf */
		tmp = buf[i] + offset;
		if (is_trig) {
			if (sign==POSITIVE && tmp<0) {
				++zero_cross;
				is_zc[top] = TRUE;
				is_trig = FALSE;
				sign = NEGATIVE;
			} else if (sign==NEGATIVE && tmp>0) {
				++zero_cross;
				is_zc[top] = TRUE;
				is_trig = FALSE;
				sign = POSITIVE;
			}
		}
		if (abs(tmp)>trigger) {
			is_trig = TRUE;
		}
		if (abs(tmp)>level) level = abs(tmp);
		tmp = data[top];
		data[top] = buf[i];
		buf[i] = tmp;
		if (++top==length) {
			top = 0;
		}
	}
	*levelp = (int)level;
	return (zero_cross);
}

void CJuliZeroCross::CopyBuffer(SP16 *newbuf, int len)
{
	int i, t;
	t = top;
	for(i=0;i<len;i++) {
		newbuf[i] = data[t];
		if (++t == length) t = 0;
	}
}

// --- from anlz/strip.c

/* distinction function: sequence of 0 and -2^15 is invalid */
#define IS_INVALID_SAMPLE(A) ((A) == 0 || (A) == -32767)
/* length to detect as invalid */
#define WINDOWLEN 16		/* 1ms in 16kHz */

int	CJuliZeroCross::StripZero(SP16 a[], int len) /* return length after stripping */
{
	int src,dst;
	int bgn,mode,j;

	dst = 0;
	bgn = 0;
	mode = 0;

	for (src = 0; src < len; src++) {
		if (IS_INVALID_SAMPLE(a[src])) {
			if (mode == 0) {          /* first time */
				bgn = src;
				mode = 1;
			}
			/* skip */
		} else {
			if (mode == 1) {
				mode = 0;
				if ((src - bgn) < WINDOWLEN) {
					for(j=bgn;j<src;j++) {
						a[dst++] = a[j];
					}
				} else {
					if (theOpt.m_bAddNoize)
					{
						J_WARNING("Warning: sample %d-%d is invalid, replaced with noise for MFCC.\n", bgn, src-1);
						int noisepattern[4]={-1,0,1,0};
						// �m�C�Y�������I�ɓ���Ă݂�
						for(j=bgn;j<src;j++) {
							a[dst++] = noisepattern[j%4];
						}
					} else {
						/* deleted (leave uncopied) */
						J_WARNING("Warning: sample %d-%d is invalid, stripped\n", bgn, src-1);
					}
				}
			}
			a[dst++] = a[src];
		}
	}
	/* end process */
	if (mode == 1) {
		mode = 0;
		if ((src - bgn) < WINDOWLEN) {
			/* restore */
			for(j=bgn;j<src;j++) {
				a[dst++] = a[j];
			}
		} else {
			if (theOpt.m_bAddNoize)
			{
				J_WARNING("Warning: sample %d-%d is invalid, replaced with noise for MFCC.\n", bgn, src-1);
				int noisepattern[4]={-1,0,1,0};
				// �m�C�Y�������I�ɓ���Ă݂�
				for(j=bgn;j<src;j++) {
					a[dst++] = noisepattern[j%4];
				}
			} else {
				/* deleted (leave uncopied) */
				J_WARNING("Warning: sample %d-%d is invalid, stripped\n", bgn, src-1);
			}
		}
	}

	return(dst);
}
