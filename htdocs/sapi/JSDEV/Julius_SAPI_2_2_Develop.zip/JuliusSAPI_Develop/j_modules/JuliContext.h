//====================================================================
// JuliContext.h: �R���e�L�X�g���N���X
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULICONTEXT_H__73F13AE1_BD9A_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULICONTEXT_H__73F13AE1_BD9A_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDefines.h"
#include <assert.h>

#include <vector>
#include <map>
using namespace std;

class CJuliHtkParam;

class CJuliOptions;
class CJuliGrammar;
class CJuliGramNgram;
class CJuliGramDfa;
class CJuliGramSAPI;
class CJuliGrammar;
class CJuliDictionary;
class CJuliHmmInfo;
class CJuliBeamSearch;
class CJuliBackTrellis;
class CJuliOutProb;
class CJuliResultOut;
class CJuliWordConjHMM;
class CJuliFactoring;
class CJuliRealTimePipeLine;
class CJuliDecode;
class CJuliDecodeNgram;
class CJuliDecodeDfa;
class CJuliSearchBestfirst;
// CJuliContext: �F���P��
// �ݒ肳�ꂽ�������f���A���ꃂ�f���A��b�A�I�v�V�������i�[

// ���ꃂ�f���̎��
enum JULISLM { JULISLM_NGRAM, JULISLM_DFA, JULISLM_SAPIXML, JULISLM_JSGF};

// �A���C�����g���
typedef struct _alignresult_
{
	vector<int> e_frame;
	vector<LOGPROB> e_score;
	LOGPROB a_score;
} ALIGNRESULT;


// ##############################################################
// # CJuliContext
// ##############################################################

// �R���e�L�X�g�N���X
// ���@���Ƃ�1�̃R���e�L�X�g�����蓖�Ă�

class CJuliContext  
{
public:
	CJuliContext();
	virtual ~CJuliContext();

	// �쐬�Ə���
	void Create(JULISLM slm, CJuliResultOut *ro);
	void Delete();

	// �R���e�L�X�g�̏�����
	int Init();
	int Prepare();
	void SetLmWeight();	// (set_lm_weight)
	void SetLmWeight2();	// (set_lm_weight2)

	// �R���e�L�X�g�̃��C������
	void DoPrepare1st(bool fRealTime);
	int Do1stRealtime(SP16 *buf, int len);
	void DoParam();
	void Do2nd();

	void SetHmm(CJuliHmmInfo *phi) { m_pHmmInfo = phi; }
	void SetGsHmm(CJuliHmmInfo *phi) { m_pGsHmm = phi; }
	void CopyOptions(CJuliOptions &opt);
	CJuliOptions * GetOptions() { return m_pOptions; }
	CJuliGrammar * GetGrammar() { return m_pGrammar; }

	void SetSLMType(JULISLM slm) { m_juliSLM = slm; }
	JULISLM GetSLMType() { return m_juliSLM; }

	CJuliGramNgram * GetGramNgram() { assert(m_juliSLM==JULISLM_NGRAM); return (CJuliGramNgram*) m_pGrammar; }
	CJuliGramDfa * GetGramDfa() { assert(m_juliSLM==JULISLM_DFA || m_juliSLM==JULISLM_SAPIXML); return (CJuliGramDfa*) m_pGrammar; }
	CJuliDecodeNgram * GetDecodeNgram() { assert(m_juliSLM==JULISLM_NGRAM); return (CJuliDecodeNgram*) m_pDecode; }
	CJuliDecodeDfa * GetDecodeDfa() { assert(m_juliSLM==JULISLM_DFA); return (CJuliDecodeDfa*) m_pDecode; }

	CJuliDictionary * GetDict() { return m_pDict; }
	CJuliHmmInfo * GetHmm() { return m_pHmmInfo; }
	CJuliHmmInfo * GetGsHmm() { return m_pGsHmm; }
	CJuliBeamSearch * GetBeamSearch() { return m_pBeamSearch; }
	CJuliBackTrellis * GetBackTrellis() { return m_pBackTrellis; }
	CJuliOutProb * GetOutProb() { return m_pOutProb; }
	CJuliResultOut * GetResultOut() { return m_pResultOut; }
	CJuliWordConjHMM * GetWCHMM() { return m_pWCHMM; }
	CJuliFactoring * GetFactoring() { return m_pFactoring; }
	CJuliRealTimePipeLine * GetRealTimePipeLine() { return m_pRTPipeLine; }
	CJuliDecode * GetDecode() { return m_pDecode; }
	CJuliSearchBestfirst * GetSearchBestfirst() { return m_pSearchBestfirst; }

	int IsNgram() { return (GetSLMType()==JULISLM_NGRAM); }
	int IsDfa() { return (GetSLMType()==JULISLM_DFA || GetSLMType()==JULISLM_SAPIXML); }
	int IsSAPI() { return (GetSLMType()==JULISLM_SAPIXML); }

	// ��1�p�X�̌���
	void SetPass1WordSeq(int i, WORD_ID w) { pass1_wseq[i] = w; }
	void SetPass1WordNum(int n) { pass1_wnum = n; }
	void SetPass1Score(LOGPROB s) { pass1_score = s; }
	WORD_ID GetPass1WordSeq(int i) const { return pass1_wseq[i]; }
	int GetPass1WordNum() const { return pass1_wnum; }
	LOGPROB GetPass1Score() const { return pass1_score; }

	void SetReady(int i) { m_bIsReady = i; }
	int IsReady() { return m_bIsReady; }
	void SetActive(int i) { m_bIsActive = i; }
	int IsActive() { return m_bIsActive; }

	int GetHypoCount() { return m_iHypoCount; }
	void ClearHypoCount() { m_iHypoCount = 0; }
	void AddHypoCount() { m_iHypoCount++; }

	// �p�u���b�N�ȃ����o
	CJuliHtkParam *m_param;
	LOGPROB m_backmax;
private:
	int m_bIsReady;
	int m_bIsActive;
	JULISLM m_juliSLM;	// ���@�̎��
	// Context Object �̎���
	CJuliOptions		*	m_pOptions;
	CJuliGrammar		*	m_pGrammar;
	CJuliDictionary		*	m_pDict;
	CJuliHmmInfo		*	m_pHmmInfo;		// ����̎��̂� CJuliContextManager::m_Hmms �ɂ���
	CJuliHmmInfo		*	m_pGsHmm;		// ����̎��̂� CJuliContextManager::m_Hmms �ɂ���
	CJuliBeamSearch		*	m_pBeamSearch;
	CJuliBackTrellis	*	m_pBackTrellis;
	CJuliOutProb		*	m_pOutProb;
	CJuliResultOut		*	m_pResultOut;
	CJuliWordConjHMM	*	m_pWCHMM;
	CJuliFactoring		*	m_pFactoring;
	CJuliRealTimePipeLine*	m_pRTPipeLine;
	CJuliDecode			*	m_pDecode;
	CJuliSearchBestfirst*	m_pSearchBestfirst;

	int m_iHypoCount;	// �����J�E���g
	// ��1�p�X�̌���
	WORD_ID pass1_wseq[MAXSEQNUM]; /* word seq. of best hypo on 1st pass */
	int pass1_wnum; /* word num of above */
	LOGPROB pass1_score;	/* score of above */
};

// ##############################################################
// # CJuliContextManager
// ##############################################################

// CJuliContext ���Ǘ�����N���X
class CJuliContextManager
{
public:
	CJuliContextManager();
	virtual ~CJuliContextManager();

	// ������ HMM �̓ǂݍ���
	int InitHMM();

	// �R���e�L�X�g�̍쐬�ƍ폜
	CJuliContext * AddNewContext(CJuliContext *ctxt, JULISLM slm, CJuliResultOut *ro);
	int DeleteContext(CJuliContext *ctxt);

	// �R���e�L�X�g�̃A�N�Z�X
	int GetNumContexts() { return (int)m_apContexts.size(); }
	CJuliContext * GetContext(int i) { return m_apContexts[i]; }

	void OutputDebug();
	void Pass1Begin() {}
	void Pass1End() {}
private:
	int m_bInited;	// InitHMM ���Ă΂ꂽ���ǂ���
	vector<CJuliContext *> m_apContexts;	// �R���e�L�X�g�̔z��
	vector<CJuliHmmInfo *> m_aHmms;	// CJuliContext::m_pHmmInfo �Ŏw�����́B���̃N���X�Ŏ��̊Ǘ�����
};

extern CJuliContextManager theContextManager;

#endif // !defined(AFX_JULICONTEXT_H__73F13AE1_BD9A_11D5_9AFA_008098E80572__INCLUDED_)
