#ifndef __SENT_STANDARD_DEFS__
#define __SENT_STANDARD_DEFS__

#endif /* __SENT_STANDARD_DEFS__*/
