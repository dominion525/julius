// JuliHMM.h: CJuliHMM �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JULIHMM_H__ECF4ED24_601C_41E4_88AF_7D017423F854__INCLUDED_)
#define AFX_JULIHMM_H__ECF4ED24_601C_41E4_88AF_7D017423F854__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDefines.h"
#include "JuliHmmInfo.h"

/* transition arc data */
typedef struct __a_cell__ {
	LOGPROB		a;	/* transition logprob */
	int			arc;	/* transition destination */
	struct __a_cell__	*next;
} A_CELL;

typedef struct __hmm_state__ {
	A_CELL		*ac;	/* transition arc info (list) */
	union {
		const CJuliHtkHmmState *state;	/* pointer to the mapped physical HMM */
		const CD_State_Set  *cdset;		/* pointer to the pseudo HMM */
	} out;
	boolean is_pseudo_state;
} HMM_STATE;


class CJuliHMM  
{
public:
	CJuliHMM(CJuliHmmInfo *hmminfo, const CJuliHtkHmmLogical **hdseq, int hdseqlen);
	virtual ~CJuliHMM();

	int GetLength() const { return len; }	// len
	HMM_STATE * GetHmmState(int i) { return &(state[i]); }	// state
	LOGPROB GetTransProbToAcceptState() const { return accept_ac_a; }	// accept_ac_a
private:
	void MakeWordHmmWithLm(CJuliHmmInfo *hmminfo, const CJuliHtkHmmLogical **hdseq, int hdseqlen, LOGPROB *lscore); // new_make_word_hmm_with_lm
	void AddArc(HMM_STATE *state, int arc, LOGPROB a); // add_arc
	int GetTotalStateLen(const CJuliHtkHmmLogical **hdseq, int hdseqlen) const; // totalstatelen
	
	int			len;	/* total state length */
	HMM_STATE *	state;	/* state array */
	LOGPROB		accept_ac_a; /* trans prob to "accept state" */
};

#endif // !defined(AFX_JULIHMM_H__ECF4ED24_601C_41E4_88AF_7D017423F854__INCLUDED_)
