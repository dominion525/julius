#ifndef __JULIDEFINES_H__
#define __JULIDEFINES_H__

#include "JuliLog.h"
#include "JuliMemory.h"

/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */
/* Configuration result of defines with "J:" will be embeded in the binary */
/* executable name */
#define EXECNAME "julius"
/* name of the product */
#define PRODUCTNAME "Julius"
/* version string */
#define VERSION "3.2pre9"
/* setting when compiled (value of "--enable-setup=...") */
#define SETUP "fast"

/* Define to empty if the keyword does not work.  */
/* #undef const */
/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void
/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1
/* Define if the X Window System is missing or not being used.  */
/* #undef X_DISPLAY_MISSING */
/* JULIAN related begin */
/* J: defined if compiled as DFA parser */
/* #undef USE_DFA */
/* J: category-based tree lexicon on DFA parser */
/* #undef CATEGORY_TREE */
/* JULIAN related end */
/* JULIUS related begin */
/* J: use 1-gram factoring on 1st pass */
#define UNIGRAM_FACTORING 1
/* J: all words share a single root on lexicon tree (save memory of inter-word LM cache) */
/* #undef LOWMEM */
/* J: separate hi-freq words from the lexicon tree */
#define LOWMEM2 1
/* JULIUS related end */
/* J: use word-pair approximation on 1st pass */
/* #undef WPAIR */
/* J: with WPAIR, keep only N-best path (option: "-nlimit N") */
/* #undef WPAIR_KEEP_NLIMIT */
/* J: generate word graph on 1st pass */
/* #undef WORD_GRAPH */
/* J: monophone tree lexicon on 1st pass (EXPERIMENTAL) */
/* #undef MONOTREE */
/* J: handle inter-word triphone on 1st pass */
#define PASS1_IWCD 1
/* J: strict inter-word triphone handling on 2nd pass */
/* #undef PASS2_STRICT_IWCD */
/* J: enable score envelope beaming on 2nd pass scan */
#define SCAN_BEAM 1
/* J: Gaussian pruning default = safe */
/* #undef GPRUNE_DEFAULT_SAFE */
/* J: Gaussian pruning default = beam */
#define GPRUNE_DEFAULT_BEAM 1
/* J: enable progressive decoding with short pause segmentation */
/* #undef SP_BREAK_CURRENT_FRAME */

/* define.h --- define some internal compile options */


/************************************************************/
/********** DO NOT MODIFY MANUALLY DEFINES BELOW ************/
/************************************************************/

// Julius for SAPI �ł͊�{�I�ɗ�����`����
#define USE_NGRAM
#define USE_DFA
#define USE_SAPI

//#ifdef USE_DFA
//#undef  USE_NGRAM
//#else
//#define USE_NGRAM
//#endif

#if 0
#ifdef USE_DFA
#ifdef UNIGRAM_FACTORING
#undef UNIGRAM_FACTORING
#endif
#else  /* USE_NGRAM */
#ifdef CATEGORY_TREE
#undef CATEGORY_TREE
#endif
#endif /* USE_DFA */
#endif

/* abbreviations */
#define VERMES if (verbose_flag) j_printerr

#define REPORT_MEMORY_USAGE

#ifdef USE_NGRAM
/*** tree construction ***/
/* With 1-best approximation, Constructing a single tree from all words
   causes much error by factoring.  Listing each word flatly with no
   tree-organization will not cause this error, but the network becomes
   much larger and, especially, the inter-word LM handling becomes much more
   complex (O(n^2)).  The cost may be eased by LM caching, but it needs much
   memory. */
/* This is a trade-off of accuracy and cost */
#define SHORT_WORD_LEN 2
#ifdef LOWMEM
/* don't separate, construct a single tree from all words */
/* root nodes are about 50 in monophone, cache size will be 5MB on max */
#define NO_SEPARATE_SHORT_WORD
#else
#ifdef LOWMEM2
/* experimental: separate words frequently appears in corpus (1-gram) */
/* root nodes will be "-sepnum num" + 50, cache size will be 10MB or so */
#define NO_SEPARATE_SHORT_WORD
#define SEPARATE_BY_UNIGRAM
#define DEFAULT_SEPARATE_WNUM 150
#else
/* separate all short words (<= 2 phonemes) */
/* root nodes are about 1100 in 20k (proportional to vocabulary),
   cache size will be about 100MB on max */
#endif /* LOWMEM2 */
#endif /* LOWMEM */

/*#define HASH_CACHE_IW*/
/* "./configure --enable-lowmem" defines NO_SEPARATE_SHORT_WORD instead */

#endif /* USE_NGRAM */

/*
 *   TEMPORARY definition for development
 *
 */
#undef FIX_PENALTY


/* enable fancy cursor animation while recognizing... */
#undef FANCY_INDICATOR

#ifdef SP_BREAK_CURRENT_FRAME
#undef SP_BREAK_EVAL		/* output messages for evaluation */
#undef SP_BREAK_DEBUG		/* output messages for debug */
#define SP_BREAK_RESUME_WORD_BEGIN /* resume word = maxword at beginning of sp area */

#define is_sil(A)  (strmatch(A, GetOption()->GetSpName()) || strmatch(A, GetOption()->GetBeginSilentPhone()) || strmatch(A, GetOption()->GetEndSilentPhone()))
#endif

/* assign prob by class N-gram for words unknown in LM */
#undef CLASS_NGRAM
#undef CLASS_UNKNOWN_ONLY
#undef CLASS_UNKNOWN_ONLY_SCALED

#define TRANS_PENALTY_DEFAULT 0.0


// ------------------------------------------------------------
// �^�A�萔
// ------------------------------------------------------------

// --- from stddefs.h

#if !defined(PI)
#define PI 3.14159265358979
#endif
#if !defined(TPI)
#define TPI 6.28318530717959
#define LOGTPI 1.83787706640935
#endif

// Windows �ɂ����ėp�ӂ���Ȃ��֐�
#ifdef _WIN32
#define getpagesize() (4096)
#define bcopy(src,dst,len) memmove(dst,src,len) 
#endif /* _WIN32 */

/* define boolean */
typedef unsigned char boolean;
#define TRUE 1
#define FALSE 0

/* some macros */
#ifndef max
#define	max(A,B)	((A)>=(B)?(A):(B))
#endif
#ifndef min
#define	min(A,B)	((A)<(B)?(A):(B))
#endif
//#define	abs(X)		((X)>0?(X):-(X))
#define strmatch	!strcmp
#define strnmatch	!strncmp

/* from ~speech/src/sent/sentence.h */
#define	LOG_ZERO	-1000000 /* �����ύX������C�Y�ꂸLOG_ADDMIN���ύX���邱�ƁI */
#define LOG_ADDMIN	-13.815510558	/* -log(-LOG_ZERO) (see lib/phmm/outprob.c for explanation) */

/* typedef and enum */
/*enum LogOutputLevel {
  LOG_NORMAL,
  LOG_VERBOSE,
  LOG_DEBUG
};*/
enum{DIR_LR, DIR_RL};		/* �v�Z���� */

/* you can't use double type for typedefs below */
/* also look at lib/util/mybmalloc.c */
typedef float PROB;		/* �m�� */
typedef float LOGPROB;		/* �m���̑ΐ��l(�X�R�A) */
typedef int FREQ;		/* �p�x�̌^ */
typedef short SP16;		/* 16bit speech data type */
typedef float VECT;		/* vector element */

/* maximum word num */
#ifdef WORDS_INT
  /* 2G = 2^31 mode */
  typedef int WORD_ID; /* �P���ID */
  #define MAX_WORD_NUM 2147483647 /* limit size of vocabulary */
  #define WORD_INVALID 2147483647 /* �u�P��ȊO�v��\��ID(�P��ԍ��Əd�Ȃ�Ȃ��l) */
#else  /* 64K */
  typedef unsigned short WORD_ID; /* �P���ID */
  #define MAX_WORD_NUM 65535	/* limit size of vocabulary */
  #define WORD_INVALID 65535	/* �u�P��ȊO�v��\��ID(�P��ԍ��Əd�Ȃ�Ȃ��l) */
#endif

// ------------------------------------------------------------
// �G���[���b�Z�[�W�o��
// ------------------------------------------------------------

#define J_MESSAGE	theJuliLog.Message
#define J_ERROR		theJuliLog.Error
#define J_WARNING	theJuliLog.Warning
#define J_OUTPUT	theJuliLog.Output
#define J_VERMES	theJuliLog.Vermes
#define J_DEBUGMESSAGE	theJuliLog.Debug

// wchar (Unicode)��ϊ����ďo��
#define J_MESSAGEW	theJuliLog.MessageW

// �f�o�b�O�p�B�t�@�C�����ƍs�ԍ����o��
#define J_LINE		theJuliLog.Debug(">>> %s(%d)\n",__FILE__,__LINE__)

// DEBUG �I�v�V�����w�莞�̂ݏo�� (Julius ���K�V�[)
#ifdef DEBUG
#define J_OUTPUT_ON_DEBUG	theJuliLog.Output
#else
#define J_OUTPUT_ON_DEBUG	if (0)
#endif

// ------------------------------------------------------------
// �������A���P�[�V����
// ------------------------------------------------------------

// bmalloc �n�́A�o�b�t�@�𖾎��I�ɉ�����Ȃ�
// Julius for SAPI �ł� J_BFREE �Ŗ����I�ɉ������

// �f�o�b�O�p�B�Ăяo�����̃t�@�C�����ƍs�ԍ��������ɓn���A�G���[���ɏo�͂���
//#define MALLOC_DEBUG

#ifdef MALLOC_DEBUG
#  define J_MALLOC(x)	theJuliMemory.MallocD(__FILE__, __LINE__, x)
#  define J_BMALLOC(x)	theJuliMemory.MallocD(__FILE__, __LINE__, x)
#  define J_FREE(x)		theJuliMemory.FreeD(__FILE__, __LINE__, x)
#  define J_BFREE(x)	theJuliMemory.FreeD(__FILE__, __LINE__, x)
#else
#  define J_MALLOC		theJuliMemory.Malloc
#  define J_BMALLOC		theJuliMemory.Malloc
#  define J_FREE		theJuliMemory.Free
#  define J_BFREE		theJuliMemory.Free
#endif

#define J_REALLOC		theJuliMemory.Realloc
#define J_CALLOC		theJuliMemory.Calloc

#define J_MALLOCARRAY	theJuliMemory.MallocArray
#define J_FREEARRAY		theJuliMemory.FreeArray


// --- from dfa.h

#define DFA_MAXSTATENUM 50000	/* �ő��Ԑ� */
#define INITIAL_S 0x10000000	/* ������ԃt���O */
#define ACCEPT_S  0x00000001	/* �󗝏�ԃt���O */
#define SP_NAME_DEFAULT "sp"	/* �X�L�b�v�\��sp���f���� */

// --- from adin.h

#define DEFAULT_WSTEP 1000	/* default size of data window */


// --- from speech.h

#define MAXSEQNUM     150	/* maximum length of words per sentence hypothesis */
				/* enough? */

#define MAXSPEECHLEN  320000	/* maximum length of speech input in sample (16k/sec)*/
				/* 30 seconds in 16kHz*/

#define OUTPUT_INTERVAL 30	/* progress output on every 30 frame (= 300 ms) */
enum{SP_RAWFILE,SP_MIC,SP_ADINNET,SP_MFCFILE,SP_NETAUDIO}; /* speech input device*/
enum{SP_RESULT_TTY,SP_RESULT_SAPI}; /* result output device*/

// --- from ngram2.h

#define BEGIN_WORD_DEFAULT "<s>"
#define END_WORD_DEFAULT "</s>"

#endif // __JULIDEFINES_H__
