// JuliGramSAPI.h: CJuliGramSAPI �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JULIGRAMSAPI_H__EE0B4465_6A82_4A8D_9550_35F8A9E003A7__INCLUDED_)
#define AFX_JULIGRAMSAPI_H__EE0B4465_6A82_4A8D_9550_35F8A9E003A7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliGrammar.h"
#include "JuliGramDfa.h"

class CJuliGramSAPI : public CJuliGrammar
{
public:
	CJuliGramSAPI();
	virtual ~CJuliGramSAPI();

};

#endif // !defined(AFX_JULIGRAMSAPI_H__EE0B4465_6A82_4A8D_9550_35F8A9E003A7__INCLUDED_)
