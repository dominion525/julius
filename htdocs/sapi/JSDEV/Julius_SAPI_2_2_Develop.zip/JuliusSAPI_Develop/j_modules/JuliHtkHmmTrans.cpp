//====================================================================
// JuliHtkHmmData.cpp: Htk HMM: Transition �I�u�W�F�N�g (HTK_HMM_Trans)
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliHtkHmmTrans.h"

CJuliHtkHmmTrans::CJuliHtkHmmTrans()
: m_siStateNum(0), m_probArcTransition(NULL), atmp(NULL)
{
}

CJuliHtkHmmTrans::~CJuliHtkHmmTrans()
{
	// ���
	if (m_probArcTransition != NULL) delete m_probArcTransition;
	if (atmp != NULL) delete atmp;
}

void CJuliHtkHmmTrans::ReadFromFile(CJuliFile &file,CJuliHmmInfo &info)
{
	int i,j;
	PROB prob;
	/* read tag */
	if (!file.CurrentTokenIs("TRANSP")) file.HmmError("<TRANSP> not found"); /* not match */
	file.GetHmmToken();
	/* read statenum */
	file.NoTokenError("missing TRANSP state num");
	m_siStateNum = atoi(file.CurrentToken());
	file.GetHmmToken();
	/* allocate array */
	m_probArcTransition = new PROB *[m_siStateNum];
	atmp = new PROB[m_siStateNum * m_siStateNum];
	m_probArcTransition[0] = &(atmp[0]);
	for (i=1;i<m_siStateNum;i++) {
		m_probArcTransition[i] = &(atmp[i*m_siStateNum]);
	}
	
	/* begin reading transition prob */
	for (i=0;i<m_siStateNum; i++) {
		for (j=0;j<m_siStateNum; j++) {
			file.NoTokenError("missing some TRANSP value");
			prob = atof(file.CurrentToken());
			m_probArcTransition[i][j] = prob;
			file.GetHmmToken();
		}
	}
}
