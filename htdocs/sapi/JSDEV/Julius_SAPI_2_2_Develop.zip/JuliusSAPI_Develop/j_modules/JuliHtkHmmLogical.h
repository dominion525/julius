// JuliHtkHmmLogical.h: CJuliHtkHmmLogical �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JULIHTKHMMLOGICAL_H__EDB545E4_7C47_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIHTKHMMLOGICAL_H__EDB545E4_7C47_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliHtkHmmSegment.h"
class CJuliHtkHmmData;
class CJuliHtkHmmTrans;
class CJuliHtkHmmState;

/* context-wise state set --- for (inter-word) triphone handling */
typedef struct {		/* HMM state set for same LC & state */
	const CJuliHtkHmmState **m_ppStates;		/* array of state */
	unsigned short num;		/* # of above */
	unsigned short maxnum;	/* allocated # of above */
} CD_State_Set;

class CD_Set
{	/* list of HMM state set for given LC */
public:
	char *name;			/* HMM set logical name ("a-k", "e+b", "e", etc.) */
	CD_State_Set *stateset;	/* array of state set for n'th node */
	unsigned short state_num;	/* # of above */
	const CJuliHtkHmmTrans *tr;		/* transition table */
	const CD_Set *next;
};

class CJuliHtkHmmLogical : public CJuliHtkHmmSegment
{
public:
	CJuliHtkHmmLogical();
	virtual ~CJuliHtkHmmLogical();

	void SetPhysicalHmm(const CJuliHtkHmmData *d) { body.defined = d; }	// def ��ݒ�
	const CJuliHtkHmmData * GetPhysicalHmm() const { return body.defined; }	// def ���擾
	void SetBodyDefined(const CJuliHtkHmmData * d) { body.defined = d; }	// def ���擾
	const CJuliHtkHmmData * GetBodyDefined() const { return body.defined; }	// def ���擾
	void SetIsPseudo(boolean p) { is_pseudo = p; }
	boolean IsPseudo() const { return is_pseudo; }
	void SetPseudo(const CD_Set *p) { body.pseudo = p; }
	const CD_Set * GetPseudo() const { return body.pseudo; }
	int GetStateNum() const; // hmm_logical_state_num
	const CJuliHtkHmmTrans *GetTrans() const; // hmm_logical_trans

	void OutputDebug() const;
private:
	boolean is_pseudo;
	union {
		const CJuliHtkHmmData *defined;	/* pointer to the mapped physical HMM */
		const CD_Set *pseudo;		/* pointer to the pseudo HMM */
	} body;
};

#endif // !defined(AFX_JULIHTKHMMLOGICAL_H__EDB545E4_7C47_11D5_9AFA_008098E80572__INCLUDED_)
