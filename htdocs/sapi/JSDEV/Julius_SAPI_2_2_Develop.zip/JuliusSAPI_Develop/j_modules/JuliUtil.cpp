//====================================================================
// JuliUtil.cpp: �⏕�I�ȋ@�\��񋟂���֐��Q
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliUtil.h"
#include "JuliHmmInfo.h"

CJuliUtil::CJuliUtil()
{
	
}

CJuliUtil::~CJuliUtil()
{
	
}


void CJuliUtil::swap_bytes(void *buf, size_t unitbyte, int unitnum)
{
	char *p, c;
	int i, j;
	p = (char *)buf;
	while (unitnum > 0) {
		i=0; j=unitbyte-1;
		while(i<j) {
			c = p[i]; p[i] = p[j]; p[j] = c;
			i++;j--;
		}
		p += unitbyte;
		unitnum--;
	}
}

/* batch bytes for SP16short */
void CJuliUtil::swap_sample_bytes(SP16 *buf, int len)
{
	char *p;
	char t;
	int i;
	
	p = (char *)buf;
	for (i=0;i<len;i++) {
		t = *p;
		*p = *(p + 1);
		*(p + 1) = t;
		p += 2;
	}
}

int CJuliUtil::strcasecmp(const char *s1, const char *s2)
{
	int c1, c2;
	do {
		c1 = (*s1 >= 'a' && *s1 <= 'z') ? *s1 - 040 : *s1;
		c2 = (*s2 >= 'a' && *s2 <= 'z') ? *s2 - 040 : *s2;
		if (c1 != c2) break;
	}  while (*(s1++) && *(s2++));
	return(c1 - c2);
}

int CJuliUtil::strncasecmp(const char *s1, const char *s2, size_t n)
{
	int c1, c2;
	do {
		c1 = (*s1 >= 'a' && *s1 <= 'z') ? *s1 - 040 : *s1;
		c2 = (*s2 >= 'a' && *s2 <= 'z') ? *s2 - 040 : *s2;
		if (c1 != c2) break;
	}  while (*(s1++) && *(s2++) && (--n));
	return(c1 - c2);
}

/* paramtypes.c --- HTK Parameter type utility functions */
/*                  convert string like "MFCC_E_D" with internal code */

/* below are used both in HMM and in ParameterFile */
static OptionStr pbase[] = {	/* parameter base types */
	{"WAVEFORM", F_WAVEFORM, "sampled waveform", FALSE},
	{"DISCRETE", F_DISCRETE, "Discrete", FALSE},
	{"LPC", F_LPC, "LPC", TRUE},
	{"LPCEPSTRA", F_LPCEPSTRA, "LPC cepstral", TRUE},
	{"MFCC", F_MFCC, "mel-frequency cepstral", TRUE},
	{"FBANK", F_FBANK, "log mel-filter bank", TRUE},
	{"MELSPEC", F_MELSPEC, "linear mel-filter bank", TRUE},
	{"LPREFC", F_LPREFC, "LPC(reflection)", TRUE},
	{"LPDELCEP", F_LPDELCEP, "LPC+Delta", TRUE},
	{"USER", F_USER, "user defined sample kind", TRUE},
	{NULL,0,NULL,FALSE}
};
static OptionStr pqual[] = {	/* parameter qualifier */
	{"_E", F_ENERGY, "log energy coef.", TRUE},
	{"_N", F_ENERGY_SUP, "uppress absolute energy", TRUE},
	{"_D", F_DELTA, "delta coef.", TRUE},
	{"_A", F_ACCL, "acceleration coef.", TRUE},
	{"_C", F_COMPRESS, "compressed", TRUE},
	{"_Z", F_CEPNORM, "cepstral mean normalization", TRUE},
	{"_K", F_CHECKSUM, "CRC checksum added", TRUE},
	{"_0", F_ZEROTH, "0'th cepstral parameter", TRUE},
	{NULL,0,NULL,FALSE}
};

short CJuliUtil::GetCodeFromQualStr(char *s) // param_qualstr2code
{
	int i, qlen;
	char *p;
	short qual_type;
	qual_type = 0;
	p = s;
	/* parse qualifiers */
	while (*p == '_') {
		for (i=0;pqual[i].name!=NULL;i++) {
			qlen = strlen(pqual[i].name);
			if (strncasecmp(p, pqual[i].name, qlen) == 0) {
				qual_type |= pqual[i].type;
				break;
			}
		}
		if (pqual[i].name == NULL) {	/* qualifier not found */
			J_ERROR("ERROR: unknown parameter qualifier: %2s\n", p);
			return(F_ERR_INVALID);
		}
		p += 2;
	}
	return(qual_type);
}

short CJuliUtil::GetCodeFromStr(char *s) // param_str2code
{
	int i;
	short param_type, qual_type;
	char *p, *buf;
	/* determine base type */
	/* cutout base part to *buf */
	buf = strcpy((char *)J_MALLOC(strlen(s)+1), s);
	p = strchr(buf, '_');
	if (p != NULL) *p = '\0';
	
	for (i=0;pbase[i].name!=NULL;i++) {
		if (strcasecmp(buf, pbase[i].name) == 0) {
			param_type = pbase[i].type;
			/* qualifiers */
			qual_type = GetCodeFromQualStr(s + strlen(buf));
			if (qual_type == F_ERR_INVALID) {
				J_FREE(buf);
				return(F_ERR_INVALID);
			} else {
				param_type |= qual_type;
				J_FREE(buf);
				return(param_type);
			}
		}
	}
	/* base type not found */
	J_FREE(buf);
	return(F_ERR_INVALID);
}

char * CJuliUtil::GetQualStrFromCode
(
 char *buf,			/* buffer to store result (must have enough length) */
 short type,		/* qualifier type code */
 boolean descflag		/* set TRUE if want detailed description */
 ) // param_qualcode2str
{
	int i;
	/* qualifier */
	for (i=0;pqual[i].name!=NULL;i++) {
		if (type & pqual[i].type) {
			if (descflag) {
				sprintf(buf, " %s %s\n", pqual[i].desc,
					(pqual[i].supported ? "" : "(not supported)"));
			} else {
				strcat(buf, pqual[i].name);
			}
		}
	}
	return(buf);
}

char * CJuliUtil::GetStrFromCode
(
 char *buf,			/* buffer to store result (must have enough length) */
 short type,		/* parameter type code */
 boolean descflag		/* set TRUE if want detailed description */
 ) // param_code2str
{
	int i;
	short btype;
	/* basetype */
	btype = type & F_BASEMASK;
	for (i = 0; pbase[i].name != NULL; i++) {
		if (pbase[i].type == btype) {
			if (descflag) {
				sprintf(buf, "%s %s with:\n", pbase[i].desc,
					(pbase[i].supported ? "" : "(not supported)"));
			} else {
				strcpy(buf, pbase[i].name);
			}
			break;
		}
	}
	if (pbase[i].name  == NULL) {	/* not found */
		sprintf(buf, "ERROR: unknown basetype ID: %d\n", btype);
		return(buf);
	}
	/* add qualifier string to buf */
	GetQualStrFromCode(buf, type, descflag);
	return(buf);
}


/* cdhmm.c ---  context-dependent HMM related functions */

// (L-)C(+R) -> (L-)C+CENTER(rc)
void CJuliUtil::AddRightContext(char name[], const char *rc) // add_right_context
{
	char *p;
	int i;
	
	if ((p = strchr(name, HMM_RC_DLIM_C)) != NULL) {
		p++;
		*p = '\0';
	} else {
		strcat(name, HMM_RC_DLIM);
	}
	i = strlen(name);
	GetCenterName(rc, &(name[i]));
}

// (L-)C(+R) -> CENTER(lc)-C(+R)
void CJuliUtil::AddLeftContext(char name[], const char *lc) // add_left_context
{
	char *p;
	char buf[40];
	
	if ((p = strchr(name, HMM_LC_DLIM_C)) != NULL) {
		p++;
	} else {
		p = name;
	}
	GetCenterName(lc, buf);
	strcat(buf, HMM_LC_DLIM);
	strcat(buf, p);
	strcpy(name, buf);
}


// (L-)C(+R) -> C
char * CJuliUtil::GetCenterName(const char *hmmname, char *buf) // center_name
{
	const char *p, *s;
	char *d;
	
	p = hmmname;
	d = buf;
	
	/* move next to '-' */
	while (*p != HMM_LC_DLIM_C && *p != '\0') p++;
	if (*p == '\0') s = hmmname;
	else s = ++p;
	
	while (*s != HMM_RC_DLIM_C && *s != '\0') {
		*d = *s;
		d++;
		s++;
	}
	*d = '\0';
	
	return (buf);
}

// (L-)C(+R) -> (L-)C
char * CJuliUtil::GetLeftCenterName(const char *hmmname, char *buf) // leftcenter_name
{
	char *p;
	/* strip off "+..." */
	strcpy(buf, hmmname);
	if ((p = strchr(buf, HMM_RC_DLIM_C)) != NULL) {
		*p = '\0';
	}
	return(buf);
}

// (L-)C(+R) -> C(+R)
char * CJuliUtil::GetRightCenterName(const char *hmmname, char *buf) // rightcenter_name
{
	char *p;
	/* strip off "...-" */
	if ((p = strchr(hmmname, HMM_LC_DLIM_C)) != NULL && *(p+1) != '\0') {
		strcpy(buf, p+1);
	} else {
		strcpy(buf, hmmname);
	}
	return(buf);
}

// �t�@�C�����ǂݍ��݉\���ǂ����̃e�X�g 0:OK 1:NG
int CJuliUtil::CheckFileCanBeRead(const char *filename)
{
#ifdef _WIN32
	FILE *fp;
	fp = fopen(filename,"r");
	if (fp == NULL)
	{
		J_ERROR("Error: Cannot Access File %s\n", filename);
		return 1;
	}
	fclose(fp);
#else
	if (access(filename, R_OK) == -1)
	{
		J_ERROR("Error: Cannot Access File %s\n", filename);
		return 1;
	}
#endif
	return 0;
}

