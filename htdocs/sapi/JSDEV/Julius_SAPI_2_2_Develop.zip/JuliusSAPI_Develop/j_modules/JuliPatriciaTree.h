//====================================================================
// JuliPatriciaTree.h: �p�g���V�A�؂̃e���v���[�g�N���X
//--------------------------------------------------------------------
// Copyright (c) 1991-2000 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIPATRICIATREE_H__28868FC2_62A9_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIPATRICIATREE_H__28868FC2_62A9_11D5_9AFA_008098E80572__INCLUDED_

#include "JuliDefines.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// ���
// �c���[�����ꍇ�ACJuliPatriciaTreeNode<int> *root; �Ƃ��ă��[�g�m�[�h���쐬
// root = CJuliPatriciaTree<int>::Make(wnameindex, windex, max_word_num, 0); �Ŏ��̂��쐬
// CJuliPatriciaTree<T *>::Clean(&m_ptreeNameNode); �ŊJ��

// �c���[�̃m�[�h

template<typename T> class CJuliPatriciaTreeNode
{
public:
	CJuliPatriciaTreeNode() : left0(NULL), right1(NULL) {}

	union {
		T	data;		/* leaf data */
		int	thres_bit;	/* threshold bit */
	} value;
	CJuliPatriciaTreeNode<T> *left0;	/* pointer to left patnode (0)*/
	CJuliPatriciaTreeNode<T> *right1;	/* pointer to right patnode (1)*/
	/* NOTE: both NULL -> this is leaf(thres_bit == WORDID)*/
};

template<typename T> class CJuliPatriciaTree
{
public:
	static void Clean(CJuliPatriciaTreeNode<T> **rootnode);

	static CJuliPatriciaTreeNode<T> * Make(
		char **words, T *data, int wordsnum, int bitplace);	// (make_ptree)
	static T Search(
		const char *str, CJuliPatriciaTreeNode<T> *node);	// (ptree_search_data)
	static CJuliPatriciaTreeNode<T> * MakeRootNode(T data);	// (ptree_make_root_node)
	static void AddEntry(									// (ptree_add_entry)
		const char *str, T data, const char *matchstr, CJuliPatriciaTreeNode<T> **rootnode);
	static void Display(
		CJuliPatriciaTreeNode<T> *node, int level);			// (disp_ptree)
	static void TraverseAndDo(
		CJuliPatriciaTreeNode<T> *node, void (*callback)(T ));	// (aptree_traverse_and_do)

private:
	static int TestBit(const char *str, int bitplace);												// (testbit)
	static int WhereTheBitDiffer(const char *str1, const char *str2);										// (where_the_bit_differ)
	static void AddEntryAt(const char *str, int bitloc, T data, CJuliPatriciaTreeNode<T> **parentlink);	// (ptree_add_entry_at)
	static T SearchData_Recursive(const char *str, CJuliPatriciaTreeNode<T> *node);					// (ptree_search_data_r)
};




template<typename T> void CJuliPatriciaTree<T>::Clean(CJuliPatriciaTreeNode<T> **rootnode)
{
	if ((*rootnode)==NULL) return;
	Clean(&((*rootnode)->left0));
	Clean(&((*rootnode)->right1));
	delete *rootnode;
	*rootnode = NULL;
}

/* string bit test function */
template<typename T> int CJuliPatriciaTree<T>::TestBit(const char *str, int bitplace)
{
	int maskptr;
	int bitshift;
	unsigned char maskbit;
	
	maskptr = bitplace / 8;
	if ((bitshift = bitplace % 8) != 0) {
		maskbit = 0x80 >> bitshift;
	} else {
		maskbit = 0x80;
	}
	return(str[maskptr] & maskbit);
}

/* get on which bit the two strings differ */
template<typename T> int CJuliPatriciaTree<T>::WhereTheBitDiffer(const char *str1, const char *str2)
{
	int p = 0;
	int bitloc;
	/* step: char, bit */
	while(str1[p] == str2[p]) p++;
	bitloc = p * 8;
	while(TestBit(str1, bitloc) == TestBit(str2, bitloc)) bitloc++;
	return(bitloc);
}

/* make patricia tree recursively for given strings */
template<typename T> CJuliPatriciaTreeNode<T> * CJuliPatriciaTree<T>::Make(char **words, T *data, int wordsnum, int bitplace)
{
	int i,j, tmp;
	char *p;
	int newnum;
	CJuliPatriciaTreeNode<T> *ntmp;
#if 0
	j_printf("%d:", wordsnum);
	for (i=0;i<wordsnum;i++) {
		j_printf(" %s",words[i]);
	}
	j_printf("\n");
	j_printf("test bit = %d\n", bitplace);
#endif
	if (wordsnum == 1) {
		/* word identified: this is leaf node */
		ntmp = new CJuliPatriciaTreeNode<T>();
		ntmp->value.data = data[0];
		return(ntmp);
	}
	newnum = 0;
	for (i=0;i<wordsnum;i++) {
		if (TestBit(words[i], bitplace) != 0) {
			newnum++;
		}
	}
	if (newnum == 0 || newnum == wordsnum) {
		/* all words has same bit, continue to descend */
		return(Make(words, data, wordsnum, bitplace + 1));
	} else {
		/* sort word pointers by tested bit */
		j = wordsnum-1;
		for (i=0; i<newnum; i++) {
			if (TestBit(words[i], bitplace) == 0) {
				for (; j>=newnum; j--) {
					if (TestBit(words[j], bitplace) != 0) {
						p = words[i]; words[i] = words[j]; words[j] = p;
						tmp = data[i]; data[i] = data[j]; data[j] = tmp;
						break;
					}
				}
			}
		}
		/* create node and descend for each node */
		ntmp = new CJuliPatriciaTreeNode<T>();
		ntmp->value.thres_bit = bitplace;
		ntmp->right1 = Make(words, data, newnum, bitplace+1);
		ntmp->left0  = Make(&(words[newnum]), &(data[newnum]), wordsnum-newnum, bitplace+1);
		return(ntmp);
	}
}

/* display tree structure (for DEBUG) */
/* traverse pre-order */
template<typename T> void CJuliPatriciaTree<T>::Display(CJuliPatriciaTreeNode<T> *node, int level)
{
	int i;
	for (i=0;i<level;i++) {
		j_printf("-");
	}
	if (node->left0 == NULL && node->right1 == NULL) {
		j_printf("LEAF:%d\n", node->value.data);
	} else {
		j_printf("%d\n", node->value.thres_bit);
		if (node->left0 != NULL) {
			Display(node->left0, level+1);
		}
		if (node->right1 != NULL) {
			Display(node->right1, level+1);
		}
	}
}
/* do search and return data (internal recursive) */
template<typename T> T CJuliPatriciaTree<T>::SearchData_Recursive(const char *str, CJuliPatriciaTreeNode<T> *node)
{
	if (node->left0 == NULL && node->right1 == NULL) {
		return(node->value.data);
	} else {
		if (TestBit(str, node->value.thres_bit) != 0) {
			return(SearchData_Recursive(str, node->right1));
		} else {
			return(SearchData_Recursive(str, node->left0));
		}
	}
}
/* do search and return data */
template<typename T> T CJuliPatriciaTree<T>::Search(const char *str, CJuliPatriciaTreeNode<T> *node)
{
	if (node == NULL) {
		J_ERROR("Error: Search: no node, search for \"%s\" failed\n", str);
		return NULL;
	}
	return(SearchData_Recursive(str, node));
}

/*******************************************************************/
/* add 1 node to given ptree */
/* first, when root node does not exist... */

template<typename T> CJuliPatriciaTreeNode<T> * CJuliPatriciaTree<T>::MakeRootNode(T data)
{
	CJuliPatriciaTreeNode<T> *nnew = new CJuliPatriciaTreeNode<T>();
	nnew->value.data = data;
	return(nnew);
}

/* add node */
template<typename T> void CJuliPatriciaTree<T>::AddEntryAt(const char *str, int bitloc, T data, CJuliPatriciaTreeNode<T> **parentlink)
{
	CJuliPatriciaTreeNode<T> *node;
	node = *parentlink;
	if (node->value.thres_bit > bitloc ||
		(node->left0 == NULL && node->right1 == NULL)) {
		CJuliPatriciaTreeNode<T> *newleaf, *newbranch;
		/* insert between [parent] and [node] */
		newleaf = new CJuliPatriciaTreeNode<T>();
		newleaf->value.data = data;
		newbranch = new CJuliPatriciaTreeNode<T>();
		newbranch->value.thres_bit = bitloc;
		*parentlink = newbranch;
		if (TestBit(str, bitloc) ==0) {
			newbranch->left0  = newleaf;
			newbranch->right1 = node;
		} else {
			newbranch->left0  = node;
			newbranch->right1 = newleaf;
		}
		return;
	} else {
		if (TestBit(str, node->value.thres_bit) != 0) {
			AddEntryAt(str, bitloc, data, &(node->right1));
		} else {
			AddEntryAt(str, bitloc, data, &(node->left0));
		}
	}
}
/* top routine */
template<typename T> void CJuliPatriciaTree<T>::AddEntry(const char *str, T data, const char *matchstr, CJuliPatriciaTreeNode<T> **rootnode)
{
	int bitloc;
	bitloc = WhereTheBitDiffer(str, matchstr);
	if (*rootnode == NULL) {
		*rootnode = MakeRootNode(data);
	} else {
		AddEntryAt(str, bitloc, data, rootnode);
	}
}

/* sequencial access to all data */
template<typename T> void CJuliPatriciaTree<T>::TraverseAndDo(CJuliPatriciaTreeNode<T> *node, void (*callback)(T ))
{
	if (node->left0 == NULL && node->right1 == NULL) {
		(*callback)(node->value.data);
	} else {
		if (node->left0 != NULL) {
			TraverseAndDo(node->left0, callback);
		}
		if (node->right1 != NULL) {
			TraverseAndDo(node->right1, callback);
		}
	}
}

#endif // !defined(AFX_JULIPATRICIATREE_H__28868FC2_62A9_11D5_9AFA_008098E80572__INCLUDED_)
