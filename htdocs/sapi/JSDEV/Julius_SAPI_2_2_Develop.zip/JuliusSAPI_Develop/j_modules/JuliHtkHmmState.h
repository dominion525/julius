//====================================================================
// JuliHtkHmmState.h: Htk HMM: State �I�u�W�F�N�g (HTK_HMM_State)
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIHTKHMMSTATE_H__C2F03B30_7AC4_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIHTKHMMSTATE_H__C2F03B30_7AC4_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDefines.h"
#include "JuliHtkHmmSegment.h"

class CJuliHtkHmmDens;

class CJuliHtkHmmState : public CJuliHtkHmmSegment
{
public:
	CJuliHtkHmmState();
	virtual ~CJuliHtkHmmState();

	void ReadFromFile(CJuliFile &file, CJuliHmmInfo &info);

	// �A�N�Z�b�T
	short GetMixNum() const { return mix_num; }
	void SetID(unsigned short i) { id = i; }
	unsigned short GetID() const { return id; }
	void SetBWeight(int i, PROB p) { bweight[i] = p; }
	PROB GetBWeight(int i) const { return bweight[i]; }
	void AllocBWeight(int s) { bweight = new PROB[s]; }
	void SetDens_pp(CJuliHtkHmmDens **p) { b = p; }
	CJuliHtkHmmDens ** GetDens_pp() const { return b; }

private:
	short			mix_num;	/* num of mixture */
	CJuliHtkHmmDens	**b;		/* density data for each mixture */
	PROB *			bweight;	/* weight of above */
	unsigned short	id;			/* uniq id (0-) for outprob cache */
};

#endif // !defined(AFX_JULIHTKHMMSTATE_H__C2F03B30_7AC4_11D5_9AFA_008098E80572__INCLUDED_)
