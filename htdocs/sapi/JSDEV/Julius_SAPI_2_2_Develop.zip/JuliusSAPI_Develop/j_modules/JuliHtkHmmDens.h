//====================================================================
// JuliHtkHmmDens.h: Htk HMM: Density �I�u�W�F�N�g (HTK_HMM_Dens)
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIHTKHMMDENS_H__C2F03B2F_7AC4_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIHTKHMMDENS_H__C2F03B2F_7AC4_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliHtkHmmSegment.h"

class CJuliHtkHmmVar;
class CJuliHmmInfo;

class CJuliHtkHmmDens : public CJuliHtkHmmSegment
{
public:
	CJuliHtkHmmDens();
	virtual ~CJuliHtkHmmDens();

	void ReadFromFile(CJuliFile &file,CJuliHmmInfo &info);

	void UpdateGconst();	// update_gconst
	// �A�N�Z�b�T
	VECT *GetMeanVect() { return mean; }
	short GetMeanLength() { return meanlen; }
	CJuliHtkHmmVar * GetVar() { return var; }
	LOGPROB GetGconst() { return gconst; }
private:
	VECT *				mean;		/* mean vector */
	short				meanlen;	/* length of above */
	CJuliHtkHmmVar *	var;		/* variance data */
	LOGPROB				gconst;		/* const value for outprob (log scale)*/
						/* gconst = (2pi)^n |(sigma of covariance) */
};

#endif // !defined(AFX_JULIHTKHMMDENS_H__C2F03B2F_7AC4_11D5_9AFA_008098E80572__INCLUDED_)
