//====================================================================
// JuliOutProbGprune.cpp: 
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliDefines.h"
#include "JuliOutProb.h"

#include "JuliHmmInfo.h"
#include "JuliHtkParam.h"

/* OP_calced operations */
int CJuliOutProb::FindInsertPoint(LOGPROB score, int len) // find_insert_point
{
	/* binary search on score */
	int left = 0;
	int right = len - 1;
	int mid;
	
	while (left < right) {
		mid = (left + right) / 2;
		if (OP_calced_score[mid] > score) {
			left = mid + 1;
		} else {
			right = mid;
		}
	}
	return(left);
}

int CJuliOutProb::PushCache(int id, LOGPROB score, int len) // cache_push
{
	int insertp;
//	int i;
	
	if (len == 0) {               /* first one */
		OP_calced_score[0] = score;
		OP_calced_id[0] = id;
		return(1);
	}
	if (OP_calced_score[len-1] >= score) { /* bottom */
		if (len < OP_gprune_num) {          /* append to bottom */
			OP_calced_score[len] = score;
			OP_calced_id[len] = id;
			len++;
		}
		return len;
	}
	if (OP_calced_score[0] < score) {
		insertp = 0;
	} else {
		insertp = FindInsertPoint(score, len);
	}
	if (len < OP_gprune_num) {
		bcopy(&(OP_calced_score[insertp]), &(OP_calced_score[insertp+1]), sizeof(LOGPROB)*(len - insertp));
		bcopy(&(OP_calced_id[insertp]), &(OP_calced_id[insertp+1]), sizeof(int)*(len - insertp));    
	} else if (insertp < len - 1) {
		bcopy(&(OP_calced_score[insertp]), &(OP_calced_score[insertp+1]), sizeof(LOGPROB)*(len - insertp - 1));
		bcopy(&(OP_calced_id[insertp]), &(OP_calced_id[insertp+1]), sizeof(int)*(len - insertp - 1));
	}
	OP_calced_score[insertp] = score;
	OP_calced_id[insertp] = id;
	if (len < OP_gprune_num) len++;
	return(len);
}

/*** beam ***/

/* clear dimthres */
void CJuliOutProb::ClearDimThres() // clear_dimthres
{
	int i;
	for(i=0;i<beam_dimthres_num;i++) beam_dimthres[i] = 0.0;
}

/* set beam dimthres */
void CJuliOutProb::SetDimThres() // set_dimthres
{
	int i;
	for(i=0;i<beam_dimthres_num;i++) beam_dimthres[i] += TMBEAMWIDTH;
}

/* calculate probability while setting max values to dimthres */
LOGPROB CJuliOutProb::ComputeGBeamUpdating(CJuliHtkHmmDens *binfo) // compute_g_beam_updating
{
	VECT tmp, x;
	VECT *mean;
	VECT *var;
	VECT *th = beam_dimthres;
	VECT *vec = OP_vec;
	short veclen = OP_veclen;
	
	if (binfo == NULL) return(LOG_ZERO);
	mean = binfo->GetMeanVect();
	var = binfo->GetVar()->GetVect();
	
	tmp = 0.0;
	for (; veclen > 0; veclen--) {
		x = *(vec++) - *(mean++);
		tmp += x * x / *(var++);
		if ( *th < tmp) *th = tmp;
		th++;
	}
	return(LOGPROB ) ((tmp + binfo->GetGconst()) / -2.0);
}

/* calculate probability with pruning by dimthres thresholds */
LOGPROB CJuliOutProb::ComputeGBeamPruning(CJuliHtkHmmDens *binfo) // compute_g_beam_pruning
{
	VECT tmp, x;
	VECT *mean;
	VECT *var;
	VECT *th = beam_dimthres;
	VECT *vec = OP_vec;
	short veclen = OP_veclen;
	
	if (binfo == NULL) return(LOG_ZERO);
	mean = binfo->GetMeanVect();
	var = binfo->GetVar()->GetVect();
	
	tmp = 0.0;
	for (; veclen > 0; veclen--) {
		x = *(vec++) - *(mean++);
		tmp += x * x / *(var++);
		if ( tmp > *(th++)) {
			return LOG_ZERO;
		}
	}
	return(LOGPROB ) ((tmp + binfo->GetGconst()) / -2.0);
}

/* init */
boolean CJuliOutProb::InitGpruneBeam() // gprune_beam_init
{
	int i;
	/* maximum Gaussian set size = maximum mixture size */
	OP_calced_maxnum = OP_hmminfo->GetMaxMixtureNum();
	OP_calced_score = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * OP_gprune_num);
	OP_calced_id = (int *)J_MALLOC(sizeof(int) * OP_gprune_num);
	mixcalced = (boolean *)J_MALLOC(sizeof(int) * OP_calced_maxnum);
	for(i=0;i<OP_calced_maxnum;i++) mixcalced[i] = FALSE;
	beam_dimthres_num = OP_hmminfo->GetOption().GetVecSize();
	beam_dimthres = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * beam_dimthres_num);
	
	return TRUE;
}

/* compute a set of Gaussians with safe pruning */
void CJuliOutProb::GpruneBeam(CJuliHtkHmmDens **g, int gnum, int *last_id) // gprune_beam
{
	int i, j, num = 0;
	LOGPROB score, thres;
	
	if (last_id != NULL) {	/* compute them first to form thresholds */
		/* 1. clear dimthres */
		ClearDimThres();
		/* 2. calculate first $OP_gprune_num and set initial thresholds */
		for (j=0; j<OP_gprune_num; j++) {
			i = last_id[j];
			score = ComputeGBeamUpdating(g[i]);
			num = PushCache(i, score, num);
			mixcalced[i] = TRUE;      /* mark them as calculated */
		}
		/* 3. set pruning thresholds for each dimension */
		SetDimThres();
		
		/* 4. calculate the rest with pruning*/
		for (i = 0; i < gnum; i++) {
			/* skip calced ones in 1. */
			if (mixcalced[i]) {
				mixcalced[i] = FALSE;
				continue;
			}
			/* compute with safe pruning */
			score = ComputeGBeamPruning(g[i]);
			if (score > LOG_ZERO) {
				num = PushCache(i, score, num);
			}
		}
	} else {			/* in case the last_id not available */
		/* at the first 0 frame */
		/* calculate with safe pruning */
		thres = LOG_ZERO;
		for (i = 0; i < gnum; i++) {
			if (num < OP_gprune_num) {
				score = ComputeGBase(g[i]);
			} else {
				score = ComputeGSafe(g[i], thres);
				if (score <= thres) continue;
			}
			num = PushCache(i, score, num);
			thres = OP_calced_score[num-1];
		}
	}
	OP_calced_num = num;
}


/*** heu ***/


/* initialize backmax */
void CJuliOutProb::InitBackMax() // init_backmax
{
	int i;
	for(i=0;i<backmax_num;i++) backmax[i] = 0;
}

/* sum-up backward to make backmax */
/*                        |
*  0 1 2 ... max-3 max-2 | max-1
*
*  a b c      x      y   | ????
*             |
*             v
*  .....     x+y     y     0.0
*/
void CJuliOutProb::MakeBackMax() // make_backmax
{
	int i;
	backmax[backmax_num-1] = 0.0;
	/* backmax[len-1] = backmax[len-1];*/
	for(i=backmax_num-2;i>=0;i--) {
		backmax[i] += backmax[i+1];
	}
	/*  for(i=0;i<=len;i++) {
    printf("backmax[%d]=%f\n",i,backmax[i]);
}*/
}

/* calculate probability while setting max values to backmax */
LOGPROB CJuliOutProb::ComputeGHeuUpdating(CJuliHtkHmmDens *binfo) // compute_g_heu_updating
{
	VECT tmp, x, sum = 0.0;
	VECT *mean;
	VECT *var;
	VECT *bm = backmax;
	VECT *vec = OP_vec;
	short veclen = OP_veclen;
	
	if (binfo == NULL) return(LOG_ZERO);
	mean = binfo->GetMeanVect();
	var = binfo->GetVar()->GetVect();
	
	tmp = 0.0;
	for (; veclen > 0; veclen--) {
		x = *(vec++) - *(mean++);
		tmp = x * x / *(var++);
		sum += tmp;
		if ( *bm < tmp) *bm = tmp;
		bm++;
	}
	return(LOGPROB ) ((sum + binfo->GetGconst()) / -2.0);
}
/* calculate probability with pruning with backmax heuristics */
LOGPROB CJuliOutProb::ComputeGHeuPruning(CJuliHtkHmmDens *binfo, LOGPROB thres) // compute_g_heu_pruning
{
	VECT tmp, x;
	VECT *mean;
	VECT *var;
	VECT *bm = backmax;
	VECT *vec = OP_vec;
	short veclen = OP_veclen;
	LOGPROB fthres;
	
	if (binfo == NULL) return(LOG_ZERO);
	mean = binfo->GetMeanVect();
	var = binfo->GetVar()->GetVect();
	fthres = (LOGPROB ) (thres * (-2.0));
	
	tmp = 0.0;
	bm++;
	for (; veclen > 0; veclen--) {
		x = *(vec++) - *(mean++);
		tmp += x * x / *(var++);
		if ( tmp + *bm > fthres) {
			return LOG_ZERO;
		}
		bm++;
	}
	return(LOGPROB ) ((tmp + binfo->GetGconst()) / -2.0);
}

/* init */
boolean CJuliOutProb::InitGpruneHeu() // gprune_heu_init
{
	int i;
	/* maximum Gaussian set size = maximum mixture size */
	OP_calced_maxnum = OP_hmminfo->GetMaxMixtureNum();
	OP_calced_score = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * OP_gprune_num);
	OP_calced_id = (int *)J_MALLOC(sizeof(int) * OP_gprune_num);
	mixcalced = (boolean *)J_MALLOC(sizeof(int) * OP_calced_maxnum);
	for(i=0;i<OP_calced_maxnum;i++) mixcalced[i] = FALSE;
	backmax_num = OP_hmminfo->GetOption().GetVecSize() + 1;
	backmax = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * backmax_num);
	
	return TRUE;
}

/* compute a set of Gaussians with safe pruning */
void CJuliOutProb::GpruneHeu(CJuliHtkHmmDens **g, int gnum, int *last_id) // gprune_heu
{
	int i, j, num = 0;
	LOGPROB score, thres;
	
	if (last_id != NULL) {	/* compute them first to form thresholds */
		/* 1. clear backmax */
		InitBackMax();
		/* 2. calculate first $OP_gprune_num with setting max for each dimension */
		for (j=0; j<OP_gprune_num; j++) {
			i = last_id[j];
			score = ComputeGHeuUpdating(g[i]);
			num = PushCache(i, score, num);
			mixcalced[i] = TRUE;      /* mark them as calculated */
		}
		/* 3. set backmax for each dimension */
		MakeBackMax();
		/* 4. calculate the rest with pruning*/
		thres = OP_calced_score[num-1];
		for (i = 0; i < gnum; i++) {
			/* skip calced ones in 1. */
			if (mixcalced[i]) {
				mixcalced[i] = FALSE;
				continue;
			}
			/* compute with safe pruning */
			score = ComputeGHeuPruning(g[i], thres);
			if (score > LOG_ZERO) {
				num = PushCache(i, score, num);
				thres = OP_calced_score[num-1];
			}
		}
	} else {			/* in case the last_id not available */
		/* at the first 0 frame */
		/* calculate with safe pruning */
		thres = LOG_ZERO;
		for (i = 0; i < gnum; i++) {
			if (num < OP_gprune_num) {
				score = ComputeGBase(g[i]);
			} else {
				score = ComputeGSafe(g[i], thres);
				if (score <= thres) continue;
			}
			num = PushCache(i, score, num);
			thres = OP_calced_score[num-1];
		}
	}
	OP_calced_num = num;
}



/*** none ***/

/* calculate probability of a Gaussian density */
LOGPROB CJuliOutProb::ComputeGBase(CJuliHtkHmmDens *binfo) // compute_g_base
{
	VECT tmp, x;
	VECT *mean;
	VECT *var;
	VECT *vec = OP_vec;
	short veclen = OP_veclen;
	
	if (binfo == NULL) return(LOG_ZERO);
	mean = binfo->GetMeanVect();
	var = binfo->GetVar()->GetVect();
	tmp = 0.0;
	for (; veclen > 0; veclen--) {
		x = *(vec++) - *(mean++);
		tmp += x * x / *(var++);
	}
	return(LOGPROB ) ((tmp + binfo->GetGconst()) / -2.0);
}

/* init */
boolean CJuliOutProb::InitGpruneNone() // gprune_none_init
{
	/* maximum Gaussian set size = maximum mixture size */
	OP_calced_maxnum = OP_hmminfo->GetMaxMixtureNum();
	OP_calced_score = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * OP_calced_maxnum);
	OP_calced_id = (int *)J_MALLOC(sizeof(int) * OP_calced_maxnum);
	/* force gprune_num to the max number */
	OP_gprune_num = OP_calced_maxnum;
	return TRUE;
}

/* compute a set of Gaussians with no pruning */
void CJuliOutProb::GpruneNone(CJuliHtkHmmDens **g, int num, int *last_id) /* last_id ignored */ // gprune_none
{
	int i = 0;
	CJuliHtkHmmDens *dens;
	LOGPROB *prob = OP_calced_score;
	int *id = OP_calced_id;
	OP_calced_num = num;
	for(; num >= 1; num--) {
		dens = *(g++);
		if (!dens) continue;	/* skip if density = NULL */
		*(prob++) = ComputeGBase(dens);
		*(id++) = i++;
	}
}


/*** safe ***/

/* calculate probability of a Gaussian density with scalar threshold */
LOGPROB CJuliOutProb::ComputeGSafe(CJuliHtkHmmDens *binfo, LOGPROB thres) // compute_g_safe
{
	VECT tmp, x;
	VECT *mean;
	VECT *var;
	VECT *vec = OP_vec;
	short veclen = OP_veclen;
	VECT fthres = (VECT) (thres * (-2.0));
	
	if (binfo == NULL) return(LOG_ZERO);
	mean = binfo->GetMeanVect();
	var = binfo->GetVar()->GetVect();
	tmp = binfo->GetGconst();
	for (; veclen > 0; veclen--) {
		x = *(vec++) - *(mean++);
		tmp += x * x / *(var++);
		if (tmp > fthres)  return LOG_ZERO;
	}
	return(LOGPROB ) (tmp / -2.0);
}


/* init */
boolean CJuliOutProb::InitGpruneSafe() // gprune_safe_init
{
	int i;
	/* maximum Gaussian set size = maximum mixture size */
	OP_calced_maxnum = OP_hmminfo->GetMaxMixtureNum();
	OP_calced_score = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * OP_gprune_num);
	OP_calced_id = (int *)J_MALLOC(sizeof(int) * OP_gprune_num);
	mixcalced = (boolean *)J_MALLOC(sizeof(int) * OP_calced_maxnum);
	for(i=0;i<OP_calced_maxnum;i++) mixcalced[i] = FALSE;
	return TRUE;
}

/* compute a set of Gaussians with safe pruning */
void CJuliOutProb::GpruneSafe(CJuliHtkHmmDens **g, int gnum, int *last_id) // gprune_safe
{
	int i, j, num = 0;
	LOGPROB score, thres;
	
	if (last_id != NULL) {	/* compute them first to form threshold */
		/* 1. calculate first $OP_gprune_num and set initial threshold */
		for (j=0; j<OP_gprune_num; j++) {
			i = last_id[j];
			score = ComputeGBase(g[i]);
			num = PushCache(i, score, num);
			mixcalced[i] = TRUE;      /* mark them as calculated */
		}
		thres = OP_calced_score[num-1];
		/* 2. calculate the rest with pruning*/
		for (i = 0; i < gnum; i++) {
			/* skip calced ones in 1. */
			if (mixcalced[i]) {
				mixcalced[i] = FALSE;
				continue;
			}
			/* compute with safe pruning */
			score = ComputeGSafe(g[i], thres);
			if (score <= thres) continue;
			num = PushCache(i, score, num);
			thres = OP_calced_score[num-1];
		}
	} else {			/* in case the last_id not available */
		/* not tied-mixture, or at the first 0 frame */
		thres = LOG_ZERO;
		for (i = 0; i < gnum; i++) {
			if (num < OP_gprune_num) {
				score = ComputeGBase(g[i]);
			} else {
				score = ComputeGSafe(g[i], thres);
				if (score <= thres) continue;
			}
			num = PushCache(i, score, num);
			thres = OP_calced_score[num-1];
		}
	}
	OP_calced_num = num;
}
