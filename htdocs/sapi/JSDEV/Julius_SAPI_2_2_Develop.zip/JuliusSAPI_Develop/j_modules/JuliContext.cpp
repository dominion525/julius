//====================================================================
// JuliContext.cpp: �R���e�L�X�g���N���X
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include <windows.h>
#include <math.h> // sqrt
#include <algorithm>
using namespace std;

#include "JuliContext.h"
#include "JuliGlobalOption.h"
#include "JuliBackTrellis.h"
#include "JuliBeamSearch.h"
#include "JuliGrammar.h"
#include "JuliGramNgram.h"
#include "JuliGramDfa.h"
#include "JuliGramSAPI.h"
#include "JuliResultOut.h"
#include "JuliFactoring.h"
#include "JuliRealTimePipeLine.h"
#include "JuliUtil.h"
#include "JuliDecode.h"
#include "JuliDecodeNgram.h"
#include "JuliDecodeDfa.h"
#include "JuliSearchBestfirst.h"

#define DELETE_SAFE(x) if ((x)!=NULL) { delete x; x = NULL; }


// ##############################################################
// # CJuliContextManager
// ##############################################################

// theContextManager �͗B��̎��̂�����
CJuliContextManager theContextManager;

CJuliContextManager::CJuliContextManager()
: m_bInited(0)
{
}

CJuliContextManager::~CJuliContextManager()
{
	// HMM �̍폜
	for (int i=0;i<(int ) m_aHmms.size();i++)
	{
		delete m_aHmms[i];
	}
	// �R���e�L�X�g�̍폜
	for (vector<CJuliContext *>::iterator it = m_apContexts.begin(); it != m_apContexts.end(); it++)
	{
		delete (*it);
	}
}

// �R���e�L�X�g��ǉ�����
// �R���e�L�X�g�� CJuliContext �̔h���N���X�̃C���X�^���X���O���ō쐬���A���̃|�C���^��n��
// �ȉ��A���̃N���X�C���X�^���X�͂��̃N���X�ŊǗ����� (�O���� delete ���Ă͂����Ȃ�)
// ���s����� NULL ��Ԃ�
CJuliContext * CJuliContextManager::AddNewContext(CJuliContext *ctxt, JULISLM slm, CJuliResultOut *ro)
{
	ctxt->Create(slm, ro);

	ctxt->SetHmm(m_aHmms[0]);	// TODO:�Ƃ肠�����Œ�
	if (theOpt.IsGsHmmFileUse())
	{
		ctxt->SetGsHmm(m_aHmms[1]);	// TODO:�Ƃ肠�����Œ�
	}
	// �R���e�L�X�g�I�v�V�������f�t�H���g�ɐݒ�
	ctxt->CopyOptions(theOpt.GetOption());
	// SAPI XML �̏ꍇ�͕��@�A������ǂݍ���ł��珉�����A�������s�����߁A�����ł͂��Ȃ�
	if (slm != JULISLM_SAPIXML)
	{
		if (ctxt->Init() != 0)
		{
			J_ERROR("Failed to Init JuliContext.\n");
			return NULL;
		}
		if (ctxt->Prepare() != 0)
		{
			J_ERROR("Failed to Prepare JuliContext.\n");
			return NULL;
		}
	}
	{
		HANDLE hMutex = ::CreateMutex(NULL, FALSE, "JULIUSSAPI_CONTEXTLIST");	// m_apContexts ��������
		J_DEBUGMESSAGE("<Mu");
		::WaitForSingleObject(hMutex, INFINITE);
		J_DEBUGMESSAGE("t");

		m_apContexts.push_back(ctxt);

		::ReleaseMutex(hMutex);
		J_DEBUGMESSAGE("ex>");
	}
	return ctxt;
}

// �R���e�L�X�g���폜����
int CJuliContextManager::DeleteContext(CJuliContext *ctxt)
{
	HANDLE hMutex = ::CreateMutex(NULL, FALSE, "JULIUSSAPI_CONTEXTLIST");	// m_apContexts ��������
		J_DEBUGMESSAGE("[Mu");
	::WaitForSingleObject(hMutex, INFINITE);
		J_DEBUGMESSAGE("t");

	vector<CJuliContext *>::iterator it = find(m_apContexts.begin(), m_apContexts.end(), ctxt);
	// CJuliContext �C���X�^���X���폜
	delete (*it);
	// �R���e�L�X�g���X�g����G���g�����폜
	m_apContexts.erase(it);

	::ReleaseMutex(hMutex);
		J_DEBUGMESSAGE("ex]");
	return 0;
}

// InitHMM:  theOpt �ɐݒ肵���t�@�C�����ɉ����ēǂݍ���
// m_aHmms[0] �Ɋi�[  GSHMM �� m_aHmms[1] �Ɋi�[
// �����͂Ƃ肠�������̏��ԂŌŒ�
int CJuliContextManager::InitHMM() // initialize_HMM
{
	int retval = 0;	// �Ԃ�l
	J_DEBUGMESSAGE("��InitHMM[this=%p]\n", this);

	// InitHMM �Ăяo���̔r������
	HANDLE hMutex;
	hMutex = ::CreateMutex(NULL, FALSE, "JULIUSSAPI_INITHMM");

	::WaitForSingleObject(hMutex, INFINITE);

	// 2��ȏ�� InitHMM �Ăяo���͖���
	if (m_bInited) goto END;
	m_bInited = 1;

	CJuliHmmInfo *hmm;
	hmm = new CJuliHmmInfo;	// �쐬 (�f�X�g���N�^�ō폜)
	m_aHmms.push_back(hmm);	// ���X�g�ɒǉ�

	/* load hmmdefs */
	int r = hmm->ReadFromFile(theOpt.GetHmmFilename(), theOpt.GetMapFilename());
	if (r != 0)
	{
		// �v���I�ȃG���[
		retval = 1;
		goto END;
	}
	/* check training parameter type */
	/* for direct speech input,
	only MFCC_{0|E}_D_Z[_N] with {25|26} dimension is supported */
	if (theOpt.speech_input != SP_MFCFILE) {
		if ((hmm->GetOption().GetParamType() == CJuliUtil::GetCodeFromStr("MFCC_E_D_Z")
			&& hmm->GetOption().GetVecSize() == 26)
			|| (hmm->GetOption().GetParamType() == CJuliUtil::GetCodeFromStr("MFCC_E_D_N_Z")
			&& hmm->GetOption().GetVecSize() == 25))
		{
			theOpt.c0_required = FALSE;
		} else if ((hmm->GetOption().GetParamType() == CJuliUtil::GetCodeFromStr("MFCC_0_D_Z")
			&& hmm->GetOption().GetVecSize() == 26)
			|| (hmm->GetOption().GetParamType() == CJuliUtil::GetCodeFromStr("MFCC_0_D_N_Z")
			&& hmm->GetOption().GetVecSize() == 25))
		{
			theOpt.c0_required = TRUE;
		} else {
			J_ERROR("Error: for direct speech input, only 25(26)-dim. MFCC_{0|E}_D[_N]_Z is supported\n");
			J_ERROR("Error: with this HMM, input must be given in HTK parameter file via \"-input mfcfile\"\n");
		}
	}
	/* check if tied_mixture */
	if (hmm->IsTiedMixture() && hmm->GetCodeBookNum() <= 0) {
		J_WARNING("%s: this tied-mixture model has no codebook!?\n", EXECNAME);
	}
#ifdef PASS1_IWCD
	/* make state clusters of same context for inter-word triphone approx. */
	if (hmm->IsTriphone()) {
		J_MESSAGE("Making pseudo bi/mono-phone for IW-triphone...");
		if (hmm->MakeCDSet() == FALSE) {
			J_ERROR("\nError: failed to make context-dependent state set\n");
		}
		J_MESSAGE("done\n");
	}
#endif

	/* set flag for context dependent handling (if not specified in command arg)*/
	if (!theOpt.ccd_flag_force) {
		if (hmm->IsTriphone()) {
			theOpt.ccd_flag = TRUE;
		} else {
			theOpt.ccd_flag = FALSE;
		}
	}
	/* set which iwcd1 method to use */

	// �f�t�H���g�� Ngram -> FALSE, others -> TRUE �Ȃ̂ŁA
	// CalcOutProbCd �Ō��݂̃R���e�L�X�g�̕��@����ɂ���Č��߂�悤�ɂ��Ă���
	theOpt.iwcdavg_flag = FALSE;

	if (theOpt.iwcdavg_flag) {
		hmm->SetPreferCdsetAvg(TRUE);
	} else {
		hmm->SetPreferCdsetAvg(FALSE);
	}

	if (theOpt.IsGsHmmFileUse())
	{
		J_MESSAGE("Reading GS HMMs:\n");
		CJuliHmmInfo *hmmgs;
		hmmgs = new CJuliHmmInfo;	// �쐬 (�f�X�g���N�^�ō폜)
		m_aHmms.push_back(hmmgs);	// ���X�g�ɒǉ�

		r = hmmgs->ReadFromFile(theOpt.GetGsHmmFilename(), NULL);
		if (r != 0)
		{
			// �v���I�ȃG���[
			retval = 1;
			goto END;
		}
	}
END:
	::ReleaseMutex(hMutex);
	J_DEBUGMESSAGE("��InitHMM end[this=%p] (retval=%d)\n", this, retval);
	return retval;
}

void CJuliContextManager::OutputDebug()
{
	J_MESSAGE("---------- Contexts State ----------\n");
	if (m_apContexts.size())
	{
		J_MESSAGE("# : DFA NGM SAP ACT RDY \n");
		for (int i=0;i<(int )m_apContexts.size();i++)
		{
			CJuliContext *p = m_apContexts[i];
			J_MESSAGE("%2d: %3s %3s %3s %3s %3s\n",
				i,
				(p->IsDfa())?" o ": " x ",
				(p->IsNgram())?" o ": " x ",
				(p->IsSAPI())?" o ": " x ",
				(p->IsActive())?" o ": " x ",
				(p->IsReady())?" o ": " x "
			);
		}
	} else J_MESSAGE("no JuliContext\n");
	if (m_aHmms.size())
	{
		J_MESSAGE("# : TRI TMX #Stat MaxMx\n");
		for (int i=0;i<(int )m_aHmms.size();i++)
		{
			CJuliHmmInfo *h = m_aHmms[i];
			J_MESSAGE("%2d: %3s %3s %5d %5d\n",
				i,
				(h->IsTriphone())?" o ": " x ",
				(h->IsTiedMixture())?" o ": " x ",
				h->GetTotalStateNum(),
				h->GetMaxMixtureNum()
			);
		}
	} else J_MESSAGE("no HMM\n");

	J_MESSAGE("------------------------------------\n");
}

// ##############################################################
// # CJuliContext
// ##############################################################

CJuliContext::CJuliContext()
: m_pOptions(NULL),
m_pGrammar(NULL),
m_pDict(NULL),
m_pHmmInfo(NULL),
m_pGsHmm(NULL),
m_pBeamSearch(NULL),
m_pBackTrellis(NULL),
m_pOutProb(NULL),
m_pResultOut(NULL),
m_pWCHMM(NULL),
m_pFactoring(NULL),
m_pRTPipeLine(NULL),
m_pDecode(NULL),
m_pSearchBestfirst(NULL),
m_bIsReady(0),
m_bIsActive(0)
{
}

CJuliContext::~CJuliContext()
{
	Delete();
}

void CJuliContext::Create(JULISLM slm, CJuliResultOut *ro)
{
	Delete();
	SetSLMType(slm);

	m_pOptions		= new CJuliOptions;
	switch(GetSLMType())
	{
	case JULISLM_NGRAM:
		J_DEBUGMESSAGE("CJuliContext::Create: JULISLM_NGRAM\n");
		m_pGrammar		= new CJuliGramNgram;
		m_pDecode		= new CJuliDecodeNgram;	m_pDecode->SetContext(this);
		break;
	case JULISLM_DFA:
		J_DEBUGMESSAGE("CJuliContext::Create: JULISLM_DFA\n");
		m_pGrammar		= new CJuliGramDfa;
		m_pDecode		= new CJuliDecodeDfa;	m_pDecode->SetContext(this);
		break;
	case JULISLM_SAPIXML:
		J_DEBUGMESSAGE("CJuliContext::Create: JULISLM_SAPIXML\n");
		m_pGrammar		= new CJuliGramDfa;
		m_pDecode		= new CJuliDecodeDfa;	m_pDecode->SetContext(this);
		break;
	default:
		J_ERROR("Fatal Error: CJuliContext::Create: Unknown Grammar Type\n");
		break;
	}
	m_pDict			= new CJuliDictionary;
	//	m_pHmmInfo, m_pGsHmm �̎��̂͂����ł͍��Ȃ�

	// CJuliContextObject �̔h���N���X
	m_pBeamSearch	= new CJuliBeamSearch;		m_pBeamSearch->SetContext(this);
	m_pBackTrellis	= new CJuliBackTrellis;		m_pBackTrellis->SetContext(this);
	m_pOutProb		= new CJuliOutProb;			m_pOutProb->SetContext(this);
	m_pResultOut	= ro;		m_pResultOut->SetContext(this);
	//	m_pResultOut	= new CJuliResultOut;		m_pResultOut->SetContext(this);
	m_pWCHMM		= new CJuliWordConjHMM;		m_pWCHMM->SetContext(this);
	m_pFactoring	= new CJuliFactoring;		m_pFactoring->SetContext(this);
	m_pRTPipeLine	= new CJuliRealTimePipeLine;	m_pRTPipeLine->SetContext(this);
	m_pSearchBestfirst	= new CJuliSearchBestfirst;	m_pSearchBestfirst->SetContext(this);
}

void CJuliContext::Delete()
{
	J_DEBUGMESSAGE("Deleting JuliContext(%p)[0", this);
	DELETE_SAFE(m_pOptions);
	J_DEBUGMESSAGE("1");
	DELETE_SAFE(m_pGrammar);
	J_DEBUGMESSAGE("2");
	DELETE_SAFE(m_pDict);
	//	DELETE_SAFE(m_pHmmInfo);	�����ŏ����Ȃ����ƁI
	//	DELETE_SAFE(m_pGsHmm);		�����ŏ����Ȃ����ƁI
	J_DEBUGMESSAGE("3");
	DELETE_SAFE(m_pBeamSearch);
	J_DEBUGMESSAGE("4");
	DELETE_SAFE(m_pBackTrellis);
	J_DEBUGMESSAGE("5");
	DELETE_SAFE(m_pOutProb);
	J_DEBUGMESSAGE("6");
	DELETE_SAFE(m_pResultOut);
	J_DEBUGMESSAGE("7");
	DELETE_SAFE(m_pWCHMM);
	J_DEBUGMESSAGE("8");
	DELETE_SAFE(m_pFactoring);
	J_DEBUGMESSAGE("9");
	DELETE_SAFE(m_pRTPipeLine);
	J_DEBUGMESSAGE("A");
	DELETE_SAFE(m_pDecode);
	J_DEBUGMESSAGE("B");
	DELETE_SAFE(m_pSearchBestfirst);
	J_DEBUGMESSAGE("]_OK\n");
}

void CJuliContext::CopyOptions(CJuliOptions &opt)
{
	// �܂邲�ƃR�s�[����
	*m_pOptions = opt;
}

// �R���e�L�X�g�̏�����(���ꃂ�f���̓ǂݍ���)
int CJuliContext::Init()	// final_fusion
{
	J_MESSAGE("��CJuliContext::Init\n");

	// ���ꃂ�f���̓ǂݍ���   initialize_dict
	if (
#ifdef MONOTREE
		/* leave winfo monophone for 1st pass lexicon tree */
		m_pDict->ReadFromFile(m_pOptions->m_strDictFile.c_str(), m_pHmmInfo, TRUE, theOpt.forcedict_flag)
#else 
		m_pDict->ReadFromFile(m_pOptions->m_strDictFile.c_str(), m_pHmmInfo, FALSE, theOpt.forcedict_flag)
#endif
		)
	{
		J_ERROR("ERROR: failed to read dictionary, terminated\n");
		return 1;
	}

	if (IS_NGRAM)
	{
		/* set {head,tail}_silwid */
		m_pDict->SetHeadSilentWordID(m_pDict->LookupWordID(m_pOptions->GetHeadSilentName()));
		if (m_pDict->GetHeadSilentWordID() == WORD_INVALID) { /* not exist */
			J_ERROR("ERROR: head sil word \"%s\" not exist in voca\n", m_pOptions->GetHeadSilentName());
			return 1;
		}
		m_pDict->SetTailSilentWordID(m_pDict->LookupWordID(m_pOptions->GetTailSilentName()));
		if (m_pDict->GetTailSilentWordID() == WORD_INVALID) { /* not exist */
			J_ERROR("ERROR: tail sil word \"%s\" not exist in voca\n", m_pOptions->GetTailSilentName());
			return 1;
		}
	}
#ifdef PASS1_IWCD
	//	if (m_pOptions->triphone_check_flag && m_pHmmInfo->IsTriphone()) {
	//		hmm_check();
	//	}
#endif

	if (IS_NGRAM)
	{
		if (! GetGramNgram()->IsLoaded())
		{
			// NGRAM �t�@�C���̓ǂݍ���  initialize_ngram
			/* load LM */
			int r;
			if (m_pOptions->m_bUseArpaFile == 0) {	/* binary format */
				r = GetGramNgram()->ReadFromFile_Binary(m_pOptions->m_strNgramFile.c_str());
			} else {			/* ARPA format */
				r = GetGramNgram()->ReadFromFile_Arpa(m_pOptions->m_strNgramArpaLRFile.c_str(), m_pOptions->m_strNgramArpaRLFile.c_str());
			}
			if (r != 0)
			{
				// �v���I�ȃG���[
				return 1;
			}

			/* map dict item to N-gram entry */
			GetGramNgram()->MakeVocaRef(m_pDict);
#ifdef CLASS_NGRAM
			initialize_class_ngram();
#endif
		}
	}
	if (IS_DFA)
	{
		// initialize_dfa
		/* load DFA grammar */
		/*
		if (GetGramDfa()->ReadFromFile(m_pOptions->m_strDfaFile.c_str()) != 0)
		{
			// �v���I�ȃG���[
			return 1;
		}
		*/
	}
	J_MESSAGE("��CJuliContext::Init done\n");
	return 0;
}

#ifdef USE_NGRAM
void CJuliContext::SetLmWeight()	// (set_lm_weight)
{
	if (GetHmm()->IsTriphone())
	{
#ifdef PASS1_IWCD
		GetOptions()->lm_weight = 8.0;
		GetOptions()->lm_penalty = -2.0;
#else
		GetOptions()->lm_weight = 9.0;
		GetOptions()->lm_penalty = 8.0;
#endif
	} else {
		GetOptions()->lm_weight = 5.0;
		GetOptions()->lm_penalty = -1.0;
	}
	J_DEBUGMESSAGE("Set Lmp %f,%f\n", GetOptions()->lm_weight, GetOptions()->lm_penalty);
}

void CJuliContext::SetLmWeight2()	// (set_lm_weight2)
{
	if (GetHmm()->IsTriphone()) {
#ifdef PASS1_IWCD
		GetOptions()->lm_weight2 = 8.0;
		GetOptions()->lm_penalty2 = -2.0;
#else  /* no IWCD on 1st pass */
		GetOptions()->lm_weight2 = 11.0;
		GetOptions()->lm_penalty2 = -2.0;
#endif /* PASS1_IWCD */
	} else {
		GetOptions()->lm_weight2 = 6.0;
		GetOptions()->lm_penalty2 = 0.0;
	}
	J_DEBUGMESSAGE("Set Lmp2 %f,%f\n", GetOptions()->lm_weight2, GetOptions()->lm_penalty2);
}
#endif

// �������f���ǂݍ��݌�̏���
int CJuliContext::Prepare()
{
	J_MESSAGE("��CJuliContext::Prepare\n");
	if (IS_DFA)
	{
		// initialize_dfa
		const CJuliHtkHmmLogical *sphmm;
		int i;
		/* map dict item to dfa terminal symbols */
		GetGramDfa()->MakeVocaRef(m_pDict);
		/* set dfa.sp_id and dfa.sp_cid from sp_name */
		J_DEBUGMESSAGE("Short pause Symbol [%s] ", m_pOptions->GetSpName());
		if ((sphmm = GetHmm()->LookupLogical(m_pOptions->GetSpName())) == NULL) {
			J_DEBUGMESSAGE("is not found in logical HMM List.\n");
			GetGramDfa()->SetShortPauseID(WORD_INVALID);
			GetGramDfa()->SetShortPauseCID(WORD_INVALID);
		} else {
			for (i=0;i<m_pDict->GetNumWords();i++)
			{
				if (m_pDict->GetWordLen(i)==1 && m_pDict->GetWordSeq(i)[0] == sphmm) break;
			}
			if (i == m_pDict->GetNumWords()) {	/* not found */
				J_DEBUGMESSAGE("is not found in vocab.\n");
				GetGramDfa()->SetShortPauseID(WORD_INVALID);
				GetGramDfa()->SetShortPauseCID(WORD_INVALID);
			} else {
				J_DEBUGMESSAGE("is found (%d, %d).\n", i, m_pDict->GetWordID(GetGramDfa()->GetShortPauseID()));
				GetGramDfa()->SetShortPauseID(i);
				GetGramDfa()->SetShortPauseCID(m_pDict->GetWordID(GetGramDfa()->GetShortPauseID()));
			}
		}
		/* build catergory-pair information */
		GetGramDfa()->ExtractCategoryPair();
	}
	/* stage 2: fixate params */
	/* set params whose default will change by models and not specified in arg */
	// configure_param
	if (IS_NGRAM)
	{
		/* set default lm parameter */
		if (!m_pOptions->lmp_specified) SetLmWeight();
		else J_DEBUGMESSAGE("Lmp Specified %f,%f\n", GetOptions()->lm_weight, GetOptions()->lm_penalty);
		if (!m_pOptions->lmp2_specified) SetLmWeight2();
		else J_DEBUGMESSAGE("Lmp2 Specified %f,%f\n", GetOptions()->lm_weight2, GetOptions()->lm_penalty2);
		if (m_pOptions->lmp_specified != m_pOptions->lmp2_specified) {
			J_WARNING("Warning: only -lmp or -lmp2 specified, LM weights may be unbalanced\n");
		}
	}	
	/* select Gaussian pruning function */
	if (m_pOptions->gprune_method == GPRUNE_SEL_UNDEF) {/* set default if not specified */
		if (m_pHmmInfo->IsTiedMixture()) {
#ifdef GPRUNE_DEFAULT_SAFE
			m_pOptions->gprune_method = GPRUNE_SEL_SAFE;
#elif GPRUNE_DEFAULT_HEURISTIC
			m_pOptions->gprune_method = GPRUNE_SEL_HEURISTIC;
#elif GPRUNE_DEFAULT_BEAM
			m_pOptions->gprune_method = GPRUNE_SEL_BEAM;
#endif
		} else {
			/* currently, pruning is available for only tied-mixture model */
			m_pOptions->gprune_method = GPRUNE_SEL_NONE;
		}
	}

	/* stage 3: build lexicon tree */

#ifdef CATEGORY_TREE
	if (old_tree_function_flag) {
		GetWCHMM()->Build();
	} else {
		GetWCHMM()->BuildFast();
	}
#else
	GetWCHMM()->BuildFast();
#endif /* CATEGORY_TREE */

	/* guess beam width from models, when not specified */
	if (GetOptions()->trellis_beam_width <= 0)
	{
		// set_beam_width
		int standard_width;
		if (GetOptions()->trellis_beam_width == 0) {
			J_DEBUGMESSAGE("doing full search\n");
			J_DEBUGMESSAGE("Warning: no routine for full search. use beam routine with full beam width\n");
			J_DEBUGMESSAGE("Warning: this will be extremely slow\n");
			GetOptions()->trellis_beam_width = GetWCHMM()->GetNumStates();
		} else {
			standard_width = GetHmm()->GetDefaultBeamWidth();
			GetOptions()->trellis_beam_width = (int )(sqrt(GetWCHMM()->GetNumStates()) * 15);
			if (GetOptions()->trellis_beam_width > standard_width)
				GetOptions()->trellis_beam_width = standard_width;
		}
		J_DEBUGMESSAGE("trellis_beam_width is now set to %d\n", GetOptions()->trellis_beam_width);
	} else {
		J_DEBUGMESSAGE("trellis_beam_width is specified %d\n", GetOptions()->trellis_beam_width);
	}
	if (GetOptions()->trellis_beam_width > GetWCHMM()->GetNumStates())
		GetOptions()->trellis_beam_width = GetWCHMM()->GetNumStates();

#ifdef MONOTREE
	/* after building tree lexocon, */
	/* convert monophone to triphone in winfo for 2nd pass */
	if (hmminfo->is_triphone) {
		J_MESSAGE("convert monophone dictionary to word-internal triphone...");
		if (voca_mono2tri(&winfo, &hmminfo) == FALSE) {
			J_ERROR("failed\n");
		}
		J_MESSAGE("done\n");
	}
#endif
	/* stage 4: setup output function */
	if (theOpt.IsGsHmmFileUse())
	{/* with GMS */
		m_pOutProb->Init(m_pHmmInfo, m_pGsHmm, m_pOptions->gs_statenum, m_pOptions->gprune_method, m_pOptions->mixnum_thres);
	} else {
		m_pOutProb->Init(m_pHmmInfo, NULL, 0, m_pOptions->gprune_method, m_pOptions->mixnum_thres);
	}

	/* stage 5: initialize work area and misc. */
	//  �R���X�g���N�^�ł��̂ŕs�v bt_init(&backtrellis);	/* backtrellis initialization */
	if (IS_NGRAM)
	{
		GetFactoring()->InitMaxSuccessorCache();	/* initialize cache for factoring */
	}
	if (theOpt.realtime_flag) {
		// 
		J_DEBUGMESSAGE("m_pRTPipeLine RealTimeInit\n");
		m_pRTPipeLine->RealTimeInit();
	}
	/* setup result output function */
	//  select_result_output();
	J_MESSAGE("��CJuliContext::Prepare done\n");
	return 0;
}

//--------------------------------------------------------------------
// �R���e�L�X�g���s
//--------------------------------------------------------------------

// 1st pass ���s����
void CJuliContext::DoPrepare1st(bool fRealTime)
{
	SetReady(0);
	if (!IsActive())
		return;

	if (fRealTime)
		GetRealTimePipeLine()->RealTimePipeLinePrepare();
	GetResultOut()->Clear();
	SetReady(1);
	ClearHypoCount();
}

// 1st pass ���A���^�C�����s
int CJuliContext::Do1stRealtime(SP16 *buf, int len)
{
	if (!IsActive())
		return 0;
	if (!IsReady())
	{
		J_DEBUGMESSAGE("DoPrepare1st in Do1stRealtime...\n");
		DoPrepare1st(true);	// ����Ȃ��Ƃł��邩�H
		J_DEBUGMESSAGE("DoPrepare1st in Do1stRealtime Ok\n");
	}
//    J_DEBUGMESSAGE("��Do1stRealtime(%p, %d)\n", this, len);	
	return GetRealTimePipeLine()->RealTimePipeLine(buf, len);
}

// 1st pass ���ʎ擾
void CJuliContext::DoParam()
{
	if (!IsReady())
		return;
	if (!IsActive())
		return;
    J_DEBUGMESSAGE("��DoParam(%p)\n", this);	
	m_param = GetRealTimePipeLine()->RealTimeParam(&m_backmax);
}

// 2nd pass ���s
void CJuliContext::Do2nd()
{
	if (!IsReady())
		return;
	if (!IsActive())
		return;
	CJuliOptions *opt = GetOptions();
	J_DEBUGMESSAGE("��Do2nd(this=%p, param=%p, backmax=%f)\n", this, m_param, m_backmax);	

	if (m_backmax == LOG_ZERO)
	{
		J_MESSAGE("Terminate 2nd pass.\n");
		GetResultOut()->Final2((NODE *)NULL, 1, NULL);/* print NULL result */
		return;
	}

#ifdef SCAN_BEAM
	/* prepare score envelope for 2nd pass */
	opt->framemaxscore = (LOGPROB *)J_MALLOC(sizeof(LOGPROB)*GetBackTrellis()->GetFrameLen());
	GetSearchBestfirst()->EnvlInit(GetBackTrellis()->GetFrameLen());
#endif /* SCAN_BEAM */

#ifndef PASS2_STRICT_IWCD
	/* adjust trellis score not to contain outprob of the last frames */
	GetBackTrellis()->DiscountPEScore(m_param, *GetWCHMM());
#endif

	if (IsSAPI())
	{
		J_VERMES("### Recognition: 2nd pass (RL heuristic best-first with DFA SAPI)\n");
	} else {
		if (IsNgram())
		{
			J_VERMES("### Recognition: 2nd pass (RL heuristic best-first with 3-gram)\n");
		}
		if (IsDfa())
		{
			J_VERMES("### Recognition: 2nd pass (RL heuristic best-first with DFA)\n");
		}
	}
	// �X�^�b�N�f�R�[�f�B���O�T���̎��s
	int nb = (theOpt.m_bUseNbest)? theOpt.m_iNbest : (theOpt.m_bUseFalseRecognition)? 2 :1;
	GetSearchBestfirst()->Start(m_param, m_backmax, opt->stack_size,
		nb, opt->hypo_overflow);

#ifdef SCAN_BEAM
	J_FREE(opt->framemaxscore);
#endif
}
