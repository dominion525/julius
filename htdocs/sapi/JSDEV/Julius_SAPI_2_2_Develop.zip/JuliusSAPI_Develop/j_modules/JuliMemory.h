//====================================================================
// JuliMemory.h: �������擾�N���X(���C�u����)
//--------------------------------------------------------------------
// Copyright (c) 1991-2000 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIMEMORY_H__71BEDA24_624B_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIMEMORY_H__71BEDA24_624B_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CJuliMemory  
{
public:
	CJuliMemory() {}
	virtual ~CJuliMemory() {}

	void * Malloc(int size);
	void * MallocD(const char *filename, int line, int size);
	void Free(void *p);
	void FreeD(const char *filename, int line, void *p);

	void * Realloc(void *ptr, int size);
	void * Calloc(int nelem, int elsize);
	void ** MallocArray(int size1,int size2,int elmsize);
	void FreeArray(void **p);
	char * StrDup(const char *s);
};

extern CJuliMemory theJuliMemory;

#endif // !defined(AFX_JULIMEMORY_H__71BEDA24_624B_11D5_9AFA_008098E80572__INCLUDED_)
