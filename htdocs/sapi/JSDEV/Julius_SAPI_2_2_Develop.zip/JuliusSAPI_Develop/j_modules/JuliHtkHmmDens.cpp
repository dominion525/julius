//====================================================================
// JuliHtkHmmDens.cpp: Htk HMM: Density �I�u�W�F�N�g (HTK_HMM_Dens)
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliHmmInfo.h"
#include <math.h>

CJuliHtkHmmDens::CJuliHtkHmmDens() : meanlen(0), mean(NULL), var(NULL), gconst(0.0) {}

CJuliHtkHmmDens::~CJuliHtkHmmDens()
{
	if (mean != NULL) delete mean;
	// var �͂����ŉ�����Ă͂����Ȃ�
	// (CJuliHmmInfo::ReadVarSegment �Q��)
}

void CJuliHtkHmmDens::UpdateGconst()
{
	int i;
	gconst = var->GetLength() * LOGTPI;
	for (i=0;i<var->GetLength();i++)
	{
		gconst += log(var->GetVec(i));
	}
}

void CJuliHtkHmmDens::ReadFromFile(CJuliFile &file,CJuliHmmInfo &info)
{
	int i;

	/* read regression class ID (just skip) */
	if (file.CurrentTokenIs("RCLASS"))
	{
		file.GetHmmToken();
		file.NoTokenError("no RCLASS arg");
		file.GetHmmToken();
	}
	/* read mean vector */
	if (!file.CurrentTokenIs("MEAN"))
		file.HmmError("<MEAN> not found");
	file.GetHmmToken();
	file.NoTokenError("MEAN vector length not found");
	meanlen = atoi(file.CurrentToken());
	file.GetHmmToken();
	mean = new VECT[meanlen];
	/* needs comversion if integerized */
	for (i=0;i<meanlen;i++) {
		file.NoTokenError("missing MEAN element");
		mean[i] = atof(file.CurrentToken());
		file.GetHmmToken();
	}
	/* read covariance matrix data */
	var = info.ReadVarSegment(file);	// ���̂̊Ǘ��� CJuliHmmInfo::m_sdbVar ������
	if ((var)->GetLength() != meanlen) {
		file.HmmError("mean vector length != variance vector len");
	}
	/* read GCONST if any */
	if (file.CurrentTokenIs("GCONST")) {
		file.GetHmmToken();
		file.NoTokenError("GCONST found but no value");
		gconst = atof(file.CurrentToken());
		file.GetHmmToken();
	} else {
		/* calc */
		UpdateGconst();
	}
}
