//====================================================================
// JuliHMM.cpp: CJuliHMM �N���X�̃C���v�������e�[�V����
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliHMM.h"

/* mkwhmm.c --- make word(phrase) HMM from CJuliHtkHmmInfo */
/* initial & accept arc will be stripped */
/* trans prob to accept state will be stored in accept_ac_a */

CJuliHMM::CJuliHMM(CJuliHmmInfo *hmminfo, const CJuliHtkHmmLogical **hdseq, int hdseqlen) // new_make_word_hmm
{
	MakeWordHmmWithLm(hmminfo, hdseq, hdseqlen, NULL);
}

CJuliHMM::~CJuliHMM() // free_hmm
{
	A_CELL *ac, *atmp;
	int i;
	
	for (i=0;i<len;i++) {
		ac = state[i].ac;
		while (ac) {
			atmp = ac->next;
			J_FREE(ac);
			ac = atmp;
		}
	}
	J_FREE(state);
}

int CJuliHMM::GetTotalStateLen(const CJuliHtkHmmLogical **hdseq, int hdseqlen) const// totalstatelen
{
	int i, len;
	
	len = 0;
	for (i=0;i<hdseqlen;i++) {
		len += hdseq[i]->GetStateNum() - 2;
	}
	return(len);
}

void CJuliHMM::AddArc(HMM_STATE *state, int arc, LOGPROB a) // add_arc
{
	A_CELL *atmp;
	
	atmp = (A_CELL *)J_MALLOC(sizeof(A_CELL));	// TODO: leak!
	atmp->a = a;
	atmp->arc = arc;
	atmp->next = state->ac;
	state->ac = atmp;
}

/* make word(phrase) HMM from CJuliHmmInfo */
/* new HMM is malloced and returned */
void CJuliHMM::MakeWordHmmWithLm(CJuliHmmInfo *hmminfo, const CJuliHtkHmmLogical **hdseq, int hdseqlen,
								 LOGPROB *lscore) // new_make_word_hmm_with_lm
{
	int i,j,n;
	int afrom, ato;
	LOGPROB logprob;
//	CJuliHtkHmmData *dt;
	const CJuliHtkHmmTrans *tr;
	int state_num;
	
	len = GetTotalStateLen(hdseq, hdseqlen);
	state = (HMM_STATE *)J_MALLOC(sizeof(HMM_STATE) * len);	// TODO: leak!
	for (i=0;i<len;i++) {
		state[i].ac = NULL;
		state[i].is_pseudo_state = FALSE;
		state[i].out.state = NULL;
		state[i].out.cdset = NULL;
	}
	
	/* assign state outprob info  */
	n = 0;
	for (i = 0; i < hdseqlen; i++) {
		if (hdseq[i]->IsPseudo()) {
			for (j = 1; j < hdseq[i]->GetPseudo()->state_num - 1; j++) {
				state[n].is_pseudo_state = TRUE;
				state[n].out.cdset = &(hdseq[i]->GetPseudo()->stateset[j]);
				n++;
			}
		} else {
			for (j = 1; j < hdseq[i]->GetBodyDefined()->GetStateNum() - 1; j++) {
				state[n].is_pseudo_state = FALSE;
				state[n].out.state = hdseq[i]->GetBodyDefined()->GetState(j);
				n++;
			}
		}
	}
	
	/* make transition arcs */
	/* initial state check */
	/* 
	*   for (i=0;i<hdseq[0]->def->state_num;i++) {
	*     if (i != 1 && (hdseq[0]->def->tr->a[0][i]) != LOG_ZERO) {
	*	 j_printerr("initial state contains more than 1 arc.\n");
	*     }
	*   }
	*/
	accept_ac_a = LOG_ZERO;
	n = 0;
	for (i = 0; i < hdseqlen; i++) {
		state_num = hdseq[i]->GetStateNum();
		tr = hdseq[i]->GetTrans();
		for (afrom = 1; afrom < state_num - 1; afrom++) {
			for (ato = 1; ato < state_num; ato++) {
				logprob = tr->GetArcTransProb(afrom, ato);
				if (logprob != LOG_ZERO) {
					if (ato == state_num - 1 && lscore != NULL){
						logprob += lscore[i];
					}
					if (n + (ato - afrom) >= len) { /* arc to accept node */
						if (accept_ac_a != LOG_ZERO) {
							J_ERROR("more than 1 arc to accept node found.\n");
						} else {
							accept_ac_a = logprob;
						}
					} else {
						AddArc(&(state[n]), n + (ato - afrom), logprob);
					}
				}
			}
			n++;
		}
	}
}


