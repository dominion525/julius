//====================================================================
// JuliHtkHmmState.cpp: Htk HMM: State �I�u�W�F�N�g (HTK_HMM_State)
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliHmmInfo.h"
#include <math.h>

CJuliHtkHmmState::CJuliHtkHmmState() : mix_num(0), b(NULL), bweight(NULL), id(0) {}

CJuliHtkHmmState::~CJuliHtkHmmState()
{
	// �J��
	if (b != NULL)
	{
/*		for (int i=0;i<mix_num;i++)
			if (b[i]!=NULL) delete b[i];*/
		delete b;
	}
	if (bweight != NULL) delete bweight;
}

void CJuliHtkHmmState::ReadFromFile(CJuliFile &file,CJuliHmmInfo &info)
{
	int mid;
	int i;
	if (file.CurrentTokenIs("NUMMIXES")) {
		file.GetHmmToken();
		file.NoTokenError("missing NUMMIXES value");
		mix_num = atoi(file.CurrentToken());
		file.GetHmmToken();
	} else {
		mix_num = 1;
	}
	if (file.CurrentTokenIs("TMIX")) {
		file.GetHmmToken();
		/* read in TMIX */
		info.ReadTmix(file,this);
	} else {
		
		b = new CJuliHtkHmmDens * [mix_num];
		bweight = new PROB[mix_num];
		for (i=0;i<mix_num;i++) {
			b[i] = NULL;
			bweight[i] = LOG_ZERO;
		}
		if (mix_num == 1) {
			mid = 0;
			bweight[mid] = 0.0;
			b[mid] = info.ReadDensSegment(file);
		} else {
			for (;;) {
				if (!file.CurrentTokenIs("MIXTURE")) break;
				file.GetHmmToken();
				file.NoTokenError("missing MIXTURE id");
				mid = atoi(file.CurrentToken()) - 1;
				file.GetHmmToken();
				file.NoTokenError("missing MIXTURE weight");
				bweight[mid] = log(atof(file.CurrentToken()));
				file.GetHmmToken();
				b[mid] = info.ReadDensSegment(file);
			}
		}
	}
#if 0
	/* diabled */
	for (i=0;i<mix_num;i++) {
		/* make error if no mixture was associated */
		if (b[i] == NULL) {
			J_ERROR("Warning: lack of mixture component found, use previous insted...\n");
			b[i] = b[i-1];
		}
	}
#endif
}
