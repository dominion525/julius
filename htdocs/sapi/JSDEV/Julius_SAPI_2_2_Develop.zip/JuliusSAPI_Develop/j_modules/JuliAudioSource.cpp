//====================================================================
// JuliAudioSource.cpp: �I�[�f�B�I���������A�������[�e�B���Ȃǂ��R�[���o�b�N����
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Speech Media Lab. Kyoto University     All rights reserved
//====================================================================

#include "JuliAudioSource.h"
#include "../j_modules/JuliGlobalOption.h"

CJuliAudioSource::CJuliAudioSource()
:
m_iPauseSegmentation(0),
m_iThreadUse(0),
c_length(5000),
c_offset(0),
wstep(DEFAULT_WSTEP),
buffer(NULL),
m_funcProcess(NULL),
m_pAudioSaver(NULL),
lastdata(NULL)
{
}

CJuliAudioSource::~CJuliAudioSource()
{
	J_FREE(buffer);
	J_FREE(lastdata);
}

/* return value: -1 on error, 0 on end of stream, >0 on segmented */
/* return on segment, error.  run forever when threaded */
int CJuliAudioSource::adin_cut()
{
	int ad_process_ret;
	int imax, stlen, cnt;

	/*
	* there are 3 buffers:
	*   temporary storage queue: buffer[]
	*   cycle buffer for zero-cross counting: (in zc_e)
	*
	* Each samples are first read to buffer[], then passed to count_zc_e()
	* to find trigger.  Samples between trigger and end of speech are 
	* passed to (*ad_process) with pointer to the first sample and its length.
	*
	*/
	if (buffer == NULL) {		/* beginning of stream */
		buffer = (SP16 *)J_MALLOC(sizeof(SP16) * MAXSPEECHLEN);
		bpmax = MAXSPEECHLEN;
		bp = 0;
		/* reset zero-cross status */
		if (adin_cut_on) {
			m_jzc.Init(thres, c_length, c_offset);
			is_valid_data = FALSE;
		}
		ending = FALSE;
		wstep = DEFAULT_WSTEP;
		nc = 0;
		if (adin_cut_on) pre_length = c_length;
	}
	if (lastdata == NULL) {
		lastdata = (SP16 *)J_MALLOC(sizeof(SP16) * c_length);
	}

	/* resume input */
	OnStartAudioCut();

	// adin_cut_on �Ő؂�o�����Ȃ��ꍇ�̓T�E���h�J�n�����o�����ŏ�����Ă�
	if (! adin_cut_on)
	{
		OnStartSound(0);
	}

	//	if (OnResume() == FALSE) return -1;

	/* ---------------------------------------------- */
	/* main loop */
	for (;;) {

		/* Read samples as 16bit shorts (SP16) */
		/* bp: pointer to samples left in queue buffer */
		/* all samples in device are read at offset [bp] -> [0..len-1] */
		if (ending) {		/* already reaches end of stream */
			/* just return */
			current_len = bp;
		} else {
			/* read as much samples as possible */
			/* returns: -2 on error, -1 on end of stream, >=0 num of read samples */
			cnt = Read(&(buffer[bp]), bpmax - bp);
			//			J_DEBUGMESSAGE("bp=%d bpmax=%d cnt=%d\n", bp, bpmax, cnt);
			if (cnt < 0) {		/* end of stream or error */
				if (cnt == -2) end_status = -1; /* error */
				else if (cnt == -1) end_status = 0; /* end of stream */
				ending = TRUE;		/* mark as end of stream */
				cnt = 0;			/* no new input */
				/* in case the first ad_read() fails */
				if (bp == 0) break;
			}
			/* strip off invalid samples */
			if (cnt > 0) {
				if (strip_flag) {
					stlen = m_jzc.StripZero(&(buffer[bp]), cnt);
					if (stlen != cnt) cnt = stlen;
				}
			}
			/* len = current samples in buffer */
			current_len = bp + cnt;
		}
#ifdef THREAD_DEBUG
		printf("input: get %d samples\n", current_len - bp);
#endif	    

		/* set process step */
		if (ending && wstep > current_len) wstep = current_len;

		/* set maximum number of processed samples per loop */
#ifdef HAVE_PTHREAD
		if (enable_thread) imax = current_len; /* store as many as possible */
		else imax = (current_len < wstep) ? current_len : wstep;
#else
		imax = (current_len < wstep) ? current_len : wstep;
#endif

		// bp			�ǂݍ��݊J�n�n�_
		// bpmax		�o�b�t�@�ɓǂ߂�ő�T���v����
		// cnt			read �œǂݍ��񂾃T���v����
		// current_len	�o�b�t�@�ɂ���T���v���� (bp + cnt)
		// wstep		���X�e�b�v
		// imax			�����I���n�_

		// 0   bp               current_len        bpmax
		// |****|*********************|--------------|
		//      |<--      cnt      -->|
		//                            ��
		//                        [m_ullEnd]

		// A: current_len < wstep �̂Ƃ�   while ���[�v�ɓ���Ȃ�
		// |<--       imax         -->|
		// |<--          wstep        -->|

		// B: current_len >= wstep �̂Ƃ�
		// |<--     wstep, imax    -->|
		// |                          |
		//      

		// zc

		/* proceed for each 'wstep' steps */
		int i = 0;
		while (i + wstep <= imax) {
			if (adin_cut_on) {
				/* count zero-cross and flip switches */
				/* swap samples in buffer to that of (length) step ago */
				zc = m_jzc.Count(&(buffer[i]), wstep);
				if (zc > noise_zerocross) {
					nc = 0;
					if (is_valid_data == FALSE) {
						// �L���ȉ��������o�����̂Œʒm
						// �܂��Ō�ɓǂݍ��񂾏ꏊ���� (current_len - i) �T���v���c���Ă��邱�Ƃ�ʒm
						OnStartSound(current_len - i);
						is_valid_data = TRUE;   /* start to record */
						if (m_pAudioSaver)
						{
							m_pAudioSaver->Start();
						}
					}
				} else if (is_valid_data == TRUE) {
					/* processing tailing silence */
					nc++;
				}
				if (is_valid_data == FALSE)
				{
					// ���������o����Ă��Ȃ��ꏊ��ʒm���ASynchronize������
					OnSilent(current_len - (i+wstep));
				}
			}
			if(
				(!adin_cut_on || (is_valid_data == TRUE && pre_length <= 0))
#ifdef HAVE_PTHREAD
				&& (!enable_thread || transfer_online)
#endif
				) {
					/* store data */
					if ( m_funcProcess != NULL ) {
						if (m_pAudioSaver)
						{
							m_pAudioSaver->Write((char *)&(buffer[i]), wstep * 2);
						}
						/* call external function */
						ad_process_ret = (*m_funcProcess)(&(buffer[i]),  wstep, m_ptrProcess);
						switch(ad_process_ret) {
					case 1:		/* segmented by ad_process() */
						Purge(i+wstep);
						end_status = 1;
#ifdef HAVE_PTHREAD
						if (enable_thread) { /* just stop transfer */
							pthread_mutex_lock(&mutex);
							transfer_online = FALSE;
							pthread_mutex_unlock(&mutex);
						} else {
							goto break_input;
						}
#else
						goto break_input;
#endif
					case -1:		/* error */
						end_status = -1;
						goto break_input;
						}
					}
				}
				if (adin_cut_on && is_valid_data && nc >= nc_max) {
					/* end input */
					is_valid_data = FALSE;
#if 1
					if ( m_funcProcess != NULL ) {
						/* process samples in cycle buffer */	  
						m_jzc.CopyBuffer(lastdata, c_length);	/* process them but keep */
						if (m_pAudioSaver)
						{
							m_pAudioSaver->Write((char *)&(lastdata[pre_length]), (c_length-pre_length) * 2);
						}
						/* last [pre_length] samples in buffer is invalid */
						ad_process_ret = (*m_funcProcess)(&(lastdata[pre_length]),  c_length-pre_length, m_ptrProcess);
						J_DEBUGMESSAGE("End Input: c_length=%d pre_length=%d wstep=%d ad_process_ret=%d\n",
							c_length,pre_length,wstep,ad_process_ret);
						switch(ad_process_ret) {
							/*case 1:
							end_status = 1;
							adin_purge(i+wstep);
							goto break_input;*/
					case -1:		/* error */
						end_status = -1;
						goto break_input;
						}
					}
#endif
					Purge(i+wstep);
					end_status = 1;
#ifdef HAVE_PTHREAD
					if (enable_thread) { /* just stop transfer */
						pthread_mutex_lock(&mutex);
						transfer_online = FALSE;
						pthread_mutex_unlock(&mutex);
					} else {
						goto break_input;
					}
#else
					goto break_input;
#endif
				}
				if (adin_cut_on) {
					if (pre_length > 0) {
						pre_length -= wstep;
						if (pre_length < 0) pre_length = 0;
					}
				}

				i += wstep;
		}

		/* purge processed samples and update queue */
		Purge(i);

		/* end of input by end of stream */
		if (ending && bp == 0) {
			if (adin_cut_on && is_valid_data) {
				/* flush samples in cycle buffer */
				if (adin_cut_on) zc = m_jzc.Count(buffer, c_length);
				if ( m_funcProcess != NULL ) {
					/* first [pre_length] samples in buffer is invalid when short input */
					ad_process_ret = (*m_funcProcess)(&(buffer[pre_length]),  c_length-pre_length, m_ptrProcess);
					J_DEBUGMESSAGE("End Input by end of Stream: c_length=%d pre_length=%d wstep=%d ad_process_ret=%d\n",
						c_length,pre_length,wstep,ad_process_ret);
					switch(ad_process_ret) {
					case 1:		/* segmented */
						end_status = 1;
						goto break_input;
					case -1:		/* error */
						end_status = -1;
						goto break_input;
					}
				}
			}
			break;
		}
	}

break_input:
	/* pause transfer */

	/*  if (OnPause() == FALSE) {
	J_ERROR("Error: failed to pause recording\n");
	end_status = -1;
	}
	*/
	OnEndAudioCut();

	if (ending) {			/* input already ends */
		if (bp == 0) {		/* rest buffer flushed */
			/* reset status */
			if (adin_cut_on) m_jzc.Release();
			J_FREE(buffer);
			buffer = NULL;
		}
		end_status = (bp) ? 1 : 0;
	}

	if (m_pAudioSaver)
	{
		m_pAudioSaver->End();
	}
	return(end_status);
}




#ifdef HAVE_PTHREAD  // ***************************************************************************
/* threading:
thread 1 = input & cut, adin_cut with store_buffer callback()
thread 2 = process, watch stored buffer and process with ad_process() 
*/
/* call-back for storing triggered samples in thread 1 */

int CJuliAudioSource::adin_store_buffer(SP16 *now, int len)
{
	if (speechlen + len > MAXSPEECHLEN) {
		j_printerr("Warning: too long input (> %d samples), segmented now\n", MAXSPEECHLEN);
		return(1);			/* force segment */
	}
	pthread_mutex_lock(&mutex);
	memcpy(&(speech[speechlen]), now, len * sizeof(SP16));
	speechlen += len;
	pthread_mutex_unlock(&mutex);
#ifdef THREAD_DEBUG
	printf("input: stored %d samples, total=%d\n", len, speechlen);
#endif
	/* output progress bar in dots */
	/*if ((++dotcount) % 3 == 1) j_printerr(".");*/
	return(0);			/* continue */
}

/* thread 1 top function */
void CJuliAudioSource::adin_thread_input_main(void *dummy)
{
	adin_cut(adin_store_buffer);
}

/* create thread 1 for adin-cut */
void CJuliAudioSource::adin_thread_create()
{
	/* init storing buffer */
	speechlen = 0;
	speech = (SP16 *)J_MALLOC(sizeof(SP16) * MAXSPEECHLEN);

	transfer_online = FALSE; /* tell adin-mic thread to wait */

	pthread_mutex_init(&(mutex), NULL);
	pthread_create(&adin_thread, NULL, (void *)adin_thread_input_main, NULL);
	pthread_detach(adin_thread); /* not join, run forever */
	j_printerr("AD-in thread created\n");
}

int CJuliAudioSource::adin_thread_process(int (*ad_process)(SP16 *, int))
{
	int prev_len, nowlen;
	int ad_process_ret;
	int end_status;

	/* reset storing buffer --- input while recognition will be ignored */
	pthread_mutex_lock(&mutex);
	if (speechlen == 0) transfer_online = TRUE; /* tell adin-mic thread to start recording */
#ifdef THREAD_DEBUG
	printf("process: reset, speechlen = %d, online=%d\n", speechlen, transfer_online);
#endif
	pthread_mutex_unlock(&mutex);

	j_printerr("<<< please speak >>>");

	/* main processing loop */
	prev_len = 0;
	for(;;) {
		/* get current length (locking) */
		pthread_mutex_lock(&mutex);
		nowlen = speechlen;
		pthread_mutex_unlock(&mutex);
		if (prev_len < nowlen) {
#ifdef THREAD_DEBUG
			printf("process: proceed [%d-%d]\n",prev_len, nowlen);
#endif
			if (prev_len == 0) {	/* first trigger */
				/* flush prompt */
				j_printerr("\r                    \r");
			}
			/* got new sample, process */
			/* As the speech[] buffer is monotonously increase,
			content of speech buffer [prev_len..nowlen] would not alter
			in both threads
			So locking is not needed while processing.
			*/
			/*printf("main: read %d-%d\n", prev_len, nowlen);*/
			if (ad_process != NULL) {
				ad_process_ret = (*ad_process)(&(speech[prev_len]),  nowlen - prev_len);
#ifdef THREAD_DEBUG
				printf("ad_process_ret=%d\n",ad_process_ret);
#endif
				switch(ad_process_ret) {
				case 1:			/* segmented */
					/* segmented by callback function */
					/* purge processed samples and keep transfering */
					pthread_mutex_lock(&mutex);
					if(speechlen > nowlen) {
						memmove(buffer, &(buffer[nowlen]), (speechlen - nowlen) * sizeof(SP16));
						speechlen = speechlen - nowlen;
					} else {
						speechlen = 0;
					}
					pthread_mutex_unlock(&mutex);
					/* keep transfering */
					return(1);		/* return with segmented status */
				case -1:		/* error */
					return(-1);		/* return with error */
				}
			}
			prev_len = nowlen;
		} else {
			if (transfer_online == FALSE) {
				/* segmented by zero-cross */
				/* reset storing buffer for next input */
				pthread_mutex_lock(&mutex);
				speechlen = 0;
				pthread_mutex_unlock(&mutex);
				break;
			}
			usleep(100000);   /* wait = 0.1sec*/            
		}
	}

	/* as threading assumes infinite input */
	/* return value should be 1 (segmented) */
	return(1);
}
#endif /* HAVE_PTHREAD */

void CJuliAudioSource::Init() // adin_initialize
{
	//	char *arg;

	if (theOpt.speech_input == SP_MFCFILE) return;

	J_VERMES("###### initialize input device\n");

	/* select input */
	/*	if (adin_select(theOpt.speech_input) == FALSE) {
	J_ERROR("Error: invalid input device\n");
	}*/
	enable_thread = TRUE;

	// �}�C�N���͂̓f�t�H���g��TRUE
	segment_default = TRUE;

	/* set device-dependent param (argument is device-dependent) */
	switch(theOpt.speech_input) {
	case SP_ADINNET:
		//	  arg = (char *)J_BMALLOC(100);
		//    sprintf(arg, "%d", adinnet_port);
		break;
	case SP_RAWFILE:
		//    if (inputlist_filename != NULL) {
		//      arg = J_BMALLOC(strlen(inputlist_filename)+1);
		//      strcpy(arg, inputlist_filename);
		//    } else {
		//      arg = NULL;
		//    }
		break;
#ifdef USE_NETAUDIO
	case SP_NETAUDIO:
		arg = J_BMALLOC(strlen(netaudio_devname)+1);
		strcpy(arg, netaudio_devname);
		break;
#endif
	}
	// �}�C�N�̃X�^���o�C
	/*
	if (adin_standby(theOpt.smpFreq, arg) == FALSE) {
	J_ERROR("Error: failed to ready input device\n");
	}
	*/

	/* set device-independent param */
	SetupParam(theOpt.pause_segment,
		theOpt.strip_zero_sample,
		theOpt.level_thres,
		theOpt.zero_cross_num,
		theOpt.head_margin_msec,
		theOpt.tail_margin_msec,
		theOpt.smpFreq);
	theOpt.adin_cut_on = adin_cut_on;
	J_DEBUGMESSAGE("adin_cut_on = %d\n",adin_cut_on);
}

void CJuliAudioSource::SetupParam(int pause_segment, boolean strip_zero, int cthres, int czc, int head_margin, int tail_margin, int sample_freq) // adin_setup_param
{
	float samples_in_msec;
	/* whether to perform silence detection */
	/* 0...force off  1...force on  2...keep device-specific default */
	if (pause_segment < 2) {
		adin_cut_on = (pause_segment == 1) ? TRUE : FALSE;
	} else {
		adin_cut_on = segment_default;
	}
	/* whether to strip zero samples */
	strip_flag = strip_zero;
	/* set level threshold */
	thres = cthres;
	/* calc & set internal parameter from configuration */
	samples_in_msec = (float) sample_freq / 1000.0f;
	c_length = (int )(head_margin * samples_in_msec);	/* in msec. */
	noise_zerocross = czc * c_length / sample_freq;
	nc_max = (int )(tail_margin * samples_in_msec / DEFAULT_WSTEP) + 2;

	//J_DEBUGMESSAGE("c_length=%d, noise_zerocross=%d nc_max=%d\n", c_length, noise_zerocross, nc_max);
	J_DEBUGMESSAGE("*** Audio Parameters ***\n");
	J_DEBUGMESSAGE("adin_cut_on     = %d\n", adin_cut_on);
	J_DEBUGMESSAGE("strip_flag      = %d\n", strip_flag);
	J_DEBUGMESSAGE("thres           = %d\n", thres);
	J_DEBUGMESSAGE("samples_in_msec = %d\n", samples_in_msec);
	J_DEBUGMESSAGE("c_length        = %d\n", c_length);
	J_DEBUGMESSAGE("noise_zerocross = %d\n", noise_zerocross);
	J_DEBUGMESSAGE("nc_max          = %d\n", nc_max);
	J_DEBUGMESSAGE("(czc)           = %d\n", czc);
	J_DEBUGMESSAGE("(head_margin)   = %d\n", head_margin);
	J_DEBUGMESSAGE("(tail_margin)   = %d\n", tail_margin);
	J_DEBUGMESSAGE("(sample_freq)   = %d\n", sample_freq);

#ifdef HAVE_PTHREAD
	if (enable_thread) {
		/* create A/D-in thread */
		adin_thread_create();
	}
#endif
}
