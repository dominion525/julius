//====================================================================
// JuliZeroCross.h: ��������𐔂���N���X(���C�u����)
//--------------------------------------------------------------------
// Copyright (c) 1991-2000 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIZEROCROSS_H__71BEDA22_624B_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIZEROCROSS_H__71BEDA22_624B_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/* Copyright (c) 1991-2000 Doshita Lab. Speech Group, Kyoto University */
/*   All rights reserved   */

/* zc-e.c --- count zerocross and level */

/**check no sound in monoral input data **/
/* Sat Feb 19 13:48:00 JST 1994 */
/*  Kawahara 1986 */
/*  Munetsugu 1991 */
/*  shinohara 1993 */
/*  mikik 1993 */
/*  ri 1997 for cycle buffer */

//#include "JuliDefines.h"
typedef short SP16;		/* 16bit speech data type */

class CJuliZeroCross  
{
public:
	CJuliZeroCross();
	virtual ~CJuliZeroCross();

	void Init(int c_trigger, int c_length, int c_offset);	// (init_count_zc_e)
	void Release();											// (end_count_zc_e)
	int Count(SP16 *buf,int step);							// (count_zc_e)
	int CountLevel(SP16 *buf,int step,int *levelp);			// (count_zc_e_level)
	void CopyBuffer(SP16 *newbuf, int len);					// (zc_copy_buffer)
	int	StripZero(SP16 a[], int len);						// (strip_zero) from anlz/strip.c

private:
	int trigger;		/* level threshold */
	int length;			/* samples to hold */
	int offset;			/* data DC offset */
	int *is_zc;			/* zero-cross point flag */
	SP16 *data;			/* data cycle buffer */
	int zero_cross;		/* total zerocross num */
	int sign;			/* sign of sample */
	int is_trig;		/* threshold */
	int top;			/* current pointer of buffer */
};

#endif // !defined(AFX_JULIZEROCROSS_H__71BEDA22_624B_11D5_9AFA_008098E80572__INCLUDED_)
