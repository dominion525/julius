//====================================================================
// JuliHtkHmmData.h: Htk HMM: Physical Data �I�u�W�F�N�g (HTK_HMM_Data)
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIHTKHMMDATA_H__C2F03B31_7AC4_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIHTKHMMDATA_H__C2F03B31_7AC4_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliHtkHmmSegment.h"
#include <assert.h>

class CJuliHtkHmmState;
class CJuliHtkHmmTrans;
class CJuliHmmInfo;

class CJuliHtkHmmData : public CJuliHtkHmmSegment
{
public:
	CJuliHtkHmmData();
	virtual ~CJuliHtkHmmData();

	void ReadFromFile(CJuliFile &file, CJuliHmmInfo &info);	// �t�@�C������ǂݍ���
	// �A�N�Z�b�T
	short GetStateNum() const { return m_siStateNum; }
	const CJuliHtkHmmState * GetState(int i) const { assert(i>=0 && i<m_siStateNum); return m_states[i]; }
	const CJuliHtkHmmTrans * GetTrans() const { return m_trans; }
	CJuliHtkHmmTrans * GetTrans() { return m_trans; }
private:
	short m_siStateNum;		// ��Ԑ�
	CJuliHtkHmmState **m_states;	// CJuliHtkHmmState * �̔z��(m_siStateNum��) /* outprob info for each state */
	CJuliHtkHmmTrans *m_trans;	// /* transition info */
};

#endif // !defined(AFX_JULIHTKHMMDATA_H__C2F03B31_7AC4_11D5_9AFA_008098E80572__INCLUDED_)
