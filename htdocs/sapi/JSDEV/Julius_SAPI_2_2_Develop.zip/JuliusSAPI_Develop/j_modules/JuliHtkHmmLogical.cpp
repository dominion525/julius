//====================================================================
// JuliHtkHmmLogical.cpp: CJuliHtkHmmLogical �N���X�̃C���v�������e�[�V����
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliHtkHmmLogical.h"
#include "JuliHtkHmmData.h"

CJuliHtkHmmLogical::CJuliHtkHmmLogical()
{
	is_pseudo = false;
	body.defined = NULL;
	body.pseudo = NULL;
}

CJuliHtkHmmLogical::~CJuliHtkHmmLogical()
{
	
}

/* return number of state in a logical HMM */
int CJuliHtkHmmLogical::GetStateNum() const// hmm_logical_state_num
{
	int len;
	if (is_pseudo) len = body.pseudo->state_num;
	else len = body.defined->GetStateNum();
	return(len);
}

/* return trans structure for a logical HMM */
const CJuliHtkHmmTrans * CJuliHtkHmmLogical::GetTrans() const// hmm_logical_trans
{
	const CJuliHtkHmmTrans *tr;
	if (is_pseudo) tr = body.pseudo->tr;
	else tr = body.defined->GetTrans();
	return(tr);
}

void CJuliHtkHmmLogical::OutputDebug() const
{
	J_DEBUGMESSAGE("HmmLogical: is_pseudo = %s\n", (is_pseudo)?"true":"false");
	J_DEBUGMESSAGE("HmmLogical: defined = %p, pseudo = %p\n", body.defined, body.pseudo);
}

