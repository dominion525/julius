//====================================================================
// JuliLogTable.cpp: �ΐ��\
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// Speech Media Lab. Kyoto University     All rights reserved
//====================================================================

#include "JuliLogTable.h"
#include <math.h>

CJuliLogTable theLogTable;

void CJuliLogTable::MakeLogTable() // make_log_tbl
{
	LOGPROB f;
	int i;
	
	if (m_bInited == true) return;
	m_bInited = true;

	J_MESSAGE("Generating addlog table...");
	for (i=0;i<TBLSIZE;i++){
		f = - ((float)VRANGE * (float)i / (float)TBLSIZE);
		m_tblLog[i] = (LOGPROB )log(1 + exp(f));
		/*if (i < 10 || i > TBLSIZE - 10) j_printf("%f: %d(%f)\n", f, i, tbl[i]);*/
	}
	J_MESSAGE("%d kb...done\n",(TBLSIZE * sizeof(LOGPROB)) / 1024);
}

LOGPROB CJuliLogTable::AddLog(LOGPROB x, LOGPROB y) // addlog
{
	/* return(log(exp(x)+exp(y))) */
	LOGPROB tmp;
	unsigned int idx;
	
	if (x < y) {
		if ((tmp = x - y) < LOG_ADDMIN) return y;
		else {
			idx = (unsigned int)((- tmp) * TMAG + 0.5);
			/* j_printf("%f == %f\n",tbl[idx],log(1 + exp(tmp))); */
			return (y + m_tblLog[idx]);
		}
	} else {
		if ((tmp = y - x) < LOG_ADDMIN) return x;
		else {
			idx =(unsigned int)((- tmp) * TMAG + 0.5);
			/* j_printf("%f == %f\n",tbl[idx],log(1 + exp(tmp))); */
			return (x + m_tblLog[idx]);
		}
	}
}

LOGPROB CJuliLogTable::AddLogArray(LOGPROB *a, int n) // addlog_array
{
	LOGPROB tmp;
	LOGPROB x,y;
	unsigned int idx;
	
	y = LOG_ZERO;
	for(n--; n >= 0; n--) {
		x = a[n];
		if (x > y) {
			tmp = x; x = y; y = tmp;
		}
		/* always y >= x */
		if ((tmp = x - y) < LOG_ADDMIN) continue;
		else {
			idx = (unsigned int)((- tmp) * TMAG + 0.5);
			y += m_tblLog[idx];
		}
	}
	return(y);
}
