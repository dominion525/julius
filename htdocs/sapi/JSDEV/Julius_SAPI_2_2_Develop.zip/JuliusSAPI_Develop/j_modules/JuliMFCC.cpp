//====================================================================
// JuliMFCC.cpp: 
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliMFCC.h"
#include <math.h>
#include "JuliFile.h"
#include "JuliUtil.h"
#include "JuliGlobalOption.h"

/* 01/01/19 store last 500frame samples */
#define CPMAX 500

CJuliMFCCParameter thePara;
CJuliMFCC theMFCC;

/* set MFCC parameter selection for IPA model */
void CJuliMFCCParameter::Init() // init_para
{
	para.smp_period = theOpt.smpPeriod;	// sample period (16kHz: 625ns)
	para.framesize  = theOpt.fsize;
	para.frameshift = theOpt.fshift;
	para.preEmph    = (float) DEF_PREENPH;
	para.mfcc_dim   = DEF_MFCCDIM;
	para.lifter     = DEF_CEPLIF;
	para.delWin     = DEF_DELWIN;
	para.silFloor   = DEF_SILFLOOR;
	para.hipass     = theOpt.hipass;
	para.lopass     = theOpt.lopass;
	para.c0         = theOpt.c0_required;
	/* para.escale     = DEF_ESCALE; */
	para.escale     = 1.0;
	para.fbank_num  = DEF_FBANK;
	para.ss_alpha   = theOpt.ssalpha;
	para.ss_floor   = theOpt.ssfloor;
	/* para.cmn        = FALSE;*/
	para.cmn        = TRUE;
	para.enormal    = FALSE;
	para.raw_e      = FALSE;
	para.vec_num    = (para.mfcc_dim + 1) * 2;

}


CJuliMFCC::CJuliMFCC()
: m_lastcsum(NULL), m_lastc(NULL), m_cp(0), m_filled(0), m_mfcc_ave(NULL), m_mfcc_ave_new(NULL), m_fbank(NULL)
{
	m_fb.cf = NULL;
	m_fb.loChan = NULL;
	m_fb.loWt = NULL;
	m_fb.Re = NULL;
	m_fb.Im = NULL;
}

CJuliMFCC::~CJuliMFCC()
{
	J_FREE(m_mfcc_ave_new);
	J_FREE(m_mfcc_ave);
	if (m_lastcsum != NULL) {
		J_FREE(m_lastcsum);
		for(int t=0;t<CPMAX;t++) {
			J_FREE(m_lastc[t]);
		}
		J_FREE(m_lastc);
	}
	J_FREE(m_fbank);

	ReleaseFBank(m_fb);
}


CJuliHtkParam *CJuliMFCC::Wave2MFCC(SP16 speech[], int speechlen)	// (new_wav2mfcc)
{
	CJuliHtkParam *param;
	Value para;			/* parameters for Wav2MFCC */
	int framenum;
	int i;
	int len;

	para.smp_period = DEF_SMPPERIOD;
	para.framesize  = DEF_FRAMESIZE;
	para.frameshift = DEF_FRAMESHIFT;
	para.preEmph    = (float) DEF_PREENPH;
	para.mfcc_dim   = DEF_MFCCDIM;
	para.lifter     = DEF_CEPLIF;
	para.delWin     = DEF_DELWIN;
	para.silFloor   = DEF_SILFLOOR;
	para.hipass     = theOpt.hipass;
	para.lopass     = theOpt.lopass;
	para.c0         = theOpt.c0_required;
	/* para.escale     = DEF_ESCALE; */
	para.escale     = 1.0;
	para.fbank_num  = DEF_FBANK;
	/* para.cmn        = FALSE;*/
	para.cmn        = TRUE;
	para.enormal    = FALSE;
	para.raw_e      = FALSE;
	/* for SS */
	para.ss_alpha   = theOpt.ssalpha;
	para.ss_floor   = theOpt.ssfloor;

	para.vec_num = (para.mfcc_dim + 1) * 2;

	if (theOpt.m_iSSMode == 2 && theOpt.m_ssbuf == NULL) {
		/* load noise spectrum for spectral subtraction from file (once) */
		if ((theOpt.m_ssbuf = new_SS_load_from_file(theOpt.m_strSSLoadFile.c_str(), &theOpt.m_sslen)) == NULL) {
			J_ERROR("Error: failed to read \"%s\"\n", theOpt.m_strSSLoadFile.c_str());
		}
	}

	if (theOpt.m_iSSMode == 1) {
		/* compute noise spectrum from head silence for each input */
		len = theOpt.sscalc_len * theOpt.smpFreq / 1000;
		if (len > speechlen) len = speechlen;
#ifdef SSDEBUG
		printf("[%d]\n", len);
#endif
		theOpt.m_ssbuf = new_SS_calculate(speech, len, para, &theOpt.m_sslen);
	}
#ifdef SSDEBUG
	{
		int i;
		for(i=0;i<theOpt.m_sslen;i++) {
			J_DEBUGMESSAGE("%d: %f\n", i, theOpt.m_ssbuf[i]);
		}
	}
#endif

	/* calculate frame length from speech length, frame size and frame shift */
	framenum = (int)((speechlen - para.framesize) / para.frameshift) + 1;
	if (framenum < 1) {
		J_MESSAGE("input too short, ignored\n");
		return NULL;
	}

	param = new CJuliHtkParam();
	param->parvec = (VECT **)J_MALLOC(sizeof(VECT *) * framenum);
	for(i=0;i<framenum;i++) {
		param->parvec[i] = (VECT *)J_MALLOC(sizeof(VECT) * para.vec_num);
	}
	/* needs conversion here if intergerized */
	Wav2MFCC_E_D(speech, param->parvec, para, speechlen, theOpt.m_ssbuf, theOpt.m_sslen);

	param->header.samplenum = framenum;
	param->header.wshift = 100000; /* 16khz */
	param->header.sampsize = para.vec_num * sizeof(VECT); /* not compressed */
	if (theOpt.c0_required) {
		param->header.samptype = F_MFCC | F_ZEROTH | F_DELTA | F_CEPNORM;
	} else {
		param->header.samptype = F_MFCC | F_ENERGY | F_DELTA | F_CEPNORM;
	}
	param->veclen = para.vec_num;
	param->samplenum = framenum;
	return param;
}



/************************************************************************/
/*    wav2mfcc.c   Convert Speech file to MFCC_E_D_(Z) file             */
/*----------------------------------------------------------------------*/
/*    Author    : Yuichiro Nakano                                       */
/*                                                                      */
/*    Copyright(C) Yuichiro Nakano 1996-1998                            */
/*----------------------------------------------------------------------*/
/************************************************************************/
/* 
*  Convert wave -> MFCC_E_D_(Z)
*  do spectral subtraction if ssbuf != NULL
*/
int CJuliMFCC::Wav2MFCC_E_D(SP16 *wave, float **mfcc, Value para, int nSamples, float *ssbuf, int ssbuflen)
{
	float *bf;                        /* Work space for FFT */
	double *fbank;                    /* Filterbank */
	float *energy;            /* Raw Energy */ 
	int i, k, t;
	int end = 0, start = 1;
	int frame_num;                    /* Number of samples in output file */
	FBankInfo fb;
	/* Get filterbank information */
	fb = InitFBank(para);

	if((fbank = (double *)J_MALLOC((para.fbank_num+1)*sizeof(double))) == NULL){
		J_ERROR("Error: Wav2MFCC_E_D: failed to malloc\n");
		return -1;
	}
	if((bf = (float *)J_MALLOC(fb.fftN * sizeof(float))) == NULL){
		J_ERROR("Error: Wav2MFCC_E_D: failed to malloc\n");
		return -1;
	}

	if (ssbuf != NULL) {
		/* check ssbuf length */
		if (fb.fftN != ssbuflen) {
			J_ERROR("Error: Wav2MFCC_E_D: noise spectrum length not match\n");
			return -1;
		}
	}

	frame_num = (int)((nSamples - para.framesize) / para.frameshift) + 1;

	energy = (float *)J_MALLOC(sizeof(float)*frame_num);

	for(t = 0; t < frame_num; t++){
		if(end != 0) start = end - (para.framesize - para.frameshift) - 1;
		k = 1;
		for(i = start; i <= start + para.framesize; i++){
			bf[k] = (float)wave[i - 1];  k++;
		}
		end = i;

		/* Calculate Log Raw Energy */
		if(para.raw_e)
			energy[t] = CalcLogRawE(bf, para.framesize); 
		/* Pre-emphasise */
		PreEmphasise(bf, para);

		/* Hamming Window */
		Hamming(bf, para.framesize);
		/* Calculate Log Energy */
		if(!para.raw_e)
			energy[t] = CalcLogRawE(bf, para.framesize);
		/* Filterbank */
		MakeFBank(bf, fbank, fb, para, ssbuf);
		/* MFCC */
		MakeMFCC(fbank, mfcc[t], para);   
		/* Weight Cepstrum */
		WeightCepstrum(mfcc[t], para);
	}
	/* Normalise Log Energy */
	if(para.enormal)
		NormaliseLogE(mfcc, energy, frame_num, para);
	else{
		for(t = 0; t < frame_num; t++)
			mfcc[t][para.mfcc_dim] = energy[t];
	}
	/* Delta */
	Delta(mfcc, frame_num, para);
	/* Cepstrum Mean Normalization */
	if(para.cmn)
		CMN(mfcc, frame_num, para.mfcc_dim);
	J_FREE(fbank);
	J_FREE(bf);
	J_FREE(energy);
	ReleaseFBank(fb);	// �����������
	return(frame_num);
}

/* 
*  Calculate Log Raw Energy 
*/
float CJuliMFCC::CalcLogRawE(float *wave, int framesize)
{		   
	int i;
	double raw_E = 0.0;
	float energy;
	for(i = 1; i <= framesize; i++)
		raw_E += wave[i] * wave[i];
	energy = (float)log(raw_E);
	return(energy);
}

/* 
*  Apply hamming window
*/
void CJuliMFCC::Hamming(float *wave, int framesize)
{
	int i;
	float a;
	a = 2 * PI / (framesize - 1);
	for(i = 1; i <= framesize; i++)
		wave[i] *= 0.54 - 0.46 * cos(a * (i - 1));
}

/* 
*  Apply pre-emphasis filter
*/
void CJuliMFCC::PreEmphasise (float *wave, Value para)
{
	int i;

	for(i = para.framesize; i >= 2; i--)
		wave[i] -= wave[i - 1] * para.preEmph;
	wave[1] *= 1.0 - para.preEmph;  
}

/* 
*  Re-scale cepstral coefficients
*/
void CJuliMFCC::WeightCepstrum (float *mfcc, Value para)
{
	int i;
	float a, b, *cepWin;

	if((cepWin = (float *)J_MALLOC(para.mfcc_dim * sizeof(float))) == NULL)	// TODO: leak!
	{
		return;	// TODO: return error
	}
	a = PI / para.lifter;
	b = para.lifter / 2.0;

	for(i = 0; i < para.mfcc_dim; i++){
		cepWin[i] = 1.0 + b * sin((i + 1) * a);
		mfcc[i] *= cepWin[i];
	}

	J_FREE(cepWin);
}

/* 
*  Return mel-frequency
*/
float CJuliMFCC::Mel(int k, float fres)
{
	return(1127 * log(1 + (k-1) * fres));
}

/* 
*  Get filterbank information
*/
FBankInfo CJuliMFCC::InitFBank(Value para)
{
	FBankInfo fb;
	float mlo, mhi, ms, melk;
	int k, chan, maxChan, nv2;
	/* Calculate FFT size */
	fb.fftN = 2;  fb.n = 1;
	while(para.framesize > fb.fftN)
	{
		fb.fftN *= 2; fb.n++;
	}
	nv2 = fb.fftN / 2;
	fb.fres = 1.0E7 / (para.smp_period * fb.fftN * 700.0);
	maxChan = para.fbank_num + 1;
	fb.klo = 2;   fb.khi = nv2;
	mlo = 0;      mhi = Mel(nv2 + 1, fb.fres);

	/* Create vector of fbank centre frequencies */
	if((fb.cf = (float *)J_MALLOC((maxChan + 1) * sizeof(float))) == NULL)
	{
		throw ;
	}
	ms = mhi - mlo;
	for (chan = 1; chan <= maxChan; chan++) 
		fb.cf[chan] = ((float)chan / maxChan)*ms + mlo;
	/* Create loChan map, loChan[fftindex] -> lower channel index */
	if((fb.loChan = (short *)J_MALLOC((nv2 + 1) * sizeof(short))) == NULL)
	{
		throw ;
	}
	for(k = 1, chan = 1; k <= nv2; k++){
		melk = Mel(k, fb.fres);
		while (fb.cf[chan] < melk && chan <= maxChan) ++chan;
		fb.loChan[k] = chan - 1;
	}
	/* Create vector of lower channel weights */   
	if((fb.loWt = (float *)J_MALLOC((nv2 + 1) * sizeof(float))) == NULL)
	{
		throw ;
	}
	for(k = 1; k <= nv2; k++) {
		chan = fb.loChan[k];
		if (chan > 0) 
			fb.loWt[k] = (fb.cf[chan + 1] - Mel(k, fb.fres)) / (fb.cf[chan + 1] - fb.cf[chan]);
		else
			fb.loWt[k] = (fb.cf[1] - Mel(k, fb.fres)) / (fb.cf[1] - mlo);
	}

	/* Create workspace for fft */
	if((fb.Re = (float *)J_MALLOC((fb.fftN + 1) * sizeof(float))) == NULL)
	{
		throw ;
	}
	if((fb.Im = (float *)J_MALLOC((fb.fftN + 1) * sizeof(float))) == NULL)
	{
		throw ;
	}
	return(fb);
}

/* 
*  Convert wave -> mel-frequency filterbank
*/
void CJuliMFCC::MakeFBank(float *wave, double *fbank, FBankInfo fb, Value para, float *ssbuf)
{
	int k, bin, i;
	double Re, Im, A, P, NP, H, temp;

	for(k = 1; k <= para.framesize; k++){
		fb.Re[k - 1] = wave[k];  fb.Im[k - 1] = 0.0;  /* copy to workspace */
	}
	for(k = para.framesize + 1; k <= fb.fftN; k++){
		fb.Re[k - 1] = 0.0;      fb.Im[k - 1] = 0.0;  /* pad with zeroes */
	}

	/* Take FFT */
	FFT(fb.Re, fb.Im, fb.n);

	if (ssbuf != NULL) {
		/* Spectral Subtraction */
		for(k = 1; k <= fb.fftN; k++){
			Re = fb.Re[k - 1];  Im = fb.Im[k - 1];
			P = sqrt(Re * Re + Im * Im);
			NP = ssbuf[k - 1];
			if((P * P -  para.ss_alpha * NP * NP) < 0){
				H = para.ss_floor;
			}else{
				H = sqrt(P * P - para.ss_alpha * NP * NP) / P;
			}
			fb.Re[k - 1] = H * Re;
			fb.Im[k - 1] = H * Im;
		}
	}

	/* Fill filterbank channels */ 
	for(i = 1; i <= para.fbank_num; i++)
		fbank[i] = 0.0;

	for(k = fb.klo; k <= fb.khi; k++){
		Re = fb.Re[k-1]; Im = fb.Im[k-1];
		A = sqrt(Re * Re + Im * Im);
		bin = fb.loChan[k];
		Re = fb.loWt[k] * A;
		if(bin > 0) fbank[bin] += Re;
		if(bin < para.fbank_num) fbank[bin + 1] += A - Re;
	}
	/* Take logs */
	for(bin = 1; bin <= para.fbank_num; bin++){ 
		temp = fbank[bin];
		if(temp < 1.0) temp = 1.0;
		fbank[bin] = log(temp);  
	}
}

// �������
void CJuliMFCC::ReleaseFBank(FBankInfo fb)
{
	J_FREE(fb.cf);
	J_FREE(fb.loChan);
	J_FREE(fb.loWt);
	J_FREE(fb.Re);
	J_FREE(fb.Im);
}

/* 
*  Apply the DCT to filterbank
*/ 
void CJuliMFCC::MakeMFCC(double *fbank, float *mfcc, Value para)
{
	int i, j;
	float A, B, C;

	A = sqrt(2.0 / para.fbank_num);
	B = PI / para.fbank_num;
	/* Take DCT */
	for(i = 1; i <= para.mfcc_dim; i++){
		mfcc[i - 1] = 0.0;
		C = i * B;
		for(j = 1; j <= para.fbank_num; j++)
			mfcc[i - 1] += fbank[j] * cos(C * (j - 0.5));
		mfcc[i - 1] *= A;     
	}       
}

/* 
*  Normalise log energy
*/
void CJuliMFCC::NormaliseLogE(float **mfcc, float *energy, int frame_num, Value para)
{  
	float *p, max, min;
	int t;
	/* find max log energy */
	p = energy;
	max = p[0];
	for(t = 0; t < frame_num; t++)
		if(p[t] > max) max = p[t];
	/* set the silence floor */
	min = max - (para.silFloor * log(10.0)) / 10.0;  
	/* normalise */
	p = energy;
	for(t = 0; t < frame_num; t++){
		if (p[t] < min) p[t] = min;               
		mfcc[t][para.mfcc_dim] = 1.0 - (max - p[t]) * para.escale;
	}
}

/* 
*  Calculate delta coefficients
*/
void CJuliMFCC::Delta(float **c, int frame, Value para)
{
	int theta, t, n, dim, B = 0;
	float A1, A2, sum;
	for(theta = 1; theta <= para.delWin; theta++)
		B += theta * theta;
	dim = para.vec_num / 2;
	for(t = 0; t < frame; t++){
		for(n = 1; n <= dim; n++){
			sum = 0;
			for(theta = 1; theta <= para.delWin; theta++){
				/* Replicate the first or last vector */
				/* at the beginning and end of speech */
				if(t - theta < 0) A1 = c[0][n - 1];
				else A1 = c[t - theta][n - 1];
				if(t + theta >= frame) A2 = c[frame - 1][n - 1];
				else A2 = c[t + theta][n - 1];
				sum += theta * (A2 - A1);
			}
			c[t][n + para.mfcc_dim] = sum / (2 * B);
		}
	}
}

/* 
*  Apply FFT
*/
void CJuliMFCC::FFT(float *xRe, float *xIm, int p)
{
	int i, ip, j, k, m, me, me1, n, nv2;
	double uRe, uIm, vRe, vIm, wRe, wIm, tRe, tIm;

	n = 1<<p;
	nv2 = n / 2;

	j = 0;
	for(i = 0; i < n-1; i++){
		if(j > i){
			tRe = xRe[j];      tIm = xIm[j];
			xRe[j] = xRe[i];   xIm[j] = xIm[i];
			xRe[i] = tRe;      xIm[i] = tIm;
		}
		k = nv2;
		while(j >= k){
			j -= k;      k /= 2;
		}
		j += k;
	}
	for(m = 1; m <= p; m++){
		me = 1<<m;                me1 = me / 2;
		uRe = 1.0;                uIm = 0.0;
		wRe = cos(PI / me1);      wIm = -sin(PI / me1);
		for(j = 0; j < me1; j++){
			for(i = j; i < n; i += me){
				ip = i + me1;
				tRe = xRe[ip] * uRe - xIm[ip] * uIm;
				tIm = xRe[ip] * uIm + xIm[ip] * uRe;
				xRe[ip] = xRe[i] - tRe;   xIm[ip] = xIm[i] - tIm;
				xRe[i] += tRe;            xIm[i] += tIm;
			}
			vRe = uRe * wRe - uIm * wIm;   vIm = uRe * wIm + uIm * wRe;
			uRe = vRe;                     uIm = vIm;
		}
	}
}

/* 
* Cepstrum Mean Normalization
*/
void CJuliMFCC::CMN(float **mfcc, int frame_num, int dim)
{
	int i, t;
	float *mfcc_ave, *sum;
	mfcc_ave = (float *)J_CALLOC(dim, sizeof(float));
	sum = (float *)J_CALLOC(dim, sizeof(float));
	for(i = 0; i < dim; i++){
		sum[i] = 0.0;
		for(t = 0; t < frame_num; t++)
			sum[i] += mfcc[t][i];
		mfcc_ave[i] = sum[i] / frame_num;
	}
	for(t = 0; t < frame_num; t++){
		for(i = 0; i < dim; i++)
			mfcc[t][i] = mfcc[t][i] - mfcc_ave[i];
	}
	J_FREE(sum);
	J_FREE(mfcc_ave);
}



/* preparation */
void CJuliMFCC::WMP_init(Value para, float **bf, float *ssbuf, int ssbuflen)
{
	/* Get filterbank information */
	m_fb = InitFBank(para);

	if((m_fbank = (double *)J_MALLOC((para.fbank_num+1)*sizeof(double))) == NULL){
		J_ERROR("WMP_init failed\n");
		throw ;
	}
	if((*bf = (float *)J_MALLOC(m_fb.fftN * sizeof(float))) == NULL){
		J_ERROR("WMP_init failed\n");
		throw ;
	}
	if (ssbuf != NULL) {
		/* check ssbuf length */
		if (m_fb.fftN != ssbuflen) {
			J_ERROR("Error: Wav2MFCC_E_D: noise spectrum length not match\n");
			throw ;
		}
	}
}
/* calc MFCC_E_Z for 1 frame */
void CJuliMFCC::WMP_calc(float *mfcc, float *bf, Value para, float *ssbuf)
{
	float energy;
	if (para.raw_e) {
		/* calculate log raw energy */
		energy = CalcLogRawE(bf, para.framesize);
		/* pre-emphasize */
		PreEmphasise(bf, para);
		/* hamming window */
		Hamming(bf, para.framesize);
	} else {
		/* pre-emphasize */
		PreEmphasise(bf, para);
		/* hamming window */
		Hamming(bf, para.framesize);
		/* calculate log energy */
		energy = CalcLogRawE(bf, para.framesize);
	}
	/* filterbank */
	MakeFBank(bf, m_fbank, m_fb, para, ssbuf);
	/* MFCC */
	MakeMFCC(m_fbank, mfcc, para);
	/* weight cepstrum */
	WeightCepstrum(mfcc, para);
	/* Normalise Log Energy is not implemented */
	if(para.enormal) {
		J_ERROR("normalize log energy is not implemented in pipeline mode\n");
		throw ;
	}
	mfcc[para.mfcc_dim] = energy;
}
/* calc MFCC_E_D_Z from MFCC_E_Z for 1 frame */
void CJuliMFCC::WMP_Delta(float **c, int t, int frame, Value para)
{
	int theta, n, dim, B = 0;
	float A1, A2, sum;
	for(theta = 1; theta <= para.delWin; theta++)
		B += theta * theta;
	dim = para.vec_num / 2;
	for(n = 1; n <= dim; n++){
		sum = 0;
		for(theta = 1; theta <= para.delWin; theta++){
			/* Replicate the first or last vector */
			/* at the beginning and end of speech */
			if(t - theta < 0) A1 = c[0][n - 1];
			else A1 = c[t - theta][n - 1];
			if(t + theta >= frame) A2 = c[frame - 1][n - 1];
			else A2 = c[t + theta][n - 1];
			sum += theta * (A2 - A1);
		}
		c[t][n + para.mfcc_dim] = sum / (2 * B);
	}
}

/* real-time CMN */
/* calc mfcc_ave[] and clear lastcsum[] for next input */
void CJuliMFCC::CMN_realtime_update()
{
	int i;
	static float *p;
	if (m_mfcc_ave_new == NULL) {
		m_mfcc_ave_new = (float *)J_MALLOC(sizeof(float) * m_dim);
	}
	for(i=0;i<m_dim;i++) {
		m_mfcc_ave_new[i] = m_lastcsum[i] / (float)m_filled;
	}
	if (m_mfcc_ave == NULL) {
		m_mfcc_ave = (float *)J_MALLOC(sizeof(float) * m_dim);
	}
	/* swap current <-> new */
	p = m_mfcc_ave;
	m_mfcc_ave = m_mfcc_ave_new;
	m_mfcc_ave_new = p;
}
/* both accumulate to lastcsum[] and do CMN by the last mean vector */
void CJuliMFCC::CMN_realtime(float *mfcc, int cdim)
{
	int t,i;
	if (m_lastcsum == NULL) {	/* initialize */
		m_dim = cdim;
		m_lastcsum = (float *)J_MALLOC(sizeof(float) * m_dim);
		for(i=0;i<m_dim;i++) m_lastcsum[i] = 0.0;
		m_lastc = (float **)J_MALLOC(sizeof(float*) * CPMAX);
		for(t=0;t<CPMAX;t++) {
			m_lastc[t] = (float *)J_MALLOC(sizeof(float) * m_dim);
		}
		m_filled = 0;
		m_cp = 0;
	}
	if (m_filled < CPMAX) {
		m_filled++;
		for(i=0;i<m_dim;i++) {
			m_lastcsum[i] += mfcc[i];
			m_lastc[m_cp][i] = mfcc[i];
		}
	} else {
		for(i=0;i<m_dim;i++) {
			m_lastcsum[i] -= m_lastc[m_cp][i];
			m_lastcsum[i] += mfcc[i];
			m_lastc[m_cp][i] = mfcc[i];
		}
	}
	m_cp++;
	if (m_cp >= CPMAX) m_cp = 0;

	if (m_mfcc_ave != NULL) {
		for(i=0;i<m_dim;i++) {
			mfcc[i] -= m_mfcc_ave[i];
		}
	}
}

/* read binary with byte swap (assume file is BE) */
static boolean
myread(void *buf, size_t unitbyte, int unitnum, CJuliFile &file)
{
	if (file.Read(buf, unitbyte, unitnum) < unitnum) {
		return(FALSE);
	}
#ifndef WORDS_BIGENDIAN
	CJuliUtil::swap_bytes(buf, unitbyte, unitnum);
#endif
	return(TRUE);
}
/* write binary with byte swap (assume file is BE) */
static boolean
mywrite(void *buf, size_t unitbyte, int unitnum, CJuliFile &file)
{
//	int tmp;
#ifndef WORDS_BIGENDIAN
	CJuliUtil::swap_bytes(buf, unitbyte, unitnum);
#endif
	if (file.Write(buf, unitbyte, unitnum) < unitnum) {
		return(FALSE);
	}
#ifndef WORDS_BIGENDIAN
	CJuliUtil::swap_bytes(buf, unitbyte, unitnum);
#endif
	return(TRUE);
}

/* load CMN parameter from file */
boolean CJuliMFCC::CMN_load_from_file(const char *filename, int dim)
{
	CJuliFile file;
//	int num;
	int veclen;
	if (file.OpenRead(filename)) {
		J_ERROR("Error: CMN_load_from_file: failed to open\n");
		return(FALSE);
	}
	/* read header */
	if (myread(&veclen, sizeof(int), 1, file) == FALSE) {
		J_ERROR("Error: CMN_load_from_file: failed to read header\n");
		file.CloseRead();
		return(FALSE);
	}
	/* check length */
	if (veclen != dim) {
		J_ERROR("Error: CMN_load_from_file: length mismatch\n");
		file.CloseRead();
		return(FALSE);
	}
	/* read body */
	if (m_mfcc_ave == NULL) {
		m_mfcc_ave = (float *)J_MALLOC(sizeof(float) * dim);
	}
	if (myread(m_mfcc_ave, sizeof(float), m_dim, file) == FALSE) {
		J_ERROR("Error: CMN_load_from_file: failed to read\n");
		file.CloseRead();
		return(FALSE);
	}
	if (file.CloseRead() == -1) {
		J_ERROR("Error: CMN_load_from_file: failed to close\n");
		return(FALSE);
	}

	return(TRUE);
}

/* save CMN parameter to file */
boolean CJuliMFCC::CMN_save_to_file(const char *filename)
{
	CJuliFile file;

	if (file.OpenWrite(filename)) {
		J_ERROR("Error: CMN_save_to_file: failed to open\n");
		return(FALSE);
	}
	/* write header */
	if (mywrite(&m_dim, sizeof(int), 1, file) == FALSE) {
		J_ERROR("Error: CMN_save_to_file: failed to write header\n");
		file.CloseWrite();
		return(FALSE);
	}
	/* write body */
	if (m_mfcc_ave == NULL) {
		J_ERROR("Error: no data to write?? should not happen!\n");
	}
	if (mywrite(m_mfcc_ave, sizeof(float), m_dim, file) == FALSE) {
		J_ERROR("Error: CMN_save_to_file: failed to write header\n");
		file.CloseWrite();
		return(FALSE);
	}
	file.CloseWrite();

	return(TRUE);
}


// ss.c

/* load noise spectrum from file (allocate new buffer) */
float * CJuliMFCC::new_SS_load_from_file(const char *filename, int *slen)
{
	CJuliFile file;
	int num;
	float *sbuf;

	/* open file */
	J_MESSAGE("Reading Noise Spectrum for SS...");
	if (file.OpenRead(filename)) {
		J_ERROR("Error: SS_load_from_file: cannot open \"%s\"\n", filename);
		return(NULL);
	}
	/* read length */
	if (myread(&num, sizeof(int), 1, file) == FALSE) {
		J_ERROR("Error: SS_load_from_file: cannot read \"%s\"\n", filename);
		return(NULL);
	}
	/* allocate */
	sbuf = (float *)J_MALLOC(sizeof(float) * num);
	/* read data */
	if (myread(sbuf, sizeof(float), num, file) == FALSE) {
		J_ERROR("Error: SS_load_from_file: cannot read \"%s\"\n", filename);
		return(NULL);
	}
	/* close file */
	file.CloseRead();

	*slen = num;
	J_MESSAGE("done\n");
	return(sbuf);
}

/* compute noise spectrum from head silence for each input */
float * CJuliMFCC::new_SS_calculate(SP16 *wave, int wavelen, Value para, int *slen)
{
	int fftN, n;
	float *bf, *Re, *Im, *spec;
	int t, framenum, start, end, k, i;
	double x, y;

	/* Calculate FFT size */
	fftN = 2;  n = 1;
	while(para.framesize > fftN){
		fftN *= 2; n++;
	}

	/* allocate work area */
	bf = (float *)J_MALLOC((fftN + 1) * sizeof(float));
	Re = (float *)J_MALLOC((fftN + 1) * sizeof(float));
	Im = (float *)J_MALLOC((fftN + 1) * sizeof(float));
	spec = (float *)J_MALLOC((fftN + 1) * sizeof(float));
	for(i=0;i<fftN;i++) spec[i] = 0.0;

	/* Caluculate Sum of Noise Power Spectral */
	framenum = (int)((wavelen - para.framesize) / para.frameshift) + 1;
	start = 1;
	end = 0;
	for (t = 0; t < framenum; t++) {
		if (end != 0) start = end - (para.framesize - para.frameshift) - 1;
		k = 1;
		for (i = start; i <= start + para.framesize; i++) {
			bf[k] = (float)wave[i-1];
			k++;
		}
		end = i;

		/* Pre-emphasis */
		PreEmphasise(bf, para);
		/* Hamming Window */
		Hamming(bf, para.framesize);
		/* FFT Spectrum */
		for (i = 1; i <= para.framesize; i++) {
			Re[i-1] = bf[i]; Im[i-1] = 0.0;
		}
		for (i = para.framesize + 1; i <= fftN; i++) {
			Re[i-1] = 0.0;   Im[i-1] = 0.0;
		}
		FFT(Re, Im, n);
		/* Sum noise spectrum */
		for(i = 1; i <= fftN; i++){
			x = Re[i - 1];  y = Im[i - 1];
			spec[i - 1] += sqrt(x * x + y * y);
		}
	}

	/* Calculate average noise spectrum */
	for(t=0;t<fftN;t++) {
		spec[t] /= (float)framenum;
	}

	/* return the new spec[] */
	J_FREE(Im);
	J_FREE(Re);
	J_FREE(bf);
	*slen = fftN;
	return(spec);
}



