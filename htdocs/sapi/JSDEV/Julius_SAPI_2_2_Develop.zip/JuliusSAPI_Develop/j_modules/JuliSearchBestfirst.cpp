//====================================================================
// JuliSearchBestfirst.cpp: CJuliSearchBestfirst �N���X�̃C���v�������e�[�V����
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliSearchBestfirst.h"

#include "JuliBackTrellis.h"
#include "JuliDictionary.h"
#include "JuliUtil.h"
#include "JuliGlobalOption.h"
#include "JuliGramDfa.h"
#include "JuliDecodeDfa.h"
#include "JuliResultOut.h"

CJuliSearchBestfirst::CJuliSearchBestfirst()
{
	
}

CJuliSearchBestfirst::~CJuliSearchBestfirst()
{
	
}

/* search_bestfirst_main.c --- main stack decoding loop for 2nd pass */

/* nw_* ... nextword related functions */
/* gm_* ... grammar related functions */

/**********************************************************************/
/* ���P��i�[�̈�̊��蓖�� */
/**********************************************************************/

NEXTWORD ** CJuliSearchBestfirst::NwMalloc(int *maxlen, NEXTWORD **root) // nw_malloc
{
	NEXTWORD *nwtmp;
	NEXTWORD **nw;
	int i;
	int max;
	
	max = GetDict()->GetNumWords();
	
	/* �A���̈��z��Ɋ��蓖�Ă� */
	nw = (NEXTWORD **)J_MALLOC(max * sizeof(NEXTWORD *)); /* ���P��̐��͌�b�����z���Ȃ� */
	nwtmp = (NEXTWORD *)J_MALLOC(max * sizeof(NEXTWORD));
	for (i=0;i<max; i++) {
		nw[i] = &(nwtmp[i]);
	}
	*maxlen = max;
	*root = nwtmp;
	return nw;
}

/* �\�����P��i�[�̈�̉�� */
void CJuliSearchBestfirst::NwFree(NEXTWORD **nw, NEXTWORD *root) // nw_free
{
	J_FREE(root);
	J_FREE(nw);
}

#ifdef USE_DFA
/* DFA �̏ꍇ, ���P��̐��͌�b�����z���� */
NEXTWORD ** CJuliSearchBestfirst::NwExpand(NEXTWORD **nwold, int *maxlen, NEXTWORD **root) // nw_expand
{
	NEXTWORD *nwtmp;
	NEXTWORD **nw;
	int i;
	int nwmaxlen;
	
	nwmaxlen = *maxlen + GetDict()->GetNumWords();
	
	nwtmp = (NEXTWORD *)J_REALLOC(*root, nwmaxlen * sizeof(NEXTWORD));
	nw = (NEXTWORD **)J_REALLOC(nwold, nwmaxlen * sizeof(NEXTWORD *));
	nw[0] = nwtmp;
	for (i=1;i<nwmaxlen; i++) {
		nw[i] = &(nwtmp[i]);
	}
	*maxlen = nwmaxlen;
	*root = nwtmp;
	return nw;
}
#endif


/**********************************************************************/
/* �������X�^�b�N���� */
/**********************************************************************/

/* �X�^�b�N�g�b�v��POP���� */
NODE * CJuliSearchBestfirst::GetBestFromStack(NODE **start, int *stacknum) // get_best_from_stack
{
	NODE *tmp;
	
	tmp=(*start);
	if ((*start)!=NULL) {
		(*start)=(*start)->next;
		if ((*start)!=NULL) (*start)->prev=NULL;
		(*stacknum)--;
		return(tmp);
	}
	else {
		return(NULL);
	}
}

/* �X�^�b�N�Ƀf�[�^������(PUSH�ɂ��炸) */
int CJuliSearchBestfirst::PutToStack(NODE *_new, NODE **start, NODE **bottom, int *stacknum, int stacksize) // put_to_stack
{
	NODE *tmp;
	
	(*stacknum)++;
	
	if ((*stacknum)>=stacksize) {	/* overflow */
		(*stacknum)--;
		if ((*bottom)->score < _new->score) { /* free bottom */
			tmp=(*bottom);
			(*bottom)->prev->next=NULL;
			(*bottom)=(*bottom)->prev;
			FreeNode(tmp);
		}
		else {
			FreeNode(_new);		/* free newnode */
			return(-1);
		}
	}
    
	if ((*start)==NULL) {		/* no data */
		(*start)=_new;
		(*bottom)=_new;
		_new->next=NULL;
		_new->prev=NULL;
		return(0);
	}
	if ((*start)->score <= _new->score) { /* on the top */
		_new->next = (*start);
		_new->next->prev = _new;
		(*start)=_new;
		_new->prev=NULL;
		return(0);
	}
	if ((*bottom)->score >= _new->score) {	/* on the bottom */
		_new->prev = (*bottom);
		_new->prev->next = _new;
		(*bottom)=_new;
		_new->next=NULL;
		return(0);
	}
    
	/* now
	(*start)->score < tmp->score < (*bottom)->score
	*/
	if (((*start)->score + (*bottom)->score) / 2 > _new->score) {
		/* search from bottom */
		tmp=(*bottom);
		while(tmp->score < _new->score) tmp=tmp->prev;
		_new->prev=tmp;
		_new->next=tmp->next;
		tmp->next->prev=_new;
		tmp->next=_new;
	} else {
		/* search from start */
		tmp=(*start);
		while(tmp->score > _new->score) tmp=tmp->next;
		_new->next=tmp;
		_new->prev=tmp->prev;
		tmp->prev->next=_new;
		tmp->prev=_new;
	}
	return(0);
}

/* �X�^�b�N���̉�����S�ďo�� */
/* �X�^�b�N�̒��g�͎����� */
void CJuliSearchBestfirst::PutAllInStack(NODE **start, int *stacknum) // put_all_in_stack
{
	NODE *ntmp;
	
	J_OUTPUT("stack remains::\n");
	while ((ntmp = GetBestFromStack(start, stacknum)) != NULL) {
		J_OUTPUT("%3d: s=%f ",*stacknum, ntmp->score);
		PutHypoOutput(ntmp);
		FreeNode(ntmp);
	}
}

/* �X�^�b�N���̑S��������� */
void CJuliSearchBestfirst::FreeAllNodes(NODE *node) // free_all_nodes
{
	NODE *tmp;
	NODE *next;
	
	tmp=node;
	while(tmp) {
		next=tmp->next;
		FreeNode(tmp);
		tmp=next;
	}
}

/**********************************************************************/
/* enveloped best-first */
/**********************************************************************/

/* ���������̉������A��萔�ȏ�͕ۑ����Ȃ��悤�ɂ��� */
/* �ň��ł��r�[���T���ɂȂ� */

void CJuliSearchBestfirst::WbInit() // wb_init
{
	int i;
	for(i=0;i<=MAXSEQNUM;i++) hypo_len_count[i] = 0;
}

boolean CJuliSearchBestfirst::WbOk(NODE *now) // wb_ok
{
	if (hypo_len_count[now->seqnum] >= GetOptions()->enveloped_bestfirst_width) {
		if (theOpt.debug2_flag) {
			J_OUTPUT("popped but pruned by word envelope: ");
			PutHypoOutput(now);
		}
		return FALSE;
	} else {
		hypo_len_count[now->seqnum]++;
		return TRUE;
	}
}

/**********************************************************************/
/* score-based envelope */
/**********************************************************************/

#ifdef SCAN_BEAM
void CJuliSearchBestfirst::EnvlInit(int framenum) // envl_init
{
	int i;
	for(i=0;i<framenum;i++) GetOptions()->framemaxscore[i] = LOG_ZERO;
}

/* ����N�̑O�����X�R�A����envelope���X�V���� */
void CJuliSearchBestfirst::EnvlUpdate(NODE *n, int framenum) // envl_update
{
	int t;
	for(t=framenum-1;t>=0;t--) {
		if (GetOptions()->framemaxscore[t] < n->g[t]) GetOptions()->framemaxscore[t] = n->g[t];
	}
}
#endif /* SCAN_BEAM */


/**********************************************************************/
/* sp segment restart */
/**********************************************************************/
#ifdef SP_BREAK_CURRENT_FRAME

/* ���̃Z�O�����g�֌��ꐧ����������邽��, �ŏI�P����X�V */
/* �ŏI�P�ꁁ�ĊJ�P��Əd�Ȃ�̂��������C���O�̔�transp�P�� */
/* �Y���Ȃ��Ȃ�X�V���Ȃ� */
void CJuliSearchBestfirst::SpSegmentSetLastNword(NODE *hypo) // sp_segment_set_last_nword
{
	int i;
	WORD_ID w;
	for(i=0;i<hypo->seqnum;i++) {
		w = hypo->seq[i];
		if (w != sp_break_last_word
			&& !is_sil(GetDict()->GetWordSeq(w)[0]->name)
			&& !GetDict()->IsTransparent(w)
			) {
			sp_break_last_nword = w;
			break;
		}
	}
}
#endif

/**********************************************************************/
/* �������̏o�͊֐� */
/**********************************************************************/

/* �����̏o�̓V���{�����o�� */
void CJuliSearchBestfirst::PutHypoOutput(NODE *hypo) // put_hypo_woutput
{
	int i,w;
	
	if (hypo != NULL) {
		for (i=hypo->seqnum-1;i>=0;i--) {
			w = hypo->seq[i];
			J_OUTPUT(" %s",GetDict()->GetWordOutput(w));
		}
		/*    if (speech_input == SP_ADINSERV) {
		for (i=hypo->seqnum-1;i>=0;i--) {
		w = hypo->seq[i];
		if (strlen(GetDict()->GetWordOutput(w)) > 0)
		wt(adinnet_asd, GetDict()->GetWordOutput(w), strlen(GetDict()->GetWordOutput(w)));
		}
		wt(adinnet_asd, (char *)&i, 0);
	}*/
	}
	J_OUTPUT("\n");  
}

/* �����̌���G���g���P���W���o�͂ɏo�͂��� */
void CJuliSearchBestfirst::PutHypoWordName(NODE *hypo) // put_hypo_wname
{
	int i,w;
	
	if (hypo != NULL) {
		for (i=hypo->seqnum-1;i>=0;i--) {
			w = hypo->seq[i];
			J_OUTPUT(" %s", GetDict()->GetWordName(w));
		}
	}
	J_OUTPUT("\n");  
}

/* �����̉��f����o�� */
void CJuliSearchBestfirst::PutHypoPhoneme(NODE *hypo) // put_hypo_phoneme
{
	int i,j,w;
	char buf[20];
	
	if (hypo != NULL) {
		for (i=hypo->seqnum-1;i>=0;i--) {
			w = hypo->seq[i];
			for (j=0;j<GetDict()->GetWordLen(w);j++) {
				CJuliUtil::GetCenterName(GetDict()->GetWordSeq(w)[j]->GetName(), buf);
				J_OUTPUT(" %s", buf);
			}
			if (i > 0) J_OUTPUT(" |");
		}
	}
	J_OUTPUT("\n");  
}

#include <math.h>
/* �����p�X�^�b�N�������ʂ̌��ʂ���C�ɏo�͂��� */
void CJuliSearchBestfirst::ReorderAndOutputResult(NODE **r_start, NODE **r_bottom, int *r_stacknum, int ncan) // result_reorder_and_output
{
	J_DEBUGMESSAGE("��CJuliSearchBestfirst::ReorderAndOutputResult(ncan=%d)\n", ncan);

	if (1/*theOpt.m_bUseFalseRecognition == 0*/)
	{
		NODE *now;
		int num;
		
		num = 0;
//		ncan = (theOpt.m_bUseNbest)? theOpt.m_iNbest : 1;
		while ((now = GetBestFromStack(r_start,r_stacknum)) != NULL && num < ncan) {
			/* �o�� */
			num++;
			OutputResult(now, num);
			/* �̂Ă� */
			FreeNode(now);
		}
		/* �c����S�� free ���� */
		if (now != NULL) FreeNode(now);
	} else {
		NODE *node1, *node2;
		// ���2�������āA�X�R�A�̈Ⴂ���݂�
		node1 = GetBestFromStack(r_start, r_stacknum);	// ��1���
		node2 = GetBestFromStack(r_start, r_stacknum);	// ��2���

		if (node2==NULL || ! GetContext()->IsSAPI())
		{
			OutputResult(node1, 1);
		} else {
			J_MESSAGE("��SCORE:%f - %f = %f <=> %f\n", node1->score, node2->score,
				node1->score- node2->score, theOpt.m_probFRScore);
			if (node1->score - node2->score > theOpt.m_probFRScore)
			{
				OutputResult(node1, 1);	// �F��
			} else {
				GetResultOut()->Final2(NULL, 1, NULL);	// �F�����s
			}
		}

		FreeNode(node1);
		FreeNode(node2);
	}
	FreeAllNodes(*r_start);
}  


/**********************************************************************/
/* �T�����s���C���֐� */
/**********************************************************************/

void CJuliSearchBestfirst::Start(
								 CJuliHtkParam *param,		/* parameter vectors */
								 LOGPROB backmax,		/* backmax (retuen value) */
								 int stacksize,		/* stack size of sentence hypothesis */
								 int ncan,			/* num of hypothesis to get */
								 int maxhypo		/* maximum number of poped hypothesis */
								 ) // wchmm_fbs
{
	J_DEBUGMESSAGE("��CJuliSearchBestfirst::Start(backmax=%f, stacksize=%d, nbest=%d, maxhypo=%d)\n",
		backmax, stacksize, ncan, maxhypo);
	// �܂�
	const CJuliBackTrellis *backtrellis = GetBackTrellis();
	
	/* �������X�^�b�N */
	int stacknum;			/* �X�^�b�N�̑傫�� ( < stacksize ) */
	NODE *start = NULL;
	NODE *bottom = NULL;
	
	/* ����ꂽ�����X�^�b�N for re-ordering */
	int r_stacksize = ncan + 1;
	int r_stacknum;
	NODE *r_start = NULL;
	NODE *r_bottom = NULL;
	
	/* �J�E���^�� */
	int popctr = 0;		/* �X�^�b�N������o������������ */
	int genectr = 0;		/* ���������� */
	int pushctr = 0;		/* �X�^�b�N�ɓ������������� */
	int finishnum = 0;		/* �T���̌��ʓ���ꂽ�������� */
	
	/* .$B%o!<%/%(%j%".(B */
	NEXTWORD **nextword, *nwroot;		/* .$BM=B,<!C18l$N3JG<NN0h.(B */
	int maxnwnum;
	int nwnum;
	NODE *now, *_new;
#ifdef USE_DFA
	NODE *now_noise, *now_noise_tmp;
	boolean now_noise_calced;
	int t;
#endif
	int w,i,j;
	LOGPROB last_score = LOG_ZERO;
	
	if (theOpt.align_result_word_flag || theOpt.align_result_phoneme_flag) tparam = param; /* store temporary */
	
	/* ������ */
	GetOptions()->peseqlen = backtrellis->GetFrameLen();	/* for quick access */
	nextword = NwMalloc(&maxnwnum, &nwroot);	/* .$BM=B,C18l3JG<NN0h$r3NJ].(B */
	MallocWordTrellis();		/* scan_word.$BMQNN0h.(B */
	start = bottom = NULL;	/* .$BJ82>@b%9%?%C%/=i4|2=.(B */
	stacknum = 0;
	if (theOpt.result_reorder_flag) {
		r_start = r_bottom = NULL;
		r_stacknum = 0;
	}
	if (GetOptions()->enveloped_bestfirst_width >= 0) WbInit();
	
	if (theOpt.verbose_flag) J_DEBUGMESSAGE("samplenum=%d\n", GetOptions()->peseqlen);
	if (theOpt.result_reorder_flag) {
		if (theOpt.debug2_flag) J_VERMES("getting %d candidates...\n",ncan);
	}
	
	/* 
	* ������1�P�ꂩ��Ȃ鉼�������C�������X�^�b�N�ɂ����
	*/
	nwnum = GetDecode()->FirstWords(nextword, GetOptions()->peseqlen, maxnwnum); /* nextwords�Ɋi�[����� */
	if (IS_DFA)
	{
		/* ��ꂽ��A�o�b�t�@�𑝂₵�čă`�������W */
		while (nwnum < 0) {
			nextword = NwExpand(nextword, &maxnwnum, &nwroot);
			nwnum = GetDecode()->FirstWords(nextword, GetOptions()->peseqlen, maxnwnum);
		}
	}
	
	J_DEBUGMESSAGE("first words=%d\n", nwnum);
	//	J_OUTPUT_ON_DEBUG("first words=%d\n", nwnum);
	for (w = 0; w < nwnum; w++) {
		_new = NewNode();
		StartWord(_new, nextword[w], param);
		if (IS_DFA)
		{
			/* NOISE: �ŏ��ɂ͂��Ȃ��d�l */
			if (_new->score <= LOG_ZERO) { /* not on trellis */
				FreeNode(_new);
				continue;
			}
		}
		genectr++;
		if (PutToStack(_new, &start, &bottom, &stacknum, stacksize) != -1) {
			pushctr++;
		}
	}
	J_MESSAGE("stacknum=%d\n",stacknum);
	
	/**************/
	/* �T�����[�v */
	/**************/
	
	for (;;) {
	/*
	* �������X�^�b�N����ł��X�R�A�̍������������o��
		*/
		J_OUTPUT_ON_DEBUG("get one hypothesis\n");
		
		now = GetBestFromStack(&start,&stacknum);
		if (now == NULL) {  /* stack empty ---> �T���I��*/
			J_OUTPUT_ON_DEBUG("stack empty\n");
			break;
		}
		if (now->score <= LOG_ZERO) continue;
		/* ���������̉�������萔�ȏ�W�J���Ă�����A��������ȏ�͓W�J���Ȃ� */
		if (GetOptions()->enveloped_bestfirst_width >= 0) {
			if (!WbOk(now)) {
				FreeNode(now);
				continue;
			}
		}
		popctr++;
		
		/* 
		* ���o���������Ƃ��̃X�R�A�����O�ɏo��
		*/
		
		if (theOpt.debug2_flag) {
			J_OUTPUT("--- pop %d:\n", popctr);
			J_OUTPUT("  "); PutHypoOutput(now);
			J_OUTPUT("  "); PutHypoWordName(now);
			J_OUTPUT("  %d words, f=%f, g=%f\n", now->seqnum, now->score, now->g[now->bestt]);
			J_OUTPUT("  last word on trellis: [%d-%d]\n", now->estimated_next_t + 1, now->bestt);
		}
		
		/* ���o���������̃X�R�A������envelope���X�V */
		EnvlUpdate(now, GetOptions()->peseqlen);
		
		/* 
		* ���o���������̎󗝃t���O�����ɗ����Ă���΁C
		* ���̉����͒T���I���Ƃ݂Ȃ��C���ʂƂ��ďo�͂��Ď��̃��[�v�ցD
		*/
		J_OUTPUT_ON_DEBUG("endflag check\n");
		if (now->endflag) {
			/* hack */
			if (now->score == last_score) {
				/* �\�����Ȃ� */
				FreeNode(now);
				continue;
			} else {
				last_score = now->score;
			}
			finishnum++;
			
			if (theOpt.result_reorder_flag) {
			/* ��萔�̉���������ꂽ���ƃX�R�A�Ń\�[�g���邽�߁C
				* �ꎞ�I�ɕʂ̃X�^�b�N�Ɋi�[���Ă��� */
				PutToStack(now, &r_start, &r_bottom, &r_stacknum, r_stacksize);
				/* �w�萔�̕�����������ꂽ�Ȃ�T�����I������ */
				if (finishnum >= ncan) {
					if (theOpt.debug2_flag) J_VERMES("%d\n",finishnum);
					break;
				} else {
					if (theOpt.debug2_flag) J_VERMES("%d..", finishnum);
					continue;
				}
			} else {
				/* ��������\�� */
				OutputResult(now, finishnum);
				/* ���̉����͂����I��� */
				FreeNode(now);
				/* �w�萔�̕�����������ꂽ�Ȃ�T�����I������ */
				if (finishnum >= ncan) break;
				else continue;
			}
			
		}
		
		/* 
		* �T�����s�����o����D
		* ��������MAXHYPO�ȏ�W�J���ꂽ�玸�s�ƌ��Ȃ��D
		*/
		J_OUTPUT_ON_DEBUG("loop end check\n");
		
		if (popctr >= maxhypo) {
			J_OUTPUT("num of hypotheses overflow\n");
			/* �T�����s���ɁA�X�^�b�N�Ɏc��������f���o�� */
			if (theOpt.debug2_flag) PutAllInStack(&start, &stacknum);
			FreeNode(now);
			break;			/* �T���I�� */
		}
		
		/* �����������l���z�����Ƃ��C���̉�����j������ */
		if (now->seqnum >= MAXSEQNUM) {
			J_MESSAGE("sentence length exceeded ( > %d)\n",MAXSEQNUM);
			FreeNode(now);
			continue;
		}
		
		/*
		* ���o���������̑O�����X�R�A���v�Z����D
		* �Ō�̒P��̕����̑O�����X�R�A���v�Z����D
		*/
		J_OUTPUT_ON_DEBUG("scan_word\n");
		
		ScanWord(now, param);
		if (now->score < backmax + LOG_ZERO) {
			J_OUTPUT("now->score = %f?\n",now->score);
			PutHypoOutput(now);
			FreeNode(now);
			break;
		}
		/* �����̏I�[���Ԃ𐄒肷�� */
		/* �v�b�V���O�� next_word (start_word) ��now->estimated_next_t�Ɋi�[�� */
		
		/* 
		* ���o�������������Ƃ��Ď󗝉\�ł���΁C
		* �󗝃t���O�𗧂Ă����̂��X�^�b�N�ɂ��꒼���Ă����D
		* (���Ɏ��o���ꂽ��I��)
		*/
		J_OUTPUT_ON_DEBUG("accept check\n");
		if (GetDecode()->Acceptable(now) && now->estimated_next_t <= 5) {
			_new = NewNode();
			LastNextWord(now, _new, param);
			_new->endflag = TRUE;
			PutToStack(_new, &start, &bottom, &stacknum, stacksize);
		}
		
		/* 
		* ���o���������ɐڑ�������P���t�������V���ȕ������𐶐����C
		* �X�^�b�N�ɂ����D(�ŏI�P��̃X�R�A�̓q���[���X�e�B�b�N�X�R�A�̂܂�)
		*/
		
		J_OUTPUT_ON_DEBUG("generate hypo\n");
		nwnum = GetDecode()->NextWords(now, nextword, maxnwnum);
		if (IS_DFA)
		{
			/* ��ꂽ��A�o�b�t�@�𑝂₵�čă`�������W */
			while (nwnum < 0) {
				nextword = NwExpand(nextword, &maxnwnum, &nwroot);
				nwnum = GetDecode()->NextWords(now, nextword, maxnwnum);
			}
		}
		
		if (IS_DFA)
		{
			now_noise_calced = FALSE;
		}
		
		i = pushctr;
		for (w = 0; w < nwnum; w++) {
			_new = NewNode();
			if (IS_DFA)
			{
				if (nextword[w]->can_insert_sp == TRUE) {
					/* �m�C�Y�����񂾃g�����X�X�R�A���v�Z */
					if (now_noise_calced == FALSE) {
						fornoise.id = GetGramDfa()->GetShortPauseID();
						now_noise = NewNode();
						CopyNode(now_noise, now);
#if 0
						now_noise_tmp = NewNode();
						NextWord(now, now_noise_tmp, &fornoise, param, backtrellis);
						ScanWord(now_noise_tmp, param);
						for(t=0;t<GetOptions()->peseqlen;t++) {
							now_noise->g[t] = max(now_noise_tmp->g[t], now->g[t]);
						}
						FreeNode(now_noise_tmp);
#else
						/* expand NOISE only if it exists in backward trellis */
						/* begin patch by kashima */
						if (theOpt.looktrellis_flag) {
							if(!GetDecodeDfa()->DfaLookAround(&fornoise, now)){
								FreeNode(now_noise);
								FreeNode(_new);
								continue;
							}
						}
						/* end patch by kashima */
						NextWord(now, now_noise, &fornoise, param);
						ScanWord(now_noise, param);
						for(t=0;t<GetOptions()->peseqlen;t++) {
							now_noise->g[t] = max(now_noise->g[t], now->g[t]);
						}
						/* cancel noise entry */
						now_noise->seqnum--;
#endif
						now_noise_calced = TRUE;
					}
					/* expand word only if it exists in backward trellis */
					/* begin patch by kashima */
					if (theOpt.looktrellis_flag) {
						if(!GetDecodeDfa()->DfaLookAround(nextword[w], now_noise)){
							FreeNode(_new);
							continue;
						}
					}
					/* end patch by kashima */
					NextWord(now_noise, _new, nextword[w], param);
				} else {
					/* expand word only if it exists in backward trellis */
					/* begin patch by kashima */
					if (theOpt.looktrellis_flag) {
						if(!GetDecodeDfa()->DfaLookAround(nextword[w], now)){
							FreeNode(_new);
							continue;
						}
					}
					/* end patch by kashima */
					NextWord(now, _new, nextword[w], param);
				}
			}
			if (IS_NGRAM)
			{
				NextWord(now, _new, nextword[w], param);
			}
			if (_new->score <= LOG_ZERO) { /* not on trellis */
				FreeNode(_new);
				continue;
			}
			genectr++;
			if (PutToStack(_new, &start, &bottom, &stacknum, stacksize) != -1) {
				if (theOpt.debug2_flag) {
					j = _new->seq[_new->seqnum-1];
					J_OUTPUT("  %15s [%15s](id=%5d)(%f) [%d-%d] pushed\n",
						GetDict()->GetWordName(j), GetDict()->GetWordOutput(j), j, _new->score,
						_new->estimated_next_t + 1, _new->bestt);
				}
				pushctr++;
			}
		}
		if (theOpt.debug2_flag) {
			J_OUTPUT("%d pushed\n",pushctr-i);
		}
		if (IS_DFA)
		{
			if (now_noise_calced == TRUE) FreeNode(now_noise);
		}
		
		/* 
		* ���o�����������̂Ă�
		*/
		FreeNode(now);
		
		/* ���f�`�F�b�N */
		if (theOpt.catch_intr_flag) break;
		
	}
	/***************/
	/* End of Loop */
	/***************/
	
	/* �o�� */
	/* �T�����s�ň����₪�����Ȃ���΁C */
	/* ��1�p�X�̌��ʂ����̂܂܏o�͂��� */
	if (finishnum == 0) {
		if (theOpt.verbose_flag) {
			J_MESSAGE("got no candidates, output 1st pass result as a final result\n",finishnum);
		}
		now = NewNode();
		for (i=0;i<GetContext()->GetPass1WordNum();i++) {
			now->seq[i] = GetContext()->GetPass1WordSeq(GetContext()->GetPass1WordNum()-1-i);
		}
		now->seqnum = GetContext()->GetPass1WordNum();
		now->score = GetContext()->GetPass1Score();
		OutputResult(now, 1);
		FreeNode(now);
	} else {
		if (theOpt.debug2_flag) {
			J_OUTPUT("got %d candidates\n",finishnum);
		}
		if (theOpt.result_reorder_flag) {
			if (theOpt.debug2_flag) J_VERMES("done\n");
			/* �����p�X�^�b�N�����\�[�g���āC���ʂ���C�ɏo�͂��� */
			/* ���łɃX�^�b�N���N���A���� */
//			ReorderAndOutputResult(&r_start, &r_bottom, &r_stacknum, GetOptions()->output_hypo_maxnum);
			ReorderAndOutputResult(&r_start, &r_bottom, &r_stacknum, 10);
		}
	}
	
	/* �e��J�E���^���o�� */
	if (theOpt.verbose_flag) {
		J_MESSAGE("%d generated, %d pushed, %d nodes popped in %d\n",
			genectr, pushctr, popctr, backtrellis->GetFrameLen());
	}
	
	/* .$B=*N;=hM}.(B */
	NwFree(nextword, nwroot);
	FreeAllNodes(start);
	FreeWordTrellis();
	
}

/* word_align.c --- perform viterbi alignment for given words or phonemes */

/* build sentence HMM from word sequence */

const CJuliHtkHmmLogical **CJuliSearchBestfirst::MakePhSeq(WORD_ID *wseq, short num, int *num_ret, int **end_ret, boolean per_phoneme) // make_phseq
{
	const CJuliHtkHmmLogical **ph;		/* phoneme sequence */
	int phnum;			/* num of above */
	WORD_ID tmpw, w;
	int i, pn, st, endn;
	const CJuliHtkHmmLogical *tmpp, *ret;
	
	/* make ph[] from wseq[] */
	/* 1. calc total phone num and malloc */
	phnum = 0;
	for (w=0;w<num;w++) phnum += GetDict()->GetWordLen(wseq[w]);
	ph = (const CJuliHtkHmmLogical **)J_MALLOC(sizeof(CJuliHtkHmmLogical *) * phnum);
	/* 2. make phoneme sequence */
	st = 0;
	pn = 0;
	endn = 0;
	for (w=0;w<num;w++) {
		tmpw = wseq[w];
		for (i=0;i<GetDict()->GetWordLen(tmpw);i++) {
			tmpp = GetDict()->GetWordSeq(tmpw)[i];
			/* handle cross-word context dependency */
			if (theOpt.ccd_flag) {
				if (w > 0 && i == 0) {	/* word head */
					
					if ((ret = GetHmm()->GetLeftContextHMM(tmpp, ph[pn-1]->GetName())) != NULL) {
						tmpp = ret;
					}
					/* if triphone not found, fallback to bi/mono-phone  */
					/* use pseudo phone when no bi-phone found in alignment... */
				}
				if (w < num-1 && i == GetDict()->GetWordLen(tmpw) - 1) { /* word tail */
					if ((ret = GetHmm()->GetRightContextHMM(tmpp, GetDict()->GetWordSeq(wseq[w+1])[0]->GetName())) != NULL) {
						tmpp = ret;
					}
				}
			}
			ph[pn++] = tmpp;
			st += tmpp->GetStateNum() - 2;
			if (per_phoneme) (*end_ret)[endn++] = st - 1;
		}
		if (!per_phoneme) (*end_ret)[endn++] = st - 1;
	}
	*num_ret = phnum;
	return ph;
}

/* build sentence HMM, call viterbi_segment() and output result */
/* NOTE: words are in reverse order */
void CJuliSearchBestfirst::DoAlign(WORD_ID *words, short wnum, CJuliHtkParam *param, boolean per_phoneme,
								   ALIGNRESULT *ar) // do_align
{
	const CJuliHtkHmmLogical **phones;		/* phoneme sequence */
	int phonenum;			/* num of above */
	CJuliHMM *shmm;			/* sentence HMM */
	int *end_state;		/* state number of word ends */
	int *end_frame;		/* segmented last frame of words */
	LOGPROB *end_score;		/* normalized score of each words */
	LOGPROB allscore;		/* total score of this word sequence */
	WORD_ID w;
	int end_num;
	
	if (per_phoneme) {
		J_OUTPUT("=== phoneme alignment begin ===\n");
	} else {
		J_OUTPUT("=== word alignment begin ===\n");
	}
	
	/* initialize result buffers */
	if (per_phoneme) {
		end_num = 0;
		for(w=0;w<wnum;w++) end_num += GetDict()->GetWordLen(words[w]);
	} else {
		end_num = wnum;
	}
	end_state = (int *)J_MALLOC(sizeof(int) * end_num);
	end_frame = (int *)J_MALLOC(sizeof(int) * end_num);
	end_score = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * end_num);
	
	/* make phoneme sequence word sequence */
	phones = MakePhSeq(words, wnum, &phonenum, &end_state, per_phoneme);
	/* build the sentence HMMs */
	shmm = new CJuliHMM(GetHmm(), phones, phonenum);
	
	/* call viterbi segmentation function */
	allscore = ViterbiSegment(shmm, param, end_state, end_num, end_frame, end_score);
	
//	���ʂ��i�[ (endframe, endscore, allscore)
	ar->e_frame.clear();
	ar->e_score.clear();
	for (int i=0;i<end_num;i++) {
		ar->e_frame.push_back(end_frame[i]);
		ar->e_score.push_back(end_score[i]);
	}
	ar->a_score = allscore;

	/* print result */
	{
		int i,p,n;
		J_OUTPUT("id: from  to    n_score    applied HMMs (logical[physical] or {pseudo})\n");
		J_OUTPUT("------------------------------------------------------------\n");
		n = 0;
		for (i=0;i<end_num;i++) {
			J_OUTPUT("%2d: %4d %4d  %f ", i, (i == 0) ? 0 : end_frame[i-1]+1, end_frame[i], end_score[i]);
			if (per_phoneme) {
				if (phones[n]->IsPseudo()) {
					J_OUTPUT(" {%s}", phones[n]->GetName());
				} else if (strmatch(phones[n]->GetName(), phones[n]->GetBodyDefined()->GetName())) {
					J_OUTPUT(" %s", phones[n]->GetName());
				} else {
					J_OUTPUT(" %s[%s]", phones[n]->GetName(), phones[n]->GetBodyDefined()->GetName());
				}
				n++;
			} else {
				for(p=0;p<GetDict()->GetWordLen(words[i]);p++) {
					if (phones[n]->IsPseudo()) {
						J_OUTPUT(" %s{%s}", phones[n]->GetName(), phones[n]->GetPseudo()->name);
					} else if (strmatch(phones[n]->GetName(), phones[n]->GetBodyDefined()->GetName())) {
						J_OUTPUT(" %s", phones[n]->GetName());
					} else {
						J_OUTPUT(" %s[%s]", phones[n]->GetName(), phones[n]->GetBodyDefined()->GetName());
					}
					n++;
				}
			}
			J_OUTPUT("\n");
		}
	}
	J_OUTPUT("re-computed AM score: %f\n", allscore);
	
	J_FREE(phones);
	J_FREE(end_score);
	J_FREE(end_frame);
	J_FREE(end_state);
	
	if (per_phoneme) {
		J_OUTPUT("=== phoneme alignment end ===\n");
	} else {
		J_OUTPUT("=== word alignment end ===\n");
	}
	delete shmm;
}

void CJuliSearchBestfirst::WordAlign(WORD_ID *words, short wnum, CJuliHtkParam *param, ALIGNRESULT *ar) // word_align
{
	DoAlign(words, wnum, param, FALSE, ar);
}

void CJuliSearchBestfirst::WordAlign_Rev(WORD_ID *revwords, short wnum, CJuliHtkParam *param, ALIGNRESULT *ar) // word_rev_align
{
	WORD_ID *words;		/* word sequence (true order) */
	int w;
	words = (WORD_ID *)J_MALLOC(sizeof(WORD_ID) * wnum);
	for (w=0;w<wnum;w++) words[w] = revwords[wnum-w-1];
	DoAlign(words, wnum, param, FALSE, ar);
	J_FREE(words);
}

void CJuliSearchBestfirst::PhonemeAlign(WORD_ID *words, short wnum, CJuliHtkParam *param, ALIGNRESULT *ar) // phoneme_align
{
	DoAlign(words, wnum, param, TRUE, ar);
}

void CJuliSearchBestfirst::PhonemeAlign_Rev(WORD_ID *revwords, short wnum, CJuliHtkParam *param, ALIGNRESULT *ar) // phoneme_rev_align
{
	WORD_ID *words;		/* word sequence (true order) */
	int w;
	words = (WORD_ID *)J_MALLOC(sizeof(WORD_ID) * wnum);
	for (w=0;w<wnum;w++) words[w] = revwords[wnum-w-1];
	DoAlign(words, wnum, param, TRUE, ar);
	J_FREE(words);
}

/* vsegment.c --- do viterbi segmentation to given unit */

/* HMM must be given in a single HMM structure, and */
/* separately specify where to get segment information in a certain unit */

typedef struct __seg_token__ {
	int last_end_frame;
	LOGPROB last_end_score;
	struct __seg_token__ *next;
} SEGTOKEN;

LOGPROB				/* returns the acoustic score */
CJuliSearchBestfirst::ViterbiSegment(CJuliHMM *hmm,	/* concatinated sentence HMMs */
				CJuliHtkParam *param,	/* input parameter vectors */
				int *endstates,	/* where unit ends in the hmm */
				int ulen,		/* total unit numin the hmm */
				int *seg_ret,	/* return segmented frame number at each endstates */
				LOGPROB *uscore_ret)/* return normalized scores for each unit */ // viterbi_segment
{
	/* for viterbi */
	LOGPROB *nodescore[2];	/* node buffer */
	SEGTOKEN **tokenp[2];		/* propagating token which holds segment info */
	int *from_node;
	int *u_end, *u_start;	/* the node is an end of the word, or -1 */
	int i, n, t;
	int tl,tn;
	LOGPROB tmpsum;
	A_CELL *ac;
	SEGTOKEN *newtoken, *token, *tmptoken;
	LOGPROB result_score;
	LOGPROB maxscore, minscore;	/* for debug */
	int maxnode;			/* for debug */
	
	/* assume more than 1 units */
	if (ulen < 1) {
		J_ERROR("Error: viterbi_segment: no unit?\n");
		return LOG_ZERO;
	}
	
	/* initialize unit start/end marker */
	u_start = (int *)J_MALLOC(hmm->GetLength() * sizeof(int));
	u_end   = (int *)J_MALLOC(hmm->GetLength() * sizeof(int));
	for (n = 0; n < hmm->GetLength(); n++) {
		u_start[n] = -1;
		u_end[n] = -1;
	}
	u_start[0] = 0;
	u_end[endstates[0]] = 0;
	for (i=1;i<ulen;i++) {
		u_start[endstates[i-1]+1] = i;
		u_end[endstates[i]] = i;
	}
#if 0
	for (i=0;i<hmm->GetLength();i++) {
		printf("unit %d: start=%d, end=%d\n", i, u_start[i], u_end[i]);
	}
#endif
	
	/* initialize node buffers */
	tn = 0;
	tl = 1;
	for (i=0;i<2;i++){
		nodescore[i] = (LOGPROB *)J_MALLOC(hmm->GetLength() * sizeof(LOGPROB));
		tokenp[i] = (SEGTOKEN **)J_MALLOC(hmm->GetLength() * sizeof(SEGTOKEN *));
	}
	for (n = 0; n < hmm->GetLength(); n++) {
		nodescore[tn][n] = LOG_ZERO;
		newtoken = (SEGTOKEN *)J_MALLOC(sizeof(SEGTOKEN));
		newtoken->last_end_frame = -1;
		newtoken->last_end_score = 0.0;
		newtoken->next = NULL;
		tokenp[tn][n] = newtoken;
	}
	from_node = (int *)J_MALLOC(sizeof(int) * hmm->GetLength());
	
	/* first frame: only set initial score */
	/*if (hmm->state[0].is_pseudo_state) {
    j_printerr("Warning: state %d: pseudo state?\n", 0);
}*/
	nodescore[tn][0] = GetOutProb()->CalcOutProb(0, hmm->GetHmmState(0), param);
	
	/* do viterbi for rest frame */
	for (t = 1; t < (int )param->samplenum; t++) {
		i = tl;
		tl = tn;
		tn = i;
		maxscore = LOG_ZERO;
		minscore = 0.0;
		
		/* clear next scores */
		for (i=0;i<hmm->GetLength();i++) {
			nodescore[tn][i] = LOG_ZERO;
			from_node[i] = -1;
		}
		
		/* select viterbi path for each node */
		for (n = 0; n < hmm->GetLength(); n++) {
			if (nodescore[tl][n] <= LOG_ZERO) continue;
			for (ac = hmm->GetHmmState(n)->ac; ac; ac = ac->next) {
				tmpsum = nodescore[tl][n] + ac->a;
				if (nodescore[tn][ac->arc] < tmpsum) {
					nodescore[tn][ac->arc] = tmpsum;
					from_node[ac->arc] = n;
				}
			}
		}
		/* propagate token, appending new if path was selected between units */
		for (n = 0; n < hmm->GetLength(); n++) {
			if (from_node[n] == -1) {
				tokenp[tn][n] = NULL;
			} else if (nodescore[tn][n] <= LOG_ZERO) {
				tokenp[tn][n] = tokenp[tl][from_node[n]];
			} else {
				if (u_end[from_node[n]] != -1 && u_start[n] != -1
					&& from_node[n] !=  n) {
					newtoken = (SEGTOKEN *)J_MALLOC(sizeof(SEGTOKEN));
					newtoken->last_end_frame = t-1;
					newtoken->last_end_score = nodescore[tl][from_node[n]];
					newtoken->next = tokenp[tl][from_node[n]];
					tokenp[tn][n] = newtoken;
				} else {
					tokenp[tn][n] = tokenp[tl][from_node[n]];
				}
			}
		}
		/* calc outprob to new nodes */
		for (n = 0; n < hmm->GetLength(); n++) {
			if (nodescore[tn][n] > LOG_ZERO) {
				if (hmm->GetHmmState(n)->is_pseudo_state) {
					J_ERROR("Warning: state %d: pseudo state?\n", n);
				}
				nodescore[tn][n] += GetOutProb()->CalcOutProb(t, hmm->GetHmmState(n), param);
			}
			if (nodescore[tn][n] > maxscore) { /* for debug */
				maxscore = nodescore[tn][n];
				maxnode = n;
			}
		}
		
#if 0
		for (i=0;i<ulen;i++) {
			printf("%d: unit %d(%d-%d): begin_frame = %d\n", t - 1, i,
				(i > 0) ? endstates[i-1]+1 : 0, endstates[i],
				tokenp[tl][endstates[i]]->last_end_frame + 1);
		}
#endif
		
		/* printf("t=%3d max=%f n=%d\n",t,maxscore, maxnode); */
		
	}
	
	result_score = nodescore[tn][hmm->GetLength()-1];
	
	/* parse back the last token to see the trail of best viterbi path */
	/* and store the informations to returning buffer */
	seg_ret[ulen-1] = t - 1;
	uscore_ret[ulen-1] = result_score;
	i = ulen - 2;
	for(token = tokenp[tn][hmm->GetLength()-1]; token; token = token->next) {
		if (i < 0 || token->last_end_frame == -1) break;
		seg_ret[i] = token->last_end_frame;
		uscore_ret[i] = token->last_end_score;
		i--;
	}
	
	/* normalize scores by frame */
	for (i=ulen-1;i>0;i--) {
		uscore_ret[i] = (uscore_ret[i] - uscore_ret[i-1]) / (seg_ret[i] - seg_ret[i-1]);
	}
	uscore_ret[0] = uscore_ret[0] / seg_ret[0];
	
	/* free memory */
	J_FREE(u_start);
	J_FREE(u_end);
	J_FREE(from_node);
	for (n = 0; n < hmm->GetLength(); n++) {
		token = tokenp[tn][n];
		while (!token) {
			tmptoken = token->next;
			J_FREE(token);
			token = tmptoken;
		}
	}
	for (i=0;i<2;i++) {
		J_FREE(nodescore[i]);
		J_FREE(tokenp[i]);
	}
	return(result_score);
}

int CJuliSearchBestfirst::OutputResult(NODE *node, int rank)
{
	J_DEBUGMESSAGE("��CJuliSearchBestfirst::OutputResult(rank=%d)\n", rank);
	ALIGNRESULT ar;
	/* Viterbi�o�H���v�Z�������e�P�ꂪ�ǂ̉�����ԂɃ}�b�`���邩��\������ */
	if (theOpt.align_result_word_flag)
	{
		WordAlign_Rev(node->seq, node->seqnum, tparam, &ar);
	}
	if (theOpt.align_result_phoneme_flag)
	{
		PhonemeAlign_Rev(node->seq, node->seqnum, tparam, &ar);
	}
	GetResultOut()->Final2(node, rank, &ar);
#ifdef SP_BREAK_CURRENT_FRAME
	if (sp_break_last_nword_allow_override) sp_segment_set_last_nword(node);
#endif
	return 0;
}
