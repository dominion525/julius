//====================================================================
// JuliLogTable.h: �ΐ��\
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// Speech Media Lab. Kyoto University     All rights reserved
//====================================================================

#if !defined(AFX_JULILOGTABLE_H__D1EC47E2_C3CE_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULILOGTABLE_H__D1EC47E2_C3CE_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define TBLSIZE 500000
#define VRANGE 15               /* must be > - LOG_ADDMIN */
#define TMAG 33333.3333         /* TBLSIZE/VRANGE */

#include "JuliDefines.h" // LOGPROB �̌^

class CJuliLogTable  
{
public:
	CJuliLogTable() : m_bInited(false) {}
	// Log Table
	void MakeLogTable();					// make_log_tbl
	LOGPROB AddLog(LOGPROB x, LOGPROB y);	// addlog
	LOGPROB AddLogArray(LOGPROB *a, int n); // addlog_array
private:
	bool m_bInited;
	LOGPROB m_tblLog[TBLSIZE];    /* [0,1] */
};

extern CJuliLogTable theLogTable;

#endif // !defined(AFX_JULILOGTABLE_H__D1EC47E2_C3CE_11D5_9AFA_008098E80572__INCLUDED_)
