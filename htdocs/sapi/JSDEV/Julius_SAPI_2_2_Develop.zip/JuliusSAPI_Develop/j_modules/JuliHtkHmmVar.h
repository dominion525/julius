//====================================================================
// JuliHtkHmmVar.h: Htk HMM: Variance �I�u�W�F�N�g (HTK_HMM_Var)
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIHTKHMMVAR_H__C2F03B2E_7AC4_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIHTKHMMVAR_H__C2F03B2E_7AC4_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <assert.h>
#include "JuliHtkHmmSegment.h"
#include "JuliDefines.h"

class CJuliHmmInfo;

class CJuliHtkHmmVar : public CJuliHtkHmmSegment
{
public:
	CJuliHtkHmmVar();
	virtual ~CJuliHtkHmmVar();

	void ReadFromFile(CJuliFile &file,CJuliHmmInfo &info);

	// �A�N�Z�b�T
	VECT GetVec(int i) { assert(i>=0 && i<len); return vec[i]; }
	VECT *GetVect() { return vec; }
	short GetLength() { return len; }
private:
	VECT *	vec;	/* covariance matrix (diagonal vector) */
	short	len;	/* length of above */
};

#endif // !defined(AFX_JULIHTKHMMVAR_H__C2F03B2E_7AC4_11D5_9AFA_008098E80572__INCLUDED_)
