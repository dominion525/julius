//====================================================================
// JuliTrellisAtom.cpp: ��1�p�X�̒P��g�����X�\����
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// All rights reserved
//====================================================================

#include "JuliTrellisAtom.h"

CJuliTrellisAtom::CJuliTrellisAtom()
{

}

CJuliTrellisAtom::~CJuliTrellisAtom()
{

}
