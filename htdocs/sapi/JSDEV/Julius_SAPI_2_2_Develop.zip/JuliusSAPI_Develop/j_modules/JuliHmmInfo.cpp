//====================================================================
// JuliHmmInfo.cpp: hmm �t�@�C���̃�������̎��� (HMM_INFO)
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliHmmInfo.h"

#include "JuliDefines.h"
#include "JuliFile.h"
#include "JuliUtil.h"
#include "JuliMemory.h"
#include <string.h>
#include <math.h>
#include <stdlib.h>

CJuliHmmInfo::CJuliHmmInfo()
{
	m_ptreeCodebook = NULL;
}

CJuliHmmInfo::~CJuliHmmInfo()
{
	CJuliPatriciaTree<CJuliHtkHmmCodebook *>::Clean(&m_ptreeCodebook);
}

void CJuliHmmInfo::Init() // init_hmm
{
	/* set default options */
	m_opt.SetStreamNum(1);
	m_opt.SetCovType(C_DIAG_C);
	m_opt.SetDurType(D_NULL);

	codebooknum = 0;
	maxcodebooksize = 0;
	totalmixnum = 0;
	totalstatenum = 0;
	totalhmmnum = 0;
	totallogicalnum = 0;
	m_bIsTriphone = FALSE;
	m_bIsTiedMixture = FALSE;
	prefer_cdset_avg = FALSE;
	totalpseudonum = 0;
}

// �t�@�C������ǂݍ���
int CJuliHmmInfo::ReadFromFile(const char *hmmfilename, const char *namemapfilename)
{
	CJuliFile hmmfile ,namemapfile;

	J_MESSAGE("Reading in HMM definition...");
	/* read hmmdef file */
	if (hmmfile.OpenRead(hmmfilename)) {
		J_ERROR("failed to open %s\n",hmmfilename);
		return 1;
	}
	if (ReadHmmDef(hmmfile) == FALSE) {
		J_ERROR("read error in %s\n",hmmfilename);
		return 1;
	}
	if (hmmfile.CloseRead() < 0) {
		J_ERROR("failed to close %s\n", hmmfilename);
		return 1;
	}
	J_MESSAGE("   defined HMMs: %5d\n", totalhmmnum);
	/* read in logical name -> physical HMM name map file */
	if (namemapfilename != NULL && namemapfilename[0] != NULL) {
		if (namemapfile.OpenRead(namemapfilename)) {
			J_ERROR("failed to open %s\n",namemapfilename);
			return 1;
		}
		if (ReadHmmList(namemapfile) == FALSE) {
			J_ERROR("HMMList \"%s\" read error\n",namemapfilename);
			return 1;
		}
		if (namemapfile.CloseRead() < 0) {
			J_ERROR("failed to close %s\n", namemapfilename);
			return 1;
		}
		J_MESSAGE("  logical names: %5d in HMMList\n", totallogicalnum);
	} else {
		/* add the names of physical HMMs as logical names (ignore if duplicated) */
		/* also set totallogicalnum */
		AddPhysicalToLogical();
		J_MESSAGE("   merged total: %5d\n", totallogicalnum);
	}
	/* Guess we need to handle context dependency */
	/* (word-internal CD is done statically, cross-word CD dynamically */
	if (GuessIfCDHmm())
	{
		m_bIsTriphone = TRUE;
	} else {
		m_bIsTriphone = FALSE;
	}
	J_MESSAGE("done\n");
	return 0;
}

// ���[�h����HMM���R���e�L�X�g�ˑ����ǂ�����Ԃ�
// TRUE: �R���e�L�X�g�ˑ�
// FALSE: ��ˑ�
boolean CJuliHmmInfo::GuessIfCDHmm() //guess_if_cd_hmm
{
	list<CJuliHtkHmmLogical *>::const_iterator dt;
	int rnum, lnum, totalnum;
	/* ���ʊ: logical �� HMM_RC_DLIM, HMM_LC_DLIM ���܂ޖ��O�����邩 */
	/* (physical �͊��� logical �Ɋ܂܂�Ă���)  */
	rnum = lnum = totalnum = 0;
	for (dt = m_sdbLogical.GetList().begin(); dt != m_sdbLogical.GetList().end(); dt++) {
		if (strstr((*dt)->GetName(), HMM_RC_DLIM) != NULL) rnum++;
		if (strstr((*dt)->GetName(), HMM_LC_DLIM) != NULL) lnum++;
		totalnum++;
	}
	if (rnum > 0) {
		if (lnum == 0) {
			J_WARNING("Warning: cannot handle right-context dependency correctly\n");
			return(FALSE);
		} else {
			return(TRUE);
		}
	}
	return(FALSE);
}

/* �J�ڊm����ΐ��� */
void CJuliHmmInfo::ConvLogArc()
{
	list<CJuliHtkHmmTrans *>::const_iterator tr;
	int i,j;
	LOGPROB l;
	for (tr = m_sdbTrans.GetList().begin(); tr != m_sdbTrans.GetList().end(); tr++)
	{
		for(i=0;i<(*tr)->GetStateNum();i++)
		{
			for(j=0;j<(*tr)->GetStateNum();j++)
			{
				l = (*tr)->GetArcTransProb(i,j);
				(*tr)->SetArcTransProb(i,j,(l != 0.0) ? (float)log10(l) : LOG_ZERO);
			}
		}
	}
}

void CJuliHmmInfo::DefTransMacro(const char *name, CJuliFile &file)	// def_trans_macro
{
	CJuliHtkHmmTrans * _new = new CJuliHtkHmmTrans;	// ~CJuliHtkHmmSegmentDatabase �ŉ��
	_new->ReadFromFile(file,*this);
	_new->SetName(name);
	//	J_DEBUGMESSAGE("Add \"%s\" to m_sdbTrans\n", name);
	m_sdbTrans.Add(_new);
}

void CJuliHmmInfo::DefStateMacro(const char *name, CJuliFile &file)	// def_state_macro
{
	CJuliHtkHmmState * _new = new CJuliHtkHmmState;	// ~CJuliHtkHmmSegmentDatabase �ŉ��
	_new->ReadFromFile(file,*this);
	_new->SetName(name);
	//	J_DEBUGMESSAGE("Add \"%s\" to m_sdbState\n", name);
	m_sdbState.Add(_new);
}

void CJuliHmmInfo::DefVarMacro(const char *name, CJuliFile &file)	// def_var_macro
{
	CJuliHtkHmmVar * _new = new CJuliHtkHmmVar;	// ~CJuliHtkHmmSegmentDatabase �ŉ��
	_new->ReadFromFile(file,*this);
	_new->SetName(name);
	//	J_DEBUGMESSAGE("Add \"%s\" to m_sdbVar\n", name);
	m_sdbVar.Add(_new);
}

//	�P�ɃX�L�b�v���邾��
void CJuliHmmInfo::DefRegTreeMacro(const char *name, CJuliFile &file)	// def_var_macro
{
	if (file.CurrentTokenIs("~r")) {        /* macro reference */
		/* ignore silently */
	} else if (file.CurrentTokenIs("REGTREE")) { /* definition */
		/* do not define actually, just read forward till next macro */
		SkipRegTreeSegment(file);
	} else {
		file.HmmError("no regtree data\n");
	}
	return;
}

void CJuliHmmInfo::DefDensMacro(const char *name, CJuliFile &file)	// def_dens_macro
{
	CJuliHtkHmmDens * _new = new CJuliHtkHmmDens;	// ~CJuliHtkHmmSegmentDatabase �ŉ��
	_new->ReadFromFile(file,*this);
	_new->SetName(name);
	//	J_DEBUGMESSAGE("Add \"%s\" to m_sdbDens\n", name);
	m_sdbDens.Add(_new);
}

void CJuliHmmInfo::DefHMMMacro(const char *name, CJuliFile &file)	// def_HMM
{
	CJuliHtkHmmData * _new = new CJuliHtkHmmData;	// ~CJuliHtkHmmSegmentDatabase �ŉ��
	_new->ReadFromFile(file,*this);
	_new->SetName(name);
	//	J_DEBUGMESSAGE("Add \"%s\" to m_sdbData\n", name);
	m_sdbData.Add(_new);
}

CJuliHtkHmmTrans * CJuliHmmInfo::ReadTransSegment(CJuliFile &file)	// get_trans_data
{
	CJuliHtkHmmTrans *tmp;
	if (file.CurrentTokenIs("TRANSP")) {
		/* �f�[�^�ǂݍ���->�ǉ�->�|�C���^�Ԃ� */
		tmp = new CJuliHtkHmmTrans;	// ~CJuliHtkHmmSegmentDatabase �ŉ��
		tmp->ReadFromFile(file,*this);
		tmp->SetName(""); /* ���O�͖��� */
		m_sdbTrans.Add(tmp);
		return(tmp);
	} else if (file.CurrentTokenIs("~t")) {
		/* �f�[�^����->�|�C���^�Ԃ� */
		file.GetHmmToken();
		file.NoTokenError("missing TRANSP macro name");
		tmp = m_sdbTrans.Lookup(file.CurrentToken());
		if (tmp == NULL) {
			J_ERROR("~t \"%s\" not defined\n", file.CurrentToken());
			file.HmmError(NULL);
		}
		file.GetHmmToken();
		return(tmp);
	} else {
		file.HmmError("no transition data");
		return NULL;
	}
}

CJuliHtkHmmVar * CJuliHmmInfo::ReadVarSegment(CJuliFile &file)	// get_var_data
{
	CJuliHtkHmmVar *tmp;
	if (file.CurrentTokenIs("~v")) {	/* Variance .$B%^%/%m$X$N;2>H.(B */
		/* .$B%G!<%?8!:w.(B->.$B%]%$%s%?JV$9.(B */
		file.GetHmmToken();
		file.NoTokenError("missing VARIANCE macro name");
		tmp = m_sdbVar.Lookup(file.CurrentToken());
		if (tmp == NULL) {
			J_ERROR("~v \"%s\" not defined\n", file.CurrentToken());
			file.HmmError(NULL);
		}
		file.GetHmmToken();
		return tmp;
	} else if (file.CurrentTokenIs("VARIANCE")){
		/* .$B%G!<%??75,FI$_9~$_.(B->.$BDI2C.(B->.$B%]%$%s%?JV$9.(B */
		tmp = new CJuliHtkHmmVar;	// ~CJuliHtkHmmSegmentDatabase �ŉ��
		tmp->ReadFromFile(file,*this);
		tmp->SetName(""); /* .$BL>A0$OL5$7.(B */
		m_sdbVar.Add(tmp);
		return tmp;
	} else {
		file.HmmError("no variance data");
		return NULL;
	}
}

//	�P�ɃX�L�b�v���邾��
void CJuliHmmInfo::SkipRegTreeSegment(CJuliFile &file)	// (regtree_read)
{
	int num;

	file.GetHmmToken();
	file.NoTokenError("missing REGTREE terminal node num");
	num = atoi(file.CurrentToken());
	file.GetHmmToken();
	for(;;) {
		if (file.CurrentTokenIs("NODE")) {    /* skip 3 arguments */
			file.GetHmmToken();
			file.GetHmmToken();
			file.GetHmmToken();
			file.GetHmmToken();
		} else if (file.CurrentTokenIs("TNODE")) { /* skip 2 argument */
			file.GetHmmToken();
			file.GetHmmToken();
			file.GetHmmToken();
		} else {
			break;
		}
	}
}

CJuliHtkHmmDens * CJuliHmmInfo::ReadDensSegment(CJuliFile &file)	// get_dens_data
{
	CJuliHtkHmmDens *tmp = NULL;
	if (file.CurrentTokenIs("~m")) {
		/* .$B%G!<%?8!:w.(B->.$B%]%$%s%?JV$9.(B */
		file.GetHmmToken();
		file.NoTokenError("missing macro name");
		tmp = m_sdbDens.Lookup(file.CurrentToken());
		if (tmp == NULL) {
			J_ERROR("~m \"%s\" not defined\n", file.CurrentToken());
			file.HmmError(NULL);
		}
		file.GetHmmToken();
	} else if (!file.CurrentTokenIs("MEAN")) {
		file.HmmError("no density data");
	} else{
		/* .$B%G!<%?FI$_9~$_.(B->.$BDI2C.(B->.$B%]%$%s%?JV$9.(B */
		tmp = new CJuliHtkHmmDens();	// ~CJuliHtkHmmSegmentDatabase �ŉ��
		tmp->ReadFromFile(file,*this);
		tmp->SetName(""); /* .$BL>A0$OL5$7.(B */
		m_sdbDens.Add(tmp);
	}
	return tmp;
}

CJuliHtkHmmState * CJuliHmmInfo::ReadStateSegment(CJuliFile &file)	// get_state_data
{
	CJuliHtkHmmState *tmp = NULL;
	if (file.CurrentTokenIs("NUMMIXES")||file.CurrentTokenIs("MEAN")) {
		/* .$B%G!<%?FI$_9~$_.(B->.$BDI2C.(B->.$B%]%$%s%?JV$9.(B */
		tmp = new CJuliHtkHmmState;	// ~CJuliHtkHmmSegmentDatabase �ŉ��
		tmp->ReadFromFile(file,*this);
		tmp->SetName(""); /* .$BL>A0$OL5$7.(B */
		m_sdbState.Add(tmp);
		return tmp;
	} else if (file.CurrentTokenIs("~s")) {
		/* .$B%G!<%?8!:w.(B->.$B%]%$%s%?JV$9.(B */
		file.GetHmmToken();
		file.NoTokenError("missing state macro name");
		tmp = m_sdbState.Lookup(file.CurrentToken());
		if (tmp == NULL) {
			J_ERROR("Error: ~s \"%s\" not defined\n", file.CurrentToken());
			file.HmmError(NULL);
		}
		file.GetHmmToken();
		return tmp;
	} else {
		file.HmmError("no state data");
		return NULL;
	}
}

// HMM�t�@�C������ HMM ����ǂݍ���
boolean CJuliHmmInfo::ReadHmmDef(CJuliFile &file)
{
	Init();				// ������

	//
	// �e�L�X�g�t�@�C���̓ǂݍ���
	//
	{
		char macrosw;
		string name;

		file.GetHmmToken();	/* �ŏ��� token �ǂݍ��� */

		/* �g�b�v���x���͂��ׂ� "~" �Ŏn�܂��` */
		while (file.CurrentToken() != NULL) /* break on EOF */
		{
			if (file.CurrentToken()[0] != '~')
			{
				file.HmmError(NULL);
				return FALSE;
			}
			macrosw = file.CurrentToken()[1];
			file.GetHmmToken();		/* "~.." �̎��̃g�[�N����ǂ�ł��� */
			switch(macrosw)
			{
			case 'o':			/* global option */
				SetGlobalOption(file);
				break;
			case 't':			/* transition macro */
				name = file.CurrentToken();
				file.GetHmmToken();
				DefTransMacro(name.c_str(),file);
				break;
			case 's':			/* state macro */
				name = file.CurrentToken();
				file.GetHmmToken();
				DefStateMacro(name.c_str(),file);
				break;
			case 'm':			/* density (mixture) macro */
				name = file.CurrentToken();
				file.GetHmmToken();
				DefDensMacro(name.c_str(),file);
				break;
			case 'h':			/* HMM define */
				name = file.CurrentToken();
				file.GetHmmToken();
				DefHMMMacro(name.c_str(),file);
				break;
			case 'v':			/* Variance macro */
				name = file.CurrentToken();
				file.GetHmmToken();
				DefVarMacro(name.c_str(),file);
				break;
			case 'r':           /* Regression class macro (ignore) */
				name = file.CurrentToken();
				file.GetHmmToken();
				DefRegTreeMacro(name.c_str(),file);
				break;
			}
		}
	}

	if (CheckAllHmmLimit())
	{
		J_MESSAGE("limit check passed...\n");
	} else {
		J_ERROR("Error: cannot use this HMM for system limitation.\n");
		return FALSE;
	}
	/* �J�ڊm����ΐ��� */
	ConvLogArc();

	/* check if this system can handle this type of duration/covmatrix type */
	if (!m_opt.CheckHmmOptions())
	{
		return FALSE;
	}
	/* �SHTK_HMM_State �ɒʂ��ԍ�(id)������EMixture�ő吔�� */
	{
		list<CJuliHtkHmmState *>::const_iterator stmp;
		int n = 0, max = 0;
		for (stmp = m_sdbState.GetList().begin(); stmp != m_sdbState.GetList().end(); stmp ++)
		{
			if (max < (*stmp)->GetMixNum()) max = (*stmp)->GetMixNum();
			(*stmp)->SetID(n++);
			if (n >= MAX_STATE_NUM) {
				J_ERROR("file.HmmError: too much states > %d\n", MAX_STATE_NUM);
				exit(1);
			}
		}
		totalstatenum = n;
		maxmixturenum = max;
	}
	/* HMM �������v�Z */
	totalhmmnum = m_sdbData.GetList().size();

	/* mixture�����𐔂��� */
	totalmixnum = m_sdbDens.GetList().size();

	return(TRUE);
}


const CJuliHtkHmmData * CJuliHmmInfo::LookupPhysical(const char *keyname) const	// htk_hmmdata_lookup_physical
{
	return m_sdbData.Lookup(keyname);
}

const CJuliHtkHmmLogical * CJuliHmmInfo::LookupLogical(const char *keyname) const	// htk_hmmdata_lookup_logical
{
	return m_sdbLogical.Lookup(keyname);
}

void CJuliHmmInfo::CountLogicalNum() // hmm_count_logical_num
{
	totallogicalnum = m_sdbLogical.GetList().size();
}

/* physical HMM �̖��O�� Logical �Ƃ��Ēǉ��o�^���� */
/* �d�Ȃ�ꍇ�͓o�^���Ȃ�(HMMList�ł̎w�肪�D��) */
void CJuliHmmInfo::AddPhysicalToLogical() // hmm_add_physical_to_logical
{
	CJuliHtkHmmLogical *_new, *match;
	list<CJuliHtkHmmData *>::const_iterator ph;

	for (ph = m_sdbData.GetList().begin(); ph != m_sdbData.GetList().end(); ph ++)
	{
		/* check logical mapping overriding */
		if (! m_sdbLogical.IsEmpty())
		{
			match = m_sdbLogical.Search((*ph)->GetName());
			if (strmatch(match->GetName(), (*ph)->GetName()))
			{
				/* the physcal name was already mapped to other HMMs in HMMList */
				J_WARNING("Warning: \"%s\" is defined in hmmdefs, but \"%s\" will be used instead\n",
					(*ph)->GetName(), match->GetBodyDefined()->GetName());
				continue;
			}
		}
		/* create new HMM_Logical */
		_new = new CJuliHtkHmmLogical;	// ~CJuliHtkHmmSegmentDatabase �ŉ��
		_new->SetName((*ph)->GetName());
		_new->SetPhysicalHmm(*ph);	// physical HMM (CJuliHtkHmmData) �ւ̃|�C���^

		m_sdbLogical.Add(_new);
	}
	/* re-count total number */
	CountLogicalNum();
}

/* pseudo �� monophone, biphone ��o�^���� */
/* ���̂�CD_Set ���Q�� */
/* ���ɒ�`����Ă���, ���邢�� HMMList �ɂ�����Ă���ꍇ�͒�`��D��I�I */
void CJuliHmmInfo::AddPseudoPhonesSub(const char *name) // hmm_add_pseudo_phones_sub
{
	CJuliHtkHmmLogical *_new, *match;

	/* check double mapping */
	match = CJuliPatriciaTree<CJuliHtkHmmLogical *>::Search(name, m_sdbLogical.GetRoot());
	if (strmatch(match->GetName(), name)) {
		/* already exist in list */
		/*    if (! match->is_pseudo) {*/
		/* this pseudo-HMM is already defined as real HMM in hmmdefs or in HMMList */
		/*designated_count++;
		}*/
	} else {
		/* create new HMM_Logical with pseudo body */
		_new = new CJuliHtkHmmLogical;	// ~CJuliHtkHmmSegmentDatabase �ŉ��
		_new->SetName(name);
		_new->SetIsPseudo(TRUE);
		_new->SetPseudo(GetCDSetInfo()->Lookup(name));
		if (_new->GetPseudo() == NULL) {	/* should never happen */
			J_ERROR("InternalError: tried to add pseudo phone \"%s\" to logical HMM, but no corresponding CD_Set found.  Why??\n");
		}
		m_sdbLogical.InsertHead(_new);
		if (m_sdbLogical.GetRoot() == NULL) {
			m_sdbLogical.SetRoot(CJuliPatriciaTree<CJuliHtkHmmLogical *>::MakeRootNode(_new));
		} else {
			CJuliPatriciaTree<CJuliHtkHmmLogical *>::AddEntry(_new->GetName(), _new, match->GetName(), m_sdbLogical.GetRootP());
		}
		add_count++;
	}
}

/* pseudo monophone, biphone �� logical HMM �Ƃ��ēo�^���� */
void CJuliHmmInfo::AddPseudoPhones() // hmm_add_pseudo_phones
{
	list<CJuliHtkHmmLogical *>::const_iterator ilg;
//	CJuliHtkHmmLogical *lg;
	char buf[50];
//	int mcount, lcount, rcount;

	add_count = 0;
	/* add monophone */
	for(ilg = m_sdbLogical.GetList().begin(); ilg != m_sdbLogical.GetList().end(); ilg++) {
		if ((*ilg)->IsPseudo()) continue;
		AddPseudoPhonesSub(CJuliUtil::GetCenterName((*ilg)->GetName(), buf));
	}
	/* add biphone, i.e. "a-k" etc. */
	for(ilg = m_sdbLogical.GetList().begin(); ilg != m_sdbLogical.GetList().end(); ilg++) {
		if ((*ilg)->IsPseudo()) continue;
		AddPseudoPhonesSub(CJuliUtil::GetLeftCenterName((*ilg)->GetName(), buf));
	}
	/* add biphone, i.e. "k+e" etc. */
	for(ilg = m_sdbLogical.GetList().begin(); ilg != m_sdbLogical.GetList().end(); ilg++) {
		if ((*ilg)->IsPseudo()) continue;
		AddPseudoPhonesSub(CJuliUtil::GetRightCenterName((*ilg)->GetName(), buf));
	}
	J_MESSAGE("%d added as logical...", add_count);

	totalpseudonum = add_count;
	/* re-count total number */
	CountLogicalNum();
}

// ============================================================
// rdmhhdef_options.c
// ============================================================

void CJuliHmmInfo::SetGlobalOption(CJuliFile &file) // set_global_opt
{
	m_opt.ReadFromFile(file);
}

#if 0
/* HMM options */
static OptionStr optcov[] = {	/* covariance matrix type */
	{"DIAGC", C_DIAG_C, "Diag", TRUE},
	{"INVDIAGC", C_INV_DIAG, "InvDiag", FALSE},
	{"FULLC", C_FULL, "Full", FALSE},
	{"LLTC", C_LLT, "LLT", FALSE}, /* not used in HTK V2.0 */
	{"XFORMC", C_XFORM, "Xform", FALSE},  /* not used in HTK V2.0 */
	{NULL,0,NULL,FALSE}
};
static OptionStr optdur[] = {	/* duration types */
	{"NULLD", D_NULL, "Null", TRUE},
	{"POISSOND", D_POISSON, "Poisson", FALSE},
	{"GAMMAD", D_GAMMA, "Gamma", FALSE},
	{"GEND", D_GEN, "Gen", FALSE},
	{NULL,0,NULL,FALSE}
};

/* get HMM Option name from type code */
static char *
get_opttype_str(OptionStr *confdata, short type)
{
	int i;
	for (i = 0; confdata[i].name != NULL; i++) {
		if (confdata[i].type == type) {
			return(confdata[i].name);
		}
	}
	//	file.HmmError("unknown typecode in header!");
	return(NULL);
}
char *
get_cov_str(short covtype)
{
	return(get_opttype_str(optcov, covtype));
}
char *
get_dur_str(short durtype)
{
	return(get_opttype_str(optdur, durtype));
}
#endif

// ============================================================
// check_hmm_restriction.c
// ============================================================

/* 
* (HTK origin)
* ������Ԃւ�arc�͑��݂��Ȃ�
* �ŏI��Ԃ����arc�͑��݂��Ȃ�
*/
/* 
* (J)
* ������Ԃ���̑J�ڂ͈�݂̂Ƃ���
* �ŏI��Ԃւ̑J�ڂ���Ƃ���D
* �����ł� skip, loop ��
*/
/* G=good,F=fixed,B=bad */
/*                      */
/*  |G|F|B */
/* -+-+-+- */
/* G|G|F|B */
/* F|F|F|B */
/* B|B|B|B */
#define GOOD 0
#define FIXED 1
#define BAD 3

static int trans_ok_p(CJuliHtkHmmTrans * t)
{
	int i, j;
	int tflag = BAD;
	int retflag = BAD;
	PROB maxprob;
	int maxid = -1;

	/* ������Ԃ���̑J�ڂ͈�݂̂Ƃ��� */
	tflag = BAD;
	for (i=0;i<t->GetStateNum();i++) {
		if (t->GetArcTransProb(0,i) != (PROB)0.0) {
			if (tflag == BAD) {
				tflag = GOOD;
			} else {			/* 2nd time */
				J_ERROR("Warning: initial state has more than one arc\n");
				tflag = BAD;
				break;
			}
		}
	}
	if (tflag == BAD) {
		if (i >= t->GetStateNum()) {	/* no arc */
			J_ERROR("file.HmmError: initial state has no arc\n");
		} else {
			/* �ł��J�ڊm���̍���1�J�ڂɂ܂Ƃ߂� */
			maxprob = 0.0; maxid = -1;
			for (j=0;j<t->GetStateNum();j++) {
				if (maxprob < t->GetArcTransProb(0,j)) {
					maxprob = t->GetArcTransProb(0,j);
					maxid = j;
				}
			}
			if (maxid == -1) {
				J_ERROR("file.HmmError: trans_ok_p: no transition in a state?\n");
				exit(1);
			}
			t->SetArcTransProb(0,maxid,1.0);
			for (j=0;j<t->GetStateNum();j++) {
				if (j == maxid) continue;
				t->SetArcTransProb(0,j,0.0);
			}
			tflag = FIXED;
		}
	}
	retflag = tflag;

	/* �ŏI��Ԃւ̑J�ڂ���Ƃ���D*/
	tflag = BAD;
	for (i=0;i<t->GetStateNum();i++) {
		if (t->GetArcTransProb(i,t->GetStateNum()-1) != (PROB)0.0) {
			if (tflag == BAD) {
				tflag = GOOD;
			} else {			/* 2nd time */
				J_ERROR("Warning: more than one arc to end state\n");
				tflag = BAD;
				break;
			}
		}
	}
	if (tflag == BAD) {
		if (i >= t->GetStateNum()) {	/* no arc */
			J_ERROR("file.HmmError: no arc to end state\n");
		} else {
			/* �ł��J�ڊm���̍���1�J�ڂɂ܂Ƃ߂� */
			maxprob = (PROB)0.0;
			for (j=0;j<t->GetStateNum();j++) {
				if (maxprob < t->GetArcTransProb(j,t->GetStateNum()-1)) {
					maxprob = t->GetArcTransProb(j,t->GetStateNum()-1);
					maxid = j;
				}
			}
			for (i=0;i<t->GetStateNum();i++) {
				if (t->GetArcTransProb(i,t->GetStateNum()-1) == (PROB)0.0) continue;
				if (i == maxid) continue;
				for (j=t->GetStateNum()-2;j>=0;j--) {
					if (t->GetArcTransProb(i,j) != (PROB)0.0) {
						t->SetArcTransProb(i,j,t->GetArcTransProb(i,j) + t->GetArcTransProb(i,t->GetStateNum()-1));
						t->SetArcTransProb(i,t->GetStateNum()-1,(PROB)0.0);
						break;
					}
				}
			}
			tflag = FIXED;
		}
	}

	return(retflag | tflag);
}

boolean CJuliHmmInfo::CheckHmmLimit(CJuliHtkHmmData *dt) // check_hmm_limit
{
	boolean return_flag = TRUE;
	int tflag;
	tflag = trans_ok_p(dt->GetTrans());
	if (tflag == BAD) {
		return_flag = FALSE;
		J_ERROR("Limit: HMM \"%s\" has unsupported arc.\n", dt->GetName());
		//put_htk_trans(dt->tr);
	} else if (tflag == FIXED) {
		J_WARNING("Warning: HMM \"%s\" has unsupported arc, fixed.\n", dt->GetName());
		//put_htk_trans(dt->tr);
	}
#if 0
	if (dt->state_num <= 3) {
		return_flag = FALSE;
		J_ERROR("Limit: HMM \"%s\" too short (only %d states)\n", dt->GetName(),
			dt->state_num);
	}
#endif
	return(return_flag);
}

boolean CJuliHmmInfo::CheckAllHmmLimit() // check_all_hmm_limit
{
	list<CJuliHtkHmmData *>::iterator dt;
	boolean return_flag = TRUE;

	for (dt = m_sdbData.GetList().begin(); dt != m_sdbData.GetList().end(); dt++)
	{
		if (CheckHmmLimit(*dt) == FALSE) {
			return_flag = FALSE;
		}
	}
	return(return_flag);
}


/* lookup codebook name */
CJuliHtkHmmCodebook * CJuliHmmInfo::CodebookLookup(char *keyname)
{
	CJuliHtkHmmCodebook *book;
	if (m_ptreeCodebook == NULL) return(NULL);
	book = CJuliPatriciaTree<CJuliHtkHmmCodebook *>::Search(keyname, m_ptreeCodebook);
	if (strmatch(book->GetName(), keyname)) {
		return book;
	} else {
		return NULL;
	}
}
/* add new codebook to lookup index */
void CJuliHmmInfo::CodebookAdd(CJuliHtkHmmCodebook *_new)
{
	CJuliHtkHmmCodebook *match;
	if (m_ptreeCodebook == NULL) {
		m_ptreeCodebook = CJuliPatriciaTree<CJuliHtkHmmCodebook *>::MakeRootNode(_new);
	} else {
		match = CJuliPatriciaTree<CJuliHtkHmmCodebook *>::Search(_new->GetName(),m_ptreeCodebook);
		if (strmatch(match->GetName(), _new->GetName())) {
			J_ERROR("Error: ~s \"%s\" is already defined\n", _new->GetName());
			//	rderr(NULL);
		} else {
			CJuliPatriciaTree<CJuliHtkHmmCodebook *>::AddEntry(_new->GetName(), _new, match->GetName(), &(m_ptreeCodebook));
		}
	}
}
/* make index for GCODEBOOK id -> HTK_HMM_Dens * */
/* error exit if ~m macro "<name><id>" not found */
void CJuliHmmInfo::CreateCodebookIndex(CJuliHtkHmmCodebook *book)//tmix_create_codebook_index
{
	char *mixname;
	CJuliHtkHmmDens *dtmp;
	int i;
	int realbooknum = 0;
	mixname = (char *)J_MALLOC(strlen(book->GetName())+30);
	book->d = new CJuliHtkHmmDens * [book->num];
	for (i=0;i<book->num;i++) {
		sprintf(mixname, "%s%d", book->GetName(), i + 1);
		if ((dtmp = m_sdbDens.Lookup(mixname)) == NULL) {
			/* 
			*	 J_ERROR("Error: mixture \"%s\" (%dth mixture in codebook \"%s\") not found\n", mixname, i + 1, book->name);
			*	 rderr(NULL);
			*/
			book->d[i] = NULL;
		} else {
			book->d[i] = dtmp;
			realbooknum++;
		}
	}
	if (realbooknum < book->num) {
		J_ERROR("Warning: book [%s]: defined=%d < %d\n",
			book->GetName(), realbooknum, book->num);
	}

	J_FREE(mixname);
}

void CJuliHmmInfo::ReadTmix(CJuliFile &file, CJuliHtkHmmState *state)
{
	char *bookname;
	CJuliHtkHmmCodebook *thebook;
	int mid, i;
	file.NoTokenError("missing TMIX bookname");
	bookname = file.CurrentToken();

	/* check whether the specified codebook exist */
	if ((thebook = CodebookLookup(bookname)) == NULL) {
		/* create GCODEBOOK global index structure from mixture macros */
		thebook = new CJuliHtkHmmCodebook;	// TODO:�ǂ��Ȃ�H
		thebook->SetName(bookname);
		thebook->num = state->GetMixNum();
		/* map codebook id to HTK_HMM_Dens* */
		CreateCodebookIndex(thebook);
		/* register the new codebook */
		CodebookAdd(thebook);
		thebook->SetID(codebooknum);
		codebooknum++;
		/* set maximum codebook size */
		if (maxcodebooksize < thebook->num) maxcodebooksize = thebook->num;
	} else {
		/* check coherence */
		if (state->GetMixNum() != thebook->num) {
			file.HmmError("tmix_read: TMIX weight num don't match the codebook size");
		}
	}
	/* set pointer to the GCODEBOOK structure  */
	state->SetDens_pp((CJuliHtkHmmDens **)thebook);
	/* store the weights to `state->bweight[]' */
	file.GetHmmToken();
	state->AllocBWeight(state->GetMixNum());
	{
		int len;
		double w;
		mid = 0;
		while (mid < state->GetMixNum())
		{
			char *p, q;
			file.NoTokenError("missing some TMIX weights");
			if ((p = strchr(file.CurrentToken(), '*')) == NULL) {
				len = 1;
				w = atof(file.CurrentToken());
			} else {
				len = atoi(p+1);
				q = *p;
				*p = '\0';
				w = atof(file.CurrentToken());
				*p = q;
			}
			file.GetHmmToken();
			for(i=0;i<len;i++) {
				state->SetBWeight(mid, log(w));
				mid++;
			}
		}
	}
	/* mark info as tied mixture */
	m_bIsTiedMixture = TRUE;
}


/* base�����Ƃ� right context �� rc �ł���HMM�̍\���̂ւ̃|�C���^��Ԃ� */
/* ������Ȃ��ꍇ��, NULL��Ԃ� */
const CJuliHtkHmmLogical * CJuliHmmInfo::GetRightContextHMM(const CJuliHtkHmmLogical *base, const char *rc_name) const	// get_right_context_HMM
{
	char gbuf[40];
	strcpy(gbuf, base->GetName());
	CJuliUtil::AddRightContext(gbuf, rc_name);
	return(LookupLogical(gbuf));
}

/* base�����Ƃ� left context �� lc �ł���HMM�̍\���̂ւ̃|�C���^��Ԃ� */
/* ������Ȃ��ꍇ��, NULL��Ԃ� */
const CJuliHtkHmmLogical * CJuliHmmInfo::GetLeftContextHMM(const CJuliHtkHmmLogical *base, const char *lc_name) const	// get_left_context_HMM
{
	char gbuf[40];
	strcpy(gbuf, base->GetName());
	CJuliUtil::AddLeftContext(gbuf, lc_name);
	return(LookupLogical(gbuf));
}

/* cdset.c --- HMM state set per context class for inter-word CD */
/* drived from lcdset.c --- extended to handle right context and both */

#define CD_STATE_SET_STEP 10

//static int maxlcnum;

CD_Set * CJuliHmmInfo::NewCDSet() // cdset_new
{
	return((CD_Set *)J_BMALLOC(sizeof(CD_Set)));
}

/* output information of cdset to stdout */
void CJuliHmmInfo::PutCDSet(const CD_Set *a) // put_cdset
{
	int i;
	printf("name: %s\n", a->name);
	/* printf("state_num: %d\n", a->state_num); */
	for(i=0;i<a->state_num;i++) {
		if (a->stateset[i].num == 0) {
			printf("\t[state %d]  not exist\n", i);
		} else {
			printf("\t[state %d]  %d variants\n", i, a->stateset[i].num);
		}
		/*
		for(j=0;j<a->stateset[i].num;j++) {
		put_htk_state(a->stateset[i].s[j]);
		}
		*/
	}
}

/* output all cdset info to stdout */
void CJuliHmmInfo::PutAllCDInfo() // put_all_cdinfo
{
	const CD_Set *cd;

	for (cd = GetCDSetInfo()->GetCDRoot(); cd; cd = cd->next) {
		PutCDSet(cd);
	}
}

/* register HMM `d' as context-dependent member of HMM "cdname" */
/* return FALSE when already registered */
boolean CJuliHmmInfo::RegistCDSet(const CJuliHtkHmmData *d, const char *cdname) // regist_cdset
{
	boolean need_new;
	CD_State_Set *tmp;
	CD_Set *lset, *lmatch;
	int j,n;
	boolean changed = FALSE;

	/* check if the cdset already exist */
	need_new = TRUE;
	if (GetCDSetInfo()->GetCDTree() != NULL) {
		lmatch = CJuliPatriciaTree<CD_Set *>::Search(cdname, GetCDSetInfo()->GetCDTree());
		if (strmatch(lmatch->name, cdname)) {
			/* exist, add to it later */
			lset = lmatch;
			need_new = FALSE;
			/* if the state num is larger than allocated, expand the lset */
			if (d->GetStateNum() > lset->state_num) {
				lset->stateset = (CD_State_Set *)J_REALLOC(lset->stateset, sizeof(CD_State_Set) * d->GetStateNum());
				/* 0 1 ... (lset->state_num-1) */
				/* N A ... N                   */
				/* 0 1 ...                     ... (d->state_num-1) */
				/* N A ... A ..................... N                */
				/* malloc new area to expanded state (N to A above) */
				for(j = lset->state_num - 1; j < d->GetStateNum() - 1; j++) {
					lset->stateset[j].maxnum = CD_STATE_SET_STEP;
					lset->stateset[j].m_ppStates = (const CJuliHtkHmmState **)J_MALLOC(sizeof(CJuliHtkHmmState *) * lset->stateset[j].maxnum);
					lset->stateset[j].num = 0;
				}
				lset->stateset[d->GetStateNum()-1].m_ppStates = NULL;
				lset->stateset[d->GetStateNum()-1].num = 0;
				lset->stateset[d->GetStateNum()-1].maxnum = 0;

				lset->state_num = d->GetStateNum();

				/* update transition table */
				lset->tr = d->GetTrans();

				changed = TRUE;
			}
		}
	}

	if (need_new) {
		/* allocate as new with blank data */
		lset = NewCDSet();
		lset->name = theJuliMemory.StrDup(cdname);
		lset->state_num = d->GetStateNum();
		lset->stateset = (CD_State_Set *)J_MALLOC(sizeof(CD_State_Set) * lset->state_num);
		/* assume first and last state has no outprob */
		lset->stateset[0].m_ppStates = lset->stateset[lset->state_num-1].m_ppStates = NULL;
		lset->stateset[0].num = lset->stateset[lset->state_num-1].num = 0;
		lset->stateset[0].maxnum = lset->stateset[lset->state_num-1].maxnum = 0;
		for(j=1;j<lset->state_num-1; j++) {
			/* pre-allocate only the first step */
			lset->stateset[j].maxnum = CD_STATE_SET_STEP;
			lset->stateset[j].m_ppStates = (const CJuliHtkHmmState **)J_MALLOC(sizeof(CJuliHtkHmmState *) * lset->stateset[j].maxnum);
			lset->stateset[j].num = 0;
		}
		/* assign transition table of first found HMM (ad-hoc?) */
		lset->tr = d->GetTrans();
		GetCDSetInfo()->Add(lset);
		/* add to search index tree */
		if (GetCDSetInfo()->GetCDTree() == NULL) {
			GetCDSetInfo()->SetCDTree(CJuliPatriciaTree<CD_Set *>::MakeRootNode(lset));
		} else {
			CJuliPatriciaTree<CD_Set *>::AddEntry(lset->name, lset, lmatch->name, GetCDSetInfo()->GetCDTree_p());
		}

		changed = TRUE;
	}

	/*j_printerr("add to \"%s\"\n", lset->name);*/
	/* register each HMM states to the lcdset */
	for (j=1;j<d->GetStateNum()-1;j++) {
		tmp = &(lset->stateset[j]);
		/* check if the state has already registered */
		for(n = 0; n < tmp->num ; n++) {
			if (tmp->m_ppStates[n] == d->GetState(j)) { /* compare by pointer */
				/*j_printerr("\tstate %d has same\n", n);*/
				break;
			}
		}
		if (n < tmp->num ) continue;	/* same state found, cancel regist. */

		/* expand storage area if necessary */
		if (tmp->num >= tmp->maxnum) {
			tmp->maxnum += CD_STATE_SET_STEP;
			tmp->m_ppStates = (const CJuliHtkHmmState **)J_REALLOC(tmp->m_ppStates, sizeof(CJuliHtkHmmState *) * tmp->maxnum);
		}

		tmp->m_ppStates[tmp->num] = d->GetState(j);
		tmp->num++;

		changed = TRUE;
	}

	return(changed);
}

/* construct whole cdsets from HMM info */
boolean CJuliHmmInfo::MakeCDSet() // make_cdset
{
	list<CJuliHtkHmmLogical *>::const_iterator ilg;
	char buf[50];

	GetCDSetInfo()->Init();
	/* make lcdset name from logical HMM name */
	/* left-context set: "a-k" for /a-k+i/, /a-k+o/, ...
	for 1st pass (word end) */
	for(ilg = m_sdbLogical.GetList().begin(); ilg != m_sdbLogical.GetList().end(); ilg++) {
		if ((*ilg)->IsPseudo()) continue;
		RegistCDSet( (*ilg)->GetBodyDefined(), CJuliUtil::GetLeftCenterName((*ilg)->GetName(), buf));
	}
	/* right-context set: "a+o" for /b-a+o/, /t-a+o/, ...
	for 2nd pass (word beginning) */
	for(ilg = m_sdbLogical.GetList().begin(); ilg != m_sdbLogical.GetList().end(); ilg++) {
		if ((*ilg)->IsPseudo()) continue;
		RegistCDSet( (*ilg)->GetBodyDefined(), CJuliUtil::GetRightCenterName((*ilg)->GetName(), buf));
	}
	/* both-context set: "a" for all triphone with same base phone "a"
	for 1st pass (1 phoneme word, with no previous word hypo.) */
	for(ilg = m_sdbLogical.GetList().begin(); ilg != m_sdbLogical.GetList().end(); ilg++) {
		if ((*ilg)->IsPseudo()) continue;
		RegistCDSet((*ilg)->GetBodyDefined(), CJuliUtil::GetCenterName((*ilg)->GetName(), buf));
	}

	/* now that cdset is completely built, so */
	/* add those `pseudo' biphone and monophone to the logical HMM names */
	/* they points not to the defined HMM, but to the CD_Set structure */
	AddPseudoPhones();

	return(TRUE);
}

/* rdhmmlist.c --- read in HMMList file and set into hmminfo */
/* no need to define physical names only */
/* NOTE: logical mapping overrides physical definition */

#define MAXLINEINHMMLIST 256	/* max length per line in HMMList */

boolean CJuliHmmInfo::ReadHmmList(CJuliFile &file)	// rdhmmlist
{
	char *buf, *lname, *pname;
	CJuliHtkHmmLogical *_new;
	const CJuliHtkHmmData *mapped;
	boolean ok_flag = TRUE;
	int n;
	/* 1 column ... define HMM_Logical of the name as referring to HMM of the same name */
	/* 2 column ... define HMM_Logical of the name "$1" which has pointer to $2 */

	buf = (char *)J_MALLOC(MAXLINEINHMMLIST);
	n = 0;
	while (file.GetLine(buf, MAXLINEINHMMLIST) != NULL) {
		n++;
		lname = file.GetFirstToken(buf);
		pname = file.GetNextTokenIfAny();
		if (pname == NULL) {
			/* 1 column */
			mapped = LookupPhysical(lname);
			if (mapped == NULL) {
				J_MESSAGE("Error: HMMList: line %d: physical HMM \"%s\" not found\n", n, lname);
				ok_flag = FALSE;
				continue;
			}
		} else {
			/* 2 column */
			mapped = LookupPhysical(pname);
			if (mapped == NULL) {
				J_MESSAGE("Error: HMMList: line %d: physical HMM \"%s\" not found\n", n, pname);
				ok_flag = FALSE;
				continue;
			}
		}
		/* create new HMM_Logical */
		_new = new CJuliHtkHmmLogical;	// ~CJuliHtkHmmSegmentDatabase �ŉ��
		_new->SetName(lname);
		_new->SetIsPseudo(FALSE);
		_new->SetBodyDefined(mapped);

		m_sdbLogical.InsertHead(_new);
		if (m_sdbLogical.AddTree(_new))
		{
			J_ERROR("Error: HMMList: line %d: logical HMM \"%s\" duplicated\n", n, _new->GetName());
			ok_flag = FALSE;
		}
	}
	J_FREE(buf);
	totallogicalnum = n;
	return(ok_flag);
}

int CJuliHmmInfo::GetDefaultBeamWidth() const // default_width
{
	if (strmatch(SETUP, "fast")) { /* for fast setup */
		if (m_bIsTriphone) {
			if (m_bIsTiedMixture) {
				/* tied-mixture triphones (PTM etc.) */
				return(600);
			} else {
				/* shared-state triphone */
#ifdef PASS1_IWCD
				return(800);
#else
				/* v2.1 compliant (no IWCD on 1st pass) */
				return(1000);		
#endif
			}
		} else {
			/* monophone */
			return(400);
		}
	} else {			/* for standard / v2.1 setup */
		if (m_bIsTriphone) {
			if (m_bIsTiedMixture) {
				/* tied-mixture triphones (PTM etc.) */
				return(800);
			} else {
				/* shared-state triphone */
#ifdef PASS1_IWCD
				return(1500);
#else
				return(1500);		/* v2.1 compliant (no IWCD on 1st pass) */
#endif
			}
		} else {
			/* monophone */
			return(700);
		}
	}
}


