//====================================================================
// JuliRealTimePipeLine.cpp: �p�C�v���C������
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliRealTimePipeLine.h"
#include "JuliGlobalOption.h"

CJuliRealTimePipeLine::CJuliRealTimePipeLine()
: param(NULL), window(NULL), need_attach(FALSE), bf(NULL), m_bCMNLoaded(0)
#ifdef SP_BREAK_CURRENT_FRAME
, rest_Speech(NULL), rest_alloc_len(0)
#endif
{
}

CJuliRealTimePipeLine::~CJuliRealTimePipeLine()
{
	J_FREE(window);
	if (param) delete param;
	J_FREE(bf);
#ifdef SP_BREAK_CURRENT_FRAME
	J_FREE(rest_Speech);
#endif
}

/* realtime-1stpass.c --- on-the-fly 1st pass processing with realtime CMN */
/* do speech input, make mfcc (attach), viterbi in one loop */
/* the main RealTimePipeLine can be called incrementally as a */
/* callback from adin_cut() */


/**** progress pointers ****/
/*
* [SPEECH DATA]
*    0               nowlen
*    |---------------|
* ooo.....
*   o........
*      ........
*        ........
*
*
* [PARAMETER VECTOR]
*     O o o o o o f_raw
*     O o o o o o
*     O . . . . .                        (MFCC+RAW_E 13)
*     O o o o o o                        
*     O o o o |-|para.delWin
*     O o o o                            (MFCC+RAW_E+delta MFCC + delta E 26)
*     O o o o
*       o o o
*     |---------|f_delay = para.delWin * 2 + 1
*     
*     f ... (MFCC + delta MFCC + delta E 25) + realtime-CMN
*/   

/* prepare parameter vector holder */
void CJuliRealTimePipeLine::InitParam() // init_param
{
	if (param) delete param;
	param = new CJuliHtkParam();
	if (theOpt.c0_required) {
		param->header.samptype = F_MFCC | F_ZEROTH | F_DELTA | F_CEPNORM;
	} else {
		param->header.samptype = F_MFCC | F_ENERGY | F_DELTA | F_CEPNORM;
	}
	param->header.wshift = GetPara().smp_period * GetPara().frameshift;
	param->header.sampsize = GetPara().vec_num * sizeof(VECT); /* not compressed */
	param->veclen = GetPara().vec_num;
	/* assign max (safe with free_param)*/
	param->parvec = (VECT **)J_MALLOC(sizeof(VECT *) * maxframelen);
	/* param->parvec */
	/* param->header.samplenum */
	/* param->samplenum */
}

/* initialize (once on startup) */
void CJuliRealTimePipeLine::RealTimeInit()
{
	/* load noise spectrum for spectral subtraction from file */
	if (theOpt.m_iSSMode == 2 && theOpt.m_ssbuf == NULL) {
		if ((theOpt.m_ssbuf = GetMFCC().new_SS_load_from_file(theOpt.m_strSSLoadFile.c_str(), &theOpt.m_sslen)) == NULL) {
			J_ERROR("Error: failed to read \"%s\"\n", theOpt.m_strSSLoadFile.c_str());
		}
	}
	GetMFCC().WMP_init(thePara.GetPara(), &bf, theOpt.m_ssbuf, theOpt.m_sslen);		// ������ bf �ɑ΂��� J_MALLOC �����
	f_delay = GetPara().delWin * 2 + 1;
	/* pre-fetch outprob cache for maximum length */
	maxframelen = MAXSPEECHLEN / GetPara().frameshift;
	windowlen = GetPara().framesize + 1;
	J_FREE(window);	// �܂� free
	window = (SP16 *)J_MALLOC(sizeof(SP16) * windowlen);

	// CMN �p�����[�^�̏�����
	if (theOpt.m_bCMNLoad) {
		if (GetPara().cmn) {
			if ((m_bCMNLoaded = GetMFCC().CMN_load_from_file(theOpt.m_strCMNLoadFile.c_str(), GetPara().mfcc_dim))== FALSE) {
				J_WARNING("Warning: failed to read cepstral mean from \"%s\"\n", theOpt.m_strCMNLoadFile.c_str());
			}
		} else {
			J_WARNING("Warning: CMN not required, file \"%s\" ignored\n", theOpt.m_strCMNLoadFile.c_str());
		}
	}
}

/* prepare (on start of every loop) */
void CJuliRealTimePipeLine::RealTimePipeLinePrepare()
{
	/* beginning of speech */
	InitParam();
	GetOutProb()->Prepare(maxframelen);
	if (!GetHmm()->GetOption().CheckParamCoherence(param)) {
		need_attach = TRUE;
		if (param->SelectParamVmark(GetHmm()->GetOption().GetParamType()) == FALSE) {
			J_ERROR("cannot attach Param!\n");
		}
		param->header.samptype = GetHmm()->GetOption().GetParamType();
	}
	f_raw = 0;
	f = 0;
	windownum = 0;

	// �S�T���v���������Z�b�g
	m_iTotalSamples = 0;
}

/* main rountine */
/* return value:
-1 ... error -> exit, terminate 
0  ... continue
1  ... segmented -> exit, resume (not drop buffer)
*/
int CJuliRealTimePipeLine::RealTimePipeLine(SP16 *Speech, int nowlen)
{
	int i, now;

	/* bf[1-bfnum] is left from previous call */

	now = 0;
	last_is_segmented = FALSE;

#ifdef RDEBUG
	printf("got %d samples\n", nowlen);
#endif

	// �T���v������ max �𒴂��Ă�����A�v�Z���Ȃ�
	m_iTotalSamples += nowlen;
	if (theOpt.m_bUseFRMaxLength && GetTotalSamplePeriod() > theOpt.m_iFRMaxLength)
	{
		J_MESSAGE("Total Samples Over (%d * %d > %d).\n", m_iTotalSamples , theOpt.smpPeriod, theOpt.m_iFRMaxLength);
		return 0;
	}

	while (now < nowlen) {
		/* fill as many as possible */
		for(i = min(windowlen - windownum, nowlen - now); i > 0 ; i--)
			window[windownum++] = (float) Speech[now++];
		if (windownum < windowlen) break; /* shortage or last */
#ifdef RDEBUG
		/*    printf("%d used, %d rest\n", now, nowlen - now);

		printf("[f_raw = %d, f = %d]\n", f_raw, f);*/
#endif


		/* needed samples -> bf[] */
		for (i=0; i < windowlen; i++) {
			bf[i+1] = (float) window[i];
		}

		/* calc wave -> MFCC_E_Z */
		/* needs conversion here if integerized */
		param->parvec[f_raw] = (VECT *)J_MALLOC(sizeof(VECT) * GetPara().vec_num);
		GetMFCC().WMP_calc(param->parvec[f_raw], bf, thePara.GetPara(), theOpt.m_ssbuf);

		if (f_raw >= GetPara().delWin) {
			/* delay calc MFCC_E -> MFCC_E_D_Z */
			/* needs conversion here if integerized */
			GetMFCC().WMP_Delta(param->parvec, f_raw-GetPara().delWin, f_raw+1, thePara.GetPara());
		}
		if (f_raw >= f_delay) {
			/* more-delayed calc MFCC_E_D_Z -> MFCC_E_D_N_Z with CMN */
			f = f_raw - f_delay;
			if(GetPara().cmn) GetMFCC().CMN_realtime(param->parvec[f], GetPara().mfcc_dim);
			if (need_attach) {
				param->ExecExcludeOneVector(param->parvec[f], GetPara().vec_num);
				param->header.sampsize = param->veclen * sizeof(VECT);
			}

			/* proceed beam for 1 frame */
			if (f == 0) {
				GetBeamSearch()->GetBackTrellisInit(param);
			} else {
				if (GetBeamSearch()->GetBackTrellisProceed(f, param) == FALSE) {
					/* segmented, end procs ([0..f])*/
					/* calced = r_raw */
					last_is_segmented = TRUE;
					last_time = f-1;
#ifdef SP_BREAK_CURRENT_FRAME
					param->header.samplenum = f_raw+1;/* len = lastid + 1 */
					param->samplenum = f_raw+1;
					rest_len = nowlen - now;
					if (rest_len > 0) {
						/* copy rest samples to rest_Speech */
						if (rest_Speech == NULL) {
							rest_alloc_len = rest_len;
							rest_Speech = (SP16 *)J_MALLOC(sizeof(SP16)*rest_alloc_len);
						} else if (rest_alloc_len < rest_len) {
							rest_alloc_len = rest_len;
							rest_Speech = (SP16 *)J_REALLOC(rest_Speech, sizeof(SP16)*rest_alloc_len);
						}
						memcpy(rest_Speech, &(Speech[now]), sizeof(SP16) * rest_len);
					}
#else
					param->header.samplenum = f;
					param->samplenum = f;
#endif
					return(1);		/* segmented by this function */
				}
			}
		}

		memmove(window, &(window[GetPara().frameshift]), sizeof(SP16) * (windowlen - GetPara().frameshift));
		windownum -= GetPara().frameshift;
		f_raw++;
	}

	return(0);			/* continue input */
}

#ifdef SP_BREAK_CURRENT_FRAME
/* process rest_param for backtrack to resume the recognition */
/* return value:
-1 ... error -> exit, terminate 
0  ... continue
1  ... segmented -> exit, resume (not drop buffer)
*/
int CJuliRealTimePipeLine::RealTimeResume()
{
	int t;
	int last_now;

	param = rest_param;

	/* MFCC .$B7W;;$O.(B, .$B$=$N$^$^$G:F3+.(B */
	outprob_prepare(maxframelen);
	param->parvec = (VECT **)myrealloc(param->parvec, sizeof(VECT *) * maxframelen); /* ready to expand param */
	/* .$B%Q%i%a!<%?B&$N:F3+%]%$%s%H$r%;%C%H.(B */
	f_raw = param->samplenum - 1;
	if (f_raw >= f_delay) {
		f = f_raw - f_delay;
#ifdef RDEBUG
		printf("Resume: f=%d,f_raw=%d\n", f, f_raw);
#endif
		/* rest_param .$BFb$K$"$k.(B param .$B$rG'<1.(B(get_backtrellis_proceed) .$B$9$k.(B */
		for (t=0;t<=f;t++) {
			if (t == 0) {
				get_back_trellis_init(param, GetBackTrellis());
			} else {
				if (get_back_trellis_proceed(t, param, GetBackTrellis()) == FALSE) {
					/* segmented, end procs ([0..f])*/
					last_is_segmented = TRUE;
					last_time = t-1;
					return(1);		/* segmented by this function */
				}
			}
		}
	} else {
		f = 0;
	}

	/* speech .$B$K;D$C$?2;@<$+$i@h$K7W;;.(B */
	memmove(window, &(window[GetPara().frameshift]), sizeof(SP16) * (windowlen - GetPara().frameshift));
	windownum -= GetPara().frameshift;
	f_raw++;

	if (rest_len > 0) {
#ifdef RDEBUG
		printf("Resume: rest %d samples\n", rest_len);
#endif
		return(RealTimePipeLine(rest_Speech, rest_len));
	}
	return 0;
}
#endif /* SP_BREAK_CURRENT_FRAME */


/* end proc and return obtained param */
CJuliHtkParam * CJuliRealTimePipeLine::RealTimeParam(LOGPROB *backmax)
{
	if (last_is_segmented) {
		/* already ended */
		*backmax = GetBeamSearch()->Finalize1stPass(last_time);
#ifdef SP_BREAK_CURRENT_FRAME
		GetBeamSearch()->FinalizeSegment(param, last_time);
#endif
		/* update CMN vector for next speech */
		if(GetPara().cmn) GetMFCC().CMN_realtime_update();
		/* return obtained parameter for 2nd pass */
		return(param);
	}
	/* flush rest samples */
	for (f = f_raw - GetPara().delWin; f < f_raw; f++){
		GetMFCC().WMP_Delta(param->parvec, f, f_raw, thePara.GetPara());
	}
	for (f = f_raw - f_delay; f < f_raw; f++) {
		if(GetPara().cmn) GetMFCC().CMN_realtime(param->parvec[f], GetPara().mfcc_dim);
		if (need_attach) {
			param->ExecExcludeOneVector(param->parvec[f], GetPara().vec_num);
			param->header.sampsize = param->veclen * sizeof(VECT);
		}
		GetBeamSearch()->GetBackTrellisProceed(f, param);
	}
	/* end procs */
	param->header.samplenum = f_raw;
	param->samplenum = f_raw;
	GetBeamSearch()->GetBackTrellisEnd(param);
	*backmax = GetBeamSearch()->Finalize1stPass(param->samplenum);
#ifdef SP_BREAK_CURRENT_FRAME
	finalize_segment(GetBackTrellis(), param, param->samplenum);
#endif

	/* update CMN vector for next speech */
	if(GetPara().cmn)
	{
		GetMFCC().CMN_realtime_update();
		if (theOpt.m_bCMNSave) {
			if (GetMFCC().CMN_save_to_file(theOpt.m_strCMNSaveFile.c_str()) == FALSE) {
				J_WARNING("Warning: failed to save cmn data to \"%s\"\n", theOpt.m_strCMNSaveFile.c_str());
			}
		}
	}

	/* return obtained parameter for 2nd pass */
	return(param);
}

int CJuliRealTimePipeLine::GetTotalSamplePeriod()
{
	return m_iTotalSamples * theOpt.smpPeriod / 10000;
}
