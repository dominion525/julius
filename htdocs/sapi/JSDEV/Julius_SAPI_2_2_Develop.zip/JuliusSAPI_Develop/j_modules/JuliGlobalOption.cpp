//====================================================================
// JuliGlobalOption.cpp: �O���[�o����(�R���e�L�X�g�Ɉˑ����Ȃ�)�I�v�V�������Ǘ�����N���X
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliGlobalOption.h"
#include "JuliFile.h"
#include "JuliOutProb.h"
#include "JuliMFCC.h"

/* convert smpPeriod (ns) <-> sample frequency (Hz) */
#define period2freq(A)  (10000000.0 / (float)(A))
#define freq2period(A)  (10000000.0 / (float)(A))

CJuliGlobalOption theOpt;

CJuliGlobalOption::CJuliGlobalOption()
{
	Clear();
}

CJuliGlobalOption::~CJuliGlobalOption()
{
	if (m_ssbuf) free(m_ssbuf);
}

void CJuliGlobalOption::SetWaveType(int type)
{
	m_iWaveType = type;
	if (type==0)
	{
		smpFreq = 16000;
		//		fshift = 160;
		//		fsize = 400;
	}
	if (type==1)
	{
		smpFreq = 8000;
		//		fshift = 80;
		//		fsize = 200;
	}
	smpPeriod = freq2period(smpFreq);
}

void CJuliGlobalOption::Clear()
{
	m_iWaveType = 0;

	m_bCMNCycle = false;
	m_strCMNLoadFile = "";	m_bCMNLoad = false;
	m_strCMNSaveFile = "";	m_bCMNSave = false;

	// �t�@�C����
	m_strHmmFile	= "";
	m_strGsHmmFile	= "";	m_bUseGsHmmFile		= false;
	m_strMapFile	= "";	m_bUseMapFile		= false;
	m_strErrLogFile	= "";	m_bUseErrLogFile	= false;
	m_strOutLogFile	= "";	m_bUseOutLogFile	= false;

	m_strWaveOutFile = "";	m_bUseWaveOutFile	= false;

	m_bNoUseSLM = false;

	m_bUseIME = true;
	m_bUseIMEDllFile = false;
	m_strIMEDllFile = "";

	m_iSSMode.Init(0);
	//	sscalc = FALSE;
	sscalc_len.Init(300);
	ssalpha.Init(DEF_SSALPHA);
	ssfloor.Init(DEF_SSFLOOR);
	m_ssbuf = NULL;

	m_fCMAlpha.Init(0.05);

	m_fScoreThresHigh = -27.0;
	m_fScoreThresLow = -30.0;

	/* -------- switches -------------------------------------------------- */
	verbose_flag			= TRUE;		/* verbose output */
	debug2_flag				= FALSE;	/* debug2 output (numerous)*/
	paramtype_check_flag	= TRUE;		/* with "-notypecheck", don't check param type */
	force_realtime_flag		= FALSE;	/* whether to force */
	forced_realtime			= FALSE;	/* forced value */
	compute_only_1pass		= FALSE;	/* if TRUE, compute only 1pass */
	forcedict_flag			= FALSE;	/* if TRUE, ignore error words and keep going */
#ifdef USE_NGRAM
	separate_score_flag		= FALSE;	/* output score in AM/LM */
#endif
	wchmm_check_flag		= FALSE;	/* wchmm interactive check */
	trellis_check_flag		= FALSE;	/* trellis interactive check */
	result_reorder_flag		= TRUE;		/* re-order result by score */
	realtime_flag			= FALSE;
	ccd_flag				= TRUE;
	ccd_flag_force			= FALSE;
	progout_flag			= FALSE;
	align_result_word_flag	= FALSE;
	align_result_phoneme_flag	= FALSE;
	catch_intr_flag			= FALSE;	/* TRUE when catch SIGINT */
	progout_interval		= 300;		/* output interval in msec */
#ifdef USE_DFA
	looktrellis_flag		= FALSE;
#endif
#ifdef CATEGORY_TREE
	old_tree_function_flag	= FALSE;	/* use build_wchmm() */
#ifdef PASS1_IWCD
	old_iwcd_flag			= FALSE;	/* use full lcdset */
#endif
#endif

	speech_input	= SP_MFCFILE;	/* speech input */
	result_output	= SP_RESULT_SAPI;

	m_bAddNoize.Init(true);
	level_thres.Init(3000);
	zero_cross_num.Init(120);
	head_margin_msec.Init(300);
	tail_margin_msec.Init(500);
	pause_segment		= 2;		/* 0..off 1.. on 2..not specified by user */
	pause_duration		= 12000;	/* silence length */
	strip_zero_sample	= TRUE;		/* strip off zero samples */
	adinnet_port		= /*ADINNET_PORT*/5530;

	/* speech analysis param */
	smpPeriod	= 625;		/* sample period (16kHz: 625ns) */
	smpFreq		= 16000;	/* sample freq.  (16kHz: 625ns) */
	fshift.Init(160);		/* Frame shift (160sample = 10ms in 16kHz) */
	fsize.Init(400);		/* Window size (400sample = 25ms in 16kHz) */

	/* lo-pass/hi-pass filter */
	hipass.Init(-1); /* frequency of hi pass filter. -1 means no use hi pass filter */
	lopass.Init(-1); /* frequency of lo pass filter. -1 means no use hi pass filter */
	c0_required = FALSE; /* TRUE when 0'th Cepstral parameter is used instead of energy in hmmdefs */

	m_iNbest = 10;

	m_probFRScore.Init(0.7);
	m_iFRMinLength.Init(300);
	m_iFRMaxLength.Init(MAXSPEECHLEN);
}

static char * filepath(const char *filename, const char *dirname)
{
	char *p;
	if (dirname != NULL
		&& filename[0] != '/' && filename[0] != '\\'	// ���[�g�f�B���N�g������̐�΃p�X
		&& filename[1] != ':'	// 'C:\' �Ȃ�
		) {
			// dirname �����݂��A���΃p�X�炵���Ƃ�
			p = (char *)J_MALLOC(strlen(filename) + strlen(dirname) + 1);
			strcpy(p, dirname);
			strcat(p, filename);
		} else {
			p = (char *)J_MALLOC(strlen(filename) + 1);
			strcpy(p, filename);
		}
		return p;
}

static const char * args_needed_exit(const char *opt)
{
	J_ERROR("%s: option requires argument -- %s\n", EXECNAME, opt);
	return(NULL);
}

int CJuliGlobalOption::ReadArgs(int argc, char * const argv[], const char *cwd)
{
	const char *tmparg;
	int i;
#define NEXTARG (++i >= argc) ? (const char *)args_needed_exit(argv[i-1]) : argv[i]
	if (argc == 1)
	{		/* no argument */
		return 1;
	}

	for (i=1;i<argc;i++) {
		if (strmatch(argv[i],"-C")) { /* config file  */
			ReadJConf(filepath(NEXTARG, cwd));
			continue;
		} else if (strmatch(argv[i],"-input")) { /* speech input */
			tmparg = NEXTARG;
			if (strmatch(tmparg,"rawfile")) {
				this->speech_input = SP_RAWFILE;
				this->realtime_flag = FALSE;
			} else if (strmatch(tmparg,"mfcfile")) {
				this->speech_input = SP_MFCFILE;
				this->realtime_flag = FALSE;
			} else if (strmatch(tmparg,"adinnet")) {
				this->speech_input = SP_ADINNET;
				this->realtime_flag = TRUE;
#ifdef USE_NETAUDIO
			} else if (strmatch(tmparg,"netaudio")) {
				this->speech_input = SP_NETAUDIO;
				this->realtime_flag = TRUE;
#endif
#ifdef USE_MIC
			} else if (strmatch(tmparg,"mic")) {
				this->speech_input = SP_MIC;
				this->realtime_flag = TRUE;
#endif
			} else if (strmatch(tmparg,"file")) { /* for 1.1 compat */
				this->speech_input = SP_RAWFILE;
				this->realtime_flag = FALSE;
			} else if (strmatch(tmparg,"mfc")) { /* for 1.1 compat */
				this->speech_input = SP_MFCFILE;
				this->realtime_flag = FALSE;
			} else {
				J_ERROR("%s: no such speech input source \"%s\" supported\n", argv[0], tmparg);
				return 1;
			}
			continue;
		} else if (strmatch(argv[i],"-result")) { /* result output */
			tmparg = NEXTARG;
			if (strmatch(tmparg,"tty")) {
				this->result_output = SP_RESULT_TTY;
			} else {
				J_ERROR("%s: no such result output \"%s\"\n", argv[0], tmparg);
				return 1;
			}
		} else if (strmatch(argv[i],"-force_realtime")) {
			tmparg = NEXTARG;
			if (strmatch(tmparg, "on")) {
				this->forced_realtime = TRUE;
			} else if (strmatch(tmparg, "off")) {
				this->forced_realtime = FALSE;
			} else {
				J_ERROR("%s: \"-force_realtime\" allows \"on\" or \"off\"\n", EXECNAME);
				return 1;
			}
			this->force_realtime_flag = TRUE;
			continue;
		} else if (strmatch(argv[i],"-realtime")) {
			this->forced_realtime = TRUE;
			this->force_realtime_flag = TRUE;
			continue;
		} else if (strmatch(argv[i], "-norealtime")) {
			this->forced_realtime = FALSE;
			this->force_realtime_flag = TRUE;
			continue;
		} else if (strmatch(argv[i],"-check")) {
			tmparg = NEXTARG;
			if (strmatch(tmparg, "wchmm")) {
				this->wchmm_check_flag = TRUE;
			} else if (strmatch(tmparg, "trellis")) {
				this->trellis_check_flag = TRUE;
			} else {
				J_ERROR("%s: no such check style: %s\n", argv[0], tmparg);
				return 1;
			}
			continue;
		} else if (strmatch(argv[i],"-notypecheck")) {
			this->paramtype_check_flag = FALSE;
			continue;
		} else if (strmatch(argv[i],"-separatescore")) {
			//			if (IS_NGRAM)
			//			{
			this->separate_score_flag = TRUE;
			//			}
			//			if (IS_DFA)
			//			{
			//				J_ERROR("Warning: option \"-separatescore\" ignored\n");
			//			}
			continue;
		} else if (strmatch(argv[i],"-nlimit")) {
#ifdef WPAIR_KEEP_NLIMIT
			wpair_keep_nlimit = atoi(NEXTARG);
#else
			J_ERROR("Warning: option \"-nlimit\" ignored\n");
#endif
			continue;
		} else if (strmatch(argv[i],"-lookuprange")) {
			m_opt.lookup_range = atoi(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-sb")) {
#ifdef SCAN_BEAM
			m_opt.scan_beam_thres = atof(NEXTARG);
#else
			J_ERROR("Warning: option \"-sb\" ignored\n");
#endif
			continue;
		} else if (strmatch(argv[i],"-discount")) {
			J_ERROR("Warning: option \"-discount\" ignored\n");
			continue;
		} else if (strmatch(argv[i],"-pausesegment")) {
			this->pause_segment = 1;
			continue;
		} else if (strmatch(argv[i],"-nopausesegment")) {
			this->pause_segment = 0;
			continue;
		} else if (strmatch(argv[i],"-lv")) {
			this->level_thres = atoi(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-zc")) {
			this->zero_cross_num = atoi(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-headmargin")) {
			this->head_margin_msec = atoi(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-tailmargin")) {
			this->tail_margin_msec = atoi(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-hipass")) { /* frequency of hi cut-off */
			this->hipass = atoi(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-lopass")) { /* frequency of low cut-off */
			this->lopass = atoi(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-smpPeriod")) { /* sample period (ns) */
			this->smpPeriod = atoi(NEXTARG);
			this->smpFreq = period2freq(this->smpPeriod);
			continue;
		} else if (strmatch(argv[i],"-smpFreq")) { /* sample frequency (Hz) */
			this->smpFreq = atoi(NEXTARG);
			this->smpPeriod = freq2period(this->smpFreq);
			continue;
		} else if (strmatch(argv[i],"-fsize")) { /* Window size */
			this->fsize = atoi(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-fshift")) { /* Frame shiht */
			this->fshift = atoi(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-ssalpha")) { /* alpha coef. for SS */
			ssalpha = atof(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-ssfloor")) { /* spectral floor for SS */
			ssfloor = atof(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-version")) {
			return 1;
		} else if (strmatch(argv[i],"--version")) {
			return 1;
		} else if (strmatch(argv[i],"-quiet")) {
			this->debug2_flag = this->verbose_flag = FALSE;
			continue;
		} else if (strmatch(argv[i],"-debug")) {
			this->debug2_flag = this->verbose_flag = TRUE;
			continue;
		} else if (strmatch(argv[i],"-progout")) {
			this->progout_flag = TRUE;
			continue;
		} else if (strmatch(argv[i],"-demo")) {
			/* quiet + progout */
			this->debug2_flag = this->verbose_flag = FALSE;
			this->progout_flag = TRUE;
			continue;
		} else if (strmatch(argv[i],"-walign")) {
			this->align_result_word_flag = TRUE;
			continue;
		} else if (strmatch(argv[i],"-palign")) {
			this->align_result_phoneme_flag = TRUE;
			continue;
		} else if (strmatch(argv[i],"-output")) {
			m_opt.output_hypo_maxnum = atoi(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-1pass")) {
			this->compute_only_1pass = TRUE;
			continue;
		} else if (strmatch(argv[i],"-hlist")) {
			this->m_strMapFile = filepath(NEXTARG, cwd);
			this->m_bUseMapFile = TRUE;
			continue;
#ifdef USE_NGRAM
		} else if (strmatch(argv[i],"-nlr")) {
			m_opt.m_strNgramArpaLRFile = filepath(NEXTARG, cwd);
			m_opt.m_strNgramFile = "";
			continue;
		} else if (strmatch(argv[i],"-nrl")) {
			m_opt.m_strNgramArpaRLFile = filepath(NEXTARG, cwd);
			m_opt.m_strNgramFile = "";
			continue;
		} else if (strmatch(argv[i],"-lmp")) {
			m_opt.lm_weight = (LOGPROB)atof(NEXTARG);
			m_opt.lm_penalty = (LOGPROB)atof(NEXTARG);
			m_opt.lmp_specified = TRUE;
			continue;
		} else if (strmatch(argv[i],"-lmp2")) {
			m_opt.lm_weight2 = (LOGPROB)atof(NEXTARG);
			m_opt.lm_penalty2 = (LOGPROB)atof(NEXTARG);
			m_opt.lmp2_specified = TRUE;
			continue;
		} else if (strmatch(argv[i],"-transp")) {
			m_opt.lm_penalty_trans = (LOGPROB)atof(NEXTARG);
			continue;
#else  /* USE_DFA */
		} else if (strmatch(argv[i],"-dfa")) {
//			m_strDfaFile = filepath(NEXTARG, cwd);
			continue;
		} else if (strmatch(argv[i],"-penalty1")) {
			m_opt.penalty1 = (LOGPROB)atof(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-penalty2")) {
			m_opt.penalty2 = (LOGPROB)atof(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-sp")) {
			m_opt.m_strSpName = strdup(NEXTARG);
			continue;
#endif
#ifdef USE_NGRAM
		} else if (strmatch(argv[i],"-SAPINOUSESLM")) {
			this->m_bNoUseSLM = TRUE;
			continue;
		} else if (strmatch(argv[i],"-silhead")) {
			m_opt.m_strHeadSilentName = strdup(NEXTARG);
			m_opt.m_bUseHeadSilName = TRUE;
			continue;
		} else if (strmatch(argv[i],"-siltail")) {
			m_opt.m_strTailSilentName = strdup(NEXTARG);
			m_opt.m_bUseTailSilName = TRUE;
			continue;
#ifdef CLASS_NGRAM
		} else if (strmatch(argv[i],"-class")) {
			class_bingram_file = filepath(NEXTARG, cwd);
			continue;
		} else if (strmatch(argv[i],"-clw")) {
			class_weight = atof(NEXTARG);
			continue;
#endif
		} else if (strmatch(argv[i],"-iwcache")) {
#ifdef HASH_CACHE_IW
			iw_cache_rate = atof(NEXTARG);
			if (iw_cache_rate > 100) iw_cache_rate = 100;
			if (iw_cache_rate < 1) iw_cache_rate = 1;
#else
			J_ERROR("Warning: option \"-iwcache\" ignored\n");
#endif
			continue;
		} else if (strmatch(argv[i],"-sepnum")) {
#ifdef SEPARATE_BY_UNIGRAM
			m_opt.separate_wnum = atoi(NEXTARG);
#else
			J_ERROR("Warning: option \"-sepnum\" ignored\n");
#endif
			continue;
#endif /* USE_NGRAM */
#ifdef USE_NETAUDIO
		} else if (strmatch(argv[i],"-NA")) {
			netaudio_devname = NEXTARG;
			continue;
#endif
		} else if (strmatch(argv[i],"-adport")) {
			this->adinnet_port = atoi(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-nostrip")) {
			this->strip_zero_sample = FALSE;
			continue;
#ifdef SP_BREAK_CURRENT_FRAME
		} else if (strmatch(argv[i],"-spdur")) {
			sp_frame_duration = atoi(NEXTARG);
			continue;
#endif
		} else if (strmatch(argv[i],"-gprune")) {
			tmparg = NEXTARG;
			if (strmatch(tmparg,"safe")) {
				m_opt.gprune_method = GPRUNE_SEL_SAFE;
			} else if (strmatch(tmparg,"heuristic")) {
				m_opt.gprune_method = GPRUNE_SEL_HEURISTIC;
			} else if (strmatch(tmparg,"beam")) {
				m_opt.gprune_method = GPRUNE_SEL_BEAM;
			} else if (strmatch(tmparg,"none")) {
				m_opt.gprune_method = GPRUNE_SEL_NONE;
			} else {
				J_ERROR("%s: no such pruning method \"%s\"\n", argv[0], tmparg);
				return 1;
			}
			continue;
			/* 
			*     } else if (strmatch(argv[i],"-reorder")) {
			*	 result_reorder_flag = TRUE;
			*	 continue;
			*/
		} else if (strmatch(argv[i],"-no_ccd")) {
			this->ccd_flag = FALSE;
			this->ccd_flag_force = TRUE;
			continue;
		} else if (strmatch(argv[i],"-force_ccd")) {
			this->ccd_flag = TRUE;
			this->ccd_flag_force = TRUE;
			continue;
		} else if (strmatch(argv[i],"-tmix")) {
			if (i + 1 < argc && isdigit(argv[i+1][0])) {
				m_opt.mixnum_thres = atoi(argv[++i]);
			}
			continue;
		} else if (strmatch(argv[i],"-b2") || strmatch(argv[i],"-bw") || strmatch(argv[i],"-wb")) {
			m_opt.enveloped_bestfirst_width = atoi(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-hgs")) {
			this->m_strGsHmmFile = filepath(NEXTARG, cwd);
			continue;
		} else if (strmatch(argv[i],"-booknum")) {
			m_opt.gs_statenum = atoi(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-gshmm")) {
			this->m_strGsHmmFile = filepath(NEXTARG, cwd);
			continue;
		} else if (strmatch(argv[i],"-gsnum")) {
			m_opt.gs_statenum = atoi(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-cmnload")) { /* load CMN parameter from file */
			m_bCMNLoad = false;
			m_strCMNLoadFile = filepath(NEXTARG, cwd);
			continue;
		} else if (strmatch(argv[i],"-cmnsave")) { /* save CMN parameter to file */
			m_bCMNSave = false;
			m_strCMNSaveFile = filepath(NEXTARG, cwd);
			continue;
		} else if (strmatch(argv[i],"-sscalc")) { /* do spectral subtraction (SS) for raw file input */
			m_iSSMode = 1;
//			sscalc = TRUE;
			m_strSSLoadFile = "";
			continue;
		} else if (strmatch(argv[i],"-sscalclen")) { /* head silence length used to compute SS (in msec) */
			sscalc_len = atoi(NEXTARG);
			continue;
		} else if (strmatch(argv[i],"-ssload")) { /* load SS parameter from file */
			m_strSSLoadFile = filepath(NEXTARG, cwd);
			m_iSSMode = 2;
//			sscalc = FALSE;
			continue;
#if 1		// Julius for SAPI �g��
		} else if (strmatch(argv[i],"-errlog")) {
			this->m_strErrLogFile = filepath(NEXTARG, cwd);
			this->m_bUseErrLogFile = TRUE;
			continue;
		} else if (strmatch(argv[i],"-outlog")) {
			this->m_strOutLogFile = filepath(NEXTARG, cwd);
			continue;
		} else if (strmatch(argv[i],"-debuglog")) {
			this->m_strDebugLogFile = filepath(NEXTARG, cwd);
			continue;
#endif
		} else if (strmatch(argv[i],"-help")) {
		} else if (strmatch(argv[i],"--help")) {
		}
		if (argv[i][0] == '-' && strlen(argv[i]) == 2) {
			/* 1-letter options */
			switch(argv[i][1]) {
			case 'h':
				this->m_strHmmFile = filepath(NEXTARG, cwd);
				break;
			case 'v':
				m_opt.m_strDictFile = filepath(NEXTARG, cwd);
				break;
#ifdef USE_NGRAM
			case 'd':
				m_opt.m_strNgramFile = filepath(NEXTARG, cwd);
				m_opt.m_strNgramArpaLRFile = "";
				m_opt.m_strNgramArpaRLFile = "";
				break;
#endif
			case 'b':
				m_opt.trellis_beam_width = atoi(NEXTARG);
				break;
			case 's':
				m_opt.stack_size = atoi(NEXTARG);
				break;
			case 'n':
				m_iNbest = atoi(NEXTARG);
				m_bUseNbest = TRUE;
				break;
			case 'm':
				m_opt.hypo_overflow = atoi(NEXTARG);
				break;
			default:
				J_ERROR("%s: wrong argument: %s\n", argv[0], argv[i]);
				return 1;
			}
		} else {			/* error */
			J_ERROR("%s: wrong argument: %s\n", argv[0], argv[i]);
			return 1;
		}
	}
	return 0;
}

int CJuliGlobalOption::ReadCommandLine(const char *cmdline)
{
	return 1;
}

#define ISTOKEN(A) (A == ' ' || A == '\t' || A == '\n' || A == '\r'/* DOS Return code*/)
/* get directory name of a file path, with trailing slash */
static void
get_dirname(char *path)
{
	char *p;
	/* /path/file -> /path/ */
	/* path/file  -> path/  */
	/* /file      -> / */
	/* file       ->  */
	/* ../file    -> ../ */
	p = path + strlen(path) - 1;
	while (*p != '/' && *p != '\\' && p != path) p--;
	if (p == path && *p != '/' && *p != '\\') *p = '\0';
	else *(p+1) = '\0';
}

int CJuliGlobalOption::ReadJConf(const char *jconffilename)
{
	int c_argc;
	char **c_argv;
	CJuliFile jconffile;
	int maxnum, step;
	char buf[512], *cpy;
	char *p, *dst, *dst_from;
	char *cdir;
	//	j_printerr("include config: %s\n", jconffilename);

	/* text in file -> c_argv[1..c_argc-1] */
	/* c_argv[0] = jconffilename name */
	if (jconffile.OpenRead(jconffilename)) {
		J_ERROR("%s: failed to open jconf file: %s\n",EXECNAME, jconffilename);
		return 1;
	}
	step = 20;
	maxnum = step;
	c_argv = (char **)J_MALLOC(sizeof(char *) * maxnum);
	c_argv[0] = strcpy((char *)J_MALLOC(strlen(jconffilename)+1), jconffilename);
	c_argc = 1;
	while (jconffile.GetLine(buf, 512) != NULL) {
		cpy = (char *)J_MALLOC(strlen(buf)+1);
		p = buf; dst = cpy;
		while (1) {
			while (*p != '\0' && ISTOKEN(*p)) p++;
			if (*p == '\0') break;

			dst_from = dst;

			while (*p != '\0' && (!ISTOKEN(*p))) {
				if (*p == 92) {	/* escape by '\' */
					if (*(++p) == '\0') break;
					*(dst++) = *(p++);
				} else {
					if (*p == 34) { /* quote by "" */
						p++;
						while (*p != '\0' && *p != 34) *(dst++) = *(p++);
						if (*p == '\0') break;
						p++;
					} else if (*p == 39) { /* quote by '' */
						p++;
						while (*p != '\0' && *p != 39) *(dst++) = *(p++);
						if (*p == '\0') break;
						p++;
					} else if (*p == 35) { /* comment out by '#' */
						*p = '\0';
						break;
					} else {		/* other */
						*(dst++) = *(p++);
					}
				}
			}
			if (dst != dst_from) {
				*dst = '\0'; dst++;
				if (c_argc >= maxnum) {
					maxnum += step;
					c_argv = (char **)J_REALLOC(c_argv, sizeof(char *) * maxnum);
				}
				c_argv[c_argc++] = dst_from;
			}
		}
	}
	if (jconffile.CloseRead()) {
		J_ERROR("%s: jconf file cannot close\n", EXECNAME);
		return 1;
	}
	if (1) {		/* for debug */
		int i;
		J_MESSAGE("JCONF: \t");
		for (i=1;i<c_argc;i++) J_MESSAGE("(%s),",c_argv[i]);
		J_MESSAGE("\n");
	}
	/* parse string as argument, changing dirname */
	cdir = strcpy((char *)J_MALLOC(strlen(jconffilename)+1), jconffilename);
	get_dirname(cdir);
	ReadArgs(c_argc, c_argv, (cdir[0] == '\0') ? NULL : cdir);
	J_FREE(cdir);
	return 1;
}

static void CatOptStr(string &s, const char *opt, const char *str)
{
	s = s + "-" + opt + " \"" + str + "\"\r\n";
}

static void CatOptInt(string &s, const char *opt, int i)
{
	char buf[256];
	sprintf(buf, "%d", i);
	s = s + "-" + opt + " " + buf + "\r\n";
}

// CONF �t�@�C�����ۂ����e���o��
void CJuliGlobalOption::GetOptionString(string &str)
{
	str = "";
	if (m_strHmmFile != "")
	{
		CatOptStr(str, "h", m_strHmmFile.c_str());
	}
	if (m_bUseMapFile && m_strMapFile != "")
	{
		CatOptStr(str, "hlist", m_strMapFile.c_str());
	}
	if (m_bUseGsHmmFile && m_strGsHmmFile != "")
	{
		CatOptStr(str, "g", m_strGsHmmFile.c_str());
		CatOptInt(str, "gsnum", GetOption().gs_statenum);
	}
	if (m_bUseErrLogFile && m_strErrLogFile != "")
	{
		CatOptStr(str, "errlog", m_strErrLogFile.c_str());
	}
	if (m_bUseOutLogFile && m_strOutLogFile != "")
	{
		CatOptStr(str, "outlog", m_strOutLogFile.c_str());
	}
	if (m_bUseDebugLogFile && m_strDebugLogFile != "")
	{
		CatOptStr(str, "debuglog", m_strDebugLogFile.c_str());
	}
	if (GetOption().m_bUseArpaFile == 0)
	{
		if (GetOption().m_strNgramFile != "")
		{
			CatOptStr(str, "d", GetOption().m_strNgramFile.c_str());
		}
	} else {
		if (GetOption().m_strNgramArpaLRFile != "")
		{
			CatOptStr(str, "alr", GetOption().m_strNgramArpaLRFile.c_str());
		}
		if (GetOption().m_strNgramArpaRLFile != "")
		{
			CatOptStr(str, "arl", GetOption().m_strNgramArpaRLFile.c_str());
		}
	}
	if (GetOption().m_strDictFile != "")
	{
		CatOptStr(str, "v", GetOption().m_strDictFile.c_str());
	}
	if (m_bNoUseSLM)
	{
		str += "-SAPINOUSESLM\r\n";
	}
	if (GetOption().m_bUseHeadSilName)
	{
		CatOptStr(str, "silhead", GetOption().m_strHeadSilentName.c_str());
	}
	if (GetOption().m_bUseTailSilName)
	{
		CatOptStr(str, "siltail", GetOption().m_strTailSilentName.c_str());
	}

	if (m_bUseNbest)	CatOptInt(str, "n", m_iNbest);
	if (m_bUseCM)		str += "-SAPICM\r\n";
	if (align_result_word_flag)		str += "-walign\r\n";
	if (align_result_phoneme_flag)	str += "-palign\r\n";

	if (GetOption().trellis_beam_width != -1)
	{
		CatOptInt(str, "b", GetOption().trellis_beam_width);
	}
	if (GetOption().lmp_specified)
	{
		char buf[256];
		sprintf(buf, "%f %f", GetOption().lm_weight, GetOption().lm_penalty);
		str = str + "-lmp " + buf + "\r\n";
	}
	if (GetOption().lmp2_specified)
	{
		char buf[256];
		sprintf(buf, "%f %f", GetOption().lm_weight2, GetOption().lm_penalty2);
		str = str + "-lmp2 " + buf + "\r\n";
	}

	// Audio Options
	if (pause_segment == 0)				str = str + "-nopausesegment\r\n";
	else if (pause_segment == 1)		str = str + "-pausesegment\r\n";
	if (! level_thres.IsDefault())		CatOptInt(str, "lv", level_thres);
	if (! head_margin_msec.IsDefault())	CatOptInt(str, "headmargin", head_margin_msec);
	if (! tail_margin_msec.IsDefault())	CatOptInt(str, "tailmargin", tail_margin_msec);
	if (! zero_cross_num.IsDefault())	CatOptInt(str, "zc", zero_cross_num);
	if (! strip_zero_sample)		str += "-nostrip\r\n";
	if (hipass != -1)				CatOptInt(str, "hipass", hipass);
	if (lopass != -1)				CatOptInt(str, "lopass", lopass);
	if (! fshift.IsDefault())		CatOptInt(str, "fshift", fshift);
	if (! fsize.IsDefault())		CatOptInt(str, "fsize", fsize);

	if (! GetOption().stack_size.IsDefault())	CatOptInt(str, "s", GetOption().stack_size);
	if (! GetOption().hypo_overflow.IsDefault())	CatOptInt(str, "m", GetOption().hypo_overflow);
	if (! GetOption().stack_size.IsDefault())
	{
		char buf[256];
		sprintf(buf, "%f", GetOption().scan_beam_thres);
		str = str + "-sb " + buf + "\r\n";
	}
	if (! GetOption().enveloped_bestfirst_width.IsDefault())	CatOptInt(str, "b2", GetOption().enveloped_bestfirst_width);
	if (! GetOption().lookup_range.IsDefault())	CatOptInt(str, "lookup", GetOption().lookup_range);
}
