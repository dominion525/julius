//====================================================================
// JuliTrellisAtom.h: ��1�p�X�̒P��g�����X�\����
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULITRELLISATOM_H__FD73AAC4_81D9_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULITRELLISATOM_H__FD73AAC4_81D9_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDefines.h"

class CJuliBackTrellis;

class CJuliTrellisAtom  
{
public:
	CJuliTrellisAtom();
	virtual ~CJuliTrellisAtom();

	// �A�N�Z�b�T
	void SetBackScore(LOGPROB s) { backscore = s; }
	LOGPROB GetBackScore() { return backscore; }
#ifdef USE_NGRAM
	void SetLangScore(LOGPROB s) { lscore = s; }
	LOGPROB GetLangScore() { return lscore; }
#endif
	void SetWordID(WORD_ID i) { wid = i; }
	WORD_ID GetWordID() { return wid; }
	void SetBeginTime(short t) { begintime = t; }
	short GetBeginTime() { return begintime; }
	void SetEndTime(short t) { endtime = t; }
	short GetEndTime() { return endtime; }

	void SetLastTre(CJuliTrellisAtom *t) { m_last_tre = t; }
	CJuliTrellisAtom * GetLastTre() { return m_last_tre; }
	void SetNext(CJuliTrellisAtom *t) { m_next = t; }
	CJuliTrellisAtom * GetNext() { return m_next; }

private:
	LOGPROB backscore;			/* �X�R�A���v */
#ifdef USE_NGRAM
	LOGPROB lscore;				/* ���̒P��̌���X�R�A */
#endif
	WORD_ID wid;				/* �P��ԍ� */
	short begintime;			/* �P��̋��E����(���̒P��̊J�n����)*/
	short endtime;				/* �I������ */
#ifdef WORDGRAPH
	boolean within_wordgraph;		/* �P��O���t���ɂ����True */
#endif
	CJuliTrellisAtom *	m_last_tre;	/* ���O�̒P���id */
	CJuliTrellisAtom *	m_next;		/* 1pass��:����TRE�ւ̃|�C���^ */
};

#endif // !defined(AFX_JULITRELLISATOM_H__FD73AAC4_81D9_11D5_9AFA_008098E80572__INCLUDED_)
