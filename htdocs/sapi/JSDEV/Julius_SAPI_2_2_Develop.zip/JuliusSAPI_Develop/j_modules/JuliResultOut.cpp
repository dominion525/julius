//====================================================================
// JuliResultOut.cpp: �o�͏���
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// All rights reserved
//====================================================================

#include "JuliResultOut.h"
#include "JuliDictionary.h"
#include "JuliGlobalOption.h"

#include <math.h>

// �p�����ăI�[�o���[�h���Ȃ��Ɖ������Ă���Ȃ�
CJuliResultOut::CJuliResultOut()
{
}

CJuliResultOut::~CJuliResultOut()
{
}

void CJuliResultOut::Clear()
{
	m_bSuccess = FALSE;
	m_results.clear();
/*
	m_widSeq.clear();
	m_ar.a_score = 0;
	m_ar.e_frame.clear();
	m_ar.e_score.clear();
	m_fScore = 0;
	m_fTotalLangScore = 0;
*/
}

int CJuliResultOut::SendRecognition(RESULT2 &res, boolean fHypo)
{
    J_DEBUGMESSAGE("��SendRecognition:Do nothing.\n");
	return 0;
}

int CJuliResultOut::SendFalseRecognition()
{
	J_DEBUGMESSAGE("��SendFalseRecognition:Do nothing.\n");
	return 0;
}

int CJuliResultOut::Send2ndPassRecognitionResult()
{
	double CMweight = (double)theOpt.m_fCMAlpha;
	if (m_results.size()<1)
	{
		J_ERROR("Send2ndPassRecognitionResult: m_results.size error!\n");
		return 0;
	}

	if (theOpt.m_bUseCM || (theOpt.m_bUseFalseRecognition && theOpt.m_bUseFRScore))
	{
		vector<double> vec_CMsent;

		// �M���x���Čv�Z����
		J_DEBUGMESSAGE("----- Re-scoreing with CM (alpha=%f)-----\n", theOpt.m_fCMAlpha.GetValue());
		double p_total = 0.0;
		for (int i=0;i<(int )m_results.size();i++)
		{
			double cm_sent = exp((m_results[i].m_fScore-m_results[0].m_fScore)*CMweight);
			vec_CMsent.push_back(cm_sent);
			p_total += cm_sent;
		}

		// ���K��
		for (int i=0;i<(int )vec_CMsent.size();i++)
		{
			vec_CMsent[i] /= p_total;
		}

		// �P�ꂲ�Ƃ̐M���x���v
		map<int, double> map_score;
		for (int i=0;i<(int )m_results.size();i++)
		{
			for (int j=0;j<(int )m_results[i].m_widSeq.size();j++)
			{
				// ���ɒP�ꂪ�d�������珜��(�����Ȃ��� 1�𒴂���)
				for (int k=0;k<j;k++)
				{
					if (m_results[i].m_widSeq[j] == m_results[i].m_widSeq[k]) break;
				}
				if (k==j)
					map_score[m_results[i].m_widSeq[j]] += vec_CMsent[i];
			}
		}

		// �o�͂Ɗi�[
		for (int i=0;i<(int )m_results.size();i++)
		{
			J_DEBUGMESSAGE("%d:(%.2f, %1.2lf)", i, m_results[i].m_fScore, vec_CMsent[i]);
			for (int j=0;j<(int )m_results[i].m_widSeq.size();j++)
			{
				m_results[i].m_ar.e_score[j] = (LOGPROB) map_score[m_results[i].m_widSeq[j]];
				J_DEBUGMESSAGE(" %1.2lf", m_results[i].m_ar.e_score[j]);
			}
			J_DEBUGMESSAGE("\n");
		}
		J_DEBUGMESSAGE("-------------------------------\n");

		// �X�R�A�ɂ��F�����s����
		if (theOpt.m_bUseFalseRecognition && theOpt.m_bUseFRScore)
		{
			if (vec_CMsent[0] < theOpt.m_probFRScore)
			{
				return SendFalseRecognition();	// �F�����s
			}
		}
	}

	int rval = SendRecognition(m_results[0], FALSE);
	return rval;
}

int CJuliResultOut::Hypothesis1(int t, WORD_ID *seq, int num, LOGPROB score, LOGPROB LMscore)
{
	J_MESSAGE("��Hypothesis1[ctxt=%p, t=%d, num=%d]:", GetContext(), t, num);
	J_OUTPUT("��1[%p]:", GetContext());

	RESULT2 res;
	res.m_fScore = score;
	res.m_fTotalLangScore = LMscore;
	for (int i=0;i<num;i++) {	res.m_widSeq.push_back(seq[i]); }

	SendRecognition(res, TRUE);
	J_MESSAGE("\n");
	return 0;
}

int CJuliResultOut::Final1(WORD_ID *seq, int num, LOGPROB score, LOGPROB LMscore)
{
	J_MESSAGE("��Final1[ctxt=%p, num=%d]:", GetContext(), num);
	J_OUTPUT("��1[%p]:", GetContext());

	RESULT2 res;
	res.m_fScore = score;
	res.m_fTotalLangScore = LMscore;
	for (int i=0;i<num;i++) {	res.m_widSeq.push_back(seq[i]); }

	SendRecognition(res, TRUE/*FALSE*/);
	J_MESSAGE("\n");
	return 0;
}

int CJuliResultOut::Final2(NODE *hypo, int rank, ALIGNRESULT *ar) // ttyout_pass2
{
#if 1
	J_MESSAGE("��Final2[ctxt=%p, rank=%d]: ", GetContext(), rank);
	J_OUTPUT("��2[%p]:", GetContext());
	if (hypo == NULL)
	{
		J_MESSAGE("False Recognition\n");
		m_bSuccess = FALSE;
		return 0;
	}
	m_bSuccess = TRUE;

	// ���ʂ��o�b�t�@����
	RESULT2 res;
	for (int i=0;i<hypo->seqnum;i++)
	{
		res.m_widSeq.push_back(hypo->seq[hypo->seqnum-i-1]);
	}
	res.m_fScore = hypo->score;
	res.m_fTotalLangScore = hypo->totallscore;
	res.m_ar = *ar;
	m_results.push_back(res);

	J_MESSAGE("\n");
#else
	if (hypo == NULL)
	{
		J_MESSAGE("��Final2[rank=%d]: False Recognition\n", rank);
		SendFalseRecognition();
		return 0;
	}
	WORD_ID *seq = new WORD_ID[hypo->seqnum];
	J_MESSAGE("��Final2[rank=%d]:", rank);
	for (int i=0;i<hypo->seqnum;i++)
	{
		seq[i] = hypo->seq[hypo->seqnum-i-1];
	}
	SendRecognition(seq, hypo->seqnum, hypo->score, hypo->totallscore, FALSE);
	delete [] seq;
	J_MESSAGE("\n");
#endif
	return 0;
}
