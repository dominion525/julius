// JuliHtkHmmOption.h: CJuliHtkHmmOption �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JULIHTKHMMOPTION_H__EDB545E1_7C47_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIHTKHMMOPTION_H__EDB545E1_7C47_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDefines.h"
#include "JuliFile.h"
#include "JuliHtkParam.h"



/* options info */
typedef struct {
	short num;			/* num of stream */
	short vsize[50];			/* vector size for each stream */
} HTK_HMM_StreamInfo;

class CJuliHtkHmmOption  
{
public:
	CJuliHtkHmmOption();
	virtual ~CJuliHtkHmmOption();
	
	void ReadFromFile(CJuliFile &file);				// read_global_opt
	
	boolean CheckHmmOptions();						// check_hmm_options
	boolean CheckParamCoherence(CJuliHtkParam *pinfo);	// check_param_coherence
	boolean CheckParamBaseType(CJuliHtkParam *pinfo);	// check_param_basetype
	
	// �A�N�Z�b�T
	short GetStreamNum() const { return stream_info.num; }
	short GetStreamVectorSize(int i) const { return stream_info.vsize[i]; }
	short GetVecSize() const { return vec_size; }
	short GetCovType() const { return cov_type; }
	short GetDurType() const { return dur_type; }
	short GetParamType() const { return param_type; }

	void SetStreamNum(short v) { stream_info.num = v; }
	void SetVecSize(short v) { vec_size = v; }
	void SetCovType(short v) { cov_type = v; }
	void SetDurType(short v) { dur_type = v; }
	void SetParamType(short v) { param_type = v; }

private:
	HTK_HMM_StreamInfo stream_info;	/* stream information */
	short vec_size;		/* size of parameter vector */
	short cov_type;		/* type of covariance matrix */
	short dur_type;		/* type of duration */
	short param_type;		/* type of parameter */
};

#endif // !defined(AFX_JULIHTKHMMOPTION_H__EDB545E1_7C47_11D5_9AFA_008098E80572__INCLUDED_)
