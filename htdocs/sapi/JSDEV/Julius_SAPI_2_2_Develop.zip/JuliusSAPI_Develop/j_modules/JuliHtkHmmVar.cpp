//====================================================================
// JuliHtkHmmVar.cpp: Htk HMM: Variance �I�u�W�F�N�g (HTK_HMM_Var)
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliHtkHmmVar.h"

CJuliHtkHmmVar::CJuliHtkHmmVar() : vec(NULL) , len(0) {}

CJuliHtkHmmVar::~CJuliHtkHmmVar()
{
	if (vec != NULL) delete vec;
}

void CJuliHtkHmmVar::ReadFromFile(CJuliFile &file,CJuliHmmInfo &info)
{
	int i;
	/* read covariance matrix (diagonal vector) */
	if (!file.CurrentTokenIs("VARIANCE")) {
		J_ERROR("variance matrix type \"%s\" not supported\n", file.CurrentToken());
		file.HmmError(NULL);
	} else {
		file.GetHmmToken();
		file.NoTokenError("missing VARIANCE vector length");
		len = atoi(file.CurrentToken());
		file.GetHmmToken();
		vec = new VECT[len];
		/* needs comversion if integerized */
		for (i=0;i<len;i++) {
			file.NoTokenError("missing some VARIANCE element");
			vec[i] = atof(file.CurrentToken());
			file.GetHmmToken();
		}
	}
}
