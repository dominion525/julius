//====================================================================
// JuliDictionary.h: �����Ǘ��N���X (WORD_INFO)
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIDICTIONARY_H__71BEDA27_624B_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIDICTIONARY_H__71BEDA27_624B_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDefines.h"
#include "JuliWord.h"

class CJuliWord;
class CJuliFile;
class CJuliHmmInfo;
class CJuliHtkHmmLogical;

#include <string>
#include <vector>
using namespace std;


class CJuliDictionary  
{
public:
	CJuliDictionary();
	virtual ~CJuliDictionary();

	int ReadFromFile(const char *filename, CJuliHmmInfo *hmminfo, boolean not_conv_tri, boolean force_dict);	// (init_voca)
	boolean	LoadHtkDict(	 /* TRUE on success */	// (voca_load_htkdict)
		CJuliFile &dictfile,CJuliHmmInfo *hmminfo/* if NULL, phonemes are ignored */,
		boolean ignore_tri_conv/* TRUE if convert to triphone should be ignored */);
	boolean	LoadHtkDict_forSAPI( /* TRUE on success */
		vector<string> &data,
		CJuliHmmInfo *hmminfo,	/* if NULL, phonemes are ignored */
		boolean ignore_tri_conv);	/* TRUE if convert to triphone should be ignored */

	boolean Mono2Tri(CJuliHmmInfo *hmminfo); // (voca_mono2tri)
	WORD_ID LookupWordID(const char *keyword); // voca_lookup_wid
	WORD_ID *NewStr2WordSeq(char *s, int *len_return); // new_str2wordseq

	// �A�N�Z�b�T
	WORD_ID GetNumWords() const { return num; }	// (num)���P�ꐔ��Ԃ�
	short GetMaxWn() const { return maxwn; }
	short GetMaxWordLength() const { return maxwlen; }

	CJuliWord * GetWord(WORD_ID id) const { return m_word[id]; }

	unsigned char GetWordLen(WORD_ID id) const { return m_word[id]->wlen; }	// (wlen)
	const char * GetWordName(WORD_ID id) const { return m_word[id]->GetWordName(); }
	const char * GetWordOutput(WORD_ID id) const { return m_word[id]->GetWordOutput(); }

	void SetWordID(WORD_ID id,WORD_ID val) { m_word[id]->wton = val; }
	WORD_ID GetWordID(WORD_ID id) const { return m_word[id]->wton; }	// (wton)

	const CJuliHtkHmmLogical ** GetWordSeq(WORD_ID id) const { return m_word[id]->wseq;	}	// (wseq)
	boolean IsTransparent(WORD_ID id) const { return m_word[id]->is_transparent; }


	// NGRAM only?
	void SetHeadSilentWordID(WORD_ID id) { head_silwid = id; }	// (head_silwid)
	WORD_ID GetHeadSilentWordID() const { return head_silwid; }	// (head_silwid)
	void SetTailSilentWordID(WORD_ID id) { tail_silwid = id; }	// (tail_silwid)
	WORD_ID GetTailSilentWordID() const { return tail_silwid; }	// (tail_silwid)

	void OutputDebug();
private:
	void Init();	// (winfo_init)
	int Expand();	// (winfo_expand)
	void SetMaxWn();	// (set_maxwn)
	void SetMaxWordLength();	// (set_maxwlen)


	CJuliWord	**m_word;		// �P��̏W��
	WORD_ID		maxnum;			/* (����t����ꂽ)�ő�P�ꐔ */
	WORD_ID		num;			/* �P�ꐔ */
	short		maxwn;			/* 1�P�ꂠ����̎�����Ԑ��̍ő�l */
	short		maxwlen;		/* wlen �̍ő�l */

	// NGRAM only?
	WORD_ID		head_silwid;	/* ���b�擪�̖����P���ID */
	WORD_ID		tail_silwid;	/* ���b�I�[�̖����P���ID */
};

#endif // !defined(AFX_JULIDICTIONARY_H__71BEDA27_624B_11D5_9AFA_008098E80572__INCLUDED_)
