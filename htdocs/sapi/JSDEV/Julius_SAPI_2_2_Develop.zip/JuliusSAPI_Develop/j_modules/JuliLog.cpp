//====================================================================
// JuliLog.cpp: �G���[���O�Ǘ��N���X(���C�u����)
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// All rights reserved
//====================================================================

#include "JuliLog.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <locale.h>

CJuliLog theJuliLog;

int CJuliLog::Output(const char *fmt, ...)
{
	if (LogHandler == NULL)	return 1;
	va_list marker;
	va_start(marker, fmt);
	char buf[1024];
	vsprintf(buf, fmt, marker);
	LogHandler(buf, m_pHandlerParam, LOG_OUTPUT);
	va_end(marker);
	return 0;
}

int CJuliLog::Debug(const char *fmt, ...)
{
	if (LogHandler == NULL)	return 1;
	va_list marker;
	va_start(marker, fmt);
	char buf[1024];
	vsprintf(buf, fmt, marker);
	LogHandler(buf, m_pHandlerParam, 0);
	va_end(marker);
	return 0;
}

int CJuliLog::Error(const char *fmt, ...)
{
	if (LogHandler == NULL)	return 1;
	va_list marker;
	va_start(marker, fmt);
	char buf[1024];
	vsprintf(buf, fmt, marker);
	LogHandler(buf, m_pHandlerParam, LOG_ERROR);
	va_end(marker);
	return 0;
}

int CJuliLog::Message(const char *fmt, ...)
{
	if (LogHandler == NULL)	return 1;
	va_list marker;
	va_start(marker, fmt);
	char buf[1024];
	vsprintf(buf, fmt, marker);
	LogHandler(buf, m_pHandlerParam, 0);
	va_end(marker);
	return 0;
}

int CJuliLog::Warning(const char *fmt, ...)
{
	if (LogHandler == NULL)	return 1;
	va_list marker;
	va_start(marker, fmt);
	char buf[1024];
	vsprintf(buf, fmt, marker);
	LogHandler(buf, m_pHandlerParam, LOG_WARNING);
	va_end(marker);
	return 0;
}

int CJuliLog::Vermes(const char *fmt, ...)
{
	if (LogHandler == NULL)	return 1;
	va_list marker;
	va_start(marker, fmt);
	char buf[1024];
	vsprintf(buf, fmt, marker);
	LogHandler(buf, m_pHandlerParam, 0);
	va_end(marker);
	return 0;
}

int CJuliLog::MessageW(const wchar_t *fmt, ...)
{
	if (LogHandler == NULL) return 1;
	va_list marker;
	va_start( marker, fmt );     /* �ό̈����̏����� */
	static wchar_t jwpbuf[1024];
	static char jpbuf[1024];
	vswprintf(jwpbuf, fmt, marker);
		
	// locale �̐ݒ�
	setlocale(LC_ALL, "Japanese");
	wcstombs(jpbuf, jwpbuf, 1024);
	LogHandler(jpbuf, m_pHandlerParam, 0);
	va_end( marker );              /* �ό̈����̃��Z�b�g */
	return 0;
}

