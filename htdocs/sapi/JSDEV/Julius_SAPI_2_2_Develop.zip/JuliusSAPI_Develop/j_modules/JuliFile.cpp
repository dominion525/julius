//====================================================================
// JuliFile.cpp: ZLIB�Ή��t�@�C���N���X
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2000 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliFile.h"
#include "JuliDefines.h"
#include "JuliUtil.h"
#include <string.h>

// �f���~�^�� DOS �`���̉��s���l������ \r ������
#define DELM " \t\r\n"

CJuliFile::~CJuliFile()
{
	if (m_buf != NULL) J_FREE(m_buf);
	// Close �Y��
	if (gp != NULL)
	{
		if (gzclose(gp) < 0) perror("fclose_readfile");
	}
	if (fp != NULL)
	{
		fclose(fp);
	}
}

int CJuliFile::OpenRead(const char *filename)
{
	gp = gzopen(filename, "rb");
	if (gp == NULL) perror("fopen_readfile");
	return 0;
}

int CJuliFile::CloseRead()
{
	if (gzclose(gp) < 0) perror("fclose_readfile");
	gp = NULL;
	return 0;
}

size_t CJuliFile::Read(void *ptr, size_t size, size_t n)
{
	int cnt;
	cnt = gzread(gp, (voidp)ptr, (unsigned)size * n);
	if (cnt < 0) perror("myfread");
	return(cnt / size);
}

int CJuliFile::OpenWrite(const char *filename)
{
	fp = fopen(filename, "wb");
	if (fp == NULL) {		/* error */
		perror("fopen_writefile");
	}
	return 0;
}

int CJuliFile::CloseWrite()
{
	fclose(fp);
	fp = NULL;
	return 0;
}

size_t CJuliFile::Write(void *ptr, size_t size, size_t n)
{
	return(fwrite(ptr, size, n, fp));
}

/* fp ���� buf �Ɉ�s�ǂݍ��ށD��s�͂Ƃ΂��D�G���[��NULL��Ԃ� */
char * CJuliFile::GetLine(char *buf, int maxlen)
{
	int newline;
	while(gzgets(gp/*(gzFile)fp*/, buf, maxlen) != Z_NULL)
	{
		newline = strlen(buf)-1;    /* chop newline */
		if (buf[newline] == '\n') buf[newline] = '\0';
		if (buf[0] == '\0') continue; /* if blank line, read next */
		return buf;
	}
	return NULL;
}

char * CJuliFile::GetFirstToken(char *buf)
{
	char *p;
	if ((p=strtok(buf, DELM)) == NULL)
	{
		J_ERROR("data format error: corrupted data?\n");
		return NULL;
	}
	return p;
}

char * CJuliFile::GetNextToken()
{
	char *p;
	if ((p=strtok(NULL,DELM)) == NULL)
	{
		J_ERROR("data format error: corrupted data?\n");
		return NULL;
	}
	return p;
}

char * CJuliFile::GetNextTokenIfAny()
{
	char *p;
	p=strtok(NULL,DELM);
	return p;
}

char * CJuliFile::GetRestToken()
{
	char *p;
	if ((p=strtok(NULL, "\n")) == NULL)
	{
		J_ERROR("data format error: corrupted data?\n");
		return NULL;
	}
	return p;
}    


/*   given string: will be corrupted after this */
#define ISTOKEN(A) (A == ' ' || A == '\t' || A == '\n' || A == '<' || A == '>')
char * CJuliFile::Strtok_quote(char *str)	// mystrtok_quote
{
	char *p;
	char *from;
	if (str != NULL) {
		pos = buf = str;
	}
	/* find start point */
	p = pos;
	while (*p != '\0' && ISTOKEN(*p)) *p++;
	if (*p == '\0') return NULL;	/* no token left */
	
	/* copy to ret_buf until end point is found */
	if (*p == 34) {		/* double-quote */
		p++;
		if (*p == '\0') return NULL;
		from = p;
		while (*p != '\0' && *p != 34) *p++;
		/* if quotation not terminated, allow the rest as one token */
		/* if (*p == '\0') return NULL; */
	} else {
		from = p;
		while (*p != '\0' && (!ISTOKEN(*p))) p++;
	}
	if (*p != '\0') {
		*p = '\0';
		p++;
	}
	pos = p;
	return from;
}

#define MAXBUFLEN  4096

char * CJuliFile::GetHmmToken()
{
	if (m_buf != NULL) {
		/* already have buffer */
		if ((rdhmmdef_token = Strtok_quote(NULL)) != NULL) {
			/* return next token */
			return rdhmmdef_token;
		}
	} else {
		/* init: allocate buffer for the first time */
		m_buf = (char *)J_MALLOC(MAXBUFLEN);
		line = 1;
	}
	/* read new 1 line */
	if (GetLine(m_buf, MAXBUFLEN) == NULL)
	{
		rdhmmdef_token = NULL;
	} else {
		rdhmmdef_token = Strtok_quote(m_buf);
		line++;
	}
	return rdhmmdef_token;
}

char * CJuliFile::CurrentToken()
{
	return rdhmmdef_token;
}

void CJuliFile::HmmError(const char *str)
{
	if (rdhmmdef_token == NULL) {	/* end of file */
		J_ERROR("\nError: %s on end of file\n", str);
	} else {
		J_ERROR("\nError at line %d: %s\n", line, (str) ? str : "parse error");
	}
}

int CJuliFile::CurrentTokenIs(const char *str)
{
	return ! CJuliUtil::strcasecmp(str,rdhmmdef_token);
}

void CJuliFile::NoTokenError(const char *str)
{
	if (! rdhmmdef_token) HmmError(str);
}
