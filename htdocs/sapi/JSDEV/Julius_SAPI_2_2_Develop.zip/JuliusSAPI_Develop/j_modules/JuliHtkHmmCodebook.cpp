//====================================================================
// JuliHtkHmmCodebook.cpp: CJuliHtkHmmCodebook �N���X�̃C���v�������e�[�V����
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// All rights reserved
//====================================================================

#pragma warning ( disable : 4786 )

#include "JuliHtkHmmCodebook.h"
#include "JuliHmmInfo.h"

CJuliHtkHmmCodebook::CJuliHtkHmmCodebook()
{
	
}

CJuliHtkHmmCodebook::~CJuliHtkHmmCodebook()
{
	
}

void CJuliHtkHmmCodebook::ReadFromFile(CJuliFile &file, CJuliHmmInfo &info)
{
}
