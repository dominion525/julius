//====================================================================
// JuliUtil.h: �⏕�I�ȋ@�\��񋟂���֐��Q
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIUTIL_H__C2F03B2C_7AC4_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIUTIL_H__C2F03B2C_7AC4_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDefines.h"

class CJuliUtil
{
public:
	CJuliUtil();
	virtual ~CJuliUtil();

	static void swap_bytes(void *buf, size_t unitbyte, int unitnum);
	static void swap_sample_bytes(SP16 *buf, int len);
	static int strcasecmp(const char *s1, const char *s2);
	static int strncasecmp(const char *s1, const char *s2, size_t n);
	static short GetCodeFromQualStr(char *s);									// param_qualstr2code
	static short GetCodeFromStr(char *s);										// param_str2code
	static char * GetQualStrFromCode(char *buf, short type, boolean descflag);	// param_qualcode2str
	static char * GetStrFromCode(char *buf, short type, boolean descflag);		// param_code2str

	static void AddRightContext(char name[], const char *rc);			// add_right_context
	static void AddLeftContext(char name[], const char *lc);			// add_left_context
	static char * GetCenterName(const char *hmmname, char *buf);		// center_name
	static char * GetLeftCenterName(const char *hmmname, char *buf);	// leftcenter_name
	static char * GetRightCenterName(const char *hmmname, char *buf);	// rightcenter_name

	static int CheckFileCanBeRead(const char *filename);	// checkpath 
};

#endif // !defined(AFX_JULIUTIL_H__C2F03B2C_7AC4_11D5_9AFA_008098E80572__INCLUDED_)
