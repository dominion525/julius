//====================================================================
// JuliOutProb.cpp: 
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliOutProb.h"
#include "JuliLogTable.h"
#include "JuliWordConjHMM.h"

#include "JuliUtil.h"
#include "JuliHmmInfo.h"
#include "JuliHtkParam.h"
#include "JuliOptions.h"

static const int OUTPROB_CACHE_PERIOD=100; /* period of expanding outprob cache in frame */

CJuliOutProb::CJuliOutProb()
:	outprob_cache(NULL),
	outprob_cache_root(NULL),
	mixture_cache(NULL),
	fallback_score(NULL),
	gms_fallback_score(NULL),
	last_id(NULL),
	last_max_id(NULL)
#ifdef BEAM
	,dimthres(NULL)
#endif
	,OP_calced_score(NULL), OP_calced_id(NULL), mixcalced(NULL), beam_dimthres(NULL), backmax(NULL)
{
}

CJuliOutProb::~CJuliOutProb()
{
	if (outprob_cache != NULL)
	{
		J_FREE(outprob_cache);
		J_FREE(outprob_cache_root);
	}
	if (mixture_cache != NULL) {
		for(int t=0;t<t_allocframenum;t++) {
			J_FREE(mixture_cache[t][0]);
			J_FREE(mixture_cache[t]);
		}
		J_FREE(mixture_cache);
	}
	if (gms_fallback_score != NULL) {
		J_FREE(gms_fallback_score[0]);
		J_FREE(gms_fallback_score);
		J_FREE(is_selected);
	}

	// for J_BMALLOC
	J_BFREE(last_id);
	J_BFREE(last_max_id);
#ifdef BEAM
	J_BFREE(dimthres);
#endif

	// gprune
	J_FREE(OP_calced_score);
	J_FREE(OP_calced_id);
	J_FREE(mixcalced);
	J_FREE(beam_dimthres);
	J_FREE(backmax);

	for (int i=0;i<(int )m_allocedmem.size();i++)
		J_FREE(m_allocedmem[i]);
}

/* outprob_init.c --- top initialize function */

/* initialize: call once on startup */
boolean CJuliOutProb::Init(CJuliHmmInfo *hmminfo, CJuliHmmInfo *gshmm, int gms_num,
						   int gprune_method, int gprune_mixnum) // outprob_init
{
	/** select functions **/
	/* select Gaussian set computation function */
	switch(gprune_method) {
	case GPRUNE_SEL_NONE:
		compute_gaussset = GpruneNone;
		compute_gaussset_init = InitGpruneNone;
		break;
	case GPRUNE_SEL_SAFE:
		compute_gaussset = GpruneSafe;
		compute_gaussset_init = InitGpruneSafe;
		break;
	case GPRUNE_SEL_HEURISTIC:
		compute_gaussset = GpruneHeu;
		compute_gaussset_init = InitGpruneHeu;
		break;
	case GPRUNE_SEL_BEAM:
		compute_gaussset = GpruneBeam;
		compute_gaussset_init = InitGpruneBeam;
		break;
	}
	/* select mixture outprob calculation function (sumup with weighing) */
	if (hmminfo->IsTiedMixture()) {
		calc_outprob = CalcTiedMix; /* TM-base: enable book-level cache */
	} else {
		calc_outprob = CalcMix; /* non-TM: only combine */
	}

	/* select lcdset computing function (maximum or average) */
	/* 
	*   if (hmminfo->prefer_cdset_avg) {
	*     outprob_cd = outprob_cd_avg;
	*   } else {
	*     outprob_cd = outprob_cd_max;
	*   }
	*/

	/* select state outprob calculation function */
	if (gshmm != NULL) {
		calc_outprob_state = CalcStateGMS; /* enable GMS */
	} else {
		calc_outprob_state = calc_outprob; /* call mixture outprob directly */
	}

	/* store common global variable */
	OP_hmminfo = hmminfo;
	OP_gshmm = gshmm;		/* NULL if GMS not used */
	OP_gprune_num = gprune_mixnum;

	/* call initialize functions of all layer */
	//	theLogTable.MakeLogTable(); �ׂ̂Ƃ��ł��

	if ((this->*compute_gaussset_init)() == FALSE) return FALSE; /* OP_gprune may change */
	if (hmminfo->IsTiedMixture()) {
		if (InitCalcTiedMix() == FALSE) return FALSE;
	}
	if (OP_gshmm != NULL) {
		if (InitGMS(gms_num) == FALSE) return FALSE;
	}
	if (InitCache() == FALSE)  return FALSE;

	return TRUE;
}

/* prepare: call at every input */
boolean CJuliOutProb::Prepare(int framenum) // outprob_prepare
{
	if (PrepareCache() == FALSE) return FALSE;
	if (OP_gshmm != NULL) {
		if (PrepareGMS(framenum) == FALSE) return FALSE;
	}
	if (OP_hmminfo->IsTiedMixture()) {
		if (PrepareCalcTiedMix(framenum) == FALSE) return FALSE;
	}
	/* reset last time */
	OP_last_time = OP_time = -1;
	return TRUE;
}

/* outprob.c --- top routine of calculate output probability  */

/* local variables init functions */
/* _init(): call once on startup */
/* _prepare(): call before every input (framenum may vary) */
boolean CJuliOutProb::InitCache() // outprob_cache_init
{
	statenum = OP_hmminfo->GetTotalStateNum();
	outprob_cache = NULL;
	allocframenum = 0;
	allocblock = OUTPROB_CACHE_PERIOD;
	OP_time = -1;
	return TRUE;
}

boolean CJuliOutProb::PrepareCache() // outprob_cache_prepare
{
	int s,t;
#if 0
	int i, size;
	if ((size = statenum * framenum) == 0) return FALSE;

	/* allocate */
	if (allocframenum < framenum) {
		if (outprob_cache != NULL) {
			J_FREE(outprob_cache_root);
			J_FREE(outprob_cache);
		}
		outprob_cache = (LOGPROB **)J_MALLOC(sizeof(LOGPROB *) * framenum);
		if ((size = statenum * framenum) == 0) return FALSE; // add "FALSE"
		J_DEBUGMESSAGE("��outprob_cache_root: %d bytes (statenum = %d, framenum = %d)\n",
			sizeof(LOGPROB)*size,statenum,framenum);
		outprob_cache_root = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * size);
		for(i=0;i<framenum;i++) {
			outprob_cache[i] = &(outprob_cache_root[i * statenum]);
		}
		allocframenum = framenum;
	}
#endif
	/* clear */
	for (t = 0; t < allocframenum; t++) {
		for (s = 0; s < statenum; s++) {
			outprob_cache[t][s] = LOG_UNDEF;
		}
	}

	return TRUE;
}

/* expand cache area if needed */
void CJuliOutProb::ExtendCache(int reqframe) // outprob_cache_extend
{
	int newnum;
	int size;
	int t, s;
	LOGPROB *tmpp;

	if (reqframe < allocframenum)
		return;

	/* allocate per certain period */
	newnum = reqframe + 1;
	if (newnum < allocframenum + allocblock)
		newnum = allocframenum + allocblock;
	size = (newnum - allocframenum) * statenum;

	/* allocate */
	outprob_cache = (LOGPROB **)J_REALLOC(outprob_cache, sizeof(LOGPROB *) * newnum);	// outprob_cache==NULL �ł� OK
	// �V�����������A���P�[�g
	tmpp = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * size);
	// ������X�g�ɓo�^
	m_allocedmem.push_back((void *)tmpp);

	for(t = allocframenum; t < newnum; t++) {
		outprob_cache[t] = &(tmpp[(t - allocframenum) * statenum]);
		for (s = 0; s < statenum; s++) {
			outprob_cache[t][s] = LOG_UNDEF;
		}
	}

	J_DEBUGMESSAGE("outprob cache: %d->%d\n", allocframenum, newnum);
	allocframenum = newnum;
}

/* �o�͊m�����v�Z����(�g�b�v���[�`��) */
LOGPROB CJuliOutProb::CalcOutProbState(
									   int t,			/* ���ԃt���[�� */
									   const CJuliHtkHmmState *stateinfo,	/* ��� */
									   const CJuliHtkParam *param)		/* �����p�����[�^ */ // outprob_state
{
	LOGPROB outp;

	/* set global values */
	OP_state = stateinfo;
	OP_state_id = stateinfo->GetID();
	OP_param = param;
	if (OP_time != t) {
		OP_last_time = OP_time;
		ExtendCache(t);	// �K�v�Ȃ�΃L���b�V���̊g��
		OP_time = t;
		OP_vec = param->parvec[t];
		OP_veclen = param->veclen;

		last_cache = outprob_cache[t]; /* reduce 2-d array access */
	}

	/* consult cache */
	if ((outp = last_cache[OP_state_id]) == LOG_UNDEF) {
		outp = last_cache[OP_state_id] = (this->*calc_outprob_state)();
	}
	return(outp);
}

/* return maximum outprob for cd state set */
LOGPROB CJuliOutProb::CalcOutProbCdMax(int t, const CD_State_Set *lset, const CJuliHtkParam *param) // outprob_cd_max
{
	LOGPROB maxprob, prob;
	int i;
	maxprob = LOG_ZERO;
	for(i=0;i<lset->num;i++) {
		prob = CalcOutProbState(t, lset->m_ppStates[i], param);
		if (maxprob < prob) maxprob = prob;
	}
	return(maxprob);
}

/* return average outprob for cd state set */
LOGPROB CJuliOutProb::CalcOutProbCdAvg(int t, const CD_State_Set *lset, const CJuliHtkParam *param) // outprob_cd_avg
{
	LOGPROB sum, p;
	int i,j;
	sum = 0.0;
	j = 0;
	for(i=0;i<lset->num;i++) {
		p = CalcOutProbState(t, lset->m_ppStates[i], param);
		if (p > LOG_ZERO) {
			sum += p;
			j++;
		}
	}
	if (j==0)
	{
		J_ERROR("DIVIDE BY ZERO!\n");
	}
	return(sum/(float)j);
}

LOGPROB CJuliOutProb::CalcOutProbCd(int t, const CD_State_Set *lset, const CJuliHtkParam *param) // outprob_cd
{
	// �I�v�V�����͖�������
#if 1
	if (IsNgram())
	{
		return(CalcOutProbCdMax(t, lset, param));
	} else {
		return(CalcOutProbCdAvg(t, lset, param));
	}
#else
	if (!OP_hmminfo->IsPreferCdsetAvg()) {
		return(CalcOutProbCdMax(t, lset, param));
	} else {
		return(CalcOutProbCdAvg(t, lset, param));
	}
#endif
}

/* generic outprob function for HMM_STATE */
LOGPROB CJuliOutProb::CalcOutProb(int t, const HMM_STATE *hmmstate, const CJuliHtkParam *param) // outprob
{
	if (hmmstate->is_pseudo_state) {
		return(CalcOutProbCd(t, hmmstate->out.cdset, param));
	} else {
		return(CalcOutProbState(t, hmmstate->out.state, param));
	}
}


LOGPROB CJuliOutProb::CalcMix() // calc_mix
{
	int i;
	LOGPROB logprob = LOG_ZERO;

	/* compute Gaussian set */
	(this->*compute_gaussset)(OP_state->GetDens_pp(), OP_state->GetMixNum(), NULL);
	/* computed Gaussians will be set in:
	score ... OP_calced_score[0..OP_calced_num]
	id    ... OP_calced_id[0..OP_calced_num] */

	/* sum */
	for(i=0;i<OP_calced_num;i++) {
		OP_calced_score[i] += OP_state->GetBWeight(OP_calced_id[i]);
	}
	logprob = theLogTable.AddLogArray(OP_calced_score, OP_calced_num);
	if (logprob <= LOG_ZERO) return LOG_ZERO;
	return (LOGPROB ) (logprob / 2.30258509);
}




/* initialize cache area (should be called once on startup) */
boolean CJuliOutProb::InitCalcTiedMix() // calc_tied_mix_init
{
	mixture_cache = NULL;
	t_allocframenum = -1;
	last_id = (int *)J_BMALLOC(sizeof(int) * OP_hmminfo->GetMaxMixtureNum());
	return TRUE;
}

/* prepare cache area (should be called for each sample) */
boolean CJuliOutProb::PrepareCalcTiedMix(int framenum) // calc_tied_mix_prepare
{
	int bid, t, size;

	/* (re)-allocate */
	if (t_allocframenum < framenum) {
		if (mixture_cache != NULL) {
			for(t=0;t<t_allocframenum;t++) {
				J_FREE(mixture_cache[t][0]);
				J_FREE(mixture_cache[t]);
			}
			J_FREE(mixture_cache);
		}
		size = OP_gprune_num * OP_hmminfo->GetCodeBookNum();

		mixture_cache = (MIXCACHE ***)J_MALLOC(sizeof(MIXCACHE **) * framenum);
		for(t=0;t<framenum;t++) {
			mixture_cache[t] = (MIXCACHE **)J_MALLOC(sizeof(MIXCACHE *) * OP_hmminfo->GetCodeBookNum());
			mixture_cache[t][0] = (MIXCACHE *)J_MALLOC(sizeof(MIXCACHE) * size);
			for(bid=1;bid<OP_hmminfo->GetCodeBookNum();bid++) {
				mixture_cache[t][bid] = &(mixture_cache[t][0][OP_gprune_num * bid]);
			}
		}
		t_allocframenum = framenum;
	}
	/* clear */
	for(t=0;t<framenum;t++) {
		for(bid=0;bid<OP_hmminfo->GetCodeBookNum();bid++) {
			mixture_cache[t][bid][0].score = LOG_ZERO;
		}
	}
	return TRUE;
}

LOGPROB CJuliOutProb::CalcTiedMix() // calc_tied_mix
{
	CJuliHtkHmmCodebook *book = (CJuliHtkHmmCodebook *)(OP_state->GetDens_pp());
	LOGPROB logprob;
	int i;

	if (OP_last_time != OP_time) { /* different frame */
		tcache = mixture_cache[OP_time];
		if (OP_time >= 1) {
			last_tcache = mixture_cache[OP_time-1];
		} else {
			last_tcache = NULL;
		}
	}
	ttcache = tcache[book->GetID()];
	if (tcache[book->GetID()][0].score != LOG_ZERO) { /* already calced */
		/* calculate using cache and weight */
		for (i=0;i<OP_calced_num;i++) {
			OP_calced_score[i] = ttcache[i].score + OP_state->GetBWeight(ttcache[i].id);
		}
	} else { /* not calced yet */
		/* compute Gaussian set */
		if (OP_time >= 1) {
			last_ttcache = last_tcache[book->GetID()];
			if (last_ttcache[0].score != LOG_ZERO) {
				for(i=0;i<OP_gprune_num;i++) last_id[i] = last_ttcache[i].id;
				/* tell last calced best */
				(this->*compute_gaussset)(book->d, book->num, last_id);
			} else {
				(this->*compute_gaussset)(book->d, book->num, NULL);
			}
		} else {
			(this->*compute_gaussset)(book->d, book->num, NULL);
		}
		/* computed Gaussians will be set in:
		score ... OP_calced_score[0..OP_calced_num]
		id    ... OP_calced_id[0..OP_calced_num] */
		/* OP_gprune_num = required, OP_calced_num = actually calced */
		/* store to cache */
		for (i=0;i<OP_calced_num;i++) {
			ttcache[i].id = OP_calced_id[i];
			ttcache[i].score = OP_calced_score[i];
			/* now OP_calced_{id|score} can be used for work area */
			OP_calced_score[i] += OP_state->GetBWeight(OP_calced_id[i]);
		}
	}
	logprob = theLogTable.AddLogArray(OP_calced_score, OP_calced_num);
	if (logprob <= LOG_ZERO) return LOG_ZERO;
	return (LOGPROB ) (logprob / 2.30258509);
}  

/* gms.c --- calculate state probability with GMS */

/*
Implementation of Gaussian Mixture Selection (old doc...)

It is called from gs_calc_selected_mixture_and_cache_{safe,heu,beam} in
the first pass for each frame.  It calculates all GS HMM outprob for
given input frame and get the N-best GS HMM states. Then,
for the selected (N-best) states:
calculate the corresponding codebook,
and set fallback_score[t][book] to LOG_ZERO.
else:
set fallback_score[t][book] to the GS HMM outprob.
Later, when calculating state outprobs, the fallback_score[t][book]
is consulted and,
if fallback_score[t][book] == LOG_ZERO:
it means it has been selected, so calculate the outprob with
the corresponding codebook and its weights.
else:
it means it was pruned, so use the fallback_score[t][book]
as its outprob.


For triphone, GS HMMs should be assigned to each state.
So the fallback_score[][] is kept according to the GS state ID,
and corresponding GS HMM state id for each triphone state id should be
kept beforehand.
GS HMM Calculation:
for the selected (N-best) GS HMM states:
set fallback_score[t][gs_stateid] to LOG_ZERO.
else:
set fallback_score[t][gs_stateid] to the GS HMM outprob.
triphone HMM probabilities are assigned as:
if fallback_score[t][state2gs[tri_stateid]] == LOG_ZERO:
it has been selected, so calculate the original outprob.
else:
as it was pruned, re-use the fallback_score[t][stateid]
as its outprob.
*/

#undef NORMALIZE_GS_SCORE	/* normalize score (ad-hoc) */

/* GS HMMs must be defined at STATE level using "~s NAME" macro,
where NAMES are like "i:4m", "s2m", etc. */


/* register all state defs in GS HMM to GS_SET */
void CJuliOutProb::BuildGSset() // build_gsset
{
	/* allocate */
	gsset = (GS_SET *)J_MALLOC(sizeof(GS_SET) * OP_gshmm->GetTotalStateNum());
	gsset_num = OP_gshmm->GetTotalStateNum();
	/* make ID */

	list<CJuliHtkHmmState *>::const_iterator ist;
	for(ist = OP_gshmm->GetStateDB().GetList().begin(); ist != OP_gshmm->GetStateDB().GetList().end(); ist++) {
		gsset[(*ist)->GetID()].state = *ist;
	}
}

/* Build correspondence from GS states to triphone states */
#define MAXHMMNAMELEN 40
boolean CJuliOutProb::BuildState2GS() // build_state2gs
{
	list<CJuliHtkHmmData *>::const_iterator idt;
	const CJuliHtkHmmState *st, *cr;
	int i;
	char gstr[MAXHMMNAMELEN], cbuf[MAXHMMNAMELEN];
	//	char *p;
	boolean ok_p = TRUE;

	/* initialize */
	state2gs = (int *)J_MALLOC(sizeof(int) * OP_hmminfo->GetTotalStateNum());
	for(i=0;i<OP_hmminfo->GetTotalStateNum();i++) state2gs[i] = -1;

	/* parse through all HMM macro to register their state */
	for(idt = OP_hmminfo->GetDataDB().GetList().begin(); idt != OP_hmminfo->GetDataDB().GetList().end(); idt++) {
		if (strlen((*idt)->GetName()) >= MAXHMMNAMELEN - 2) {
			J_ERROR("Error: too long hmm name (>%d): \"%s\"\n",
				MAXHMMNAMELEN-3, (*idt)->GetName());
			ok_p = FALSE;
			continue;
		}
		for(i=1;i<(*idt)->GetStateNum()-1;i++) { /* for all state */
			st = (*idt)->GetState(i);
			/* skip if already assigned */
			if (state2gs[st->GetID()] != -1) continue;
			/* set corresponding gshmm name */
			sprintf(gstr, "%s%dm", CJuliUtil::GetCenterName((*idt)->GetName(), cbuf), i + 1);
			/* look up the state in OP_gshmm */
			if ((cr = OP_gshmm->GetStateDB().Lookup(gstr)) == NULL) {
				J_ERROR("Error: GS HMM \"%s\" not defined\n", gstr);
				ok_p = FALSE;
				continue;
			}
			/* store its ID */
			state2gs[st->GetID()] = cr->GetID();
		}
	}
#ifdef PARANOIA
	{
		CJuliHtkHmmState *st;
		for(st=OP_hmminfo->ststart; st; st=st->next) {
			printf("%s -> %s\n", (st->GetName() == NULL) ? "(NULL)" : st->GetName(),
				(gsset[state2gs[st->GetID()]].state)->GetName());
		}
	}
#endif
	return ok_p;
}

/* sort to find N-best states */
#define SD(A) gsindex[A-1]
#define SCOPY(D,S) D = S
#define SVAL(A) (t_fs[gsindex[A-1]])
#define STVAL (t_fs[s])

/* heap sort upward */
void CJuliOutProb::SortGSIndexUpward(int neednum, int totalnum) // sort_gsindex_upward
{
	int n,root,child,parent;
	int s;
	for (root = totalnum/2; root >= 1; root--) {
		SCOPY(s, SD(root));
		parent = root;
		while ((child = parent * 2) <= totalnum) {
			if (child < totalnum && SVAL(child) < SVAL(child+1)) {
				child++;
			}
			if (STVAL >= SVAL(child)) {
				break;
			}
			SCOPY(SD(parent), SD(child));
			parent = child;
		}
		SCOPY(SD(parent), s);
	}
	n = totalnum;
	while ( n > totalnum - neednum) {
		SCOPY(s, SD(n));
		SCOPY(SD(n), SD(1));
		n--;
		parent = 1;
		while ((child = parent * 2) <= n) {
			if (child < n && SVAL(child) < SVAL(child+1)) {
				child++;
			}
			if (STVAL >= SVAL(child)) {
				break;
			}
			SCOPY(SD(parent), SD(child));
			parent = child;
		}
		SCOPY(SD(parent), s);
	}
}

/* calculate all gs state score and select best ones */
void CJuliOutProb::DoGMS() // do_gms
{
	int i;

	/* compute all gshmm scores (in gs_score.c) */
	ComputeGSScores(gsset, gsset_num, t_fs);
	/* sort and select */
	SortGSIndexUpward(my_nbest, gsset_num);
	for(i=gsset_num - my_nbest;i<gsset_num;i++) {
		/* set scores of selected states to LOG_ZERO */
		t_fs[gsindex[i]] = LOG_ZERO;
	}

	/* power e -> 10 */
#ifdef NORMALIZE_GS_SCORE
	/* normalize other fallback scores (rate of max) */
	for(i=0;i<gsset_num;i++) {
		if (t_fs[i] != LOG_ZERO) {
			t_fs[i] = t_fs[i] * 0.975;
		}
	}
#endif
}  

/* initialize */
boolean CJuliOutProb::InitGMS(int nbest) // gms_init
{
	int i;

	/* Check gshmm type */
	if (OP_gshmm->IsTriphone()) {
		J_ERROR("Error: GS HMM should be a monophone model\n");
		return FALSE;
	}
	if (OP_gshmm->IsTiedMixture()) {
		J_ERROR("Error: GS HMM should not be a tied mixture model\n");
		return FALSE;
	}

	/* store as local info */
	my_nbest = nbest;

	/* Register all GS HMM states in GS_SET */
	BuildGSset();
	/* Make correspondence of all triphone states to GS HMM states */
	J_MESSAGE("Mapping HMM states to GS HMM...");
	if (BuildState2GS() == FALSE) {
		J_ERROR("Error: failed in assigning GS HMM state for each state\n");
		return FALSE;
	}
	J_MESSAGE("done\n");

	/* prepare index buffer for heap sort */
	gsindex = (int *)J_MALLOC(sizeof(int) * gsset_num);
	for(i=0;i<gsset_num;i++) gsindex[i] = i;

	/* init cache status */
	gms_fallback_score = NULL;
	is_selected = NULL;
	gms_allocframenum = -1;

	/* initialize gms_gprune functions */
	InitGMSGprune(OP_hmminfo, gsset_num);

	return TRUE;
}

boolean CJuliOutProb::PrepareGMS(int framenum) // gms_prepare
{
	LOGPROB *tmp;
	int t;

	/* allocate cache */
	if (gms_allocframenum < framenum) {
		if (gms_fallback_score != NULL) {
			J_FREE(gms_fallback_score[0]);
			J_FREE(gms_fallback_score);
			J_FREE(is_selected);
		}
		gms_fallback_score = (LOGPROB **)J_MALLOC(sizeof(LOGPROB *) * framenum);
		tmp = (LOGPROB *)J_MALLOC(sizeof(LOGPROB) * gsset_num * framenum);
		for(t=0;t<framenum;t++) {
			gms_fallback_score[t] = &(tmp[gsset_num * t]);
		}
		is_selected = (boolean *)J_MALLOC(sizeof(boolean) * framenum);
		gms_allocframenum = framenum;
	}
	/* clear */
	for(t=0;t<framenum;t++) is_selected[t] = FALSE;

	/* prepare gms_gprune functions */
	PrepareGMSGprune();

	return TRUE;
}

/* return state probability with Gaussiam Mixture Selection */
LOGPROB CJuliOutProb::CalcStateGMS() // gms_state
{
	LOGPROB gsprob;
	if (OP_last_time != OP_time) { /* different frame */
		/* set current buffer */
		t_fs = gms_fallback_score[OP_time];
		/* select state if not yet */
		if (!is_selected[OP_time]) {
			DoGMS();
			is_selected[OP_time] = TRUE;
		}
	}
	if ((gsprob = t_fs[state2gs[OP_state_id]]) != LOG_ZERO) {
		/* un-selected: return the fallback value */
		return(gsprob);
	}
	/* selected: calculate the real outprob of the state */
	return((this->*calc_outprob)());
}



/* activate experimental methods */
#define GS_MAX_PROB		/* compute only max for GS states */
#define LAST_BEST		/* compute last best Gaussian first */
#undef BEAM			/* enable beam pruning */
#define BEAM_OFFSET 10.0	/* envelope offset */

#ifdef BEAM
#define LAST_BEST
#endif
#ifdef LAST_BEST
#define GS_MAX_PROB
#endif


/************************************************************************/
/* initialization */
void CJuliOutProb::InitGMSGprune(const CJuliHmmInfo *hmminfo, int gsset_num) // gms_gprune_init
{
	my_gsset_num = gsset_num;
	last_max_id = (int *)J_BMALLOC(sizeof(int) * gsset_num);
#ifdef BEAM
	dimthres_num = hmminfo->opt.vec_size;
	dimthres = (LOGPROB *)J_BMALLOC(sizeof(LOGPROB) * dimthres_num);
#endif
}

void CJuliOutProb::PrepareGMSGprune() // gms_gprune_prepare
{
	int i;
	for(i=0;i<my_gsset_num;i++) {
		last_max_id[i] = -1;
	}
}

/**********************************************************************/
/* compute only max by (safe|beam) pruning */
/* LAST_BEST ... compute the maximum component in last frame first */
/* BEAM ... use beam pruning */
LOGPROB CJuliOutProb::CalcContProbWithSafePruning(CJuliHtkHmmDens *binfo, LOGPROB thres) // calc_contprob_with_safe_pruning
{
	LOGPROB tmp, x;
	VECT *mean;
	VECT *var;
	LOGPROB fthres = (LOGPROB) (thres * (-2.0));
	VECT *vec = OP_vec;
	short veclen = OP_veclen;

	if (binfo == NULL) return(LOG_ZERO);
	mean = binfo->GetMeanVect();
	var = binfo->GetVar()->GetVect();

	tmp = binfo->GetGconst();
	for (; veclen > 0; veclen--) {
		x = *(vec++) - *(mean++);
		tmp += x * x / *(var++);
		if ( tmp > fthres) {
			return LOG_ZERO;
		}
	}
	return(LOGPROB ) (tmp / -2.0);
}

#ifdef BEAM

LOGPROB CJuliOutProb::CalcContProbWithBeamPruningPre(CJuliHtkHmmDens *binfo) // calc_contprob_with_beam_pruning_pre
{
	LOGPROB tmp, x;
	VECT *mean;
	VECT *var;
	VECT *th = dimthres;
	VECT *vec = OP_vec;
	short veclen = OP_veclen;

	if (binfo == NULL) return(LOG_ZERO);
	mean = binfo->mean;
	var = binfo->GetVar()->GetVect();

	tmp = 0.0;
	for (; veclen > 0; veclen--) {
		x = *(vec++) - *(mean++);
		tmp += x * x / *(var++);
		if ( *th < tmp) *th = tmp;
		th++;
	}
	return((tmp + binfo->gconst) / -2.0);
}

LOGPROB CJuliOutProb::CalcContProbWithBeamPruningPost(CJuliHtkHmmDens *binfo) // calc_contprob_with_beam_pruning_post
{
	LOGPROB tmp, x;
	LOGPROB *mean;
	LOGPROB *var;
	LOGPROB *th = dimthres;
	VECT *vec = OP_vec;
	short veclen = OP_veclen;

	if (binfo == NULL) return(LOG_ZERO);
	mean = binfo->mean;
	var = binfo->GetVar()->GetVect();

	tmp = 0.0;
	for (; veclen > 0; veclen--) {
		x = *(vec++) - *(mean++);
		tmp += x * x / *(var++);
		if ( tmp > *(th++)) {
			return LOG_ZERO;
		}
	}
	return((tmp + binfo->gconst) / -2.0);
}

#endif /* BEAM */

#ifdef LAST_BEST
LOGPROB CJuliOutProb::ComputeGMax(CJuliHtkHmmState *stateinfo, int last_maxi, int *maxi_ret) // compute_g_max
{
	int i, maxi;
	LOGPROB prob;
	LOGPROB maxprob = LOG_ZERO;

	if (last_maxi != -1) {
		maxi = last_maxi;
#ifdef BEAM
		/* clear dimthres */
		for(i=0;i<dimthres_num;i++) dimthres[i] = 0.0;
		/* calculate and set thres for each dimension */
		maxprob = CalcContProbWithBeamPruningPre(stateinfo->b[maxi]);
		/* set final beam */
		for(i=0;i<dimthres_num;i++) dimthres[i] += BEAM_OFFSET;
#else  /* ~BEAM */
		maxprob = CalcContProbWithSafePruning(stateinfo->GetDens_pp()[maxi], LOG_ZERO);
#endif
		for (i = stateinfo->GetMixNum() - 1; i >= 0; i--) {
			if (i == last_maxi) continue;
#ifdef BEAM
			prob = CalcContProbWithBeamPruningPost(stateinfo->GetDens_pp()[i]);
#else  /* ~BEAM */
			prob = CalcContProbWithSafePruning(stateinfo->GetDens_pp()[i], maxprob);
#endif
			if (prob > maxprob) {
				maxprob = prob;
				maxi = i;
			}
		}
		*maxi_ret = maxi;
	} else {
		maxi = stateinfo->GetMixNum() - 1;
		maxprob = CalcContProbWithSafePruning(stateinfo->GetDens_pp()[maxi],  LOG_ZERO);
		i = maxi - 1;
		for (; i >= 0; i--) {
			prob = CalcContProbWithSafePruning(stateinfo->GetDens_pp()[i], maxprob);
			if (prob > maxprob) {
				maxprob = prob;
				maxi = i;
			}
		}
		*maxi_ret = maxi;
	}

	return(LOGPROB ) ((maxprob + stateinfo->GetBWeight(maxi)) / 2.30258509);
}

#else  /* ~LAST_BEST */

LOGPROB CJuliOutProb::ComputeGMax(CJuliHtkHmmState *stateinfo) // compute_g_max
{
	int i, maxi;
	LOGPROB prob;
	LOGPROB maxprob = LOG_ZERO;

	i = maxi = stateinfo->GetMixNum() - 1;
	for (; i >= 0; i--) {
		prob = CalcContProbWithSafePruning(stateinfo->b[i], maxprob);
		if (prob > maxprob) {
			maxprob = prob;
			maxi = i;
		}
	}
	return((maxprob + stateinfo->bweight[maxi]) / 2.30258509);
}
#endif

/**********************************************************************/
/* main function: compute all gshmm scores */
/* *** assume to be called for sequencial frame (using last result) */
void CJuliOutProb::ComputeGSScores(GS_SET *gsset, int gsset_num, LOGPROB *scores_ret) // compute_gs_scores
{
	int i;
#ifdef LAST_BEST
	int max_id;
#endif

	for (i=0;i<gsset_num;i++) {
#ifdef GS_MAX_PROB
#ifdef LAST_BEST
		/* compute only the maximum with pruning (last best first) */
		scores_ret[i] = ComputeGMax(gsset[i].state, last_max_id[i], &max_id);
		last_max_id[i] = max_id;
#else
		scores_ret[i] = ComputeGMax(gsset[i].state);
#endif /* LAST_BEST */
#else
		/* compute all mixture */
		scores_ret[i] = compute_g_base(gsset[i].state);
#endif
		/*printf("%d:%s:%f\n",i,gsset[i].book->GetName(),scores_ret[i]);*/
	}

}



/* outprob_style.c --- compute outprob according to its context dependency */

#ifdef PASS1_IWCD

void CJuliOutProb::InitStyleCache() // outprob_style_cache_init
{
	int n;
	for(n=0;n<GetWCHMM()->GetNumStates();n++) {
		if (GetWCHMM()->GetState(n).outstyle == AS_RSET) {
			(GetWCHMM()->GetState(n).out.rset)->cache.state = NULL;
		} else if (GetWCHMM()->GetState(n).outstyle == AS_LRSET) {
			(GetWCHMM()->GetState(n).out.lrset)->cache.state = NULL;
		}
	}
}

#ifdef CATEGORY_TREE
/*
* �J�e�S��ID�t�� lcd_set �����
*
* �P��I�[�� lcd_set���͒ʏ�� "a-k" �ƈقȂ� "a-k::38" �ƂȂ�(�J�e�S��ID�t�^)
* ���o�^�̏ꍇ, �㑱�\�ȃJ�e�S�����̒P��̐擪���f�����X�g�A�b�v���C
* ����Ƃ� triphone �� lcd_set �Ƃ��Ēǉ�����D
*
* pseudo phone �ƕ��p���̓���͖��`�F�b�N
*
*/
CD_Set * CJuliOutProb::RegisterLcdsetWithCategory(HTK_HMM_INFO *hmminfo, HMM_Logical *hmm, WORD_ID category) // lcdset_register_with_category
{
	CD_Set *ret;
	WORD_ID c2, i, w;
	HMM_Logical *ltmp;

	int cnt_c, cnt_w, cnt_p;

	leftcenter_name(hmm->GetName(), lccbuf);
	sprintf(lccbuf2, "%s::%04d", lccbuf, category);
	if ((ret = cdset_lookup(hmminfo, lccbuf2)) == NULL) {
		if (theOpt.debug2_flag) {
			j_printf("category-aware lcdset {%s}...", lccbuf2);
		}
		cnt_c = cnt_w = cnt_p = 0;
		for(c2=0;c2<dfa.term_num;c2++) {
			if (!dfa.cp[category][c2]) continue;
			for(i=0;i<dfa.term.wnum[c2];i++) {
				w = dfa.term.tw[c2][i];
				ltmp = get_right_context_HMM(hmm, GetDict()->wseq[w][0]->GetName(), hmminfo);
				if (ltmp == NULL) {
					ltmp = hmm;
					if (ltmp->IsPseudo()) {
						error_missing_right_triphone(hmm, GetDict()->wseq[w][0]->GetName());
					}
				}
				if (! ltmp->IsPseudo()) {
					if (regist_cdset(hmminfo, ltmp->body.defined, lccbuf2)) {
						cnt_p++;
					}
				}
			}
			cnt_c++;
			cnt_w += dfa.term.wnum[c2];
		}
		if (theOpt.debug2_flag) {
			j_printf("%d categories (%d words) can follow, %d HMMs registered\n", cnt_c, cnt_w, cnt_p);
		}
	}
	return(ret);
}

/* �J�e�S��ID�t�� lcd_set �ւ̃|�C���^��Ԃ� */
/* ������Ȃ����NULL��Ԃ� */
CD_Set *CJuliOutProb::LookupLcdsetWithCategory(HTK_HMM_INFO *hmminfo, HMM_Logical *hmm, WORD_ID category) // lcdset_lookup_with_category
{
	leftcenter_name(hmm->GetName(), lccbuf);
	sprintf(lccbuf2, "%s::%04d", lccbuf, category);
	return(cdset_lookup(hmminfo, lccbuf2));
}

/* �S�ẴJ�e�S��ID�t�� lcd_set ���쐬 */
void CJuliOutProb::RegisterLcdsetWithCategoryAll() // lcdset_register_with_category_all
{
	WORD_ID c1, w, w_prev;
	int i;
	HMM_Logical *ltmp;

	/* (1) �P��I�[�̉��f�ɂ��� */
	for(w=0;w<GetDict()->num;w++) {
		ltmp = GetDict()->wseq[w][GetDict()->wlen[w]-1];
		lcdset_register_with_category(&hmminfo, ltmp, GetDict()->wton[w]);
	}
	/*  (2)�P���f�P��̏ꍇ, ��s������P��̏I�[���f���l������
	lcd_set ����� */
	for(w=0;w<GetDict()->num;w++) {
		if (GetDict()->wlen[w] > 1) continue;
		for(c1=0;c1<dfa.term_num;c1++) {
			if (!dfa.cp[c1][GetDict()->wton[w]]) continue;
			for(i=0;i<dfa.term.wnum[c1];i++) {
				w_prev = dfa.term.tw[c1][i];
				ltmp = get_left_context_HMM(GetDict()->wseq[w][0], GetDict()->wseq[w_prev][GetDict()->wlen[w_prev]-1]->GetName(), &hmminfo);
				if (ltmp == NULL) continue; /* 1���f���g��lcd_set��(1)�ō쐬�� */
				if (ltmp->IsPseudo()) continue; /* pseudo phone �Ȃ�lcd_set�͂���Ȃ� */
				lcdset_register_with_category(&hmminfo, ltmp, GetDict()->wton[w]);
			}
		}
	}
}
#endif

/* outstyle ���ƂɈقȂ�v�Z���@���g�� */
LOGPROB CJuliOutProb::CalcOutProbStyle(int node, int last_wid, int t, CJuliHtkParam *param) // outprob_style
{
	const CJuliHtkHmmLogical *ohmm, *rhmm;
	RC_INFO *rset;
	LRC_INFO *lrset;
	const CD_Set *lcd;

	switch(GetWCHMM()->GetState(node).outstyle) {
	case AS_STATE:		/* normal state */
		return(CalcOutProbState(t, GetWCHMM()->GetState(node).out.state, param));
	case AS_LSET:			/* end of word */
		return(CalcOutProbCd(t, GetWCHMM()->GetState(node).out.lset, param));
	case AS_RSET:			/* beginning of word */
		rset = GetWCHMM()->GetState(node).out.rset;
		if (rset->lastwid_cache != last_wid || rset->cache.state == NULL) {
			/* cache miss...calculate */
			if (last_wid != WORD_INVALID) {
				/* lookup triphone with left-context (= last phoneme) */
				if ((ohmm = GetHmm()->GetLeftContextHMM(rset->hmm, (GetDict()->GetWordSeq(last_wid)[GetDict()->GetWordLen(last_wid)-1])->GetName())) != NULL) {
					rhmm = ohmm;
				} else {
					/* ���� bi-phone �� fallback, defined �łȂ���΃G���[ */
					rhmm = rset->hmm;
					if (rhmm->IsPseudo()) {
						ErrorMissingLeftTriphone(rset->hmm, (GetDict()->GetWordSeq(last_wid)[GetDict()->GetWordLen(last_wid)-1])->GetName());
					}
				}
			} else {
				/* ���� bi-phone �� fallback, defined �łȂ���΃G���[ */
				rhmm = rset->hmm;
				if (rhmm->IsPseudo()) {
					ErrorMissingLeftTriphone(rset->hmm, (GetDict()->GetWordSeq(last_wid)[GetDict()->GetWordLen(last_wid)-1])->GetName());
				}
			}
			/* rhmm may be a pseudo phone (when last_wid is WORD_INVALID) */
			/* store to cache */
			if (rhmm->IsPseudo()) {
				rset->last_is_lset  = TRUE;
				rset->cache.lset    = &(rhmm->GetPseudo()->stateset[rset->state_loc]);
			} else {
				rset->last_is_lset  = FALSE;
				rset->cache.state   = rhmm->GetPhysicalHmm()->GetState(rset->state_loc);
			}
			rset->lastwid_cache = last_wid;
		}
		if (rset->last_is_lset) {
			return(CalcOutProbCd(t, rset->cache.lset, param));
		} else {
			return(CalcOutProbState(t, rset->cache.state, param));
		}
	case AS_LRSET:		/* 1 phoneme --- beggining and end */
		lrset = GetWCHMM()->GetState(node).out.lrset;
		if (lrset->lastwid_cache != last_wid || lrset->cache.state == NULL) {
			/* cache miss...calculate */
			rhmm = lrset->hmm;
			strcpy(rbuf, rhmm->GetName());
			if (last_wid != WORD_INVALID) {
				CJuliUtil::AddLeftContext(rbuf, (GetDict()->GetWordSeq(last_wid)[GetDict()->GetWordLen(last_wid)-1])->GetName());
			}
			/* lookup lcdset for given left-context (= last phoneme) */
#ifdef CATEGORY_TREE
			if (!old_iwcd_flag) {
				if (last_wid != WORD_INVALID &&
					(ohmm = get_left_context_HMM(rhmm, (GetDict()->GetWordSeq(last_wid)[GetDict()->GetWordLen(last_wid)-1])->GetName(), &hmminfo)) != NULL) {
						lcd = lcdset_lookup_with_category(GetHmm(), ohmm, lrset->category);
					} else {
						lcd = lcdset_lookup_with_category(GetHmm(), rhmm, lrset->category);
					}
			} else {
				lcd = GetHmm()->GetCDSetInfo_const()->LookupLCDSetByHmmname(rbuf);
			}
#else
			lcd = GetHmm()->GetCDSetInfo_const()->LookupLCDSetByHmmname(rbuf);
#endif /* CATEGORY_TREE */
			if (lcd != NULL) {
				lrset->last_is_lset  = TRUE;
				lrset->cache.lset    = &(lcd->stateset[lrset->state_loc]);
				lrset->lastwid_cache = last_wid;
			} else {
				/* no relating lcdset found, falling to normal state */
				if (rhmm->IsPseudo()) {
					lrset->last_is_lset  = TRUE;
					lrset->cache.lset    = &(rhmm->GetPseudo()->stateset[lrset->state_loc]);
					lrset->lastwid_cache = last_wid;
				} else {
					lrset->last_is_lset  = FALSE;
					lrset->cache.state   = rhmm->GetPhysicalHmm()->GetState(lrset->state_loc);
					lrset->lastwid_cache = last_wid;
				}
			}
			/*printf("[%s->%s]\n", lrset->hmm->GetName(), rhmm->GetName());*/
		}
		if (lrset->last_is_lset) {
			return(CalcOutProbCd(t, lrset->cache.lset, param));
		} else {
			return(CalcOutProbState(t, lrset->cache.state, param));
		}
	default:
		/* should not happen */
		J_ERROR("no outprob style??\n");
		return(LOG_ZERO);
	}
}

#else  /* ~PASS1_IWCD */

LOGPROB CJuliOutProb::CalcOutProbStyle(int node, int last_wid, int t, HTK_Param *param) // outprob_style
{
	return(CalcOutProbState(t, GetWCHMM()->GetState(node).out, param));
}

#endif /* PASS1_IWCD */


/* called when no IW-triphone found (and no bi/mono-phone specified in HMMList)  */
void CJuliOutProb::ErrorMissingRightTriphone(const CJuliHtkHmmLogical *base, const char *rc_name) // error_missing_right_triphone
{
	/* only output message */
	strcpy(rbuf, base->GetName());
	CJuliUtil::AddRightContext(rbuf, rc_name);
	J_ERROR("Error: IW-triphone \"%s\" not found, fallback to pseudo {%s}\n", rbuf, base->GetName());
}

void CJuliOutProb::ErrorMissingLeftTriphone(const CJuliHtkHmmLogical *base, const char *lc_name) // error_missing_left_triphone
{
	/* only output message */
	strcpy(rbuf, base->GetName());
	CJuliUtil::AddLeftContext(rbuf, lc_name);
	J_ERROR("Error: IW-triphone \"%s\" not found, fallback to pseudo {%s}\n", rbuf, base->GetName());
}


