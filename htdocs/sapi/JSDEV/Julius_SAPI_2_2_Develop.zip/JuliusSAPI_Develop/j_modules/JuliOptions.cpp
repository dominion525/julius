//====================================================================
// JuliOptions.cpp: �R���e�L�X�g�Ɉˑ�����I�v�V����
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "JuliOptions.h"
#include "JuliOutProb.h"

CJuliOptions::CJuliOptions()
{
	Clear();
}

CJuliOptions::~CJuliOptions()
{
	
}

#if 0

/* m_chkparam.c --- check parameter and set default if needed */

/* argument check */
void
check_specs()  /* set parameters which was not explicitly specified */
{
	boolean ok_p;
	
	VERMES("###### check configurations\n");
	
	/* check files */
	ok_p = TRUE;
	if (hmmfilename == NULL) {
		j_printerr("Error: needs HMM definition file (-h hmmdef_file)\n");
		ok_p = FALSE;
	}
	if (dictfilename == NULL) {
		j_printerr("Error: needs dictionary file (-v dict_file)\n");
		ok_p = FALSE;
	}
#ifdef USE_NGRAM
	/* only LR 2-gram specified .... calculate only 1-pass */
	/* only RL 3-gram specified .... ERROR */
	if (ngram_filename == NULL) {
		if (ngram_filename_lr_arpa == NULL && ngram_filename_rl_arpa == NULL) {
			j_printerr("Error: needs word n-gram file (-d bingram | -nlr ARPA_2gram -nrl ARPA_r3gram)\n");
			ok_p = FALSE;
		} else if (ngram_filename_lr_arpa == NULL) {
			j_printerr("Error: also needs ARPA 2-gram file (-nlr ARPA_2gram_file)\n");
			ok_p = FALSE;
		} else if (ngram_filename_rl_arpa == NULL) {
			compute_only_1pass = TRUE;
		}
	}
#endif  /* USE_NGRAM */
#ifdef USE_DFA
	if (dfa_filename == NULL) {
		j_printerr("Error: needs DFA grammar file (-dfa dfa_file)\n");
		ok_p = FALSE;
	}
#endif
	
	/* path check */
	if (hmmfilename != NULL) checkpath(hmmfilename);
	if (mapfilename != NULL) checkpath(mapfilename);
	if (dictfilename != NULL) checkpath(dictfilename);
#ifdef USE_NGRAM
	if (ngram_filename != NULL) checkpath(ngram_filename);
	if (ngram_filename_lr_arpa != NULL) checkpath(ngram_filename_lr_arpa);
	if (ngram_filename_rl_arpa != NULL) checkpath(ngram_filename_rl_arpa);
#ifdef CLASS_NGRAM
	if (class_bingram_file != NULL) checkpath(class_bingram_file);
#endif
#endif  /* USE_NGRAM */
#ifdef USE_DFA
	if (dfa_filename != NULL) checkpath(dfa_filename);
#endif
	if (hmm_gs_filename != NULL) checkpath(hmm_gs_filename);
	if (inputlist_filename != NULL) checkpath(inputlist_filename);
	
	/* check input mode */
	if (force_realtime_flag) {
		if (speech_input == SP_MFCFILE) {
			j_printerr("Warning: realtime decoding of mfcfile is not supported yet\n");
			j_printerr("Warning: -realtime turned off\n");
			realtime_flag = FALSE;
		} else {
			realtime_flag = forced_realtime;
		}
	} else {
		if (speech_input == SP_RAWFILE || speech_input == SP_MFCFILE || speech_input == SP_ADINNET) {
			realtime_flag = FALSE;
		} else {
			realtime_flag = TRUE;
		}
	}
	
	if (trellis_beam_width == 0) {
		VERMES("doing full search\n");
		VERMES("Warning: no routine for full search. use beam routine with full beam width\n");
		VERMES("Warning: this will be extremely slow\n");
		trellis_beam_width = wchmm.n;
	}
	
	if (!ok_p) {
		j_error("check spec failed\n");            /* exit on error */
	}
}

/************* set default params according to the models ************/

/* return default beam width */
/* these defaults are originally determined for IPA models */
static int
default_width()
{
	if (strmatch(SETUP, "fast")) { /* for fast setup */
		if (hmminfo.is_triphone) {
			if (hmminfo.is_tied_mixture) {
				/* tied-mixture triphones (PTM etc.) */
				return(600);
			} else {
				/* shared-state triphone */
#ifdef PASS1_IWCD
				return(800);
#else
				/* v2.1 compliant (no IWCD on 1st pass) */
				return(1000);		
#endif
			}
		} else {
			/* monophone */
			return(400);
		}
	} else {			/* for standard / v2.1 setup */
		if (hmminfo.is_triphone) {
			if (hmminfo.is_tied_mixture) {
				/* tied-mixture triphones (PTM etc.) */
				return(800);
			} else {
				/* shared-state triphone */
#ifdef PASS1_IWCD
				return(1500);
#else
				return(1500);		/* v2.1 compliant (no IWCD on 1st pass) */
#endif
			}
		} else {
			/* monophone */
			return(700);
		}
	}
}

/* set beam width automatically */
/* called when not specified */
void
set_beam_width()
{
	int standard_width;
	if (trellis_beam_width == 0) {
		VERMES("doing full search\n");
		VERMES("Warning: no routine for full search. use beam routine with full beam width\n");
		VERMES("Warning: this will be extremely slow\n");
		trellis_beam_width = wchmm.n;
	} else {
		standard_width = default_width();
		trellis_beam_width = sqrt(winfo.num) * 15;
		if (trellis_beam_width > standard_width) trellis_beam_width = standard_width;
	}
}

#ifdef USE_NGRAM
/* set default LM weight and penalty */
/* called when not specified */
void
set_lm_weight()
{
	if (hmminfo.is_triphone) {
#ifdef PASS1_IWCD
		lm_weight = 8.0;
		lm_penalty = -2.0;
#else
		lm_weight = 9.0;
		lm_penalty = 8.0;
#endif
	} else {
		lm_weight = 5.0;
		lm_penalty = -1.0;
	}
}
void
set_lm_weight2()
{
	if (hmminfo.is_triphone) {
#ifdef PASS1_IWCD
		lm_weight2 = 8.0;
		lm_penalty2 = -2.0;
#else  /* no IWCD on 1st pass */
		lm_weight2 = 11.0;
		lm_penalty2 = -2.0;
#endif /* PASS1_IWCD */
	} else {
		lm_weight2 = 6.0;
		lm_penalty2 = 0.0;
	}
}

#endif /* USE_NGRAM */


#endif

void CJuliOptions::Clear()
{
	m_strNgramFile = "";
	m_strNgramArpaLRFile = "";
	m_strNgramArpaRLFile = "";
	m_strDictFile = "";
	
#ifdef USE_NGRAM
	//	ngram_filename_lr_arpa = NULL;
	//	ngram_filename_rl_arpa = NULL;
	lmp_specified = FALSE; /* true if -lmp explicitly specified */
	lmp2_specified = FALSE; /* true if -lmp2 explicitly specified */
	lm_penalty_trans = 0.0; /* insertion penalty for transparent word */
#ifdef CLASS_NGRAM
	class_bingram_file = NULL;
	class_weight = 1.0;
#endif
#endif  /* USE_NGRAM */
#ifdef USE_DFA
	dfa_filename = NULL; /* dfa file */
	penalty1 = 0.0;
	penalty2 = 0.0;
#endif
#ifdef USE_NGRAM
	m_strHeadSilentName = BEGIN_WORD_DEFAULT;
	m_strTailSilentName = END_WORD_DEFAULT;

	m_bUseHeadSilName = 0;
	m_bUseTailSilName = 0;
#endif  /* USE_NGRAM */
#ifdef USE_DFA
	m_strSpName = SP_NAME_DEFAULT; /* sp model name that can skip in search */
	m_strBeginSilentPhone = "silB";
	m_strEndSilentPhone = "silE";
#endif
	/* -------- search parameters ----------------------------------------- */
	trellis_beam_width = -1; /* trellis beam width */
	gprune_method = GPRUNE_SEL_UNDEF; /* Gaussian pruning method*/
	mixnum_thres = 2;	/* Gaussian pruning value */
	gs_statenum = 24;	/* GMS value */
#define DEFAULT_STACK_SIZE 500	/* default stack size for search */
	stack_size.Init(DEFAULT_STACK_SIZE); /* -s */
	hypo_overflow.Init(2000); /* -m */
	output_hypo_maxnum = 1; /* max num of hypo to output */
	enveloped_bestfirst_width.Init(30); /* -1 means no beam-lize */
	lookup_range.Init(5); /* lookup range of word expansion in 2nd pass */
#ifdef SCAN_BEAM
	scan_beam_thres.Init(80.0); /* beam threshold rate in 2nd pass */
#endif
#ifdef SEPARATE_BY_UNIGRAM
	separate_wnum = DEFAULT_SEPARATE_WNUM; /* word num from best freq. to separate from tree */
#endif
#ifdef WPAIR
# ifdef WPAIR_KEEP_NLIMIT
	wpair_keep_nlimit = 3; /* keeps only N token on wpair */
# endif
#endif
#ifdef HASH_CACHE_IW
	iw_cache_rate = 10;	/* inter-word LM cache size rate for vocabulary size */
#endif
	
//	beam_token_is_expanded = FALSE;
	
	// fast �R���p�C���̏ꍇ
//    nbest = 1;
    enveloped_bestfirst_width = 30;
	
}
