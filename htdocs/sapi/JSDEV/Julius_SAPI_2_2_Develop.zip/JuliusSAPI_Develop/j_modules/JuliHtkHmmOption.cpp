//====================================================================
// JuliHtkHmmOption.cpp: CJuliHtkHmmOption �N���X�̃C���v�������e�[�V����
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliHtkHmmOption.h"
#include "JuliHmmInfo.h"
#include "JuliUtil.h"


/* HMM options */
static OptionStr optcov[] = {	/* covariance matrix type */
  {"DIAGC", C_DIAG_C, "Diag", TRUE},
  {"INVDIAGC", C_INV_DIAG, "InvDiag", FALSE},
  {"FULLC", C_FULL, "Full", FALSE},
  {"LLTC", C_LLT, "LLT", FALSE}, /* not used in HTK V2.0 */
  {"XFORMC", C_XFORM, "Xform", FALSE},  /* not used in HTK V2.0 */
  {NULL,0,NULL,FALSE}
};
static OptionStr optdur[] = {	/* duration types */
  {"NULLD", D_NULL, "Null", TRUE},
  {"POISSOND", D_POISSON, "Poisson", FALSE},
  {"GAMMAD", D_GAMMA, "Gamma", FALSE},
  {"GEND", D_GEN, "Gen", FALSE},
  {NULL,0,NULL,FALSE}
};

CJuliHtkHmmOption::CJuliHtkHmmOption()
{
	stream_info.num = 1;
	cov_type = C_DIAG_C;
	dur_type = D_NULL;
}

CJuliHtkHmmOption::~CJuliHtkHmmOption()
{
	
}

void CJuliHtkHmmOption::ReadFromFile(CJuliFile &file) // read_global_opt
{
	int i;
	short tmptype;
	for (;;)
	{
		if (file.CurrentToken() == NULL) return;
		if (file.CurrentTokenIs("HMMSETID")) { /* <HMMSETID> */
			file.GetHmmToken();
			file.NoTokenError("missing HMMSETID argument");
		} else if (file.CurrentTokenIs("STREAMINFO")) { /* <STREAMINFO> */
			file.GetHmmToken();
			file.NoTokenError("missing STREAMINFO num");
			stream_info.num = atoi(file.CurrentToken());
			/*DM("%d STREAMs:", stream_info.num);*/
			if (stream_info.num > 50) {
				J_ERROR("stream num exceeded %d\n", 50);
				file.HmmError(NULL);
			}
			for (i=0;i<stream_info.num;i++) {
				file.GetHmmToken();
				file.NoTokenError("missing STREAMINFO vector size");
				stream_info.vsize[i] = atoi(file.CurrentToken());
				/*DM(" %d",stream_info.vsize[i]);*/
			}
			/*DM("\n");*/
			
		} else if (file.CurrentTokenIs("VECSIZE")) {	/* <VECSIZE> */
			file.GetHmmToken();
			file.NoTokenError("missing VECSIZE value");
			vec_size = atoi(file.CurrentToken());
			/*DM("vector size: %d\n", vec_size);*/
			
		} else {
			/* covariance matrix type */
			for (i=0;optcov[i].name!=NULL;i++) {
				if (file.CurrentTokenIs(optcov[i].name)) {
					cov_type = optcov[i].type;
					/*DM("covariance matrix type: %s\n", optcov[i].desc);*/
					goto optloop;
				}
			}
			/* duration type */
			for (i=0;optdur[i].name!=NULL;i++) {
				if (file.CurrentTokenIs(optdur[i].name)) {
					dur_type = optdur[i].type;
					/*DM("duration type: %s\n", optdur[i].desc);*/
					goto optloop;
				}
			}
			/* parameter type */
			tmptype = CJuliUtil::GetCodeFromStr(file.CurrentToken());
			if (tmptype != F_ERR_INVALID) { /* conv success */
				param_type = tmptype;
				/*DM("param type: %s", param_code2str(buf, param_type, FALSE));*/
				goto optloop;
			} else {
				/* nothing of above --- not option */
				return;
			}
		}
optloop:
		file.GetHmmToken();
	}
}

/* check if J can handle the type */
boolean CJuliHtkHmmOption::CheckHmmOptions() // check_hmm_options
{
	boolean ret_flag = TRUE;
	
	if (stream_info.num > 1) {
		J_ERROR("ERROR: Input stream must be single\n");
		ret_flag = FALSE;
	}
	if (dur_type != D_NULL) {
		J_ERROR("ERROR: Duration not supported.\n");
		ret_flag = FALSE;
	}
	if (cov_type != C_DIAG_C) {
		J_ERROR("ERROR: Covariance matrix type must be DIAGC, others not supported.\n");
		ret_flag = FALSE;
	}
	return(ret_flag);
}

/* check compatibility of param type for HMM and Param */
boolean CJuliHtkHmmOption::CheckParamCoherence(CJuliHtkParam *pinfo) // check_param_coherence
{
	boolean ret_flag;
	ret_flag = TRUE;
	if (param_type
		!= (pinfo->header.samptype & ~(F_COMPRESS | F_CHECKSUM))) {
		/* 
		*     J_ERROR("ERROR: incompatible parameter type\n");
		*     j_printf("HMM trained by %s\n", param_code2str(buf, param_type, FALSE));
		*     j_printf("input parameter is %s\n", param_code2str(buf, pinfo->header.samptype, FALSE));
		*/
		ret_flag = FALSE;
	}
	/* vector length check */
	if (vec_size != pinfo->veclen) {
	/* 
	*     J_ERROR("ERROR: vector length differ.\n");
	*     J_ERROR("HMM=%d, param=%d\n", vec_size, pinfo->veclen);
		*/
		ret_flag = FALSE;
	}
	
	return(ret_flag);
}

boolean CJuliHtkHmmOption::CheckParamBaseType(CJuliHtkParam *pinfo) // check_param_basetype
{
	if ((param_type & F_BASEMASK) != (pinfo->header.samptype & F_BASEMASK))
	{
		return FALSE;
	} else {
		return TRUE;
	}
} 
