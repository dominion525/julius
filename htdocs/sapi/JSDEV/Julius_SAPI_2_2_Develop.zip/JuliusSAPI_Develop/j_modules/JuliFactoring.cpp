//====================================================================
// JuliFactoring.cpp: 
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliDefines.h"
#include "JuliWordConjHmm.h"
#include "JuliFactoring.h"
#include "JuliGramNGram.h"
#include "JuliGramDfa.h"
#include "JuliGlobalOption.h"

CJuliFactoring::CJuliFactoring()
#ifdef CLASS_NGRAM
: wtoc(NULL), c_probsum(NULL), wtoc_prob(NULL)
#endif
{
}

CJuliFactoring::~CJuliFactoring()
{
#ifdef CLASS_NGRAM
    J_BFREE(wtoc);
    J_BFREE(c_probsum);
    J_BFREE(wtoc_prob);
#endif

//	FreeMaxSuccessorCache();	// TODO: ���܂�������Ă���Ȃ�
}

/* factoring_sub.c --- subroutines for factoring */

#ifndef CATEGORY_TREE		/* �J�e�S���P�ʂ̃c���[��factoring�@�\�K�v�Ȃ� */



/*----------------------------------------------------------------------*/
/* ��Ԃ��ƂɁC���� successor word �̃��X�g��^���� */
/* sc->word �� N-gram�P��ԍ� */
/* �����ɕۑ����� */
void CJuliFactoring::AddSuccessor(int node, WORD_ID w) // add_successor
{
	S_CELL *sctmp, *sc;
	
	sctmp=(S_CELL *) J_MALLOC(sizeof(S_CELL));	// TODO: leak!
	if (sctmp == NULL) {
		J_ERROR("malloc fault at add_succesor(%d,%d)\n",node,w);
	}
	sctmp->word = GetDict()->GetWordID(w);
	
	sc = GetWCHMM()->GetState(node).sc;
	if (sc == NULL || sctmp->word < sc->word) {
		sctmp->next = sc;
		GetWCHMM()->GetStateP(node)->sc = sctmp;
	} else {
		for(;sc;sc=sc->next) {
			if (sc->next == NULL || sctmp->word < (sc->next)->word) {
				if (sctmp->word == sc->word) break; /* 2�d�o�^��� */
				sctmp->next = sc->next;
				sc->next = sctmp;
				break;
			}
		}
	}
}

boolean CJuliFactoring::MatchSuccessor(int node1, int node2) // match_successor
{
	S_CELL *sc1,*sc2;
	
	/* successor�͏����Ɋi�[����Ă�͂� */
	sc1 = GetWCHMM()->GetState(node1).sc;
	sc2 = GetWCHMM()->GetState(node2).sc;
	for (;;) {
		if (sc1 == NULL || sc2 == NULL) {
			if (sc1 == NULL && sc2 == NULL) {
				return TRUE;
			} else {
				return FALSE;
			}
		} else if (sc1->word != sc2->word) {
			return FALSE;
		}
		sc1 = sc1->next;
		sc2 = sc2->next;
	}
}

void CJuliFactoring::FreeSuccessor(int node) // free_successor
{
	S_CELL *sc;
	S_CELL *sctmp;
	
	sc = GetWCHMM()->GetState(node).sc;
	while (sc != NULL) {
		sctmp = sc;
		sc = sc->next;
		J_FREE(sctmp);
	}
	GetWCHMM()->GetStateP(node)->sc = NULL;
}

void CJuliFactoring::MakeSuccessorList() // make_successor_list
{
	int node;
	WORD_ID w;
	int i;
	int freed_num = 0;
	boolean *freemark;
	
	J_VERMES("  make successor lists for factoring...");
	
	/* ������ */
	freemark = (boolean *)J_MALLOC(sizeof(boolean) * GetWCHMM()->GetNumStates());
	for (node=0;node<GetWCHMM()->GetNumStates();node++) {
		GetWCHMM()->GetStateP(node)->sc = NULL;
		freemark[node] = FALSE;
	}
	
	/* successor list ���\�z */
	for (w=0;w<GetDict()->GetNumWords();w++) {
		/* �e���f�̍ŏ���node�ɂ��� */
		for (i=0;i<GetDict()->GetWordLen(w);i++) {
			AddSuccessor(GetWCHMM()->GetOffset(w,i), w);
		}
		/* �P��̏I�[��Ԃɑ΂��� */
		AddSuccessor(GetWCHMM()->GetWordEnd(w), w);
	}
	
	/* ����_(=successor�̕ς���)�̂ݎc�� */
	/* �A���S���Y��: �؂̑S�Ẵ��[�t���炽�ǂ�C
	*   1)�e�Ǝ�����successor_list���r���C
	*          �����Ȃ�C�����̂������}�[�N������D
	*          �Ⴆ�΁C���̂܂܁D
	*/
	for (w=0;w<GetDict()->GetNumWords();w++) {
		node = GetWCHMM()->GetWordEnd(w);	/* �P��̏I�[��Ԃ���X�^�[�g */
		i = GetDict()->GetWordLen(w)-1;
		while (i >= 0) {
		if (node == GetWCHMM()->GetOffset(w,i)) {	/* ��Ԑ�=1�̉��f�́C
											GetWCHMM()->wordend[word] ==
											GetWCHMM()->offset[word][�Ō�̉��f]
			�Ȃ̂ŁC�p�X */
			i--;
			continue;
		}
		if (MatchSuccessor(node, GetWCHMM()->GetOffset(w,i))) {
			freemark[node] = TRUE;
		}
		/* 
		*	 if (freemark[GetWCHMM()->GetOffset(w,i)] != FALSE) {
		*	   break;
		*	 }
		*/
		node = GetWCHMM()->GetOffset(w,i);
		i--;
		}
	}
	for (node=0;node<GetWCHMM()->GetNumStates();node++) {
		if (freemark[node] == TRUE) {
			freed_num++;
			FreeSuccessor(node);
		}
	}
	
	if (theOpt.debug2_flag) {
		J_MESSAGE("%d freed...", freed_num);
	}
	
	J_FREE(freemark);
	
	J_VERMES("done\n");
}


/* -------------------------------------------------------------------- */
/* factoring �̎��s */

#ifdef USE_NGRAM


/* �L���b�V���̈�̊m�� */
void CJuliFactoring::InitMaxSuccessorCache() // max_successor_cache_init
{
	int i;
	
	probcache = (LOGPROB *) J_MALLOC(sizeof(LOGPROB) * GetWCHMM()->GetScNum());
	lastwcache = (WORD_ID *) J_MALLOC(sizeof(WORD_ID) * GetWCHMM()->GetScNum());
	for (i=0;i<GetWCHMM()->GetScNum();i++) {
		lastwcache[i] = WORD_INVALID;
	}
#ifdef HASH_CACHE_IW
# ifdef CLASS_NGRAM
	iw_cache_num = true_max_num * iw_cache_rate / 100;
# else
	iw_cache_num = ngram.max_word_num * iw_cache_rate / 100;
# endif
	if (iw_cache_num < 10) iw_cache_num = 10;
#else
# ifdef CLASS_NGRAM
	iw_cache_num = true_max_num;
# else
	iw_cache_num = GetGramNgram()->GetMaxWordNum();
#endif
#endif /* HASH_CACHE_IW */
	iw_sc_cache = (LOGPROB **)J_MALLOC(sizeof(LOGPROB *) * iw_cache_num);
	for (i=0;i<iw_cache_num;i++) {
		iw_sc_cache[i] = NULL;
	}
#ifdef HASH_CACHE_IW
	iw_lw_cache = (WORD_ID *)J_MALLOC(sizeof(WORD_ID) * iw_cache_num);
	for (i=0;i<iw_cache_num;i++) {
		iw_lw_cache[i] = WORD_INVALID;
	}
#endif
}

/* .$BC18l4V.(BLM.$B%-%c%C%7%e$r2rJ|.(B */
void CJuliFactoring::FreeMaxSuccessorProbIw() // max_successor_prob_iw_free
{
	int i;
	for (i=0;i<iw_cache_num;i++) {
		if (iw_sc_cache[i] != NULL) J_FREE(iw_sc_cache[i]);
		iw_sc_cache[i] = NULL;
	}
}

/* .$B%-%c%C%7%eNN0h$N2rJ|.(B */
void CJuliFactoring::FreeMaxSuccessorCache() // max_successor_cache_free
{
	J_FREE(probcache);	probcache = NULL;
	J_FREE(lastwcache);	lastwcache = NULL;
	if (iw_sc_cache != NULL)
	{
		FreeMaxSuccessorProbIw();
		J_FREE(iw_sc_cache);	iw_sc_cache = NULL;
	}
#ifdef HASH_CACHE_IW
	J_FREE(iw_lw_cache);	iw_lw_cache = NULL;
#endif
}

#ifdef UNIGRAM_FACTORING

/* 1-gram factoring�p: */
/* �e�m�[�h�� 1-gram factoring�l�i�Œ�j���v�Z���Ċi�[���� */
/* �T���O�Ɉ�x�ǂ�ł����΂悢 */
/* �܂��C���[�ȊO��sc�͕K�v�Ȃ��̂Ńt���[���� */
void CJuliFactoring::CalcAllUnigramFactoringValues() // calc_all_unigram_factoring_values
{
	S_CELL *sc, *sctmp;
	LOGPROB tmpprob, maxprob;
	int n;
	
	for (n=0;n<GetWCHMM()->GetNumStates();n++) {
		GetWCHMM()->GetStateP(n)->fscore = LOG_ZERO;
		sc = GetWCHMM()->GetState(n).sc;
		if (sc != NULL) {
			if (sc->next == NULL) {
				/* ���[ ... �̂��� */
			} else {
				/* 1-gram��max�l���v�Z */
				/* fscore�Ɋi�[��Csc����� */
				maxprob = LOG_ZERO;
				for (sctmp = sc; sctmp; sctmp = sctmp->next) {
#ifdef CLASS_NGRAM
					tmpprob = ClassUniProb(sctmp->word);
#else
					tmpprob = GetGramNgram()->UniProb(sctmp->word);
#endif
					if (maxprob < tmpprob) maxprob = tmpprob;
				}
				GetWCHMM()->GetStateP(n)->fscore = maxprob;
				FreeSuccessor(n);
			}
		}
	}
}
/* fscore\SC   != NULL   == NULL */
/* !=LOG_ZERO   1-gram    1-gram */
/* ==LOG_ZERO   2-gram      ---  */

#else  /* ~UNIGRAM_FACTORING */

/* �m�[�h�ɑΉ����� 2-gram factoring�l��Ԃ� */
LOGPROB CJuliFactoring::CalcSuccessorProb(WORD_ID last_nword, int node) // calc_successor_prob
{
	S_CELL *sc;
	LOGPROB tmpprob, maxprob;
	
	maxprob = LOG_ZERO;
	for (sc = GetWCHMM()->GetState(node).sc; sc; sc = sc->next) {
#ifdef CLASS_NGRAM
		tmpprob = ClassBiProbLR(last_nword, sc->word);
#else
		tmpprob = GetGramNgram()->BiProb_LR(last_nword, sc->word);
#endif
		if (maxprob < tmpprob) maxprob = tmpprob;
	}
	return(maxprob);
}

#endif  /* ~UNIGRAM_FACTORING */

/* �m�[�h�ɑΉ�����factoring�l��Ԃ�(�P���) */
LOGPROB CJuliFactoring::MaxSuccessorProb(WORD_ID lastword, int node) // max_successor_prob
{
	LOGPROB maxprob;
	WORD_ID last_nword;
	int scid;
	
	if (lastword != WORD_INVALID) { /* return nothing */
		last_nword = GetDict()->GetWordID(lastword);
#ifdef UNIGRAM_FACTORING
		if (GetWCHMM()->GetState(node).fscore != LOG_ZERO) {
			/* return 1-gram factoring value already calced */
			return(GetWCHMM()->GetState(node).fscore);
		} else {
			scid = GetWCHMM()->GetState2ScID(node);
			/* return precise 2-gram score */
			if (last_nword != lastwcache[scid]) {
				/* calc and cache */
#ifdef CLASS_NGRAM
				maxprob = ClassBiProbLR(last_nword, (GetWCHMM()->GetState(node).sc)->word);
#else
				maxprob = GetGramNgram()->BiProb_LR(last_nword, (GetWCHMM()->GetState(node).sc)->word);
#endif
				lastwcache[scid] = last_nword;
				probcache[scid] = maxprob;
				return(maxprob);
			} else {
				/* return cached */
				return (probcache[scid]);
			}
		}
#else  /* UNIGRAM_FACTORING */
		/* 2-gram */
		scid = GetWCHMM()->GetState2ScID(node);
		if (last_nword != lastwcache[scid]) {
			maxprob = CalcSuccessorProb(last_nword, node);
			/* store to cache */
			lastwcache[scid] = last_nword;
			probcache[scid] = maxprob;
			return(maxprob);
		} else {
			return (probcache[scid]);
		}
#endif /* UNIGRAM_FACTORING */
	} else {
		return(0.0);
#if 0
		maxprob = LOG_ZERO;
		for (sc=GetWCHMM()->GetState(node).sc;sc;sc=sc->next) {
			tmpprob = uni_prob(&ngram, sc->word);
			if (maxprob < tmpprob) maxprob = tmpprob;
		}
		return(maxprob);
#endif
	}
	
}

/* �m�[�h�ɑΉ�����factoring�l��Ԃ�(�P���) */
/* ��Ɍv�Z���Ĕz���Ԃ� */
#ifdef HASH_CACHE_IW
#define hashid(A) A % iw_cache_limit
#endif
LOGPROB * CJuliFactoring::MaxSuccessorProbIw(WORD_ID lastword) // max_successor_prob_iw
{
	int i, j, x, node;
	int last_nword;
	
	/* lastword�̓A���S���Y����WORD_INVALID�ɂ͂Ȃ蓾�Ȃ� */
	last_nword = GetDict()->GetWordID(lastword);
#ifdef HASH_CACHE_IW
	x = hashid(last_nword);
	if (iw_lw_cache[x] == last_nword) { /* cache hit */
		return(iw_sc_cache[x]);
	}
#else  /* full cache */
	if (iw_sc_cache[last_nword] != NULL) { /* cache hit */
		return(iw_sc_cache[last_nword]);
	}
	x = last_nword;
	/* cache mis-hit, calc probs and cache new */
#endif
	
	/* allocate cache memory */
	if (iw_sc_cache[x] == NULL) {
#ifdef UNIGRAM_FACTORING
		iw_sc_cache[x] = (LOGPROB *)J_MALLOC(sizeof(LOGPROB)*GetWCHMM()->GetIsolateNum());
#else
		iw_sc_cache[x] = (LOGPROB *)J_MALLOC(sizeof(LOGPROB)*GetWCHMM()->GetStartNum());
#endif
		if (iw_sc_cache[x] == NULL) { /* malloc failed */
			/* clear existing cache, and retry */
			FreeMaxSuccessorProbIw();
			J_OUTPUT("inter-word LM cache (%dMB) rehashed\n",
				(iw_cache_num * 
#ifdef UNIGRAM_FACTORING
				GetWCHMM()->GetIsolateNum()
#else
				GetWCHMM()->GetStartNum()
#endif
				) / 1000 * sizeof(LOGPROB) / 1000);
#ifdef UNIGRAM_FACTORING
			iw_sc_cache[x] = (LOGPROB *)J_MALLOC(sizeof(LOGPROB)*GetWCHMM()->GetIsolateNum());
#else
			iw_sc_cache[x] = (LOGPROB *)J_MALLOC(sizeof(LOGPROB)*GetWCHMM()->GetStartNum());
#endif
			if (iw_sc_cache[x] == NULL) { /* malloc failed again? */
				J_ERROR("max_successor_prob_iw: cannot malloc\n");
			}
		}
	}
	
	/* calc prob for all startid */
#ifdef UNIGRAM_FACTORING
	for (j=0;j<GetWCHMM()->GetStartNum();j++) {
		i = GetWCHMM()->GetStart2Isolate(j);
		if (i == -1) continue;
		node = GetWCHMM()->GetStartNode(j);
		if (GetWCHMM()->GetState(node).fscore != LOG_ZERO) {
			/* should not be happen!!! below is just for debugging */
			J_ERROR("No!!\n");
		} else {
#ifdef CLASS_NGRAM
			iw_sc_cache[x][i] = ClassBiProbLR(last_nword, (GetWCHMM()->GetState(node).sc)->word);
#else
			iw_sc_cache[x][i] = GetGramNgram()->BiProb_LR(last_nword, (GetWCHMM()->GetState(node).sc)->word);
#endif
		}
	}
#else  /* ~UNIGRAM_FACTORING */
	for (i=0;i<GetWCHMM()->GetStartNum();i++) {
		node = GetWCHMM()->GetStartNode(i);
		iw_sc_cache[x][i] = CalcSuccessorProb(last_nword, node);
	}
#endif
#ifdef HASH_CACHE_IW
	iw_lw_cache[x] = last_nword;
#endif
	
	return(iw_sc_cache[x]);
}

#endif /* USE_NGRAM */
#ifdef USE_DFA /* USE_DFA --- �J�e�S���؂Ȃ�s�K�v */

/* in DFA, factoring equals to tree subtraction on demand */
/* sc->word��DFA�ł̓J�e�S���ԍ��ƂȂ� */
/* ����I factoring */
/* �P��̐擪�i�؂̍��m�[�h�j�����ʈ������Ȃ��i�J�e�S�����͏��Ȃ�����s�K�v�j*/
boolean CJuliFactoring::CanSucceed(WORD_ID lastword, int node) // can_succeed
{
	int lc;
	S_CELL *sc;
	
	/* �S�Đڑ��s�Ȃ�J�ڂ����Ȃ� */
	
	if (lastword == WORD_INVALID) { /* ���� */
		for (sc=GetWCHMM()->GetState(node).sc;sc;sc=sc->next) {
			if (GetGramDfa()->GetCpBegin(sc->word) == TRUE) return(TRUE);
		}
		return(FALSE);
	} else {
		lc = GetDict()->GetWordID(lastword);
		for (sc=GetWCHMM()->GetState(node).sc;sc;sc=sc->next) {
			if (GetGramDfa()->GetCp(lc, sc->word) == TRUE) return(TRUE);
		}
		return(FALSE);
	}
}

#endif /* USE_DFA */


#endif /* CATEGORY_TREE */

#ifdef CLASS_NGRAM
/*
When apply:

  if GetWordID(w) >= ngram.max_word_num; then
  GetWordID(w) - ngram.max_word_num == ID of class N-gram 
  else
  GetWordID(w) == ID of word N-gram
  
*/

#define EP 2.302585093
/* try to use class N-gram for those whose N-gram entry does not
exist in normal word N-gram */
void CJuliFactoring::MakeClassRef() // make_class_ref
{
	WORD_ID w, c;
	char *cname, *buf, *p, *q;
	int i;
	int hitcount;
	
	
	true_max_num = ngram.max_word_num;
    
	buf = (char *)J_MALLOC(4096);
	
	wtoc = (WORD_ID *)J_BMALLOC(sizeof(WORD_ID) * ngram.max_word_num);
	
	/* regist class of each words for use as context */
	hitcount = 0;
	for(w=0;w<GetDict()->GetNumWords();w++) {
		/* (1)�����P�� */
		c = ngram_lookup_word(GetGrammar(), GetDict()->wname[w]);
		if (c == WORD_INVALID) {
			/* (2)�\�L+�P��ID (�ǂݔ���) */
			if (strlen(GetDict()->wname[w]) >= 4096) {
				J_ERROR("ERROR: make_class_ref: wname len exceed 4096!!\n");
			}
			strcpy(buf,GetDict()->wname[w]);
			p = strchr(buf, '+');
			q = strrchr(buf, '+');
			if (p && q && p != q) {
				memmove(p+1,q+1,buf+strlen(GetDict()->wname[w])-q);
				c = ngram_lookup_word(GetGrammar(), buf);
			}
		}
		if (c == WORD_INVALID) {
			/* (3) �P��ID */
			strcpy(buf,GetDict()->wname[w]);
			q = strrchr(buf, '+');
			if (q) {
				c = ngram_lookup_word(GetGrammar(), q+1);
			}
		}
		if (c == WORD_INVALID) {
			/* (4) �\�L */
			p = strchr(buf, '+');
			if (p) {
				*p = '\0';
				c = ngram_lookup_word(GetGrammar(), buf);
			}
		}
		if (c == WORD_INVALID) {
			/* �M�u�A�b�v */
			/*J_MESSAGE("Warning: class N-gram entry for \"%s\" not found, use UNK class\n", GetDict()->wname[w]);*/
			c = GetGrammar()->unk_id;
		} else {
			hitcount++;
		}
#if 0
		printf("%d (ngram=%d): %s [%s] belongs to [%s]\n", w, GetDict()->GetWordID(w), ngram.wname[GetDict()->GetWordID(w)], GetDict()->wname[w], GetGrammar()->wname[c]);
#endif
		wtoc[GetDict()->GetWordID(w)] = c;
	}
	printf("%d / %d hit\n", hitcount, GetDict()->GetNumWords());
	
	/* set wtoc_prob */
	c_probsum = (LOGPROB *)J_BMALLOC(sizeof(LOGPROB)*GetGrammar()->max_word_num);
	for(i=0;i<GetGrammar()->max_word_num;i++) c_probsum[i] = 0.0;
	for(w=0;w<GetDict()->GetNumWords();w++) {
		c = wtoc[GetDict()->GetWordID(w)];
		if (c >= GetGrammar()->max_word_num) {
			J_ERROR("ERROR!!!\n");
		}
		c_probsum[c] += exp(uni_prob(&ngram, GetDict()->GetWordID(w))*EP);
	}
	for(i=0;i<GetGrammar()->max_word_num;i++) {
		if (c_probsum[i] > 0.0) c_probsum[i] = log10(c_probsum[i]);
	}
	wtoc_prob = (LOGPROB *)J_BMALLOC(sizeof(LOGPROB) * ngram.max_word_num);
	for(w=0;w<GetDict()->GetNumWords();w++) {
		c = wtoc[GetDict()->GetWordID(w)];
		wtoc_prob[GetDict()->GetWordID(w)] = uni_prob(&ngram, GetDict()->GetWordID(w)) - c_probsum[c];
	}
#if 0
	for(w=0;w<GetDict()->GetNumWords();w++) {
		printf("%f %s-%s(%s)\n", wtoc_prob[GetDict()->GetWordID(w)],GetGrammar()->wname[wtoc[GetDict()->GetWordID(w)]],ngram.wname[GetDict()->GetWordID(w)], GetDict()->wname[w]);
	}
#endif
	
	J_FREE(buf);
	
#ifndef CLASS_UNKNOWN_ONLY
	if (class_weight > 0.0) {
		class_weight_log = log10(class_weight);
	} else {
		class_weight_log = LOG_ZERO;
	}
	if (1.0 - class_weight > 0.0) {
		class_weight_inv_log = log10(1.0 - class_weight);
	} else {
		class_weight_inv_log = LOG_ZERO;
	}
#endif
}

LOGPROB CJuliFactoring::ClassUniProb(WORD_ID w) // class_uni_prob
{
#ifdef CLASS_UNKNOWN_ONLY
	LOGPROB f;
#ifdef CLASS_UNKNOWN_ONLY_SCALED
	LOGPROB scale;
	scale = - log(1.0 - exp(uni_prob(GetGrammar(),GetGrammar()->unk_id)*EP) + exp(uni_prob(&class_ngram, wtoc[GetGrammar()->unk_id])*EP))/EP ;
	if (w == GetGrammar()->unk_id) {
		f = uni_prob(&class_ngram, wtoc[w]) + wtoc_prob[w] + scale;
	} else {
		f = uni_prob(GetGrammar(), w) + scale;
	}
	return(f);
#else
	if (w == GetGrammar()->unk_id) {
		f = uni_prob(&class_ngram, wtoc[w]) + wtoc_prob[w];
	} else {
		f = uni_prob(GetGrammar(), w);
	}
	return(f);
#endif
#else
	/* linear interpolation for all (\beta = class_wright (option "-clw") */
	LOGPROB fw, fc;
	fc = uni_prob(&class_ngram, wtoc[w]) + class_weight_log + wtoc_prob[w];
	fw = uni_prob(GetGrammar(), w) + class_weight_inv_log;
	return(log(exp(fc*EP)+exp(fw*EP))/EP);
#endif
}

LOGPROB CJuliFactoring::ClassBiProbLR(WORD_ID w1, WORD_ID w2) // class_bi_prob_lr
{
#ifdef CLASS_UNKNOWN_ONLY
	LOGPROB f;
#ifdef CLASS_UNKNOWN_ONLY_SCALED
	LOGPROB scale;
	scale = - log(1.0 - exp(GetGramNgram()->BiProb_LR(GetGrammar(), w1, GetGrammar()->unk_id)*EP) + exp(GetGramNgram()->BiProb_LR(&class_ngram, wtoc[w1], wtoc[GetGrammar()->unk_id])*EP))/EP ;
	if (w2 == GetGrammar()->unk_id) {
		f = GetGramNgram()->BiProb_LR(&class_ngram, wtoc[w1], wtoc[w2]) + wtoc_prob[w2] + scale;
	} else {
		f = GetGramNgram()->BiProb_LR(GetGrammar(), w1, w2) + scale;
	}
	return(f);
#else  
	if (w2 == GetGrammar()->unk_id) {
		f = GetGramNgram()->BiProb_LR(&class_ngram, wtoc[w1], wtoc[w2]) + wtoc_prob[w2];
#if 0
		printf("[%s %s] - ", ngram.wname[w1], ngram.wname[w2]);
		printf("[%s %s %f]]\n",class_ngram.wname[wtoc[w1]], class_ngram.wname[wtoc[w2]], f);
#endif
	} else {
		f = GetGramNgram()->BiProb_LR(GetGrammar(), w1, w2);
	}
	return(f);
#endif
#else
	LOGPROB fw, fc;
	fc = GetGramNgram()->BiProb_LR(&class_ngram, wtoc[w1], wtoc[w2]) + class_weight_log + wtoc_prob[w2];
	fw = GetGramNgram()->BiProb_LR(GetGrammar(), w1, w2) + class_weight_inv_log;
	return(log(exp(fc*EP)+exp(fw*EP))/EP);
#endif
}

LOGPROB CJuliFactoring::ClassBiProbRL(WORD_ID w1, WORD_ID w2) // class_bi_prob_rl
{
#ifdef CLASS_UNKNOWN_ONLY
	LOGPROB f;
#ifdef CLASS_UNKNOWN_ONLY_SCALED
	LOGPROB scale;
	scale = - log(1.0 - exp(bi_prob_rl(GetGrammar(), GetGrammar()->unk_id, w2)*EP) + exp(bi_prob_rl(&class_ngram, wtoc[GetGrammar()->unk_id], wtoc[w2])*EP))/EP ;
	if (w1 == GetGrammar()->unk_id) {
		f = bi_prob_rl(&class_ngram, wtoc[w1], wtoc[w2]) + wtoc_prob[w1] + scale;
	} else {
		f = bi_prob_rl(GetGrammar(), w1, w2) + scale;
	}
	return(f);
#else
	if (w1 == GetGrammar()->unk_id) {
		f = bi_prob_rl(&class_ngram, wtoc[w1], wtoc[w2]) + wtoc_prob[w1];
	} else {
		f = bi_prob_rl(GetGrammar(), w1, w2);
	}
	return(f);
#endif
#else
	LOGPROB fw, fc;
	fc = bi_prob_rl(&class_ngram, wtoc[w1], wtoc[w2]) + class_weight_log + wtoc_prob[w1];
	fw = bi_prob_rl(GetGrammar(), w1, w2) + class_weight_inv_log;
	return(log(exp(fc*EP)+exp(fw*EP))/EP);
#endif
}

LOGPROB CJuliFactoring::ClassTriProbRL(WORD_ID w1, WORD_ID w2, WORD_ID w3) // class_tri_prob_rl
{
#ifdef CLASS_UNKNOWN_ONLY
	LOGPROB f;
#ifdef CLASS_UNKNOWN_ONLY_SCALED
	LOGPROB scale;
	scale = - log(1.0 - exp(tri_prob_rl(GetGrammar(), GetGrammar()->unk_id, w2, w3)*EP) + exp(tri_prob_rl(&class_ngram, wtoc[GetGrammar()->unk_id], wtoc[w2], wtoc[w3])*EP))/EP ;
	if (w1 == GetGrammar()->unk_id) {
		f = tri_prob_rl(&class_ngram, wtoc[w1], wtoc[w2], wtoc[w3]) + wtoc_prob[w1] + scale;
	} else {
		f = tri_prob_rl(GetGrammar(), w1, w2, w3) + scale;
	}
	return(f);
#else
	if (w1 == GetGrammar()->unk_id) {
		f = tri_prob_rl(&class_ngram, wtoc[w1], wtoc[w2], wtoc[w3]) + wtoc_prob[w1];
	} else {
		f = tri_prob_rl(GetGrammar(), w1, w2, w3);
	}
	return(f);
#endif
#else
	LOGPROB fw, fc;
	fc = tri_prob_rl(&class_ngram, wtoc[w1], wtoc[w2], wtoc[w3]) + class_weight_log + wtoc_prob[w1];
	fw = tri_prob_rl(GetGrammar(), w1, w2, w3) + class_weight_inv_log;
	return(log(exp(fc*EP)+exp(fw*EP))/EP);
#endif
}

#endif
