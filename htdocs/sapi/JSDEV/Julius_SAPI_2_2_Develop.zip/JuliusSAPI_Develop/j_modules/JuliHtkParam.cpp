//====================================================================
// JuliHtkParam.cpp: 
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include "JuliHtkParam.h"
#include "JuliUtil.h"
#include "JuliHmmInfo.h"

CJuliHtkParam::CJuliHtkParam()	// (new_param)
: samplenum(0), parvec(NULL), vmark(NULL)
{
}

CJuliHtkParam::~CJuliHtkParam()	// (free_param)
{
	int i;
	if (samplenum > 0)
	{
		for (i=0;i<samplenum;i++) {
			J_FREE(parvec[i]);
		}
		J_FREE(parvec);
	}
	J_FREE(vmark);
}

void CJuliHtkParam::OutputInfo() const
{
	float sec;
	sec = (float)header.samplenum * (float)header.wshift / 10000000;
	J_DEBUGMESSAGE("length: %d frames (%.2f sec.)\n", header.samplenum, sec);
}


/* paramselect.c --- select which parameter component to use */
/*                   example1: MFCC_E_D_Z (26)-> MFCC_E_D_N_Z (25)*/
/*                   example2: MFCC_E_D_A (39)-> MFCC_E_D (26) */

/*
F_ENERGY     0x0040      _E log energy coef. 
F_ENERGY_SUP 0x0080      _N (with _E) suppress absolute energy 
F_DELTA      0x0100      _D delta (first-order regression) coef. 
F_ACCL       0x0200      _A (with _D) acceleration (second-order) coef. 
F_COMPRESS   0x0400      _C compressed 
F_CEPNORM    0x0800      _Z cepstral mean normalization 
F_CHECKSUM   0x1000      _K CRC checksum added 
F_ZEROTH     0x2000      _0 (with MFCC) 0'th cepstral parameter
*/


/* selection algorithm --- mark-based: */
/* 1. initialize (=0) mark for each vector element */
/* 2. compare parameter type which is present and needed, and */
/*    mark each element which is not needed as EXCLUDE(=1) */
/* 3. allocate new parameter area and copy only NOT marked element */
/* '-DDEBUG' displays the process on stdout */

/* initialize vmark */
void CJuliHtkParam::InitMark() // init_mark
{
	int i;
	J_FREE(vmark); // �܂��͉��
	vmark = (int *)J_MALLOC(sizeof(int) * veclen);
	vlen = veclen;
	for (i=0;i<vlen;i++) {
		vmark[i] = 0;
	}
}
/* free vmark */
void CJuliHtkParam::FreeMark() // free_mark
{
	J_FREE(vmark);
	vmark = NULL;
}

/* mark part of vectors ([loc..(loc+len-1)] as exclude) */
void CJuliHtkParam::MarkExcludeVector(int loc, int len) // mark_exclude_vector
{
	int i;
	J_OUTPUT_ON_DEBUG("delmark: %d-%d\n",loc, loc+len-1);
	for (i=0;i<len;i++) {
		if (loc + i >= vlen) {
			J_ERROR("delmark buffer exceeded!!\n");
		}
		vmark[loc+i] = 1;
	}
#ifdef DEBUG
	J_MESSAGE("now :");
	for (i=0;i<vlen;i++) {
		if (vmark[i] == 1) {
			J_MESSAGE("-");
		} else {
			J_MESSAGE("O");
		}
	}
	J_MESSAGE("\n");
#endif
}

/* execute exclusion */
/* copy vectors from src to new according to vmark status */
void CJuliHtkParam::ExecExcludeVectors(CJuliHtkParam *_new) // exec_exclude_vectors
{
	int i,loc, t;
	/* src ---(vmark)--> new */
	
	/* new length */
	_new->veclen = vnewlen;
	J_OUTPUT_ON_DEBUG("new length = %d\n", _new->veclen);
	
	/* malloc */
	_new->samplenum = samplenum;
	_new->parvec = (VECT **)J_MALLOC(sizeof(VECT *) * _new->samplenum);
	
	for(t = 0; t < samplenum; t++) {
		_new->parvec[t] = (VECT *)J_MALLOC(sizeof(VECT) * _new->veclen);
		loc = 0;
		for (i=0;i<veclen;i++) {
			if (vmark[i] == 0) {	/* not delete == copy */
				_new->parvec[t][loc] = parvec[t][i];
				loc++;
			}
		}
	}
}

/* for in-line one-vector execution */
/* modify the vector, not copy */
void CJuliHtkParam::ExecExcludeOneVector(VECT *vec, int len) // exec_exclude_one_vector
{
	int i,loc;
	
	loc = 0;
	for (i=0;i<len;i++) {
		if (vmark[i] == 0) {	/* not delete == copy */
			vec[loc] = vec[i];
			loc++;
		}
	}
	veclen = loc;
}

/* guess base parameter vector length */
int CJuliHtkParam::GuessBasenum(short qualtype) // guess_basenum
{
	int size;
	int compnum;
	
	compnum = 1 + ((qualtype & F_DELTA) ? 1 : 0) + ((qualtype & F_ACCL) ? 1 : 0);
	
	size = veclen;
	if (header.samptype & F_ENERGY_SUP) size += 1;
	if ((size % compnum) != 0) {
		J_ERROR("ERROR: illegal vector length (should not happen)!\n");
		return -1;
	}
	size /= compnum;
	if (header.samptype & F_ENERGY) size -= 1;
	if (header.samptype & F_ZEROTH) size -= 1;
	
	return(size);
}

/* compare source param type and required type in HTK format, and set mark */
/* can add: _N */
/* can sub: _E_D_A_0 */
boolean CJuliHtkParam::SelectParamVmark(short dst_type_arg) // select_param_vmark
{
	short dst_type;
	short del_type, add_type;
	int basenum, pb[3],pe[3],p0[3]; /* location */
	int i, len;
	char srcstr[80], dststr[80], buf[80];
	
	src_type = header.samptype & ~(F_COMPRESS | F_CHECKSUM);
	src_type &= ~(F_BASEMASK);	/* only qualifier code needed */
	srcstr[0] = '\0';
	CJuliUtil::GetQualStrFromCode(srcstr, src_type, FALSE);
	dst_type = dst_type_arg & ~(F_COMPRESS | F_CHECKSUM);
	dst_type &= ~(F_BASEMASK);	/* only qualifier code needed */
	dststr[0] = '\0';
	CJuliUtil::GetQualStrFromCode(dststr, dst_type, FALSE);
	
	J_OUTPUT_ON_DEBUG("try to select qualifiers: %s -> %s\n", srcstr, dststr);
	
	if (dst_type == F_ERR_INVALID) {
		J_ERROR("ERROR: unknown parameter kind for selection: %s\n", dststr);
		return(FALSE);
	}
	
	/* guess base coefficient num */
	basenum = GuessBasenum(src_type);
	if (basenum < 0) {		/* error */
		return(FALSE);
	}
	J_OUTPUT_ON_DEBUG("base num = %d\n", basenum);
	
	/* determine which component to use */
	del_type = src_type & (~(dst_type));
	add_type = (~(src_type)) & dst_type;
	
	InitMark();
	
	/* vector layout for exclusion*/
	pb[0] = 0;
	if ((src_type & F_ENERGY) && (src_type & F_ZEROTH)){
		p0[0] = basenum;
		pe[0] = basenum + 1;
		len = basenum + 2;
	} else if ((src_type & F_ENERGY) || (src_type & F_ZEROTH)){
		p0[0] = pe[0] = basenum;
		len = basenum + 1;
	} else {
		p0[0] = pe[0] = 0;
		len = basenum;
	}
	for (i=1;i<3;i++) {
		pb[i] = pb[i-1] + len;
		pe[i] = pe[i-1] + len;
		p0[i] = p0[i-1] + len;
	}
	if (src_type & F_ENERGY_SUP) {
		pe[0] = 0;
		for (i=1;i<3;i++) {
			pb[i]--;
			pe[i]--;
			p0[i]--;
		}
	}
	
	/* modification begin */
	/* qualifier addition: "_N" */
#ifdef DEBUG
	buf[0] = '\0';
	J_MESSAGE("try to add: %s\n", CJuliUtil::GetQualStrFromCode(buf, add_type, FALSE));
#endif
	
	if (add_type & F_ENERGY_SUP) {
		if (src_type & F_ENERGY) {
			MarkExcludeVector(pe[0], 1);
			src_type = src_type | F_ENERGY_SUP;
		} else if (src_type & F_ZEROTH) {
			MarkExcludeVector(p0[0], 1);
			src_type = src_type | F_ENERGY_SUP;
		} else {
			J_WARNING("WARNING: \"_N\" needs \"_E\" or \"_0\". ignored\n");
		}
		add_type = add_type & (~(F_ENERGY_SUP)); /* set to 0 */
	}
	if (add_type != 0) {		/* others left */
		buf[0] = '\0';
		J_WARNING("WARNING: can do only parameter exclusion. qualifiers %s ignored\n", CJuliUtil::GetQualStrFromCode(buf, add_type, FALSE));
	}
	
	/* qualifier excludeion: "_D","_A","_0","_E" */
#ifdef DEBUG
	buf[0] = '\0';
	J_MESSAGE("try to del: %s\n", CJuliUtil::GetQualStrFromCode(buf, del_type, FALSE));
#endif
	
	if (del_type & F_DELTA) del_type |= F_ACCL;
	/* mark delete vector */
	if (del_type & F_ACCL) {
		MarkExcludeVector(pb[2], len);
		src_type &= ~(F_ACCL);
		del_type &= ~(F_ACCL);
	}
	if (del_type & F_DELTA) {
		MarkExcludeVector(pb[1], len);
		src_type &= ~(F_DELTA);
		del_type &= ~(F_DELTA);
	}
	
	if (del_type & F_ENERGY) {
		MarkExcludeVector(pe[2], 1);
		MarkExcludeVector(pe[1], 1);
		if (!(src_type & F_ENERGY_SUP)) {
			MarkExcludeVector(pe[0], 1);
		}
		src_type &= ~(F_ENERGY | F_ENERGY_SUP);
		del_type &= ~(F_ENERGY | F_ENERGY_SUP);
	}
	if (del_type & F_ZEROTH) {
		MarkExcludeVector(p0[2], 1);
		MarkExcludeVector(p0[1], 1);
		if (!(src_type & F_ENERGY_SUP)) {
			MarkExcludeVector(p0[0], 1);
		}
		src_type &= ~(F_ZEROTH | F_ENERGY_SUP);
		del_type &= ~(F_ZEROTH | F_ENERGY_SUP);
	}
	
	if (del_type != 0) {		/* left */
		buf[0] = '\0';
		J_WARNING("WARNING: cannot exclude qualifiers %s. selection ignored\n", CJuliUtil::GetQualStrFromCode(buf, del_type, FALSE));
	}
	
	vnewlen = 0;
	for (i=0;i<vlen;i++) {
		if (vmark[i] == 0) vnewlen++;
	}
	
	return(TRUE);
	
}


/* extracts needed parameter vector specified in dst_type_arg from src, and */
/* returns newly allocated parameter structure */
CJuliHtkParam * CJuliHtkParam::NewSelectParamKind(short dst_type_arg) // new_select_param_kind
{
	CJuliHtkParam *_new;
	char buf[80];
	
	/* prepare _new parameter */
	_new = new CJuliHtkParam();
	/* mark to determine operation */
	if (SelectParamVmark(dst_type_arg) == FALSE) return(NULL);
	/* execute deletion (copy needed to _new param)*/
	ExecExcludeVectors(_new);
	
	/* copy & set header info */
	_new->header.samplenum = header.samplenum;
	_new->header.wshift = header.wshift;
	_new->header.sampsize = _new->veclen * sizeof(VECT);
	_new->header.samptype = src_type | (header.samptype & F_BASEMASK);
	
	J_OUTPUT_ON_DEBUG("_new param made: %s\n", CJuliUtil::GetStrFromCode(buf, _new->header.samptype, FALSE));
	
	FreeMark();
	
	return(_new);
}

/* top function: */
/* compare types for given parameter 'param' and HMM definition 'hmminfo' */
/* if type is not same, try to adjust by vector selection */
/* vflag is verbose flag (if TRUE, output verbose messages) */
/* returns NULL on paramtype error */

// SAPI: �G���[�̏ꍇ�� NULL ��Ԃ�
// SAPI: �ʏ�́A�������g���A�V�����C���X�^���X�ւ̃|�C���^��Ԃ�

CJuliHtkParam * CJuliHtkParam::NewParamCheckAndAdjust(CJuliHmmInfo *hmminfo, boolean vflag) // new_param_check_and_adjust
{
	CJuliHtkParam *selected_param;
	char pbuf[80],hbuf[80];
	
	CJuliUtil::GetStrFromCode(pbuf, header.samptype & ~(F_COMPRESS | F_CHECKSUM), FALSE);
	CJuliUtil::GetStrFromCode(hbuf, hmminfo->GetOption().GetParamType(), FALSE);  
	if (!hmminfo->GetOption().CheckParamBaseType(this))
	{
		/* error if base type not match */
		J_ERROR("Error: incompatible parameter type\n");
		J_ERROR("  HMM  trained  by %s(%d)\n", hbuf, hmminfo->GetOption().GetVecSize());
		J_ERROR("input parameter is %s(%d)\n", pbuf, veclen);
		return NULL;
	}
	if (!hmminfo->GetOption().CheckParamCoherence(this))
	{
		/* try to select needed parameter vector */
		if (vflag) J_MESSAGE("attach %s", pbuf);
		selected_param = NewSelectParamKind(hmminfo->GetOption().GetParamType());
		if (selected_param == NULL) {
			if (vflag) J_MESSAGE("->%s failed\n", hbuf);
			J_ERROR("Error: incompatible parameter type\n");
			J_ERROR("  HMM  trained  by %s(%d)\n", hbuf, hmminfo->GetOption().GetVecSize());
			J_ERROR("input parameter is %s(%d)\n", pbuf, veclen);
			return NULL;
		}
		CJuliUtil::GetStrFromCode(pbuf, selected_param->header.samptype, FALSE);
		if (vflag) J_MESSAGE("->%s\n", pbuf);
		return(selected_param);
	}
	return(this);
}
