//====================================================================
// JuliOutProb.h: 
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIOUTPROB_H__D1EC47E1_C3CE_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIOUTPROB_H__D1EC47E1_C3CE_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CJuliHtkHmmState;
class CJuliHtkParam;
class CJuliHtkHmmDens;

#include "JuliDefines.h"
#include "JuliHmmInfo.h"
#include "JuliHMM.h"
#include "JuliContextObject.h"

#define LOG_UNDEF (LOG_ZERO - 1) /* not calced */

// --- from gprune.h

enum{GPRUNE_SEL_UNDEF, GPRUNE_SEL_NONE, GPRUNE_SEL_SAFE, GPRUNE_SEL_HEURISTIC, GPRUNE_SEL_BEAM};
/* Gaussian prob. cache */
typedef struct __mixcache__ {
	LOGPROB score;		/* cached prob. */
	unsigned short id;		/* Gaussian ID in the codebook */
} MIXCACHE;
#define TMBEAMWIDTH 5.0		/* score offset for Gprune=beam */



/* activate experimental methods */
#define GS_MAX_PROB		/* compute only max for GS states */
#define LAST_BEST		/* compute last best Gaussian first */
#undef BEAM			/* enable beam pruning */
#define BEAM_OFFSET 10.0	/* envelope offset */

#ifdef BEAM
#define LAST_BEST
#endif
#ifdef LAST_BEST
#define GS_MAX_PROB
#endif

class CJuliOutProb : public CJuliContextObject
{
public:
	CJuliOutProb();
	virtual ~CJuliOutProb();
	
	boolean Init(CJuliHmmInfo *hmminfo, CJuliHmmInfo *gshmm, int gms_num,
		int gprune_method, int gprune_mixnum); // outprob_init
	boolean Prepare(int framenum); // outprob_prepare
	boolean InitCache(); // outprob_cache_init
	boolean PrepareCache(); // outprob_cache_prepare
	void ExtendCache(int reqframe); // outprob_cache_expand
	LOGPROB CalcOutProbState(int t, const CJuliHtkHmmState *stateinfo, const CJuliHtkParam *param); // outprob_state
	LOGPROB CalcOutProbCd(int t, const CD_State_Set *lset, const CJuliHtkParam *param); // outprob_cd
	LOGPROB CalcOutProb(int t, const HMM_STATE *hmmstate, const CJuliHtkParam *param); // outprob
	
	void InitStyleCache(); // outprob_style_cache_init
	CD_Set * RegisterLcdsetWithCategory(CJuliHmmInfo *hmminfo, CJuliHtkHmmLogical *hmm, WORD_ID category); // lcdset_register_with_category
	CD_Set *LookupLcdsetWithCategory(CJuliHmmInfo *hmminfo, CJuliHtkHmmLogical *hmm, WORD_ID category); // lcdset_lookup_with_category
	void RegisterLcdsetWithCategoryAll(); // lcdset_register_with_category_all
	LOGPROB CalcOutProbStyle(int node, int last_wid, int t, CJuliHtkParam *param); // outprob_style
	void ErrorMissingRightTriphone(const CJuliHtkHmmLogical *base, const char *rc_name); // error_missing_right_triphone
	void ErrorMissingLeftTriphone(const CJuliHtkHmmLogical *base, const char *lc_name); // error_missing_left_triphone
	
private:
	LOGPROB CalcOutProbCdMax(int t, const CD_State_Set *lset, const CJuliHtkParam *param); // outprob_cd_max
	LOGPROB CalcOutProbCdAvg(int t, const CD_State_Set *lset, const CJuliHtkParam *param); // outprob_cd_avg
	
	
	/* functions selected */
	LOGPROB (CJuliOutProb::*calc_outprob)();
	LOGPROB (CJuliOutProb::*calc_outprob_state)();
	void (CJuliOutProb::*compute_gaussset)(CJuliHtkHmmDens **g, int num, int *last_id);
	boolean (CJuliOutProb::*compute_gaussset_init)();
	
	/* for instant access */
	const CJuliHmmInfo *OP_hmminfo;
	const CJuliHmmInfo *OP_gshmm;
	int OP_gprune_num;
	
	const CJuliHtkParam *OP_param;	/* current parameter */
	const CJuliHtkHmmState *OP_state;	/* current state */
	int OP_state_id;		/* current state ID */
	int OP_time;		/* current time */
	int OP_last_time;	/* last time */
	VECT *OP_vec;		/* current input vector */
	short OP_veclen;		/* vector length */
	
	/* work buffer for compute_gsset */
	LOGPROB *OP_calced_score;
	int *OP_calced_id;
	int OP_calced_num;
	int OP_calced_maxnum;
	
	/* cache */
	int statenum;				/* total number of HMM state */
	LOGPROB *outprob_cache_root;/* outprob cache [t][stateid] */
	LOGPROB **outprob_cache;	/* allocated number of frame */
	int allocframenum;			/* allocated number of frame */
	int allocblock;				/* allocate block size per allocateion */
	LOGPROB *last_cache;		/* local cache */
	
	LOGPROB CalcMix(); // calc_mix
	boolean InitCalcTiedMix(); // calc_tied_mix_init
	boolean PrepareCalcTiedMix(int framenum); // calc_tied_mix_prepare
	LOGPROB CalcTiedMix(); // calc_tied_mix
	
	/**** tiedmix ****/
	/* control */
	int t_allocframenum;
	
	/* book cache */
	MIXCACHE ***mixture_cache;/* [time][bookid][#] */
	MIXCACHE **tcache;		/* [bookid][#] of current time */
	MIXCACHE *ttcache;		/* [#] of current time and book */
	MIXCACHE **last_tcache;
	MIXCACHE *last_ttcache;		/* [#] of current time and book */
	int *last_id;
	
	/* results */
	LOGPROB **fallback_score; /* [t][gssetid], LOG_ZERO if selected*/
	
	
	/**** GMS ****/
	
	/* variables for GMS */
	int my_nbest;		/* num of states to be selected */
	int gms_allocframenum;
	
	/* GMS info */
	GS_SET *gsset;		/* set of GS states */
	int gsset_num;		/* num of above */
	int *state2gs; /* mapping from triphone state id to gs id */
	
	/* results */
	boolean *is_selected;	/* TRUE if the frame is already selected */
	LOGPROB **gms_fallback_score; /* [t][gssetid], LOG_ZERO if selected*/
	
	/* for calculation */
	int *gsindex;		/* index buffer */
	LOGPROB *t_fs;		/* current fallback_score */
	
	void BuildGSset(); // build_gsset
	boolean BuildState2GS(); // build_state2gs
	void SortGSIndexUpward(int neednum, int totalnum); // sort_gsindex_upward
	void DoGMS(); // do_gms
	boolean InitGMS(int nbest); // gms_init
	boolean PrepareGMS(int framenum); // gms_prepare
	LOGPROB CalcStateGMS(); // gms_state
	
	
	/**** gms gprune ****/
	/* local cache */
	int my_gsset_num;	/* num of gsset states (local copy) */
	int *last_max_id;	/* maximum mixture id of last call for each states */
#ifdef BEAM
	VECT *dimthres;	/* threshold for each dimension (reversed,base=1) */
	int dimthres_num;
#endif
	
	void InitGMSGprune(const CJuliHmmInfo *hmminfo, int gsset_num); // gms_gprune_init
	void PrepareGMSGprune(); // gms_gprune_prepare
	LOGPROB CalcContProbWithSafePruning(CJuliHtkHmmDens *binfo, LOGPROB thres); // calc_contprob_with_safe_pruning
#ifdef BEAM
	LOGPROB CalcContProbWithBeamPruningPre(CJuliHtkHmmDens *binfo); // calc_contprob_with_beam_pruning_pre
	LOGPROB CalcContProbWithBeamPruningPost(CJuliHtkHmmDens *binfo); // calc_contprob_with_beam_pruning_post
#endif /* BEAM */
#ifdef LAST_BEST
	LOGPROB ComputeGMax(CJuliHtkHmmState *stateinfo, int last_maxi, int *maxi_ret); // compute_g_max
#else  /* ~LAST_BEST */
	LOGPROB ComputeGMax(CJuliHtkHmmState *stateinfo); // compute_g_max
#endif
	void ComputeGSScores(GS_SET *gsset, int gsset_num, LOGPROB *scores_ret); // compute_gs_scores
	
	/*** Gprune ***/
	int FindInsertPoint(LOGPROB score, int len); // find_insert_point
	int PushCache(int id, LOGPROB score, int len); // cache_push
	
	/*** beam ***/
	void ClearDimThres(); // clear_dimthres
	void SetDimThres(); // set_dimthres
	LOGPROB ComputeGBeamUpdating(CJuliHtkHmmDens *binfo); // compute_g_beam_updating
	LOGPROB ComputeGBeamPruning(CJuliHtkHmmDens *binfo); // compute_g_beam_pruning
	boolean InitGpruneBeam(); // gprune_beam_init
	void GpruneBeam(CJuliHtkHmmDens **g, int gnum, int *last_id); // gprune_beam
	
	LOGPROB *beam_dimthres;	/* threshold for each dimension (inversed) */
	int beam_dimthres_num;	/* veclen */
	boolean *mixcalced;	/* mark which Gaussian has been computed */	// beam,heu,safe �ŋ��L
	/*** heu ***/
	void InitBackMax(); // init_backmax
	void MakeBackMax(); // make_backmax
	LOGPROB ComputeGHeuUpdating(CJuliHtkHmmDens *binfo); // compute_g_heu_updating
	LOGPROB ComputeGHeuPruning(CJuliHtkHmmDens *binfo, LOGPROB thres); // compute_g_heu_pruning
	boolean InitGpruneHeu(); // gprune_heu_init
	void GpruneHeu(CJuliHtkHmmDens **g, int gnum, int *last_id); // gprune_heu
	
	LOGPROB *backmax;	/* backward sum of max for each dimension (inversed) */
	int backmax_num;		/* veclen */
	//boolean *mixcalced;	/* mark which Gaussian has been computed */
	LOGPROB ComputeGBase(CJuliHtkHmmDens *binfo); // compute_g_base
	boolean InitGpruneNone(); // gprune_none_init
	void GpruneNone(CJuliHtkHmmDens **g, int num, int *last_id); /* last_id ignored */ // gprune_none
	/*** safe ***/
	LOGPROB ComputeGSafe(CJuliHtkHmmDens *binfo, LOGPROB thres); // compute_g_safe
	boolean InitGpruneSafe(); // gprune_safe_init
	void GpruneSafe(CJuliHtkHmmDens **g, int gnum, int *last_id); // gprune_safe
	//boolean *mixcalced;	/* mark which Gaussian has been computed */
	
	// outprob style
	char rbuf[40];
#ifdef CATEGORY_TREE
	char lccbuf[256], lccbuf2[256];
#endif


	vector<void *> m_allocedmem;	// �L���b�V���p�ɃG�N�X�e���h�����������̃|�C���^�B�f�X�g���N�^�ŉ������
};

#endif // !defined(AFX_JULIOUTPROB_H__D1EC47E1_C3CE_11D5_9AFA_008098E80572__INCLUDED_)
