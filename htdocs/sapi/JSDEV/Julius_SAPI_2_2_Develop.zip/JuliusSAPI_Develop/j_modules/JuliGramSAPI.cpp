//====================================================================
// JuliGramSAPI.cpp: CJuliGramSAPI �N���X�̃C���v�������e�[�V����
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// All rights reserved
//====================================================================

#include "JuliGramSAPI.h"

CJuliGramSAPI::CJuliGramSAPI()
{

}

CJuliGramSAPI::~CJuliGramSAPI()
{

}
