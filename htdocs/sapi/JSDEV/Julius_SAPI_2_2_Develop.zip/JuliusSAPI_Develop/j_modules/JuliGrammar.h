//====================================================================
// JuliGrammar.h: ���@�Ǘ��N���X�̊��N���X
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIGRAMMAR_H__7262E4A5_7E1E_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIGRAMMAR_H__7262E4A5_7E1E_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CJuliGrammar  
{
public:
	CJuliGrammar();
	virtual ~CJuliGrammar();

};

#endif // !defined(AFX_JULIGRAMMAR_H__7262E4A5_7E1E_11D5_9AFA_008098E80572__INCLUDED_)
