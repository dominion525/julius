//====================================================================
// JuliMemory.cpp: �������擾�N���X(���C�u����)
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Copyright (c) 1991-2000 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#include <stdlib.h>
#include <memory.h>
#include <string.h>

#include "JuliMemory.h"
#include "JuliDefines.h"

CJuliMemory theJuliMemory;

void * CJuliMemory::Malloc(int size)	// (Malloc)
{
	void *p;
	if ( (p = malloc(size)) == NULL) {
		J_ERROR("Error: CJuliMemory::Malloc: Cannot malloc %d byte(s)\n",size);
		exit(1);
	}
	return p;
}

void * CJuliMemory::MallocD(const char *filename, int line, int size)	// (Malloc)
{
	void *p;
	if ( (p = malloc(size)) == NULL) {
		J_ERROR("Error: CJuliMemory::Malloc: Cannot malloc %d byte(s) at %s (line %d)\n",size, filename, line);
		exit(1);
	}
	J_DEBUGMESSAGE("M,%d,%s:%d,%p\n",size, filename, line, p);
	return p;
}

void CJuliMemory::Free(void *p)
{
	free(p);
}

void CJuliMemory::FreeD(const char *filename, int line, void *p)
{
	J_DEBUGMESSAGE("F,%s:%d,%p\n", filename, line, p);
	free(p);
}

void * CJuliMemory::Realloc(void *ptr, int size)
{
	void *p;
	if ( (p = realloc(ptr,size)) == NULL) {
		J_ERROR("Error: CJuliMemory::Realloc: Cannot realloc %d byte(s)\n",size);
		exit(1);
	}
	return p;
}

void * CJuliMemory::Calloc(int nelem, int elsize)
{
	void *p;
    J_DEBUGMESSAGE("calloc %d x %d\n",nelem, elsize);
	if ( (p = calloc(nelem,elsize)) == NULL) {
		J_ERROR("Error: CJuliMemory::Calloc: Cannot calloc %d x %d byte(s)\n",nelem, elsize);
		exit(1);
	}
	return p;
}

/* sequancially allocate [size1][size2] array */
/* will sequencially allocate [n][0] - [n][size2-1] */
void ** CJuliMemory::MallocArray(
			 int size1,			/* size of 1st axis */
			 int size2,			/* size of 2nd axis */
			 int elmsize)		/* element size (byte) */
{
	char **p;
	int i;
    J_ERROR("array %d x %d x %d\n",size1,size2,elmsize);
	
	p = (char **)Malloc(sizeof(void *) * size1);
	p[0] = (char *)Malloc(elmsize * size2 * size1);
	for (i=1;i<size1;i++) {
		p[i] = &(p[0][elmsize * size2 * i]);
	}
	
	return ((void **)p);
}

void CJuliMemory::FreeArray(void **p)
{
	Free(p[0]);
	Free(p);
}

/* duplicate string using mybmalloc */
char * CJuliMemory::StrDup(const char *s) // mybstrdup
{
	char *allocated;
	int size = strlen(s) + 1;
	allocated = (char *)J_BMALLOC(size);
	memcpy(allocated, s, size);
	return(allocated);
}
