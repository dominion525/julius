//====================================================================
// JuliHtkHmmCodebook.h: Htk HMM: Codebook �I�u�W�F�N�g (GCODEBOOK)
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIHTKHMMCODEBOOK_H__D19DAB81_7D29_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIHTKHMMCODEBOOK_H__D19DAB81_7D29_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliHtkHmmSegment.h"

class CJuliHtkHmmDens;
class CJuliHmmInfo;

class CJuliHtkHmmCodebook : public CJuliHtkHmmSegment
{
public:
	CJuliHtkHmmCodebook();
	virtual ~CJuliHtkHmmCodebook();

	void ReadFromFile(CJuliFile &file,CJuliHmmInfo &info);

	void SetID(unsigned short i) { id = i; }
	unsigned short GetID() { return id; }

	int					num;	/* # of mixtures in the codebook */
	CJuliHtkHmmDens **	d;		/* pointer to each mixture info */
private:
	unsigned short		id;
};

#endif // !defined(AFX_JULIHTKHMMCODEBOOK_H__D19DAB81_7D29_11D5_9AFA_008098E80572__INCLUDED_)
