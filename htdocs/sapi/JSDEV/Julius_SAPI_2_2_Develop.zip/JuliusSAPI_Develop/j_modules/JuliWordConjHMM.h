//====================================================================
// JuliWordConjHMM.h: �؍\��������
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIWORDCONJHMM_H__4F825662_8746_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIWORDCONJHMM_H__4F825662_8746_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDefines.h"
#include "JuliContextObject.h"
#include "JuliHmmInfo.h"
#include "JuliDictionary.h"

#include "JuliOutProb.h"

#define		MAXWCNSTEP  40000
enum{HEAD,TAIL};                /* tree direction */
/* typedef of A_CELL is in HMM.h */
typedef struct s_cell {		/* succesor word list */
	WORD_ID word;
	struct s_cell *next;
} S_CELL;

#ifdef PASS1_IWCD
typedef struct {
	const CJuliHtkHmmLogical  *hmm;		/* original HMM */
	short		state_loc;	/* state location (1-) */
	boolean	last_is_lset;
	union {
		const CJuliHtkHmmState *state;	/* last assigned state */
		CD_State_Set  *lset;	/* last assigned lset */
	} cache;
	WORD_ID	lastwid_cache;	/* wid when above is assigned */
} RC_INFO;
typedef struct {		/* for 1-phoneme LRSET */
	const CJuliHtkHmmLogical  *hmm;		/* original HMM */
	short		state_loc;	/* state location (1-) */
	boolean	last_is_lset;
#ifdef CATEGORY_TREE
	WORD_ID	category;
#endif
	union {
		const CJuliHtkHmmState *state;	/* last assigned state */
		CD_State_Set  *lset;	/* last assigned lset */
	} cache;
	WORD_ID	lastwid_cache;	/* wid when above is assigned */
} LRC_INFO;
typedef union {
	/* for AS_STATE */
	const CJuliHtkHmmState *state;		/* HMM state for normal node */
	/* for AS_LSET */
	CD_State_Set  *lset;		/* left-context dependent HMM state set */
	/* for AS_RSET */
	RC_INFO	*rset;		/* right-context dependent state info */
	/* for AS_LRSET */
	LRC_INFO	*lrset;		/* right-context dependent state info */
} ACOUSTIC_SPEC;
typedef enum {
	AS_STATE,			/* normal state */
	AS_LSET,			/* left-context-dependent HMM state set */
	AS_RSET,			/* right-context-dependent HMM state set */
	AS_LRSET			/* both (for 1-phoneme word) */
} AS_Style;
#endif

typedef struct {
	A_CELL	*ac;
#ifdef PASS1_IWCD
	ACOUSTIC_SPEC out;
	unsigned char	outstyle;
#else  /* ~PASS1_IWCD */
	CJuliHtkHmmState *	out;
#endif /* ~PASS1_IWCD */

#ifndef CATEGORY_TREE
	S_CELL  *sc;			/* successor word list for factoring */
#endif

#ifdef USE_NGRAM
#ifdef UNIGRAM_FACTORING
	/* max 1-gram prob of all words in "sc" */
	/* for 1-gram factoring, simply use this value */
	LOGPROB fscore;
#endif
#endif /* USE_NGRAM */
} WCHMM_STATE;

typedef struct wchmm_info {
} WCHMM_INFO;

class CJuliWordConjHMM : public CJuliContextObject
{
public:
	CJuliWordConjHMM();
	virtual ~CJuliWordConjHMM();
	void Build();		// (build_wchmm)
	void BuildFast();	// (build_wchmm2) ������: �J�e�S���P�ʂ͖�����
	void PrintInfo();	// (print_wchmm_info) wchmm�̏���W���o�͂ɏo�͂���

	// �A�N�Z�b�T
	WCHMM_STATE GetState(int i) { return m_pState[i]; }
	WCHMM_STATE * GetStateP(int i) { return &m_pState[i]; }
	WORD_ID GetStartID(int i) { return m_pidStart[i]; }
	WORD_ID GetEndID(int i) { return m_pidEnd[i]; }
	int	GetWordEnd(int i) { return m_piWordEnd[i]; }	// wordend
	LOGPROB	GetWordEndA(int i) { return wordend_a[i]; }	// wordend_a
	int GetNumStates() { return m_iNumStates; }
	int GetStartNum() { return startnum; }
	int GetOffset(int i,int j) { return m_ppiOffset[i][j]; }
	int GetStartNode(int i) { return startnode[i]; }
#ifdef UNIGRAM_FACTORING
	int GetStart2Isolate(int i) { return start2isolate[i]; }
	void SetIsolateNum(int i) { isolatenum = i; }
	int GetIsolateNum() { return isolatenum; }
#endif
#ifndef CATEGORY_TREE
	int GetState2ScID(int i) { return state2scid[i]; }
	void SetScNum(int n) { scnum = n; }
	int GetScNum() { return scnum; }
#endif

private:
	void Init();	// (wchmm_init) ������
	void Extend();	// (wchmm_extend) �؂̑傫���ɉ����ė̈��L��
	void Check();	// (check_wchmm)
	int CompareWordSeq(WORD_ID *widx1, WORD_ID *widx2);	// (compare_wseq)
	void SortIndexByWordSeq(WORD_ID *windex, WORD_ID bgn, WORD_ID len);	// (wchmm_sort_idx_by_wseq)
	void SortIndexByCategory(WORD_ID *windex, WORD_ID len);	// (wchmm_sort_idx_by_category)
	int CheckMatch(int i, int j);	// (wchmm_check_match) �P��(ID=i)�ƒP��(ID=j)�̃}�b�`���O�𒲂ׂ�
	void AddWArc(int node, LOGPROB a, int arc);	// (add_wacc) arc ��ǉ�
	void LinkHmm(int from_node, int to_node, const CJuliHtkHmmTrans *tinfo); // (wchmm_link_hmm) ���fHMM�ǂ������Ȃ�
	void LinkSubword(int from_word, int from_seq, int to_word, int to_seq);	// (wchmm_link_subword)
	void DuplicateState(int node, int word);	// (wchmm_duplicate_state)
	void DuplicateLeafNode();	// (wchmm_duplicate_leafnode)
	void AddWord(int word, int matchlen, int matchword);	// (wchmm_add_word) �P�� word (�P��matchword��matchlen���̉��f���}�b�`����)�� wchmm �ɕt��������
	void IndexStateStart();	// (wchmm_index_ststart) �P��̐擪��Ԃ̃C���f�b�N�X���쐬
	void CalcWordendArc();	// (wchmm_calc_wordend_arc) �P��̏I�[��Ԃ���̎��J�ڊm�������߂Ă���
	LOGPROB GetNBestUniprob(int n);	// (get_nbest_uniprob)

	int			m_iMaxWCN;		// (maxwcn)		/* ���݂̗̈�m�ې�(=�ő吔) */
	int			m_iNumStates;	// (n)			/* ��Ԑ� */
	WCHMM_STATE	*	m_pState;		// (state)		/* ��ԏ�� * n */
	WORD_ID *	m_pidStart;		// (ststart)	/* ��Ԃ��J�n��ԂƂ���P���ID * n */
	WORD_ID *	m_pidEnd;		// (stend)		/* ��Ԃ��I����ԂƂ���P���ID * n */
	int	**		m_ppiOffset;	// (offset)		/* �e�P��̊e���f�̊J�n�ʒu * wnum */
	int	*		m_piWordEnd;	// (wordend)	/* �e�P��̍ŏI��� * wnum */
	int			startnum;		/* �؂̍��m�[�h�� */
	int	*		startnode;		/* �؂̍��m�[�h�̃C���f�b�N�X(�ő�wnum) */
	int			m_iDictNumWords; // ����̂Ƃ��Ɏg�� GetDict()->GetNumWords()

#ifdef UNIGRAM_FACTORING
	void MakeIwcacheIndex(); // make_iwcache_index
	int	*	start2isolate;		/* root node ID -> isolated root node ID */
	int		isolatenum;			/* isolated root node �� */
#endif

	LOGPROB *	wordend_a;		/* �P��̊O�ւ̑J�ڊm�� * wnum */
#ifndef CATEGORY_TREE
	void MakeScIndex(); // make_sc_index
	int *	state2scid;		/* node ID -> factoring node ID */
	int		scnum;			/* sc!=NULL�̏�Ԑ� */
#endif

	int bogus_arc;				/* reduced arc by tree*/
	int homophone_word_num;		/* number of homophone words in vocabulary */
	int separated_word_count;	/* words num actually separated */
	int dupcount;

	//	CJuliDictionary *tmp_dicp;
};

#endif // !defined(AFX_JULIWORDCONJHMM_H__4F825662_8746_11D5_9AFA_008098E80572__INCLUDED_)
