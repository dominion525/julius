//====================================================================
// JuliGramNgram.h: Ngram ���@�Ǘ��N���X (NGRAM_INFO)
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIGRAMNGRAM_H__7262E4A3_7E1E_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIGRAMNGRAM_H__7262E4A3_7E1E_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliGrammar.h"
#include "JuliPatriciaTree.h"
#include "JuliDictionary.h"

#define MAX_N 3			/* trigram�܂łɌŒ� */

/* data structures */
/* revision 3 has flat structure */
typedef int NNID;
#define NNID_INVALID -1

#define BEGIN_WORD_DEFAULT "<s>"
#define END_WORD_DEFAULT "</s>"

// Ngram ���@�̎��̂�����1�������悤�ɂ���
//#define UNIQUE_NGRAM

class CJuliGramNgram : public CJuliGrammar
{
public:
#ifdef UNIQUE_NGRAM
	static void * operator new(size_t c);
	static void operator delete(void *o);
#endif

	CJuliGramNgram();
	virtual ~CJuliGramNgram();

	// init_ngram.c
	int ReadFromFile_Binary(const char *bin_ngram_file); // (init_ngram_bin)
	int ReadFromFile_Arpa(const char *ngram_lr_file,const char *ngram_rl_file); // (init_ngram_arpa)
	void MakeVocaRef(CJuliDictionary *winfo);	// (make_voca_ref) ��b������N-gram�G���g����mapping

	LOGPROB UniProb(WORD_ID w) const;	// (uni_prob)
	LOGPROB BiProb_LR(WORD_ID w1, WORD_ID w2) const;	// (bi_prob_lr)
	LOGPROB BiProb_RL(WORD_ID w1, WORD_ID w2) const;	// (bi_prob_rl)
	LOGPROB TriProb_RL(WORD_ID w1, WORD_ID w2, WORD_ID w3) const;	// (tri_prob_rl)

	int GetMaxWordNum() const { return max_word_num; }

	bool IsLoaded() { return m_bLoaded; }
	/* read in N-gram data from fp to ndata */
	boolean				/* return value :TRUE on success */
	NgramReadArpa(CJuliFile &fp, int direction); // ngram_read_arpa

private:
	NNID SearchBigram(WORD_ID w_l, WORD_ID w_r) const;	// (search_bigram)
	NNID SearchTrigram(NNID n2, WORD_ID wkey) const;	// (search_trigram)

	void MakeLookupTree();	// (ngram_make_lookup_tree)
	WORD_ID LookupWord(const char *wordstr);	// (ngram_lookup_word)
	WORD_ID MakeRef(const char *wstr);	// (make_ngram_ref)

	void PrintNgramInfo(); // (print_ngram_info)
	void SetUnknownID();	// (set_unknown_id)

	int GetUnigramSize();	// (get_unigram_size)
	int GetBigramSize();	// (get_bigram_size)
	int GetTrigramSize();	// (get_trigram_size)
	
	void Read_Endianing(CJuliFile &file, void *buf, size_t unitbyte, int unitnum);	// (rdn)
	int CheckHeader(CJuliFile &file);	// (check_header)
	boolean NgramReadBin(CJuliFile &file);	// (ngram_read_bin)

	void Write_Endianing(CJuliFile &file, void *buf, size_t unitbyte, int unitnum);	// (wdn)
	void WriteHeader(CJuliFile &file, char *str);	// (write_header)
	boolean NgramWriteBin(CJuliFile &file, char *headerstr);	// (ngram_write_bin)

	// ARPA
	WORD_ID LkupWord(const char *str);	// lookup_word
	void SetTotalInfo(CJuliFile &fp); // set_total_info 
	void SetAndCheckTotalInfo(CJuliFile &fp); // set_and_check_total_info
	void SetUnigram(CJuliFile &fp); // set_unigram
	void AddUnigram(CJuliFile &fp); // add_unigram
	void SetBigram(CJuliFile &fp); // set_bigram
	void AddBigramRL(CJuliFile &fp); // add_bigram_rl
	void SetTrigram(CJuliFile &fp); // set_trigram

	boolean LR_2gram_read;

#ifdef UNIQUE_NGRAM
	static CJuliGramNgram * m_theInstance;
#endif


	boolean from_bin;	/* TRUE if source is bingram, otherwise ARPA */
	WORD_ID max_word_num;		/* N-gram�̌�b�� */
	NNID ngram_num[MAX_N];		/* N-gram��tuple�� */
	NNID total_ngram_num[MAX_N];	/* n-gram�̏o�������v */
	WORD_ID unk_id;		/* �������̖��m���ID */
	int unk_num;			/* �i��L�̐��j */
	LOGPROB unk_num_log;		/* �i��L�̐��̑ΐ��l�j */
	boolean isopen;		/* open vocabulary���ǂ��� */

	/* ��{�G���g�� + 1-gram ( nid: 0 - ngram_num[0]-1 ) */
	char *wname_buffer;			/* �P�ꖼ������o�b�t�@ */
	char **wname;			/* �P�ꖼ������[nid] */
	CJuliPatriciaTreeNode<int> *root;		/* �P�ꖼ�����ptree�̍��m�[�h */
	
	LOGPROB *p;			/* 1-gram�m��[nid] */
	LOGPROB *bo_wt_lr;		/* LR2-gram�pback-off�W��[nid] */
	LOGPROB *bo_wt_rl;		/* RL2-gram�pback-off�W��[nid] */
	NNID *n2_bgn;
	WORD_ID *n2_num;		/* [nid] -> n2 bgn--end-1 nid�͍��R���e�L�X�g */
	
	/* 2-gram (n2: 0 - ngram_num[1] - 1) */
	WORD_ID *n2tonid;		/* [n2] -> nid */
	LOGPROB *p_lr;		/* LR2-gram�m��[n2] */
	LOGPROB *p_rl;		/* RL2-gram�m��[n2] */
	LOGPROB *bo_wt_rrl;		/* 3-gram�pRL2-gram back-off�W��[n2] */
	NNID *n3_bgn;
	WORD_ID *n3_num;		/* [n2] -> n3 (�͈�) n2�͉E�R���e�L�X�g */
	
	/* 3-gram (n3: 0 - ngram_num[2] - 1) */
	WORD_ID *n3tonid;		/* �P��ID�ϊ�[n3] = nid */
	LOGPROB *p_rrl;		/* RL3-gram�m��[n3] */

	bool m_bLoaded;
};

#endif // !defined(AFX_JULIGRAMNGRAM_H__7262E4A3_7E1E_11D5_9AFA_008098E80572__INCLUDED_)
