//====================================================================
// JuliHtkHmmSegment.cpp: CJuliHtkHmmSegment �N���X�̃C���v�������e�[�V����
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// All rights reserved
//====================================================================

#include "JuliHtkHmmSegment.h"

CJuliHtkHmmSegment::CJuliHtkHmmSegment()
{
	m_strName = "";
}

CJuliHtkHmmSegment::~CJuliHtkHmmSegment()
{
	
}

void CJuliHtkHmmSegment::ReadFromFile(CJuliFile &file,CJuliHmmInfo &info)
{
	
}

