//====================================================================
// JuliFactoring.h: 
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIFACTORING_H__30F9EAB6_02A9_4D0D_95BA_A06B2CB371F2__INCLUDED_)
#define AFX_JULIFACTORING_H__30F9EAB6_02A9_4D0D_95BA_A06B2CB371F2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDefines.h"
#include "JuliContextObject.h"

class CJuliFactoring : public CJuliContextObject
{
public:
	CJuliFactoring();
	virtual ~CJuliFactoring();
	
	void MakeSuccessorList(); // make_successor_list
	void InitMaxSuccessorCache(); // max_successor_cache_init
	void FreeMaxSuccessorCache(); // max_successor_cache_free
	void MakeIwcacheIndex(); // make_iwcache_index
	void CalcAllUnigramFactoringValues(); // calc_all_unigram_factoring_values
	LOGPROB * MaxSuccessorProbIw(WORD_ID lastword); // max_successor_prob_iw
#ifdef USE_DFA /* USE_DFA --- �J�e�S���؂Ȃ�s�K�v */
	boolean CanSucceed(WORD_ID lastword, int node); // can_succeed
#endif
	void MakeClassRef(); // make_class_ref
	LOGPROB ClassUniProb(WORD_ID w); // class_uni_prob
	LOGPROB ClassBiProbLR(WORD_ID w1, WORD_ID w2); // class_bi_prob_lr
	LOGPROB ClassBiProbRL(WORD_ID w1, WORD_ID w2); // class_bi_prob_rl
	LOGPROB ClassTriProbRL(WORD_ID w1, WORD_ID w2, WORD_ID w3); // class_tri_prob_rl
	LOGPROB MaxSuccessorProb(WORD_ID lastword, int node); // max_successor_prob
	
private:
	void AddSuccessor(int node, WORD_ID w); // add_successor
	boolean MatchSuccessor(int node1, int node2); // match_successor
	void FreeSuccessor(int node); // free_successor
	void FreeMaxSuccessorProbIw(); // max_successor_prob_iw_free
	LOGPROB CalcSuccessorProb(WORD_ID last_nword, int node); // calc_successor_prob
	
#ifdef USE_NGRAM
	/* cache�͒��O�����o����Cnode�P�ʂŊǗ� */
	LOGPROB *	probcache;
	WORD_ID *	lastwcache;
	/* �P��Ԃł�factoring�͕ʃ��[�`�� */
	/* �P��P�ʂŁC���ꂼ��S�P��擪�m�[�h�ւ̒l��cache */
	/* ��x�v�Z������Ō�܂Ŋo���Ă��� */
	LOGPROB **	iw_sc_cache;
	int			iw_cache_num;
#ifdef HASH_CACHE_IW
	WORD_ID *	iw_lw_cache;
#endif
	
#endif
#ifdef CLASS_NGRAM
	/*
	When apply:
	
	  if wton[w] >= ngram.max_word_num; then
	  wton[w] - ngram.max_word_num == ID of class N-gram 
	  else
	  wton[w] == ID of word N-gram
	*/
	LOGPROB		log_beta_w, log_beta_c; /* LM prob distibution coef. */
	WORD_ID *	wtoc;		/* N-gram word ID -> class ID */
	LOGPROB *	c_probsum;		/* sum of uniprob assigned by the class */
	LOGPROB *	wtoc_prob;	/* interpolate prob for each word */
#ifndef CLASS_UNKNOWN_ONLY
	LOGPROB		class_weight_log, class_weight_inv_log;
#endif
#endif
};

#endif // !defined(AFX_JULIFACTORING_H__30F9EAB6_02A9_4D0D_95BA_A06B2CB371F2__INCLUDED_)
