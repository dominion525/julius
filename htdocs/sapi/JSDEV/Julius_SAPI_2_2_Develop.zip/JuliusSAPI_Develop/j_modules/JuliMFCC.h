//====================================================================
// JuliMFCC.h: 
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIMFCC_H__4E0B6581_8B72_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIMFCC_H__4E0B6581_8B72_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliDefines.h"
#include "JuliHtkParam.h"

// sent/mfcc.h

/* Define pi */ 
#if !defined(PI)
#define PI 3.14159265358979
#endif
/* Define 2*pi */
#if !defined(TPI)
#define TPI 6.28318530717959 
#endif

/* define default values (MFCC_E_D) */
#define DEF_FRAMESIZE   400
#define DEF_FFTNUM      512
#define DEF_FRAMESHIFT  160
#define DEF_PREENPH     0.97
#define DEF_MFCCDIM     12
#define DEF_CEPLIF      22
#define DEF_DELWIN      2
#define DEF_SILFLOOR    50.0
#define DEF_ESCALE      0.1
#define DEF_FBANK       24
#define DEF_SMPPERIOD   625
#define DEF_SSALPHA     2.0
#define DEF_SSFLOOR     0.5

#define MAXLEN          200
#if !defined(FALSE)
#define FALSE           0
#endif
#if !defined(TRUE)
#define TRUE            1
#endif
typedef struct value{
	char inFile[MAXLEN];  /* Input file */
	char outFile[MAXLEN]; /* Output fle */
	long smp_period;      /* sample period in 100ns units (16KHz) */
	int framesize;        /* Window size */
	int frameshift;       /* Frame shift */
	float preEmph;        /* Pre-emphasis coefficient */
	int mfcc_dim;         /* Number of MFCC dimensions */
	int lifter;           /* Cepstral liftering coefficient */
	int delWin;           /* Delta window size */
	float silFloor;       /* Energy silence floor in dBs */
	float escale;         /* Scale log energy */
	int vec_num;          /* Number of dimensions */
	int fbank_num;        /* Number of filterbank channels */
	int hipass;		/* hi pass frequency */
	int lopass;		/* lo pass frequency */
	int cmn;              /* Cepstrum Mean Normalization */
	int enormal;          /* Normalise Energy */
	int raw_e;            /* Raw Energy */
	int c0;		/* 0'th cepstral parameter */
	float ss_alpha;       /* alpha coef. for spectral subtraction */
	float ss_floor;       /* spectral floor in spectral subtraction */
}Value;

typedef struct{
	int fftN;            /* fft size */
	int n;               /* log2(fftN) */
	int klo,khi;         /* lopass to hipass cut-off fft indices */
	float fres;          /* scaled fft resolution */
	float *cf;           /* array[1..pOrder+1] of centre freqs */
	short *loChan;       /* array[1..fftN/2] of loChan index */
	float *loWt;         /* array[1..fftN/2] of loChan weighting */
	float *Re;           /* array[1..fftN] of fftchans (real part) */
	float *Im;           /* array[1..fftN] of fftchans (imag part) */
}FBankInfo;

class CJuliMFCCParameter
{
public:
	void Init();
	Value & GetPara() { return para; }
private:
	Value para;		/* parameters for Wav2MFCC */	// ���[�h�I�����[�ȃp�����[�^
};

extern CJuliMFCCParameter thePara;

class CJuliMFCC  
{
public:
	CJuliMFCC();
	virtual ~CJuliMFCC();
	
	CJuliHtkParam *Wave2MFCC(SP16 speech[], int speechlen);	// (new_wav2mfcc)

	void WMP_init(Value para, float **bf, float *ssbuf, int ssbuflen);
	void WMP_calc(float *mfcc, float *bf, Value para, float *ssbuf);
	void WMP_Delta(float **c, int t, int frame, Value para);

	void CMN_realtime_update();
	void CMN_realtime(float *mfcc, int cdim);
	boolean CMN_load_from_file(const char *filename, int dim);
	boolean CMN_save_to_file(const char *filename);

	float * new_SS_load_from_file(const char *filename, int *slen);
	float * new_SS_calculate(SP16 *wave, int wavelen, Value para, int *slen);

	int GetDim() const { return m_dim;}
	void GetParam(float *f) const { memcpy(f, m_mfcc_ave, m_dim * sizeof(float)); }
	void SetCMNParam(const float *p, int d)
	{
		if (m_mfcc_ave == NULL) {
			m_mfcc_ave = (float *)J_MALLOC(sizeof(float) * d);
		}
		memcpy(m_mfcc_ave, p, d * sizeof(float));
	}

private:	
	int Wav2MFCC_E_D(SP16 *wave, float **mfcc, Value para, int nSamples, float *ssbuf, int ssbuflen);
	float CalcLogRawE(float *wave, int framesize);
	void Hamming(float *wave, int framesize);
	void PreEmphasise (float *wave, Value para);
	void WeightCepstrum (float *mfcc, Value para);
	float Mel(int k, float fres);

	FBankInfo InitFBank(Value para);
	void MakeFBank(float *wave, double *fbank, FBankInfo fb, Value para, float *ssbuf);
    void ReleaseFBank(FBankInfo fb);

	void MakeMFCC(double *fbank, float *mfcc, Value para);
	void NormaliseLogE(float **mfcc, float *energy, int frame_num, Value para);
	void Delta(float **c, int frame, Value para);
	void FFT(float *xRe, float *xIm, int p);
	void CMN(float **mfcc, int frame_num, int dim);
	
	double *	m_fbank;                    /* Filterbank */
	FBankInfo	m_fb;

	// CMN
	float *		m_lastcsum;		// MFCC �̍��v
	float **	m_lastc;		// �����O�o�b�t�@(CPMAX)
	int			m_dim;			// ����
	int			m_cp;			// m_lastc �̃����O�|�C���^
	int			m_filled;		// m_lastcsum �J�E���^
	float *		m_mfcc_ave;		// MFCC ���ρi�O��j
	float *		m_mfcc_ave_new;	// MFCC ����
};

extern CJuliMFCC theMFCC;

#endif // !defined(AFX_JULIMFCC_H__4E0B6581_8B72_11D5_9AFA_008098E80572__INCLUDED_)
