//====================================================================
// JuliRealTimePipeLine.h: �p�C�v���C������
//--------------------------------------------------------------------
// Copyright (c) 1991-2001 Doshita Lab. Speech Group, Kyoto University
// All rights reserved
//====================================================================

#if !defined(AFX_JULIREALTIMEPIPELINE_H__9592B341_C335_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIREALTIMEPIPELINE_H__9592B341_C335_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JuliHtkParam.h"
#include "JuliMFCC.h"
#include "JuliContextObject.h"
#include "JuliBeamSearch.h"
#include "JuliBackTrellis.h"

class CJuliRealTimePipeLine : public CJuliContextObject
{
public:
	CJuliRealTimePipeLine();
	virtual ~CJuliRealTimePipeLine();

	void RealTimeInit();
	void RealTimePipeLinePrepare();
	int RealTimePipeLine(SP16 *Speech, int nowlen);
#ifdef SP_BREAK_CURRENT_FRAME
	int RealTimeResume();
#endif
	CJuliHtkParam * RealTimeParam(LOGPROB *backmax);

	int m_iTotalSamples;	// �S�T���v����
	int GetTotalSamplePeriod();

private:
	Value & GetPara() { return thePara.GetPara();}
	CJuliMFCC & GetMFCC() { return theMFCC;}
	void InitParam();
	
	/* MFCC parameter */
	CJuliHtkParam *param;	/* hold MFCC param */
	float *bf;		/* work space for FFT */
	
	boolean need_attach; /* whether param need selection */
	int maxframelen;		/* maximum frame length from MAXSPEECHLEN */
	
	boolean last_is_segmented;
	int last_time;
#ifdef SP_BREAK_CURRENT_FRAME
	SP16 *rest_Speech;
	int rest_alloc_len;
	int rest_len;
#endif
	
	int f_raw;
	int f_delay;
	int f;
	SP16 *window;
	int windowlen;
	int windownum;		/* current left samples in a window */

	int m_bCMNLoaded;

};

#endif // !defined(AFX_JULIREALTIMEPIPELINE_H__9592B341_C335_11D5_9AFA_008098E80572__INCLUDED_)
