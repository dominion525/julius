#pragma once

#include <windows.h>

class CJuliSAPI_TaskTray
{
public:
	CJuliSAPI_TaskTray(void);
	~CJuliSAPI_TaskTray(void);

	int Init(HINSTANCE hInst);
	HWND m_hwndDummy;
};

extern CJuliSAPI_TaskTray theTaskTray;
