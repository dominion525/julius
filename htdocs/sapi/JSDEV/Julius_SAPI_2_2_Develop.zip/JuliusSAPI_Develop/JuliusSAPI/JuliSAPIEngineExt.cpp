//====================================================================
// JuliSAPIEngineExt.cpp: CJuliSAPIEngineExt �̃C���v�������g
//--------------------------------------------------------------------
// Copyright (c) 2001 Takashi Sumiyoshi
// Speech Media Lab. Kyoto University     All rights reserved
//====================================================================
#include "stdafx.h"
#include "JuliusSAPI.h"
#include "JuliSAPIEngineExt.h"

STDMETHODIMP CJuliSAPIEngineExt::SkipNext2ndPass(void)
{
	char str[] = "2";
    return m_pEngineCall->CallEngine( (void*)str, strlen(str) );
}
