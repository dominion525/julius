//====================================================================
// DFA.h: DFA ���\�z����
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Speech Media Lab. Kyoto University     All rights reserved
//====================================================================

#if !defined(AFX_DFA_H__40046BE9_2D9D_4312_8999_14CE3E9624AE__INCLUDED_)
#define AFX_DFA_H__40046BE9_2D9D_4312_8999_14CE3E9624AE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <iostream>
#include <vector>
#include <set>
#include <map>
using namespace std;
// #define NDEBUG (���邢�� /D �I�v�V����)�� assert �͏�����Ԃ炵��
#include <assert.h>

class CNFA;

// ���[�U�f�[�^�Ƃ��ă����o�� void * ��������
#define DFA_SUPPORT_USERDATA

// �}
class CDFAArc
{
public:
	void SetSymbol(short s) { m_sSymbol = s;}
	short GetSymbol() { return m_sSymbol; }
	void SetNextState(short n) { m_sNextState = n; }
	short GetNextState() { return m_sNextState; }

private:
	short m_sSymbol;		// �J�ڋL��
	short m_sNextState;		// �����

#ifdef DFA_SUPPORT_USERDATA
public:
	void SetUserData(void *p) { m_pUserData = p; }
	void * GetUserData() { return m_pUserData; }
private:
	void *m_pUserData;
#endif
};

// ���
class CDFAState
{
public:
	CDFAState() : m_bFlag(0) {}
	int AddArc(int symbol, int next) { CDFAArc a;a.SetSymbol(symbol); a.SetNextState(next);m_vArcs.push_back(a); return 0; }
	int GetNumArcs() { return m_vArcs.size(); }
	CDFAArc & GetArc(int a) { assert(a>=0 && a<GetNumArcs()); return m_vArcs[a]; }

	int GetFlag() { return m_bFlag; }
	void SetAccept(int a) { m_bFlag = (m_bFlag & ~1) | a?1:0;}
	int IsAccept() { return (m_bFlag & 1)?1:0;}
private:
	vector<CDFAArc> m_vArcs;	// �}
	int m_bFlag;	// �t���O &1: �󗝏��

#ifdef DFA_SUPPORT_USERDATA
public:
	void SetUserData(void *p) { m_pUserData = p; }
	void * GetUserData() { return m_pUserData; }
private:
	void *m_pUserData;
#endif
};

class CDFA;

ostream & operator<<(ostream &ost, CDFA &dfa);


class CDFA
{
public:
	CDFA();
	virtual ~CDFA();

	int CreateStates(int num);
	int GetNumStates() { return m_iNumStates; }
	CDFAState & GetState(int s) { assert(s>=0 && s<m_iNumStates); return m_pStates[s]; }

	int Reverse(CNFA *nfa);
	int GroupingArcs(CDFA *dfa, vector<set<short> > * grouparcs);
	void InsertSp(CDFA *dfa, int spid);
	int ReverseAndGroupingArcs(CNFA *nfa, vector<set<short> > * grouparcs);
	int Optimize(CDFA *dfa_new);
	friend ostream & operator<<(ostream &ost, CDFA &dfa);
private:
	int m_iNumStates;		// ��Ԑ�
	CDFAState * m_pStates; // ���
};

#endif // !defined(AFX_DFA_H__40046BE9_2D9D_4312_8999_14CE3E9624AE__INCLUDED_)
