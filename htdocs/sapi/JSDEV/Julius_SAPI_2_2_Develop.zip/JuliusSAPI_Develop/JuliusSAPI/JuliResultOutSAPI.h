#pragma once
#include "../j_modules/JuliResultOut.h"

class CJuliSAPIEngine;

class CJuliResultOutSAPI :
	public CJuliResultOut
{
public:
	CJuliResultOutSAPI(void);
	virtual ~CJuliResultOutSAPI(void);

	void SetEngine(CJuliSAPIEngine *p) { m_pEngine = p; }
	// keisho
	int SendRecognition(RESULT2 &res, boolean fHypo);
	int SendFalseRecognition();
private:
	int SetPhraseFromWords(SPPHRASE *phrase, RESULT2 &res, int *nWords);
	int SetParseFromWords(SPPARSEINFO *parse, RESULT2 &res, int *nWords);
	void SetElementAlignment(SPPHRASEELEMENT *e, int begin_frame, int end_frame);
	void SetElementScore(SPPHRASEELEMENT *e, float score);
	int SetAndParse(CComPtr<ISpPhraseBuilder> & cpBuilder, RESULT2 &res, BOOL fHypo, int *nElems);

	CJuliSAPIEngine * GetEngine() { return m_pEngine; }
	CJuliSAPIEngine * m_pEngine;
};
