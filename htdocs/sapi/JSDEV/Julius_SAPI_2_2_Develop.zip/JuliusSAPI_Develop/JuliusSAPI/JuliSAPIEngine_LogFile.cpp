#include "stdafx.h"
#include "JuliSAPIEngine.h"
#include "../j_modules/JuliLog.h"
#include "../j_modules/JuliGlobalOption.h"

#if 0
static string strbuffermessage;
#endif

static int bFileOpened[3] = {0};
static FILE *fplogfile[3] = {NULL};

static int RecordLogMessageToFile(int &bFileOpened, FILE *& fplog, const char *filename, const char *message)
{
	if (bFileOpened==0)
	{
		if (filename != NULL && filename[0]!='\0')
		{
			fplog = fopen(filename, "w");
			if (fplog != NULL)
			{
				bFileOpened=1;
				// �^�C���X�^���v
				{
					SYSTEMTIME st;
					GetLocalTime(&st);
					char buf[256];
					sprintf(buf,"Created on %04d/%02d/%02d %02d:%02d:%02d\n",
						st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
					fputs(buf, fplog);
				}
			}
		}
	}
	if (bFileOpened)
	{
		fputs(message, fplog);
		fflush(fplog);
	}	return 0;
}

static int RecordLogMessage(const char *message, void *dummy, int opt)
{
	if (opt & LOG_OUTPUT && (! theOpt.m_strOutLogFile.empty()))
		RecordLogMessageToFile(bFileOpened[0], fplogfile[0], theOpt.m_strOutLogFile.c_str(), message);
	if (opt & LOG_ERROR && (! theOpt.m_strErrLogFile.empty()))
		RecordLogMessageToFile(bFileOpened[1], fplogfile[1], theOpt.m_strErrLogFile.c_str(), message);
	if (1 && (! theOpt.m_strDebugLogFile.empty()))
		RecordLogMessageToFile(bFileOpened[2], fplogfile[2], theOpt.m_strDebugLogFile.c_str(), message);
	return 0;
}


void CJuliSAPIEngine::SetLogHandler()
{
	theJuliLog.SetLogHandler(RecordLogMessage, NULL);
}

