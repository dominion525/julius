// JuliSAPIEngine.h : CJuliSAPIEngine �̐錾

#ifndef __JULISAPIENGINE_H_
#define __JULISAPIENGINE_H_

#include "resource.h"       // ���C�� �V���{��
#include "JuliusSAPI.h"

#include "stdafx.h"

#include <string>
#include <map>
#include <deque>
using namespace std;
class CNFA;
class CDFA;
class CJuliAudioSourceSAPI;
class CJuliMFCC;

#include "../j_modules/JuliOptions.h"
#include "../j_modules/JuliContext.h"

#include "../j_modules/JuliLog.h"

class CJuliSAPIGrammar;

// CJuliContext �� SAPI ���p��
class CJuliContext_SAPI : public CJuliContext
{
public:
	void SetGrammarHandle(SPGRAMMARHANDLE h) { m_hGrammar = h; }
	SPGRAMMARHANDLE GetGrammarHandle() { return m_hGrammar; }
	void SetRuleHandle(SPRULEHANDLE h) { m_hRule = h; }
	SPRULEHANDLE GetRuleHandle() { return m_hRule; }

	map<int, SPTRANSITIONID> m_map_WORDID_SPTRANSITIONID;	// WORD_ID -> SPTRANSITIONID �̃}�b�v

private:
	SPGRAMMARHANDLE m_hGrammar;	// ���@�̃n���h��
	SPRULEHANDLE m_hRule;		// JULISLM_SAPIXML �̏ꍇ�̂�
};

// SAPI �� Reco Context �̃��X�g
class CJuliSAPIRecoContext
{
public:
    CJuliSAPIRecoContext(SPRECOCONTEXTHANDLE hSapiContext) :
		m_hSapiContext(hSapiContext)
    {
	}
    BOOL operator==(SPRECOCONTEXTHANDLE hContext)
    {
        return (m_hSapiContext == hContext);
    }
	
    SPRECOCONTEXTHANDLE		m_hSapiContext; // SAPI �̃R���e�N�X�g�n���h�� (OnCreateContext �Őݒ�)
	vector<CJuliSAPIGrammar *>	m_grams;	// ���̃R���e�N�X�g�ɏ������� CJuliSAPIGrammar �ւ̃|�C���^

	void RemoveGrammar(CJuliSAPIGrammar *g)
	{
		for (vector<CJuliSAPIGrammar *>::iterator i=m_grams.begin();i!=m_grams.end();)
		{
			if (*i == g)
			{
				i = m_grams.erase(i);
				continue;
			}
			i++;
		}
	}
public:
    CJuliSAPIRecoContext *	m_pNext;
};

// SAPI �� Grammar Context �̃��X�g
class CJuliSAPIGrammar
{
public:
    CJuliSAPIGrammar(SPGRAMMARHANDLE hSapiGrammar) :
	m_hSapiGrammar(hSapiGrammar),
        m_SLMLoaded(FALSE),
        m_SLMActive(FALSE),
        m_pWordSequenceText(NULL),
        m_cchText(0),
		jc(NULL)
    {
    }
	
    ~CJuliSAPIGrammar()
    {
        // Free up resources
        if(m_pWordSequenceText)
        {
            delete m_pWordSequenceText;
        }
    }
	
#ifdef _WIN32_WCE
    CJuliSAPIGrammar()
    {
    }
	
    static LONG Compare(const CJuliSAPIGrammar *, const CJuliSAPIGrammar *)
    {
        return 0;
    }
#endif
	CJuliSAPIRecoContext *	m_pSapiRecoContext;
    SPGRAMMARHANDLE			m_hSapiGrammar;	// SAPI �̃O���}�[�n���h�� (OnCreateGrammar �Őݒ�)
    BOOL					m_SLMLoaded;	// Does the grammar have an associated SLM for dictation
    BOOL					m_SLMActive;	// Is the dictation active
    WCHAR *		m_pWordSequenceText;	// The text of the word sequence buffer if one is set
    ULONG		m_cchText;				// The size of the word sequence buffer

public:
	CJuliContext_SAPI * GetJuliContext() { return jc; }
	void SetJuliContext(CJuliContext_SAPI *c) { jc = c; }
private:
	CJuliContext_SAPI *	jc;	// SAPI �̕��@1�ɑ΂��āA1�� CJuliContext_SAPI �����蓖�Ă�
							// NGRAM ���@�̂ݎg�p�I SAPI ���@�� RuleEntry �Ɋ��蓖�Ă�
public:
    CJuliSAPIGrammar *	m_pNext;
};

// Class so we can use CSpBasicQueue to store rule information
class CJuliSAPIRuleEntry
{
public:
	CJuliSAPIRuleEntry()
		: m_hRule(0), m_fTopLevel(FALSE), m_fActive(FALSE), m_fConstructed(FALSE),
		jc(NULL), m_pNext(NULL)
	{
	}


    BOOL operator==(SPRULEHANDLE rh)
    {
        return (m_hRule == rh);
    }
    SPRULEHANDLE m_hRule;   // SAPI rule handle
    BOOL m_fTopLevel;		// �g�b�v���x����(�A�N�e�B�u�ɂȂ肤�邩)
    BOOL m_fActive;			// ���݃A�N�e�B�u��
    BOOL m_fConstructed;	// ��x�ł��A�N�e�B�u�ɂȂ���dfa���\�z���ꂽ��
	
public:
	CJuliContext_SAPI * GetJuliContext() { return jc; }
	void SetJuliContext(CJuliContext_SAPI *c) { jc = c; }
private:
	CJuliContext_SAPI *	jc;	// SAPI �̕��@1�ɑ΂��āA1�� CJuliContext_SAPI �����蓖�Ă�
public:
   CJuliSAPIRuleEntry   * m_pNext;
};


/////////////////////////////////////////////////////////////////////////////
// CJuliSAPIEngine
class ATL_NO_VTABLE CJuliSAPIEngine : 
public CComObjectRootEx<CComMultiThreadModel>,
public CComCoClass<CJuliSAPIEngine, &CLSID_JuliSAPIEngine>,
//	public IDispatchImpl<IJuliSAPIEngine, &IID_IJuliSAPIEngine, &LIBID_JULIUSSAPILib>,
public ISpSREngine,
public ISpObjectWithToken,
public ISpThreadTask
{
public:
	CJuliSAPIEngine() :
	  m_pJuliAudioSourceSAPI(NULL),
		  overflowed_samples(NULL),
		  m_bInitializedEngine(0),
		  m_bPhraseStarted(FALSE),
		  m_bSoundStarted(FALSE),
		  m_hRequestSync(NULL),
		  m_bSentSoundStart(FALSE),
		  m_LangID(0)
	  {}
	  DECLARE_REGISTRY_RESOURCEID(IDR_JULISAPIENGINE)
		  
		  DECLARE_PROTECT_FINAL_CONSTRUCT()
		  
		  BEGIN_COM_MAP(CJuliSAPIEngine)
		  COM_INTERFACE_ENTRY(ISpSREngine)
		  COM_INTERFACE_ENTRY(ISpObjectWithToken)
		  //	COM_INTERFACE_ENTRY(IJuliSAPIEngine)
		  //	COM_INTERFACE_ENTRY(IDispatch)
		  END_COM_MAP()
		  
		  // DFA�쐬
private:
	void _ConstructDFAFromRule(SPRULEHANDLE hRule, CDFA *dfa, vector<SPWORDHANDLE> & _vec_wordindex_SPWORDHANDLE);
	void _ConstructDFARecursive(CNFA *nfa, deque<SPRULEHANDLE> &rule_stack, deque<short> &initrulestate_stack, deque<short> &tostate_stack, deque<int> leftright_stack);
	void _ClearMaps()
	{
		m_mapHStateIndex.clear();
		m_map_SPTRANSITIONID_wordindex.clear();
		m_vec_wordindex_SPTRANSITIONID.clear();
		m_vec_wordindex_SPWORDHANDLE.clear();
	}
	short _GetStateIDFromTable(SPSTATEHANDLE hState, const deque<SPRULEHANDLE> &rule_stack, short acceptstate);
	int _GetWordIDFromTable(SPTRANSITIONID id, SPWORDHANDLE hWord);

	// SPSTATEHANDLE & ���[���X�^�b�N -> short �ւ̑Ή��\
	map<pair<SPSTATEHANDLE, deque<SPRULEHANDLE> >, short> m_mapHStateIndex;

	// SPWORDHANDLE -> wordindex
	map<SPTRANSITIONID, short> m_map_SPTRANSITIONID_wordindex;
	// wordindex -> SPWORDHANDLE
	vector<SPWORDHANDLE> m_vec_wordindex_SPWORDHANDLE;
	// wordindex -> SPTRANSITIONID
	vector<SPTRANSITIONID> m_vec_wordindex_SPTRANSITIONID;

private:
	CJuliAudioSourceSAPI *m_pJuliAudioSourceSAPI;	// SAPI�I�[�f�B�I�I�u�W�F�N�g

	int m_bInitializedEngine;	// �G���W���� _InitializeJulius ���Ă΂ꂽ���̃t���O

	// ��1�p�X�񃊃A���^�C���F���p
	SP16 speech[MAXSPEECHLEN];	// �����o�b�t�@
	int speechlen;				// �����o�b�t�@�̒���
	SP16 *overflowed_samples;
	int overflowed_samplenum;

	// RecoContext, Grammar, RuleEntry ���Ǘ�����
	CSpBasicQueue<CJuliSAPIGrammar>		m_GrammarList;
    CSpBasicQueue<CJuliSAPIRecoContext>	m_ContextList;
    CSpBasicQueue<CJuliSAPIRuleEntry>	m_RuleList;

    HANDLE                          m_hRequestSync;
    BOOL                            m_bSoundStarted:1;
    BOOL							m_bPhraseStarted:1;
    CComPtr<ISpThreadControl>       m_cpDecoderThread;
    CComPtr<ISpLexicon>             m_cpLexicon;			// ��b
    CComPtr<ISpObjectToken>         m_cpEngineObjectToken;	// �G���W���̃v���t�@�C��
    CComPtr<ISpObjectToken>         m_cpUserObjectToken;	// ���[�U�v���t�@�C��
	
private:
	int _ConstructDictDfa(CJuliSAPIRuleEntry *pRuleEntry, const SPRULEENTRY &rule);
	HRESULT _MakeDictDfa(SPRULEHANDLE hRule, CJuliContext_SAPI *jc);

protected:
	int AddContext(CJuliContext_SAPI *jc);
	int RemoveContext(CJuliContext_SAPI *jc);
	vector<CJuliContext_SAPI *> m_jclist;

public:
	CComPtr<ISpSREngineSite>        m_cpSite;
    LANGID                          m_LangID;	
    HANDLE      m_hThreadEnd;	// �X���b�h���I�������Ƃ���RecognizeStream�ɑ���C�x���g
    ULONGLONG	m_ullStart;		// �����̊J�n�ʒu(�o�C�g�P��)
    ULONGLONG	m_ullEnd;		// ������ǂݍ��񂾃o�C�g��
	BOOL		m_bSentSoundStart;	// SPEI_SOUND_START �𑗂������ǂ����̃t���O
	BOOL		m_bInputEnd;
	BOOL		m_bVoiceDetected;
	BOOL		m_bRealTime;		// ��1�p�X�����A���^�C���������邩�ǂ����̃t���O
	
public:
	const char * _GetSpEventEnumString(SPEVENTENUM e);
	const char * _GetErrorString(HRESULT hr);
    HRESULT _AddEvent(SPEVENTENUM eEventId, ULONGLONG ullStreamPos, WPARAM wParam = 0, LPARAM lParam = 0);
    HRESULT _AddEventString(SPEVENTENUM eEvent, ULONGLONG ulLStreamPos, const WCHAR * psz, WPARAM = 0);
	HRESULT _GenerateRandomPath(SPSTATEHANDLE hState, SPPATHENTRY * pPath, int * piTrans);
	
	int _InitializeJulius();
	int _ProcessAudio(SP16 *buf, int len);
	int _StoreBuffer(SP16 *buf, int len);

public:
	void SetLogHandler();
	ISpSREngineSite * GetSite() { return m_cpSite; }	
	
	// ISpSREngine �C���^�t�F�[�X
	// ==========================

	// ATL contstructor / destructor
    HRESULT FinalConstruct();
    HRESULT FinalRelease();
	
    // Initialization methods
    STDMETHODIMP SetObjectToken(ISpObjectToken * pToken);
    STDMETHODIMP GetObjectToken(ISpObjectToken ** ppToken);
	
    STDMETHODIMP SetRecoProfile(ISpObjectToken * pProfileToken);
    STDMETHODIMP SetSite(ISpSREngineSite *pSite);
    STDMETHODIMP GetInputAudioFormat(const GUID * pSrcFormatId, const WAVEFORMATEX * pSrcWFEX,
		GUID * pDesiredFormatId, WAVEFORMATEX ** ppCoMemDesiredWFEX);
	
    STDMETHODIMP OnCreateRecoContext(SPRECOCONTEXTHANDLE hSAPIRecoContext, void ** ppvDrvCtxt);
    STDMETHODIMP OnDeleteRecoContext(void * pvDrvCtxt);
	
	STDMETHODIMP OnCreateGrammar(void * pvEngineRecoContext,
		SPGRAMMARHANDLE hSAPIGrammar,
		void ** ppvEngineGrammar);
	
    STDMETHODIMP OnDeleteGrammar(void * pvEngineGrammar);
	
    // CFG methods
    STDMETHODIMP WordNotify(SPCFGNOTIFY Action, ULONG cWords, const SPWORDENTRY * pWords);
    STDMETHODIMP RuleNotify(SPCFGNOTIFY Action, ULONG cRules, const SPRULEENTRY * pRules);
	
    // Proprietary grammar methods
    STDMETHODIMP LoadProprietaryGrammar(void * pvEngineGrammar, REFGUID rguidParam,
		const WCHAR * pszStringParam, const void * pvDataParam,
		ULONG ulDataSize, SPLOADOPTIONS Options);
    STDMETHODIMP UnloadProprietaryGrammar(void * pvEngineGrammar);
    STDMETHODIMP SetProprietaryRuleState(void * pvEngineGrammar, const WCHAR * pszName,
		void * pvReserved, SPRULESTATE NewState, ULONG * pcRulesChanged);
    STDMETHODIMP SetProprietaryRuleIdState(void * pvEngineGrammar, DWORD dwRuleId, SPRULESTATE NewState);
    STDMETHODIMP SetGrammarState(void * pvEngineGrammar, SPGRAMMARSTATE eGrammarState);
    STDMETHODIMP SetContextState(void * pvEngineContxt, SPCONTEXTSTATE eCtxtState);
	
    // Dictation methods
    STDMETHODIMP LoadSLM(void * pvEngineGrammar, const WCHAR * pszTopicName);
    STDMETHODIMP UnloadSLM(void * pvEngineGrammar);
    STDMETHODIMP SetSLMState(void * pvEngineGrammar, SPRULESTATE NewState);
	
    STDMETHODIMP IsPronounceable(void *pDrvGrammar, const WCHAR *pszWord, SPWORDPRONOUNCEABLE * pWordPronounceable);
    STDMETHODIMP SetWordSequenceData(void * pvEngineGrammar, const WCHAR * pText, ULONG cchText, const SPTEXTSELECTIONINFO * pInfo);
    STDMETHODIMP SetTextSelection(void * pvEngineGrammar, const SPTEXTSELECTIONINFO * pInfo);
    STDMETHODIMP SetAdaptationData(void * pvEngineCtxtCookie, const WCHAR * pText, const ULONG cch);    
	
    // Property methods
    STDMETHODIMP SetPropertyNum( SPPROPSRC eSrc, void* pvSrcObj, const WCHAR* pName, LONG lValue );
    STDMETHODIMP GetPropertyNum( SPPROPSRC eSrc, void* pvSrcObj, const WCHAR* pName, LONG * plValue );
    STDMETHODIMP SetPropertyString( SPPROPSRC eSrc, void* pvSrcObj, const WCHAR* pName, const WCHAR* pValue );
    STDMETHODIMP GetPropertyString( SPPROPSRC eSrc, void* pvSrcObj, const WCHAR* pName, WCHAR** ppCoMemValue );
	
	
    // The main recognition method
    STDMETHODIMP RecognizeStream(REFGUID rguidFmtId, const WAVEFORMATEX * pWaveFormatEx,
		HANDLE hRequestSync, HANDLE hDataAvailable,
		HANDLE hExit, BOOL fNewAudioStream, BOOL fRealTimeAudio,
		ISpObjectToken * pAudioObjectToken);
	
    STDMETHODIMP PrivateCall(void * pvEngineContext, void * pCallFrame, ULONG ulCallFrameSize);
    STDMETHODIMP PrivateCallEx(void * pvEngineContext, const void * pInCallFrame, ULONG ulCallFrameSize,
		void ** ppvCoMemResponse, ULONG * pcbResponse);
	
	
    // ISpThreadTask methods
    STDMETHODIMP InitThread( void * pvTaskData, HWND hwnd )
    {
        return S_OK;
    }
    LRESULT STDMETHODCALLTYPE WindowMessage( void *pvTaskData, HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam )
    {
        return E_UNEXPECTED;
    }
	
    STDMETHODIMP ThreadProc( void *pvTaskData, HANDLE hExitThreadEvent, HANDLE hNotifyEvent, HWND hwndWorker, volatile const BOOL * pfContinueProcessing );
};

#endif //__JULISAPIENGINE_H_
