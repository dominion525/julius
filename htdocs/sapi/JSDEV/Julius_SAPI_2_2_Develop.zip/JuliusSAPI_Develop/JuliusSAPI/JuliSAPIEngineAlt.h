// JuliSAPIEngineAlt.h : CJuliSAPIEngineAlt �̐錾

#ifndef __JULISAPIENGINEALT_H_
#define __JULISAPIENGINEALT_H_

#include "resource.h"       // ���C�� �V���{��

/////////////////////////////////////////////////////////////////////////////
// CJuliSAPIEngineAlt
class ATL_NO_VTABLE CJuliSAPIEngineAlt : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CJuliSAPIEngineAlt, &CLSID_JuliSAPIEngineAlt>
//	public IDispatchImpl<IJuliSAPIEngineAlt, &IID_IJuliSAPIEngineAlt, &LIBID_JULIUSSAPILib>
{
public:
	CJuliSAPIEngineAlt()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_JULISAPIENGINEALT)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CJuliSAPIEngineAlt)
//	COM_INTERFACE_ENTRY(IJuliSAPIEngineAlt)
//	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IJuliSAPIEngineAlt
    STDMETHODIMP GetAlternates( 
        SPPHRASEALTREQUEST *pAltRequest,
        SPPHRASEALT **ppAlts,
        ULONG *pcAlts);
    
    STDMETHODIMP Commit( 
        SPPHRASEALTREQUEST *pAltRequest,
        SPPHRASEALT *pAlt,
        void **ppvResultExtra,
        ULONG *pcbResultExtra);
public:
};

#endif //__JULISAPIENGINEALT_H_
