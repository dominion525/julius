#include <objbase.h>
#include <initguid.h>

#include "msime.h"

// �Q�l:http://www.ceres.dti.ne.jp/~goto-ta/windows/felang.html

class CIMEStringConvert
{
public:
	int Initialize(const char *imemodulename);
	int GetYomi(LPCSTR pszStr,LPSTR pszPhonetic,int nSize);
	int Release();
private:
	HRESULT m_hr;
	HINSTANCE m_hLib;
	IFELanguage* m_pILang;
};
