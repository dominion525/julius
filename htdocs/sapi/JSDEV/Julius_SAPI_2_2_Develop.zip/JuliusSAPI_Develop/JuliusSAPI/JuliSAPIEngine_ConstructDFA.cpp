//====================================================================
// JuliSAPIEngine_ConstructDFA.cpp: CJuliSAPIEngine �̃C���v�������g
//--------------------------------------------------------------------
// Copyright (c) 2002-2003 Takashi Sumiyoshi
// Speech Media Lab. Kyoto University     All rights reserved
//====================================================================

#include "stdafx.h"
#include "JuliSAPIEngine.h"
#include "JuliWinUtil.h"
#include "SpHelper.h"
#include "../j_modules/JuliDictionary.h"
#include "../j_modules/JuliGramDfa.h"
#include "JuliResultOutSAPI.h"
#include "DFA.h"
#include "NFA.h"

#include <queue>
#include <stack>
#include <algorithm>
#include <strstream>
using namespace std;

#define OUTPUTDFA 0

#if 0
// �t�B���[���f�������[�h���A�ǂݍ��ށB
// Grammar Handle �� 0xffffffff
HRESULT CJuliSAPIEngine::_AddFillerModel()
{
	J_DEBUGMESSAGE("_AddFillerModel\n");
	CComPtr<ISpRecoGrammar> cpFillerGrammar;
	HRESULT hr;
	hr = cpFillerGrammar->LoadCmdFromResource(g_hInst, L"IDR_GRAMMAR_FILLER", L"GRAMMAR", hoge, SPLO_STATIC);
	if (FAILED(hr))
	{
		J_ERROR("ERROR: Failed to Load Filler Grammar from Resource.\n");
		return hr;
	}
	SPRULEHANDLE hRule = 

	// Julius�R���e�N�X�g���쐬
	CJuliContext_SAPI *jc = new CJuliContext_SAPI();
	jc->SetGrammarHandle(0xffffffff);
	jc->SetRuleHandle(hRule);

	// ���ʏo�̓I�u�W�F�N�g���쐬
	CJuliResultOutSAPI *rosapi = new CJuliResultOutSAPI();
	rosapi->SetEngine(this);
	
	if (theContextManager.AddNewContext(jc, JULISLM_SAPIXML, rosapi) == NULL)
	{
		J_ERROR("Failed to AddNewContext\n");
		return 1;
	}
//	pGrammar->SetJuliContext(jc);
	pRuleEntry->SetJuliContext(jc);

	// CJuliSAPIEngine �I�u�W�F�N�g�̃R���e�N�X�g���X�g�Ƃ��Ēǉ�
	AddContext(jc);

	// ���@���쐬
	_MakeDictDfa(hRule, jc);	

	// ����
	jc->Prepare();

//	jc->GetDict()->OutputDebug();

	J_DEBUGMESSAGE("Done\n");
	return S_OK;
}
#endif

// Rule ���� Dictation �� Dfa ���쐬
int CJuliSAPIEngine::_ConstructDictDfa(CJuliSAPIRuleEntry *pRuleEntry, const SPRULEENTRY &rule)
{
	J_DEBUGMESSAGE("_ConstructDictDfa: ");

	// Julius�R���e�N�X�g���쐬
	CJuliContext_SAPI *jc = new CJuliContext_SAPI();
	CJuliSAPIGrammar *pGrammar = (CJuliSAPIGrammar *)rule.pvClientGrammarContext;
	jc->SetGrammarHandle(pGrammar->m_hSapiGrammar);
	jc->SetRuleHandle(rule.hRule);

	// ���ʏo�̓I�u�W�F�N�g���쐬
	CJuliResultOutSAPI *rosapi = new CJuliResultOutSAPI();
	rosapi->SetEngine(this);
	
	if (theContextManager.AddNewContext(jc, JULISLM_SAPIXML, rosapi) == NULL)
	{
		J_ERROR("Failed to AddNewContext\n");
		return 1;
	}
//	pGrammar->SetJuliContext(jc);
	pRuleEntry->SetJuliContext(jc);

	// CJuliSAPIEngine �I�u�W�F�N�g�̃R���e�N�X�g���X�g�Ƃ��Ēǉ�
	AddContext(jc);

	// ���@���쐬
	_MakeDictDfa(rule.hRule, jc);	

	// ����
	jc->Prepare();

//	jc->GetDict()->OutputDebug();

	J_DEBUGMESSAGE("Done.\n"); 
	return 0;
}


HRESULT CJuliSAPIEngine::_MakeDictDfa(SPRULEHANDLE hRule, CJuliContext_SAPI *jc)
{
	vector<SPWORDHANDLE> vec_wordindex_SPWORDHANDLE;	// WORD_ID -> SPWORDHANDLE �̃e�[�u��
	CDFA dfa;
	J_DEBUGMESSAGE("Rule->DFA,"); 
	_ConstructDFAFromRule(hRule, &dfa, vec_wordindex_SPWORDHANDLE);

#if 0
	J_DEBUGMESSAGE("_ConstructDictDfa: DFA�̌��ʂ�\��\n"); 
	{
		ostrstream sstrm;
		sstrm << dfa << '\0';
		J_DEBUGMESSAGE("%s", sstrm.str());
	}
#endif
	
//	jc->m_map_WORDID_SPTRANSITIONID = m_map_WORDID_SPTRANSITIONID;
	
#if 0
	// �����̈ꗗ(�f�o�b�O�p)
	J_DEBUGMESSAGE("_ConstructDictDfa: �����̈ꗗ\n"); 
	for (int i=0;i<vec_wordindex_SPWORDHANDLE.size();i++)
	{
		SPWORDENTRY WordEntry;
		WordEntry.hWord = vec_wordindex_SPWORDHANDLE[i];
		m_cpSite->GetWordInfo(&WordEntry, SPWIO_WANT_TEXT);
		
		char *phones = (char *)WordEntry.pvClientContext;
		
		J_MESSAGEW(L"wid=%d, SPWORDHANDLE=%d, TID=%d: %s %s", i, vec_wordindex_SPWORDHANDLE[i], m_map_WORDID_SPTRANSITIONID[i], WordEntry.pszDisplayText, WordEntry.pszLexicalForm);
		J_MESSAGE(" %s\n", phones);
		::CoTaskMemFree((void*)WordEntry.pszDisplayText);	// ��ΕK�v!!
		::CoTaskMemFree((void*)WordEntry.pszLexicalForm);	// ��ΕK�v!!
	}
#endif
	// DFA ���t�ɂ��đJ�ڂ��J�e�S�����A�擪��silB(1), �Ō�� silE(2) ��ǉ�
	CDFA dfa_final;
	{
		vector<set<short> > vec_Category_Words;	// �J�e�S�� -> wordindex�W��
		{
			CNFA nfa_rev;
			CDFA dfa_rev, dfa_group, dfa_group_sp;

			// ���](DFA->NFA)
			J_DEBUGMESSAGE("Rev,");
			dfa.Reverse(&nfa_rev);
			if (OUTPUTDFA) {
				ostrstream sstrm;
				sstrm << nfa_rev << '\0';
				J_DEBUGMESSAGE("%s", sstrm.str());
			}
			// NFA->DFA
			J_DEBUGMESSAGE("Dfa,"); 
			nfa_rev.Convert2DFA(&dfa_rev);
			if (OUTPUTDFA) {
				ostrstream sstrm;
				sstrm << dfa_rev << '\0';
				J_DEBUGMESSAGE("%s", sstrm.str());
			}
			// �O���[�v��
			J_DEBUGMESSAGE("Grouping,"); 
			dfa_rev.GroupingArcs(&dfa_group,&vec_Category_Words);
			if (OUTPUTDFA) {
				ostrstream sstrm;
				sstrm << dfa_group << '\0';
				J_DEBUGMESSAGE("%s", sstrm.str());
			}
			// SP �}��
			J_DEBUGMESSAGE("Sp,"); 
			dfa_group.InsertSp(&dfa_group_sp, 0);
			if (OUTPUTDFA) {
				ostrstream sstrm;
				sstrm << dfa_group_sp << '\0';
				J_DEBUGMESSAGE("%s", sstrm.str());
			}
			// �œK��
			J_DEBUGMESSAGE("Opt,"); 
			dfa_group_sp.Optimize(&dfa_final);
			if (OUTPUTDFA) {
				ostrstream sstrm;
				sstrm << dfa_final << '\0';
				J_DEBUGMESSAGE("%s", sstrm.str());
			}
		}
		// �O���[�v�����ꂽ�P��ɏォ��1��1�V����ID���ӂ�
		vector<short> m_WORDID_wordindex;	// �V����ID -> �Â�ID
		vector<short> m_WORDID_Category;	// �V����ID -> �J�e�S���ԍ�
			
		// �e�[�u���̍\�z������
		jc->m_map_WORDID_SPTRANSITIONID.clear();
			
		short cat =0;
		{
			int n=0;
			for (int g=0;g<(int )vec_Category_Words.size();g++)
			{
				for (set<short>::iterator it=vec_Category_Words[g].begin();it!=vec_Category_Words[g].end();it++)
				{
					m_WORDID_wordindex.push_back(*it);
					m_WORDID_Category.push_back(cat);

					jc->m_map_WORDID_SPTRANSITIONID[(n++)-3] = m_vec_wordindex_SPTRANSITIONID[*it-3];
//					J_DEBUGMESSAGE("Category %d : wordindex+3 %d : SPTRANSITIONID %d\n",
//						g, *it, m_vec_wordindex_SPTRANSITIONID[*it-3]);
				}
				cat++;
			}
#if 0
			// jc->m_map_WORDID_SPTRANSITIONID �̃G���g�����Ĕz�u
			map<int, SPTRANSITIONID> tmp = jc->m_map_WORDID_SPTRANSITIONID;
			
			for (map<int, SPTRANSITIONID>::iterator it = jc->m_map_WORDID_SPTRANSITIONID.begin();
			it != jc->m_map_WORDID_SPTRANSITIONID.end(); it++)
			{
				// SPTRANSITIONID ���A�Â�ID�̂��̂ɏ���������
				it->second = tmp[m_WORDID_wordindex[it->first+3]-3];
			}
#else

#endif
		}
		
		// �����ɒǉ�
		J_DEBUGMESSAGE("Dict,"); 
		vector<string> dict_data;	// dict �t�@�C���`��
		dict_data.push_back((string)"0\t[sp]\t"+jc->GetOptions()->GetSpName()+"\n");
		dict_data.push_back((string)"1\t[silB]\t"+jc->GetOptions()->GetBeginSilentPhone()+"\n");
		dict_data.push_back((string)"2\t[silE]\t"+jc->GetOptions()->GetEndSilentPhone()+"\n");
		
		for (int ii=3;ii<(int )m_WORDID_wordindex.size();ii++)
		{
#if 0
			J_MESSAGE("newID %d (oldID %d): ", ii, m_WORDID_wordindex[ii]);
#endif
			SPWORDENTRY WordEntry;
			WordEntry.hWord = vec_wordindex_SPWORDHANDLE[m_WORDID_wordindex[ii]-3];
			m_cpSite->GetWordInfo(&WordEntry, SPWIO_WANT_TEXT);
			
			char *phones = (char *)WordEntry.pvClientContext;
			char w[1024], buf[1024];
			CJuliWinUtil::WideCharToEuc(WordEntry.pszDisplayText, w);
			sprintf(buf, "%d\t[%s]\t%s\n", m_WORDID_Category[ii], w, phones);
#if 0
			J_MESSAGE("newcat:%s",buf);
#endif
			string str = buf;
			dict_data.push_back(str);
			
			::CoTaskMemFree((void*)WordEntry.pszDisplayText);	// ��ΕK�v!!
			::CoTaskMemFree((void*)WordEntry.pszLexicalForm);	// ��ΕK�v!!
		}

#if 0
		// �t�@�C���ɏo��
		{
			FILE *fp = fopen("C:\\juli.dict", "w");
			for (int i=0;i<dict_data.size();i++)
			{
				fputs(dict_data[i].c_str(),fp);
			}
			fclose(fp);
		}
#endif

#ifdef MONOTREE
		/* leave winfo monophone for 1st pass lexicon tree */
		jc->GetDict()->LoadHtkDict_forSAPI(dict_data, jc->GetHmm(), TRUE);
#else 
		jc->GetDict()->LoadHtkDict_forSAPI(dict_data, jc->GetHmm(), FALSE);
#endif
	}
	
	// DFA �̍\�z
	J_DEBUGMESSAGE("Dfa,"); 
	vector<int> stat, term, next,accept;
	for (int s=0;s<dfa_final.GetNumStates();s++)
	{
		if (dfa_final.GetState(s).GetNumArcs()==0)
		{
			stat.push_back(s);
			term.push_back(-1);
			next.push_back(-1);
			accept.push_back(dfa_final.GetState(s).IsAccept());
		} else
			for (int a=0;a<dfa_final.GetState(s).GetNumArcs();a++)
			{
				stat.push_back(s);
				term.push_back(dfa_final.GetState(s).GetArc(a).GetSymbol());
				next.push_back(dfa_final.GetState(s).GetArc(a).GetNextState());
				accept.push_back(dfa_final.GetState(s).IsAccept());
				//						J_MESSAGE("%d %d %d %x\n", stat[stat.size()-1], term[stat.size()-1], next[stat.size()-1], accept[stat.size()-1]);
			}
	}
#if 0
	// �t�@�C���ɏo��
	{
		FILE *fp = fopen("C:\\juli.dfa", "w");
		for (int i=0;i<stat.size();i++)
		{
			char buf[256];
			sprintf(buf, "%d %d %d %d\n", stat[i], term[i], next[i], accept[i]);
			fputs(buf,fp);
		}
		fclose(fp);
	}
#endif
	jc->GetGramDfa()->ReadDfa_forSAPI(stat, term, next, accept);

	return S_OK;
}


void CJuliSAPIEngine::_ConstructDFARecursive(CNFA *nfa, deque<SPRULEHANDLE> &rule_stack, deque<short> &initrulestate_stack, deque<short> &tostate_stack, deque<int> leftright_stack)
{
//	J_DEBUGMESSAGE("_ConstructDFARecursive(%d)\n", rule_stack.front());
	
	HRESULT hr = S_OK;
	SPRULEENTRY RuleInfo;
	
	RuleInfo.hRule = rule_stack.back();
	// RuleInfo.hRule ���� hInitialState �Ȃǂ𓾂�B
	hr = m_cpSite->GetRuleInfo(&RuleInfo, SPRIO_NONE);
	if (FAILED(hr))
	{
		J_ERROR("Error: GetRuleInfo Failed (hRule = %p)\n", RuleInfo.hRule);
		return;
	}
	
	SPSTATEHANDLE hState = RuleInfo.hInitialState;
	short initstate = _GetStateIDFromTable(hState, rule_stack, tostate_stack.back());
    CSpStateInfo StateInfo;
	
	// ���̃��[�����̏�Ԃ𕝗D��T�����邽�߂̃L���[
	vector<SPSTATEHANDLE> queue_state;
	queue_state.push_back(hState);
	
	// ���[�v
	for (int i=0;i<(int )queue_state.size();i++)
	{
		hState = queue_state[i];
		short nowstate = _GetStateIDFromTable(hState, rule_stack, tostate_stack.back());
		
        hr = m_cpSite->GetStateInfo(hState, &StateInfo);
        if (SUCCEEDED(hr))
        {
            ULONG cTransInState = StateInfo.cEpsilons + StateInfo.cWords + StateInfo.cRules
				+ StateInfo.cSpecialTransitions;
            if (cTransInState == 0)
            {
				J_ERROR("Error: No Transition State is Found!\n");
                // ����Ԃւ̑J�ڂ��Ȃ� --- Error
                hr = E_FAIL;
                break;
            }
			for (int i=0;i<(int )cTransInState;i++)
			{
				SPTRANSITIONENTRY * pTransEntry = StateInfo.pTransitions + i;
				short tostate = _GetStateIDFromTable(pTransEntry->hNextState, rule_stack,
					tostate_stack.back());

				switch(pTransEntry->Type)
				{
				case SPTRANSEPSILON:
//					J_DEBUGMESSAGE("%d(%d) --��--> %d(%d)\n", nowstate, rule_stack.size(), tostate, rule_stack.size());
					nfa->GetState(nowstate).AddArc(-1, tostate);
					break;
				case SPTRANSWORD:
					// �P��ID�̎Q��
					{
						int wordid = _GetWordIDFromTable(pTransEntry->ID, pTransEntry->hWord);	// �J��ID�Ŕ��ʂ���ق����֗��H
//						int wordid = _GetWordIDFromTable(pTransEntry->hWord);
#if 0
						SPWORDENTRY WordEntry;
						WordEntry.hWord = pTransEntry->hWord;
						hr = m_cpSite->GetWordInfo(&WordEntry, SPWIO_WANT_TEXT);
						J_MESSAGEW(L"%d(%d) --[%d:%s]--> %d(%d)\n", nowstate, rule_stack.size(), wordid, WordEntry.pszDisplayText, tostate, rule_stack.size());
						J_MESSAGEW(L"%d[%s]---%p\n", wordid, WordEntry.pszDisplayText, pTransEntry->ID);
						::CoTaskMemFree((void*)WordEntry.pszDisplayText);	// ��ΕK�v!!
						::CoTaskMemFree((void*)WordEntry.pszLexicalForm);	// ��ΕK�v!!
#endif
						nfa->GetState(nowstate).AddArc(wordid, tostate);
					}
					break;
				case SPTRANSRULE:
					{
						int call_rstate = 0;
						SPRULEHANDLE hRule = pTransEntry->hRule;
						if (pTransEntry->hNextState != NULL)
						{
							call_rstate |= 2;	// �E�ɂ���ɑJ�ڂ����݂���
						}
						if (nowstate != initstate)
						{
							call_rstate |= 1;	// ���ɂ���ɑJ�ڂ����݂���
						}
						// ���[�������[���X�^�b�N�ɂ��邩
						deque<SPRULEHANDLE>::iterator it;
						if ((it = find(rule_stack.begin(), rule_stack.end(), hRule)) != rule_stack.end())
						{
							// �X�^�b�N�ɂ���ꍇ�́A�ċA�̉���
//							J_DEBUGMESSAGE("Resolving Self Recursion (Right Recursion)...\n");

							// �W�����v�惋�[�����猻�݂̃��[���܂ł́A�ċA�����`�F�b�N
							// ���ċA�������������`�F�b�N���Ă���
							int leftright = call_rstate;
							deque<int>::iterator it2;
							for (it2 = leftright_stack.begin() + (it-rule_stack.begin()) + 1; it2 != leftright_stack.end(); it2++)
							{
								leftright |= *it2;
							}
							if (leftright == 3)
							{
								J_ERROR("Error! This Grammar can't be a Regular Grammar\n");
								continue;
							}
							if (leftright == 2)
							{
								J_ERROR("Error! This Grammar includes Left Recursion\n");
								continue;
							}
							// ������ԂփÑJ��

							// find ��̃��[���̏�����Ԃł���K�v������
							// nfa->GetState(nowstate).AddArc(-1, initstate);
							// J_DEBUGMESSAGE("%d(%d) --��--> %d(%d)\n", nowstate, rule_stack.size(), initstate, rule_stack.size());
							nfa->GetState(nowstate).AddArc(-1, *(initrulestate_stack.begin()+(it-rule_stack.begin())));
						} else {
							// �X�^�b�N�ɖ����ꍇ�́A�ċA�Ăяo��
							rule_stack.push_back(hRule);
							initrulestate_stack.push_back(initstate);
							{
								// ���[���̏�����ԂփÑJ��
								RuleInfo.hRule = hRule;
								hr = m_cpSite->GetRuleInfo(&RuleInfo, SPRIO_NONE);
								SPSTATEHANDLE hState = RuleInfo.hInitialState;
								int ristate = _GetStateIDFromTable(hState, rule_stack, tostate_stack.back());
//								J_DEBUGMESSAGE("%d(%d) --��--> %d(%d)\n", nowstate, rule_stack.size()-1, ristate, rule_stack.size());
								nfa->GetState(nowstate).AddArc(-1, ristate);
							}
							// ���[���̎󗝏�Ԃ̏��ID�́Atostate
							tostate_stack.push_back(tostate);
							leftright_stack.push_back(call_rstate);
							_ConstructDFARecursive(nfa, rule_stack, initrulestate_stack, tostate_stack, leftright_stack);
							leftright_stack.pop_back();
							tostate_stack.pop_back();
							rule_stack.pop_back();
							initrulestate_stack.pop_back();
						}
					}
					break;
				}
				// ����Ԃ�NULL����Ȃ��ꍇ�L���[��
				if (pTransEntry->hNextState != NULL)
				{
					if (find(queue_state.begin(), queue_state.end(), pTransEntry->hNextState)
						== queue_state.end())
						queue_state.push_back(pTransEntry->hNextState);
				}
            }
        }
    }
//	J_DEBUGMESSAGE("End _ConstructDFARecursive(%d)\n", rule_stack.front());
}

void CJuliSAPIEngine::_ConstructDFAFromRule(SPRULEHANDLE hRule, CDFA *dfa, vector<SPWORDHANDLE> & _vec_wordindex_SPWORDHANDLE)
{
	// (rddfa ���ۂ����Ƃ�����)
	// hRule ��������ԂƂ��� DFA �𐶐�����B
	_ClearMaps();
	
	CNFA nfa;
	nfa.CreateStates(50000);	// TODO: �\���ȏ�Ԑ�
	nfa.GetState(0).SetInitial(1);
	
	// ���[���̍ċA�Ăяo���X�^�b�N
	deque<SPRULEHANDLE> stackRule;
	stackRule.push_front(hRule);

	// 0��������ԁA1���󗝏�ԂƂ�����
	SPRULEENTRY RuleInfo;
	HRESULT hr;
	RuleInfo.hRule = stackRule.front();
	// RuleInfo.hRule ���� hInitialState �Ȃǂ𓾂�B
	hr = m_cpSite->GetRuleInfo(&RuleInfo, SPRIO_NONE);
	SPSTATEHANDLE hRuleInitialState = RuleInfo.hInitialState;

	// ������ԁA�󗝏�Ԃ�\��A�o�^���Ă���
	int initial_state_id = _GetStateIDFromTable(hRuleInitialState, stackRule, 0);
	assert(initial_state_id == 0);
	int accept_state_id = _GetStateIDFromTable((SPSTATEHANDLE)0xffffffff, stackRule, 0);
	assert(accept_state_id == 1);	// ���Ƃ��Ԃ�Ȃ����S�z
	nfa.GetState(1).SetAccept(1);
	
	// ���[���̏�����ԁA����ԃX�^�b�N
	deque<short> stackInitState, stackToState;
	stackInitState.push_front(0);
	stackToState.push_front(1);

	deque<int> stackLeftRight;
	stackLeftRight.push_front(0);

	_ConstructDFARecursive(&nfa, stackRule, stackInitState, stackToState, stackLeftRight);
	
	// NFA �� DFA �ɂ��čœK��
#if 1
	CDFA dfa_org;
	nfa.Convert2DFA(&dfa_org);
	dfa_org.Optimize(dfa);
	J_MESSAGE("Dfa : %d states -> Optimized %d states\n",
		dfa_org.GetNumStates(),
		dfa->GetNumStates());
#else 
	nfa.Convert2DFA(dfa);
#endif
	_vec_wordindex_SPWORDHANDLE = m_vec_wordindex_SPWORDHANDLE;
}

short CJuliSAPIEngine::_GetStateIDFromTable(SPSTATEHANDLE hState, const deque<SPRULEHANDLE> &rule_stack,
										  short acceptstate)
{
	short s;
	// �󗝏�ԂȂ炻��ID��Ԃ�
	if (hState == NULL) return acceptstate;
	// ��ԃC���f�b�N�X���Q�� �Ȃ���΍쐬
	pair<SPSTATEHANDLE, deque<SPRULEHANDLE> > p;
	p.first = hState;
	p.second = rule_stack;
	map<pair<SPSTATEHANDLE, deque<SPRULEHANDLE> >, short>::iterator it = m_mapHStateIndex.find(p);
	if (it==m_mapHStateIndex.end())
	{
		s = m_mapHStateIndex.size();
		m_mapHStateIndex[p] = s;
	} else {
		s = m_mapHStateIndex[p];
	}
	return s;
}

int CJuliSAPIEngine::_GetWordIDFromTable(SPTRANSITIONID id, SPWORDHANDLE hWord)
{
	int s;
	// �P��C���f�b�N�X���Q�� �Ȃ���΍쐬
	map<SPTRANSITIONID, short>::iterator it = m_map_SPTRANSITIONID_wordindex.find(id);
	if (it==m_map_SPTRANSITIONID_wordindex.end())
	{
		s = m_map_SPTRANSITIONID_wordindex.size();
		m_map_SPTRANSITIONID_wordindex[id] = s;
		// �P��C���f�b�N�X -> SPWORDHANDLE �e�[�u��
		m_vec_wordindex_SPWORDHANDLE.push_back(hWord);
		// �P��C���f�b�N�X -> SPTRANSITIONID
		m_vec_wordindex_SPTRANSITIONID.push_back(id);
	} else {
		s = m_map_SPTRANSITIONID_wordindex[id];
	}
	return s;
}
