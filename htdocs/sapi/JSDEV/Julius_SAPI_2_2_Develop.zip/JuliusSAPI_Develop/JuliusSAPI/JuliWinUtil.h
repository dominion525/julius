// JuliWinUtil.h: CJuliWinUtil �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JULIWINUTIL_H__C2A2B64D_9809_4971_B87A_EA1ED2BF9E82__INCLUDED_)
#define AFX_JULIWINUTIL_H__C2A2B64D_9809_4971_B87A_EA1ED2BF9E82__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>

class CIMEStringConvert;

#include <string>
#include <vector>
using namespace std;

class CJuliWinUtil
{
public:
	CJuliWinUtil();
	virtual ~CJuliWinUtil();
	static HRESULT Init();
	static void Release();

	static void Euc2Sjis_OverWrite(char *str);
	static int WideCharToPhone(const WCHAR *wcstr, char *outstr);
	static int WideCharToEuc(const WCHAR *wcstr, char *outstr);

	static wchar_t * PhonemesToPhoneIDs(vector<string> &phonemes);
private:
	static CIMEStringConvert * m_pISC; 
};

#endif // !defined(AFX_JULIWINUTIL_H__C2A2B64D_9809_4971_B87A_EA1ED2BF9E82__INCLUDED_)
