//====================================================================
// JuliSAPIEngineAlt.cpp: CJuliSAPIEngineAlt �̃C���v�������g
//--------------------------------------------------------------------
// Copyright (c) 2001 Takashi Sumiyoshi
// Speech Media Lab. Kyoto University     All rights reserved
//====================================================================
#include "stdafx.h"
#include "JuliusSAPI.h"
#include "JuliSAPIEngineAlt.h"

STDMETHODIMP CJuliSAPIEngineAlt::GetAlternates(SPPHRASEALTREQUEST *pAltRequest,
    SPPHRASEALT **ppAlts, ULONG *pcAlts)
{
    return S_OK;
}
    
STDMETHODIMP CJuliSAPIEngineAlt::Commit(SPPHRASEALTREQUEST *pAltRequest,
    SPPHRASEALT *pAlt, void **ppvResultExtra, ULONG *pcbResultExtra)
{
    return S_OK;
}
