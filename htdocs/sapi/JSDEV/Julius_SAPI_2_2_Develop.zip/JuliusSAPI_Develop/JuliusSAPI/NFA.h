//====================================================================
// NFA.h: NFA ���\�z����
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Speech Media Lab. Kyoto University     All rights reserved
//====================================================================

#if !defined(AFX_NFA_H__B552E333_A825_4AD4_9FC6_C4A469CA117E__INCLUDED_)
#define AFX_NFA_H__B552E333_A825_4AD4_9FC6_C4A469CA117E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <iostream>
#include <vector>
#include <set>
using namespace std;
// #define NDEBUG (���邢�� /D �I�v�V����)�� assert �͏�����Ԃ炵��
#include <assert.h>

class CDFA;

// ���[�U�f�[�^�Ƃ��ă����o�� void * ��������
#define NFA_SUPPORT_USERDATA

// �}
class CNFAArc
{
public:
	void SetSymbol(short s) { m_sSymbol = s;}
	short GetSymbol() { return m_sSymbol; }
	void SetNextState(short n) { m_sNextState = n; }
	short GetNextState() { return m_sNextState; }

	int IsEpsillon() { return (m_sSymbol==-1)?1:0; }
private:
	short m_sSymbol;	// �J�ڋL�� -1: �ÑJ��
	short m_sNextState;	// �����

#ifdef NFA_SUPPORT_USERDATA
public:
	void SetUserData(void *p) { m_pUserData = p; }
	void * GetUserData() { return m_pUserData; }
private:
	void *m_pUserData;
#endif
};

// ���
class CNFAState
{
public:
	CNFAState() : m_bFlag(0) {}
	int AddArc(int symbol, int next) { CNFAArc a;a.SetSymbol(symbol); a.SetNextState(next);m_vArcs.push_back(a); return 0; }
	int GetNumArcs() { return m_vArcs.size(); }
	CNFAArc & GetArc(int a) { assert(a>=0 && a<GetNumArcs()); return m_vArcs[a]; }

	int GetFlag() { return m_bFlag; }
	void SetAccept(int a) { m_bFlag = (m_bFlag & ~1) | a?1:0;}
	void SetInitial(int a) { m_bFlag = (m_bFlag & ~2) | a?2:0;}
	int IsAccept() { return (m_bFlag & 1)?1:0;}
	int IsInitial() { return (m_bFlag & 2)?1:0;}
private:
	vector<CNFAArc> m_vArcs;	// �}
	int m_bFlag;	// �t���O &1: �󗝏��

#ifdef NFA_SUPPORT_USERDATA
public:
	void SetUserData(void *p) { m_pUserData = p; }
	void * GetUserData() { return m_pUserData; }
private:
	void *m_pUserData;
#endif
};

class CNFA;

ostream & operator<<(ostream &ost, CNFA &nfa);

typedef set<short> STATESET;	// ��ԏW��

class CNFA
{
public:
	CNFA();
	virtual ~CNFA();

	int CreateStates(int num);
	int GetNumStates() { return m_iNumStates; }
	CNFAState & GetState(int s) { assert(s>=0 && s<m_iNumStates); return m_pStates[s]; }

	int Convert2DFA(CDFA *dfa);
	friend ostream & operator<<(ostream &ost, CNFA &nfa);
private:
	int GetStatesForEpsillon(int s, STATESET *ss);
	int m_iNumStates;		// ��Ԑ�
	CNFAState * m_pStates; // ���
};

#endif // !defined(AFX_NFA_H__B552E333_A825_4AD4_9FC6_C4A469CA117E__INCLUDED_)
