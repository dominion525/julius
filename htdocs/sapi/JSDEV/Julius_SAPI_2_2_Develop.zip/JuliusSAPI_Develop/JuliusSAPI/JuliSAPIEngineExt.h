// JuliSAPIEngineExt.h : CJuliSAPIEngineExt �̐錾

#ifndef __JULISAPIENGINEEXT_H_
#define __JULISAPIENGINEEXT_H_

#include "stdafx.h" 
#include "resource.h"       // ���C�� �V���{��

/////////////////////////////////////////////////////////////////////////////
// CJuliSAPIEngineExt
class ATL_NO_VTABLE CJuliSAPIEngineExt : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CJuliSAPIEngineExt, &CLSID_JuliSAPIEngineExt>,
	public IDispatchImpl<IJuliSAPIEngineExt, &IID_IJuliSAPIEngineExt, &LIBID_JULIUSSAPILib>
{
public:
	CJuliSAPIEngineExt()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_JULISAPIENGINEEXT)
DECLARE_GET_CONTROLLING_UNKNOWN()
DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CJuliSAPIEngineExt)
	COM_INTERFACE_ENTRY(IJuliSAPIEngineExt)
//	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

    HRESULT FinalConstruct()
    {
        // We can query back to SAPI to find both the reco context, and,
        // an IID__ISpPrivateEngineCall interface which can be used to call
        // back to the main engine object.
        HRESULT hr;
        hr = OuterQueryInterface(IID__ISpPrivateEngineCall, (void **)&m_pEngineCall);
        if(SUCCEEDED(hr))
        {
            hr = OuterQueryInterface(IID_ISpRecoContext, (void **)&m_pRecoCtxt);
            if (SUCCEEDED(hr))
            {
                GetControllingUnknown()->Release();
            }
        }
        return hr;
    }
// IJuliSAPIEngineExt
    STDMETHODIMP SkipNext2ndPass(void); // Just a test method
public:
private:
    _ISpPrivateEngineCall *m_pEngineCall;
    ISpRecoContext *m_pRecoCtxt;
};

#endif //__JULISAPIENGINEEXT_H_
