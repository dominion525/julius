// JuliAudioSourceSAPI.h: CJuliAudioSourceSAPI �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JULIAUDIOSOURCESAPI_H__71BEDA25_624B_11D5_9AFA_008098E80572__INCLUDED_)
#define AFX_JULIAUDIOSOURCESAPI_H__71BEDA25_624B_11D5_9AFA_008098E80572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../j_modules/JuliAudioSource.h"

class CJuliSAPIEngine;

class CJuliAudioSourceSAPI : public CJuliAudioSource  
{
public:
	CJuliAudioSourceSAPI(const char *logfile = NULL);
	virtual ~CJuliAudioSourceSAPI();

	void SetEngine(CJuliSAPIEngine *e) { m_Engine = e; }
	int OnStartAudioCut();
	int OnEndAudioCut();
	int OnStartSound(int pos);
	int OnSilent(int pos);
	int OnEndSound();

	// SAPI �� Site ����T���v����ǂݍ���
	int Read(SP16* buf, int sampnum);
private:
	CJuliSAPIEngine *m_Engine;
};

#endif // !defined(AFX_JULIAUDIOSOURCESAPI_H__71BEDA25_624B_11D5_9AFA_008098E80572__INCLUDED_)
