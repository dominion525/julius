// JuliSAPIEngineUI.h : CJuliSAPIEngineUI �̐錾

#ifndef __JULISAPIENGINEUI_H_
#define __JULISAPIENGINEUI_H_

#include "resource.h"       // ���C�� �V���{��

#include "../j_modules/JuliGlobalOption.h"

/////////////////////////////////////////////////////////////////////////////
// CJuliSAPIEngineUI
class ATL_NO_VTABLE CJuliSAPIEngineUI : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CJuliSAPIEngineUI, &CLSID_JuliSAPIEngineUI>,
//	public IDispatchImpl<IJuliSAPIEngineUI, &IID_IJuliSAPIEngineUI, &LIBID_JULIUSSAPILib>,
	public ISpTokenUI
{
public:
	CJuliSAPIEngineUI()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_JULISAPIENGINEUI)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CJuliSAPIEngineUI)
    	COM_INTERFACE_ENTRY(ISpTokenUI)
//	COM_INTERFACE_ENTRY(IJuliSAPIEngineUI)
//	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IJuliSAPIEngineUI
public:
    STDMETHODIMP IsUISupported(const WCHAR * pszTypeOfUI, void * pvExtraData, ULONG cbExtraData,
								IUnknown * punkObject, BOOL *pfSupported);
    STDMETHODIMP DisplayUI(HWND hwndParent, const WCHAR * pszTitle, const WCHAR * pszTypeOfUI,
                    void * pvExtraData, ULONG cbExtraData, ISpObjectToken * pToken, IUnknown * punkObject);

	CJuliGlobalOption m_gopt;
private:
	int DoEngineProperty(HWND hwndParent);
	static int InitAudioDialog(HWND hwndDlg);
	static int InitAnalyzeDialog(HWND hwndDlg);
	static int InitLmDialog(HWND hwndDlg);
	static int InitAmDialog(HWND hwndDlg);
	static int InitMainDialog(HWND hwndDlg);
	static int InitDecodeDialog(HWND hwndDlg);
	static int InitCMNSSDialog(HWND hwndDlg);
	static int InitEx1Dialog(HWND hwndDlg);

	static int RefreshAudioDialog(HWND hwndDlg);
	static int RefreshAnalyzeDialog(HWND hwndDlg);
	static int RefreshLmDialog(HWND hwndDlg);
	static int RefreshAmDialog(HWND hwndDlg);
	static int RefreshMainDialog(HWND hwndDlg);
	static int RefreshDecodeDialog(HWND hwndDlg);
	static int RefreshCMNSSDialog(HWND hwndDlg);
	static int RefreshEx1Dialog(HWND hwndDlg);

	static BOOL CALLBACK EnginePropertiesDialogProc(HWND hwndDlg,UINT uMsg,WPARAM wParam,LPARAM lParam);
	static BOOL CALLBACK EnginePropertiesAudioProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
	static BOOL CALLBACK EnginePropertiesAnalyzeProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
	static BOOL CALLBACK EnginePropertiesMainProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	static BOOL CALLBACK EnginePropertiesLmProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	static BOOL CALLBACK EnginePropertiesAmProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	static BOOL CALLBACK EnginePropertiesDecodeProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	static BOOL CALLBACK EnginePropertiesCMNSSProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	static BOOL CALLBACK EnginePropertiesAboutProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	static BOOL CALLBACK EnginePropertiesEx1Proc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
};

#endif //__JULISAPIENGINEUI_H_
