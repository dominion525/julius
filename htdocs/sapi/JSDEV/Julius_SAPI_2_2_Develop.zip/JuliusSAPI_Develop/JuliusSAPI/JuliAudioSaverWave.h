#pragma once

#include "../j_modules/JuliGlobalOption.h"
#include "../j_modules/juliaudiosource.h"
#pragma comment(lib, "winmm.lib" )

class CJuliAudioSaverWave : public CJuliAudioSaver
{
public:
	CJuliAudioSaverWave() : m_fOpened(0), m_hmmio(NULL), m_iCount(0),
		m_strBaseFileName("./JuliusLog") {}
	~CJuliAudioSaverWave()	{	CloseFile();	}

	// �ۑ�����t�@�C�������w��
	void SetBaseFileName(const char *f) { m_strBaseFileName = f; }

	int Init() { return 0; }
	void Release() { }

	void Start()
	{
		char b[20];
		sprintf(b, "%03d.wav", m_iCount);
		m_strNowFileName = m_strBaseFileName + b;
	}
	void End()
	{
		m_iCount++;
		CloseFile();
	}

	// ��������
	int Write(const char *b, int size)
	{
		// �t�@�C�����I�[�v������Ă��Ȃ���΃I�[�v������
		if (m_fOpened == 0) CreateNewFile();
		if (m_fOpened)
		{
			mmioWrite(m_hmmio, (const char *)b, size);
		}
		return 0;
	}
private:
	string m_strBaseFileName;
	string m_strNowFileName;
	int m_iCount;
	HMMIO m_hmmio;
	int m_fOpened;
	MMCKINFO ckinfo_RIFF;
	MMCKINFO ckinfo_data;

	// �t�@�C�����쐬���A�w�b�_������������
	int CreateNewFile()
	{
		MMIOINFO info;
		int ret;

		ZeroMemory(&info, sizeof(info));

		char buf[1024];
		strcpy(buf, m_strNowFileName.c_str());
		m_hmmio = mmioOpen(buf, &info, MMIO_CREATE | MMIO_WRITE);
		if (! m_hmmio) return 1;

		mmioSeek(m_hmmio, 0, SEEK_SET);
		ckinfo_RIFF.fccType = mmioFOURCC('W','A','V','E');
		ckinfo_RIFF.cksize = 0;
		ret = mmioCreateChunk(m_hmmio, &ckinfo_RIFF, MMIO_CREATERIFF);
		if (ret != MMSYSERR_NOERROR) return 1;

		{
			MMCKINFO ckinfo_fmt;
			ckinfo_fmt.ckid = mmioFOURCC('f','m','t',' ');
			ckinfo_fmt.cksize = sizeof(WAVEFORMATEX);
			ret = mmioCreateChunk(m_hmmio, &ckinfo_fmt, 0);
			if (ret != MMSYSERR_NOERROR) return 1;

			WAVEFORMATEX wfx;
			wfx.wFormatTag = WAVE_FORMAT_PCM;
			wfx.nChannels = 1;
			wfx.nSamplesPerSec = theOpt.smpFreq;
			wfx.nAvgBytesPerSec = theOpt.smpFreq;
			wfx.nBlockAlign = 2;
			wfx.wBitsPerSample = 16;
			wfx.cbSize = 0;
			long nWrite = mmioWrite(m_hmmio, (const char *)&wfx, sizeof(WAVEFORMATEX));
			if (nWrite != sizeof(WAVEFORMATEX))	return 1;
			mmioAscend(m_hmmio, &ckinfo_fmt, 0);
		}

		ckinfo_data.ckid = mmioFOURCC('d','a','t','a');
		ckinfo_data.cksize = 0;
		ret = mmioCreateChunk(m_hmmio, &ckinfo_data, 0);
		if (ret != MMSYSERR_NOERROR) return 1;

		m_fOpened =1;

		return 0;
	}

	void CloseFile()
	{
		if (m_fOpened)
		{
			mmioAscend(m_hmmio, &ckinfo_data, 0);

			mmioAscend(m_hmmio, &ckinfo_RIFF, 0);

			mmioFlush(m_hmmio, 0);
			mmioClose(m_hmmio, 0);
			m_fOpened = 0;
		}
	}
};
