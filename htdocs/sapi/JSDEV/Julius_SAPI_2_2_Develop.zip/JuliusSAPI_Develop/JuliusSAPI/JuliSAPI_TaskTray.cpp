#include "julisapi_tasktray.h"

#define MYMSG_TRAY WM_USER
#define ID_MYTRAY 101

CJuliSAPI_TaskTray theTaskTray;

CJuliSAPI_TaskTray::CJuliSAPI_TaskTray(void)
: m_hwndDummy(NULL)
{
}

CJuliSAPI_TaskTray::~CJuliSAPI_TaskTray(void)
{
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	return 0;
}

int CJuliSAPI_TaskTray::Init(HINSTANCE hInst)
{
	if (m_hwndDummy == NULL)
	{
		// �E�B���h�E�N���X���̐ݒ�
		LPCTSTR lpszMyClassName = "JuliusSAPIDummyWindow";  // �K���Ȗ��O������

		// �E�B���h�E �N���X�̓o�^ (�_�~�[�̃E�B���h�E)
		WNDCLASSEX wcex;
		wcex.cbSize			= sizeof(WNDCLASSEX);
		wcex.style			= 0;
		wcex.lpfnWndProc	= (WNDPROC)WndProc;
		wcex.cbClsExtra		= 0;
		wcex.cbWndExtra		= 0;
		wcex.hInstance		= hInst;
		wcex.hIcon			= NULL;
		wcex.hCursor		= NULL;
		wcex.hbrBackground	= NULL;
		wcex.lpszMenuName	= NULL;
		wcex.lpszClassName	= lpszMyClassName;
		wcex.hIconSm        = NULL;

		if (!RegisterClassEx(&wcex))
			return 1;

		// �E�B���h�E�̍쐬 (�_�~�[�̃E�B���h�E)
		m_hwndDummy = CreateWindowEx(NULL,
			lpszMyClassName, NULL, 0, CW_USEDEFAULT, 0,
			CW_USEDEFAULT, 0, HWND_MESSAGE , NULL, hInst, NULL);

		if(! m_hwndDummy)
			return GetLastError();

		// �A�C�R���̓o�^
		HICON hIcon;
		NOTIFYICONDATA nid;

		hIcon = LoadIcon(hInst, "IDI_ENGINE_PAGE_ABOUT");
		nid.cbSize	= sizeof(NOTIFYICONDATA);
		nid.hIcon	= hIcon;
		nid.hWnd	= m_hwndDummy;
		nid.uCallbackMessage = MYMSG_TRAY;
		nid.uFlags	= NIF_ICON | NIF_MESSAGE | NIF_TIP;
		nid.uID		= ID_MYTRAY;
		strcpy(nid.szTip, "Julius for SAPI SAPI SAPI!");

		Shell_NotifyIcon(NIM_ADD, &nid);
	}
	return 0;
}

