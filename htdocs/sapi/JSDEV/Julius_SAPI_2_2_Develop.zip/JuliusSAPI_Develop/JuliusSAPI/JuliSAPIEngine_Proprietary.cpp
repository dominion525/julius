//====================================================================
// JuliSAPIEngine_Proprietary.cpp: CJuliSAPIEngine �̃C���v�������g
//     (Un)LoadProprietaryGrammar
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Speech Media Lab. Kyoto University     All rights reserved
//====================================================================

#include "stdafx.h"
#include "JuliSAPIEngine.h"

#include "SpHelper.h"
//#include "shfolder.h"

//====================================================================
// CJuliSAPIEngine::LoadProprietaryGrammar
//		�G���W���ŗL���@�̓ǂݍ��� (.dfa & .dict ���T�|�[�g)
//---- �Ԃ�l --------------------------------------------------------
// ������
//---- ���� ----------------------------------------------------------
// void * pvEngineGrammar		[in] 
// REFGUID rguidParam			[in] ���@�̃��j�[�NID
// const WCHAR * pszStringParam	[in] ���@�̕�����f�[�^
// const void * pvDataParam		[in] ���@�̃C���[�W�f�[�^�ւ̃|�C���^
// ULONG ulDataSize				[in] ���@�̃C���[�W�f�[�^�̃T�C�Y
// SPLOADOPTIONS Options		[in] SPLOADOPTIONS �\����(RULE ���ύX����邩�ǂ���)
//====================================================================
STDMETHODIMP CJuliSAPIEngine::LoadProprietaryGrammar(void * pvEngineGrammar, 
													 REFGUID rguidParam, 
													 const WCHAR * pszStringParam,
													 const void * pvDataParam, 
													 ULONG ulDataSize, 
													 SPLOADOPTIONS Options)
{
    J_DEBUGMESSAGE("��LoadProprietaryGrammar(%d)\n", ulDataSize);
	return E_NOTIMPL;
}

STDMETHODIMP CJuliSAPIEngine::UnloadProprietaryGrammar(void * pvEngineGrammar)
{
    J_DEBUGMESSAGE("��UnloadProprietaryGrammar(%p)\n", pvEngineGrammar);
	return E_NOTIMPL;
}

STDMETHODIMP CJuliSAPIEngine::SetProprietaryRuleState(void * pvEngineGrammar,
													  const WCHAR * pszName,
													  void * pvReserved,
													  SPRULESTATE NewState,
													  ULONG * pcRulesChanged)
{
    J_DEBUGMESSAGE("��SetProprietaryRuleState(%p)\n", pvEngineGrammar);
	return E_NOTIMPL;
}
STDMETHODIMP CJuliSAPIEngine::SetProprietaryRuleIdState(void * pvEngineGrammar, 
														DWORD dwRuleId,
														SPRULESTATE NewState)
{
    J_DEBUGMESSAGE("��SetProprietaryRuleIdState(%p)\n", pvEngineGrammar);
	return E_NOTIMPL;
}

STDMETHODIMP CJuliSAPIEngine::SetGrammarState(void * pvEngineGrammar, SPGRAMMARSTATE eGrammarState)
{
    J_DEBUGMESSAGE("��SetGrammarState(%p, %d)\n", pvEngineGrammar, eGrammarState);

	return S_OK;
}
STDMETHODIMP CJuliSAPIEngine::SetContextState(void * pvEngineContxt, SPCONTEXTSTATE eCtxtState)
{
    J_DEBUGMESSAGE("��SetContextState(%p)\n", pvEngineContxt);
	return S_OK;
}
