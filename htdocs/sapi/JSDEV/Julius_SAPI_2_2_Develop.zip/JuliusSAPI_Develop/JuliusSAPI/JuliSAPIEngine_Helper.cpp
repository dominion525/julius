//====================================================================
// JuliSAPIEngine_Initialize.cpp: CJuliSAPIEngine �̃C���v�������g
//     �p�����Ă��Ȃ��A�w���p�[���\�b�h
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Speech Media Lab. Kyoto University     All rights reserved
//====================================================================

#include "stdafx.h"
#include "JuliSAPIEngine.h"

#include "SpHelper.h"
//#include "shfolder.h"

static const WCHAR DICT_WORD[] = L"Blah"; // This is the default word the sample engine uses for dictation
static const WCHAR ALT_WORD[] = L"Alt"; // This is the default word used for alternates

//====================================================================
// CJuliSAPIEngine::_GetSpEventEnumString
//		�f�o�b�O�p�ɁASPEVENTENUM �̃V���{���𕶎���Ƃ��ĕԂ��֐�
//---- �Ԃ�l --------------------------------------------------------
// ������
//---- ���� ----------------------------------------------------------
// SPEVENTENUM e	[in] ID
//====================================================================
const char * CJuliSAPIEngine::_GetSpEventEnumString(SPEVENTENUM e)
{
	switch(e)
	{
	case SPEI_START_SR_STREAM:		return "SPEI_START_SR_STREAM";
	case SPEI_END_SR_STREAM:		return "SPEI_END_SR_STREAM";
	case SPEI_SOUND_START:			return "SPEI_SOUND_START";
	case SPEI_SOUND_END:			return "SPEI_SOUND_END";
	case SPEI_PHRASE_START:			return "SPEI_PHRASE_START";
	case SPEI_RECOGNITION:			return "SPEI_RECOGNITION";
	case SPEI_FALSE_RECOGNITION:	return "SPEI_FALSE_RECOGNITION";
	case SPEI_HYPOTHESIS:			return "SPEI_HYPOTHESIS";
	default:	return "Other";
	}
	return "?";
}

//====================================================================
// CJuliSAPIEngine::_GetErrorString
//		�f�o�b�O�p�ɁAHRESULT �̃V���{���𕶎���Ƃ��ĕԂ��֐�
//---- �Ԃ�l --------------------------------------------------------
// ������
//---- ���� ----------------------------------------------------------
// HRESULT hr	[in] ID
//====================================================================
const char * CJuliSAPIEngine::_GetErrorString(HRESULT hr)
{
	static char buf[256];	// Umm...
	switch(hr)
	{
	case S_OK:						return "S_OK";
	case SPERR_STREAM_POS_INVALID:	return "SPERR_STREAM_POS_INVALID";
	case E_INVALIDARG:				return "E_INVALIDARG";
	case E_POINTER:					return "E_POINTER";
	case SPERR_AUDIO_BUFFER_OVERFLOW:	return "SPERR_AUDIO_BUFFER_OVERFLOW";
	case SPERR_AUDIO_BUFFER_UNDERFLOW:	return "SPERR_AUDIO_BUFFER_UNDERFLOW";
	case SPERR_AUDIO_STOPPED:			return "SPERR_AUDIO_STOPPED";
	case SPERR_STREAM_NOT_ACTIVE:		return "SPERR_STREAM_NOT_ACTIVE";
	case E_OUTOFMEMORY:					return "E_OUTOFMEMORY";
	}
	sprintf(buf,"%08x",hr);
	return buf;
}

//====================================================================
// CJuliSAPIEngine::AddEvent
//		SAPI �� site �ɃC�x���g�𑗂郁�\�b�h
//---- �Ԃ�l --------------------------------------------------------
// S_OK / FAILED(hr)
//---- ���� ----------------------------------------------------------
// SPEVENTENUM eEventId		[in] �C�x���g��ID
// ULONGLONG ullStreamPos	[in] �X�g���[���̈ʒu
// WPARAM wParam			[in] �p�����[�^
// LPARAM lParam			[in] �p�����[�^
//====================================================================
HRESULT CJuliSAPIEngine::_AddEvent(SPEVENTENUM eEventId, ULONGLONG ullStreamPos, WPARAM wParam, LPARAM lParam)
{
    SPDBG_FUNC("��AddEvent");
    J_DEBUGMESSAGE("��AddEvent(%d)",ullStreamPos);
    HRESULT hr = S_OK;
	
    SPEVENT Event;
    Event.eEventId = eEventId;
    Event.elParamType = SPET_LPARAM_IS_UNDEFINED;
    Event.ulStreamNum = 0; // 0 �ł悢
    Event.ullAudioStreamOffset = ullStreamPos;
    Event.wParam = wParam;
    Event.lParam = lParam;
	
    hr = m_cpSite->AddEvent(&Event, NULL);
	J_DEBUGMESSAGE("<%s> hr = %s\n",_GetSpEventEnumString(eEventId),_GetErrorString(hr));
	

    return hr;
}

//====================================================================
// CJuliSAPIEngine::AddEventString
//		SAPI �� site �ɕ�������̃C�x���g�𑗂郁�\�b�h
//---- �Ԃ�l --------------------------------------------------------
// S_OK / FAILED(hr)
//---- ���� ----------------------------------------------------------
// SPEVENTENUM eEventId		[in] �C�x���g��ID
// ULONGLONG ullStreamPos	[in] �X�g���[���̈ʒu
// const WCHAR * psz		[in] ������
// WPARAM wParam			[in] �p�����[�^
//====================================================================
HRESULT CJuliSAPIEngine::_AddEventString(SPEVENTENUM eEventId, ULONGLONG ullStreamPos, const WCHAR * psz, WPARAM wParam)
{
    SPDBG_FUNC("��AddEventString");
    J_DEBUGMESSAGE("��AddEventString");
    HRESULT hr = S_OK;
	
    SPEVENT Event;
    Event.eEventId = eEventId;
    Event.elParamType = SPET_LPARAM_IS_STRING;
    Event.ulStreamNum = 0; // Always set this to zero - SAPI fills this in
    Event.ullAudioStreamOffset = ullStreamPos;
    Event.wParam = wParam;
    Event.lParam = (LPARAM)psz;
	
    hr = m_cpSite->AddEvent(&Event, NULL);
	J_DEBUGMESSAGE("<%s> hr = %s\n",_GetSpEventEnumString(eEventId),_GetErrorString(hr));
	
    return hr;
}
