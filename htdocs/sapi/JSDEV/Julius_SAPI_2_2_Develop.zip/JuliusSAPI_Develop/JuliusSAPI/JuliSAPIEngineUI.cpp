//====================================================================
// JuliusUI.cpp: CJuliSAPIEngineUI(ISpTokenUI) �̃C���v�������g
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Speech Media Lab. Kyoto University     All rights reserved
//====================================================================

#include "stdafx.h"
#include "JuliSAPIEngine.h"
#include "JuliSAPIEngineUI.h"
#include "../j_modules/JuliGlobalOption.h"

#include "SpHelper.h"
#include <Prsht.h>
#include <windowsx.h>
#include <commctrl.h>
#pragma comment (lib, "Comctl32.lib")

// SAPI �̃��W�X�g����ǂݏ�������֐� (JuliSAPIEngine_ObjectToken.cpp)
extern HRESULT ReadJuliOptions(ISpObjectToken * pToken, CJuliGlobalOption *gopt);
extern HRESULT WriteJuliOptions(ISpObjectToken * pToken, CJuliGlobalOption *gopt);
extern HINSTANCE g_hInst;	// DLL �̃C���X�^���X (JuliusSAPI.cpp)

// �e�_�C�A���O�̃n���h��
static HWND hwnddlg_main = 0;
static HWND hwnddlg_audio = 0;
static HWND hwnddlg_analyze = 0;
static HWND hwnddlg_am = 0;
static HWND hwnddlg_lm = 0;
static HWND hwnddlg_decode = 0;
static HWND hwnddlg_about = 0;
static HWND hwnddlg_ex1 = 0;
static HWND hwnddlg_cmnss = 0;


// '\\'->'\' �ɕϊ����Ȃ���R�s�[
static void StrCpyNormalizingPath(char *dst, const char *src)
{
	while(*src!='\0')
	{
		if (*src=='\\')
		{
			for(;*(src+1)=='\\';src++);
		}
		*(dst++) = *(src++);
	}
	*dst = '\0';
}

static int SelectLogFile(HWND hwnd, const char *title, int idEditCtrl, string &filename)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwnd, GWL_USERDATA);

	OPENFILENAME ofn;
	char fn_buffer[MAX_PATH];
	StrCpyNormalizingPath(fn_buffer,filename.c_str());

	ZeroMemory(&ofn,sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = hwnd;
	ofn.hInstance = g_hInst;
	ofn.lpstrFilter = "*.txt\0";
	ofn.lpstrCustomFilter = NULL;
	ofn.nFilterIndex = 0;
	ofn.lpstrFile = fn_buffer;
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = MAX_PATH;
	ofn.lpstrInitialDir = filename.c_str();
	ofn.lpstrTitle = title;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;
	ofn.lpstrDefExt = NULL;
	ofn.lpTemplateName = NULL;
	if (GetSaveFileName(&ofn))
	{
		if (strcmp(filename.c_str(), ofn.lpstrFile)!=0)
		{
			SetDlgItemText(hwnd, idEditCtrl, ofn.lpstrFile);
			return 0;
		}
	}
	return 1;
}

// �I�[�v���t�@�C���_�C�A���O���쐬���A�t�@�C�������擾
// �G�f�B�b�g�R���g���[���ɂ��̕������ݒ�
// �Ԃ�l 0: �ݒ� 1:�L�����Z��
static int SelectModelFile(HWND hwnd, const char *title, int idEditCtrl, string &filename)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwnd, GWL_USERDATA);

	OPENFILENAME ofn;
	char fn_buffer[MAX_PATH];
	StrCpyNormalizingPath(fn_buffer,filename.c_str());

	ZeroMemory(&ofn,sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = hwnd;
	ofn.hInstance = g_hInst;
	ofn.lpstrFilter = "*.*\0";
	ofn.lpstrCustomFilter = NULL;
	ofn.nFilterIndex = 0;
	ofn.lpstrFile = fn_buffer;
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = MAX_PATH;
	ofn.lpstrInitialDir = filename.c_str();
	ofn.lpstrTitle = title;
	ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;
	ofn.lpstrDefExt = NULL;
	ofn.lpTemplateName = NULL;
	if (GetOpenFileName(&ofn))
	{
		if (strcmp(filename.c_str(), ofn.lpstrFile)!=0)
		{
			SetDlgItemText(hwnd, idEditCtrl, ofn.lpstrFile);
			return 0;
		}
	}
	return 1;
}

// �t�@�C�����ǂݍ��߂Ȃ��ă��[�U�����f�����Ƃ��� 1��Ԃ�
int CheckAndWarning(const char *filename)
{
	FILE *fp;
	if (filename==NULL) return 0;
	if (filename[0]=='\0')
	{
		int r = MessageBox(NULL,
			((string )filename + "�t�@�C�������w�肳��Ă��܂���B���̂܂ܑ����܂����H").c_str(),
			"�t�@�C���ǂݍ��݃G���[", MB_YESNO);
		if (r==IDNO) return 1;
		return 0;
	}
	if ((fp=fopen(filename, "r"))==NULL)
	{
		int r = MessageBox(NULL,
			((string )filename + "���ǂݍ��߂܂���B���̂܂ܑ����܂����H").c_str(),
			"�t�@�C���ǂݍ��݃G���[", MB_YESNO);
		if (r==IDNO) return 1;
		return 0;
	}
	fclose(fp);
	return 0;
}

// �G�f�B�b�g�R���g���[���̃t�@�C�������擾����
static int SetDlgTextToString(HWND hwnd, int idEditCtrl, string &str)
{
	char buf[1024];
	if (GetDlgItemText(hwnd, idEditCtrl, buf, 1024) == 0)
	{
		// 0�����̏ꍇ�ƃG���[�̏ꍇ�̋�ʂ����Ȃ�
		//		MessageBox(hwnd, "�t�@�C�������������܂�!", "�G���[", MB_OK);
		//		return 1;
		str = buf;
	} else {
		str = buf;
	}
	return 0;
}

// �G�f�B�b�g�R���g���[���̐��l���擾����
static int SetDlgTextToInt(HWND hwnd, int idEditCtrl)
{
	char buf[1024];
	if (GetDlgItemText(hwnd, idEditCtrl, buf, 1024) == 0)
	{
		// 0�����̏ꍇ�ƃG���[�̏ꍇ�̋�ʂ����Ȃ�
		//		MessageBox(hwnd, "�t�@�C�������������܂�!", "�G���[", MB_OK);
		//		return 1;
		return atoi(buf);
	} else {
		return atoi(buf);
	}
	return 0;
}

// �G�f�B�b�g�R���g���[���̕��������_�l���擾����
static float SetDlgTextToFloat(HWND hwnd, int idEditCtrl)
{
	char buf[1024];
	if (GetDlgItemText(hwnd, idEditCtrl, buf, 1024) == 0)
	{
		// 0�����̏ꍇ�ƃG���[�̏ꍇ�̋�ʂ����Ȃ�
		//		MessageBox(hwnd, "�t�@�C�������������܂�!", "�G���[", MB_OK);
		//		return 1;
		return (float )atof(buf);
	} else {
		return (float )atof(buf);
	}
	return 0.0;
}

// �G�f�B�b�g�R���g���[���̕��������_�l���擾����
static LOGPROB SetDlgTextToLOGPROB(HWND hwnd, int idEditCtrl)
{
	char buf[1024];
	if (GetDlgItemText(hwnd, idEditCtrl, buf, 1024) == 0)
	{
		// 0�����̏ꍇ�ƃG���[�̏ꍇ�̋�ʂ����Ȃ�
		//		MessageBox(hwnd, "�t�@�C�������������܂�!", "�G���[", MB_OK);
		//		return 1;
		return (LOGPROB )atof(buf);
	} else {
		return (LOGPROB )atof(buf);
	}
	return 0.0;
}

// �t�@�C�����ǂݍ��߂Ȃ��ă��[�U�����f�����Ƃ��� 1��Ԃ�
static int CheckAndWarningEdit(HWND hwnd, int idEditCtrl)
{
	string str;
	if (SetDlgTextToString(hwnd, idEditCtrl, str)) return 1;
	return CheckAndWarning(str.c_str());
}


// jconf �t�@�C����I������_�C�A���O��\�����ACJuliOptions::ReadJConf ���\�b�h���Ăяo��
static int LoadJConfFile(HWND hwnd, CJuliGlobalOption *gopt)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwnd, GWL_USERDATA);

	OPENFILENAME ofn;
	char fn_buffer[MAX_PATH];
	fn_buffer[0]=0;

	ZeroMemory(&ofn,sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = hwnd;
	ofn.hInstance = g_hInst;
	ofn.lpstrFilter = "JCONF Files\0*.jconf\0All Files\0*.*\0";
	ofn.lpstrCustomFilter = NULL;
	ofn.nFilterIndex = 0;
	ofn.lpstrFile = fn_buffer;
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = MAX_PATH;
	ofn.lpstrInitialDir = "";
	ofn.lpstrTitle = "JCONF �t�@�C����I��";
	ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;
	ofn.lpstrDefExt = NULL;
	ofn.lpTemplateName = NULL;
	if (GetOpenFileName(&ofn))
	{
		gopt->Clear();
		gopt->GetOption().Clear();
		gopt->ReadJConf(ofn.lpstrFile);
		return 0;
	}
	return 1;
}

// jconf �t�@�C����I������_�C�A���O��\�����A���݂̐ݒ���e����������
static int SaveJConfFile(HWND hwnd, CJuliGlobalOption *gopt)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwnd, GWL_USERDATA);

	OPENFILENAME ofn;
	char fn_buffer[MAX_PATH];
	strcpy(fn_buffer, "default.jconf");
	//	strcpy(fn_buffer,filename.c_str());

	ZeroMemory(&ofn,sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = hwnd;
	ofn.hInstance = g_hInst;
	ofn.lpstrFilter = "JCONF Files\0*.jconf\0All Files\0*.*\0";
	ofn.lpstrCustomFilter = NULL;
	ofn.nFilterIndex = 0;
	ofn.lpstrFile = fn_buffer;
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = MAX_PATH;
	ofn.lpstrInitialDir = "";
	ofn.lpstrTitle = "JCONF �t�@�C����I��";
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;
	ofn.lpstrDefExt = NULL;
	ofn.lpTemplateName = NULL;
	if (GetSaveFileName(&ofn))
	{
		string str;
		gopt->GetOptionString(str);
retry:
		// \r\n �ɂȂ��Ă��邩��A���̂܂܃o�C�i���Ƃ��ď�������
		FILE * fp = fopen(ofn.lpstrFile, "wb");
		if (fp==NULL)
		{
			if (MessageBox(hwnd, "�������݂Ɏ��s", "JCONF �������݃G���[", MB_RETRYCANCEL)==IDRETRY)
			{
				goto retry;
			}
			return 1;
		}
		fwrite(str.c_str(), str.length(), 1, fp);
		fclose(fp);
		return 0;
	}
	return 1;
}

// checkid �̏�Ԃɂ���� editid �̃C�l�[�u����ύX
void SyncEditEnable(HWND hwndDlg, int checkid, int editid, BOOL x=TRUE)
{
	if (Button_GetCheck(GetDlgItem(hwndDlg, checkid)) == BST_CHECKED)
	{
		EnableWindow(GetDlgItem(hwndDlg, editid), x);
	} else {
		EnableWindow(GetDlgItem(hwndDlg, editid), !x);
	}
}

BOOL SetDlgItemFloat(HWND hdlg, int id, float f)
{
	char buf[256];
	sprintf(buf, "%f", f);
	return SetDlgItemText(hdlg, id, buf);
}
float GetDlgItemFloat(HWND hDlg, int id)
{
	float r;
	char buf[100];
	GetDlgItemText(hDlg, id, buf, 100);
	sscanf(buf, "%f", &r);
	return r;
}
// �f�t�H���g�l���`�F�b�N���ă{�^���̏�Ԃ�ύX����
void DefaultCheckLOGPROB(HWND hwnddlg, int editid, int buttonid, LOGPROB defval)
{
	if (GetDlgItemFloat(hwnddlg, editid) == defval)
	{
		Button_SetCheck(GetDlgItem(hwnddlg, buttonid), BST_CHECKED);
		EnableWindow(GetDlgItem(hwnddlg, buttonid), FALSE);
	} else {
		Button_SetCheck(GetDlgItem(hwnddlg, buttonid), BST_UNCHECKED);
		EnableWindow(GetDlgItem(hwnddlg, buttonid), TRUE);
	}
}
// �f�t�H���g�l���`�F�b�N���ă{�^���̏�Ԃ�ύX����
void DefaultCheckInt(HWND hwnddlg, int editid, int buttonid, int defval)
{
	if (GetDlgItemInt(hwnddlg, editid, NULL, TRUE) == defval)
	{
		Button_SetCheck(GetDlgItem(hwnddlg, buttonid), BST_CHECKED);
		EnableWindow(GetDlgItem(hwnddlg, buttonid), FALSE);
	} else {
		Button_SetCheck(GetDlgItem(hwnddlg, buttonid), BST_UNCHECKED);
		EnableWindow(GetDlgItem(hwnddlg, buttonid), TRUE);
	}
}

// =====================================================
// �_�C�A���O�̏�����
// -----------------------------------------------------
int CJuliSAPIEngineUI::InitMainDialog(HWND hwndDlg)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);

	if (pThis)
	{
		SetDlgItemText(hwndDlg, IDC_EDIT_ERRLOGFILE, pThis->m_gopt.m_strErrLogFile.c_str());
		SetDlgItemText(hwndDlg, IDC_EDIT_OUTLOGFILE, pThis->m_gopt.m_strOutLogFile.c_str());
		SetDlgItemText(hwndDlg, IDC_EDIT_DEBUGLOGFILE, pThis->m_gopt.m_strDebugLogFile.c_str());
		if (pThis->m_gopt.m_bUseErrLogFile)
		{
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_ERRLOG), BST_CHECKED);
		} else {
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_ERRLOG), BST_UNCHECKED);
		}
		if (pThis->m_gopt.m_bUseOutLogFile)
		{
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_OUTLOG), BST_CHECKED);
		} else {
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_OUTLOG), BST_UNCHECKED);
		}
		if (pThis->m_gopt.m_bUseDebugLogFile)
		{
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_DEBUGLOG), BST_CHECKED);
		} else {
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_DEBUGLOG), BST_UNCHECKED);
		}
	}

	RefreshMainDialog(hwndDlg);

	return 0;
}
int CJuliSAPIEngineUI::InitAudioDialog(HWND hwndDlg)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);

	ComboBox_AddString(GetDlgItem(hwndDlg, IDC_COMBO_SEGMENT), "���Ȃ�");
	ComboBox_AddString(GetDlgItem(hwndDlg, IDC_COMBO_SEGMENT), "����");
	ComboBox_AddString(GetDlgItem(hwndDlg, IDC_COMBO_SEGMENT), "�}�C�N���͎��̂�");
	ComboBox_SetCurSel(GetDlgItem(hwndDlg, IDC_COMBO_SEGMENT), pThis->m_gopt.pause_segment);

	if (pThis)
	{
		SetDlgItemText(hwndDlg, IDC_EDIT_WAVEOUTFILE, pThis->m_gopt.m_strWaveOutFile.c_str());
		if (pThis->m_gopt.m_bUseWaveOutFile)
		{
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_WAVEOUTFILE), BST_CHECKED);
		} else {
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_WAVEOUTFILE), BST_UNCHECKED);
		}
		Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_NOSTRIP), (! pThis->m_gopt.strip_zero_sample)?BST_CHECKED:BST_UNCHECKED);
		Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_ADDNOISE), (! pThis->m_gopt.m_bAddNoize)?BST_CHECKED:BST_UNCHECKED);
		SetDlgItemInt(hwndDlg, IDC_EDIT_LEVELTHRESHOLD, pThis->m_gopt.level_thres, TRUE);
		SetDlgItemInt(hwndDlg, IDC_EDIT_HEADMARGIN, pThis->m_gopt.head_margin_msec, TRUE);
		SetDlgItemInt(hwndDlg, IDC_EDIT_TAILMARGIN, pThis->m_gopt.tail_margin_msec, TRUE);
		SetDlgItemInt(hwndDlg, IDC_EDIT_ZCTHRESHOLD, pThis->m_gopt.zero_cross_num, TRUE);
	}
	RefreshAudioDialog(hwndDlg);
	return 0;
}
int CJuliSAPIEngineUI::InitAnalyzeDialog(HWND hwndDlg)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);

	ComboBox_AddString(GetDlgItem(hwndDlg, IDC_COMBO_AUDIOFORMAT), "16bit 16kHz Monoral");
	ComboBox_AddString(GetDlgItem(hwndDlg, IDC_COMBO_AUDIOFORMAT), "16bit 8kHz Monoral");
	ComboBox_SetCurSel(GetDlgItem(hwndDlg, IDC_COMBO_AUDIOFORMAT), pThis->m_gopt.m_iWaveType);

	if (pThis)
	{
		SetDlgItemInt(hwndDlg, IDC_EDIT_HIPASS, pThis->m_gopt.hipass, TRUE);
		SetDlgItemInt(hwndDlg, IDC_EDIT_LOPASS, pThis->m_gopt.lopass, TRUE);
		SetDlgItemInt(hwndDlg, IDC_EDIT_FRAMESHIFT, pThis->m_gopt.fshift, TRUE);
		SetDlgItemInt(hwndDlg, IDC_EDIT_FRAMESIZE, pThis->m_gopt.fsize, TRUE);
	}
	RefreshAnalyzeDialog(hwndDlg);
	return 0;
}

int CJuliSAPIEngineUI::InitDecodeDialog(HWND hwndDlg)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);

	if (pThis)
	{
		SetDlgItemInt(hwndDlg,IDC_EDIT_TRELLISBEAMWIDTH, pThis->m_gopt.GetOption().trellis_beam_width, TRUE);
#ifdef USE_NGRAM
		SetDlgItemFloat(hwndDlg,IDC_EDIT_LMWEIGHT, pThis->m_gopt.GetOption().lm_weight);
		SetDlgItemFloat(hwndDlg,IDC_EDIT_LMWEIGHT2, pThis->m_gopt.GetOption().lm_weight2);
		SetDlgItemFloat(hwndDlg,IDC_EDIT_WORDINSERTIONPENALTY, pThis->m_gopt.GetOption().lm_penalty);
		SetDlgItemFloat(hwndDlg,IDC_EDIT_WORDINSERTIONPENALTY2, pThis->m_gopt.GetOption().lm_penalty2);

		SendDlgItemMessage(hwndDlg,IDC_CHECK_LMPSPECIFIED,BM_SETCHECK,(WPARAM) (pThis->m_gopt.GetOption().lmp_specified)?BST_CHECKED:BST_UNCHECKED,0);
		SendDlgItemMessage(hwndDlg,IDC_CHECK_LMP2SPECIFIED,BM_SETCHECK,(WPARAM) (pThis->m_gopt.GetOption().lmp2_specified)?BST_CHECKED:BST_UNCHECKED,0);
#else
		SetDlgItemFloat(hwndDlg,IDC_EDIT_WORDINSERTIONPENALTY, pThis->m_gopt.GetOption().penalty1);
		SetDlgItemFloat(hwndDlg,IDC_EDIT_WORDINSERTIONPENALTY2, pThis->m_gopt.GetOption().penalty2);
#endif
		if (pThis->m_gopt.align_result_word_flag)
		{
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_WORDALIGN), BST_CHECKED);
		} else {
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_WORDALIGN), BST_UNCHECKED);
		}

		// �F�����s��臒l
		if (pThis->m_gopt.m_bUseFalseRecognition)
		{
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_FR), BST_CHECKED);
		} else {
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_FR), BST_UNCHECKED);
		}
		Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_FR_SCORE), (pThis->m_gopt.m_bUseFRScore)?BST_CHECKED:BST_UNCHECKED);
		Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_FR_MINLENGTH), (pThis->m_gopt.m_bUseFRMinLength)?BST_CHECKED:BST_UNCHECKED);
		Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_FR_MAXLENGTH), (pThis->m_gopt.m_bUseFRMaxLength)?BST_CHECKED:BST_UNCHECKED);
		Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_FR_FILLER), (pThis->m_gopt.m_bUseFRFiller)?BST_CHECKED:BST_UNCHECKED);
		SetDlgItemFloat(hwndDlg,IDC_EDIT_FR_SCORE, pThis->m_gopt.m_probFRScore);
		SetDlgItemInt(hwndDlg,IDC_EDIT_FR_MINLENGTH, pThis->m_gopt.m_iFRMinLength, TRUE);
		SetDlgItemInt(hwndDlg,IDC_EDIT_FR_MAXLENGTH, pThis->m_gopt.m_iFRMaxLength, TRUE);

		SetDlgItemInt(hwndDlg,IDC_EDIT_STACKSIZE, pThis->m_gopt.GetOption().stack_size, TRUE);
		SetDlgItemInt(hwndDlg,IDC_EDIT_HYPOOVERFLOW, pThis->m_gopt.GetOption().hypo_overflow, TRUE);
		SetDlgItemFloat(hwndDlg,IDC_EDIT_SCANBEAMTHRES, pThis->m_gopt.GetOption().scan_beam_thres);
		SetDlgItemInt(hwndDlg,IDC_EDIT_ENVELOPEDBESTFIRSTWIDTH, pThis->m_gopt.GetOption().enveloped_bestfirst_width, TRUE);
		SetDlgItemInt(hwndDlg,IDC_EDIT_LOOKUPRANGE, pThis->m_gopt.GetOption().lookup_range, TRUE);

		// nbest
		if (pThis->m_gopt.m_bUseNbest)
		{
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_NBEST), BST_CHECKED);
		} else {
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_NBEST), BST_UNCHECKED);
		}

		SetDlgItemInt(hwndDlg,IDC_EDIT_NBEST, pThis->m_gopt.m_iNbest, TRUE);

		// CM
		if (pThis->m_gopt.m_bUseCM)
		{
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USECM), BST_CHECKED);
		} else {
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USECM), BST_UNCHECKED);
		}
		SetDlgItemFloat(hwndDlg,IDC_EDIT_CMALPHA, pThis->m_gopt.m_fCMAlpha);

		// �X�R�A��臒l
		SetDlgItemFloat(hwndDlg,IDC_EDIT_SCORETHRES_HIGH, pThis->m_gopt.m_fScoreThresHigh);
		SetDlgItemFloat(hwndDlg,IDC_EDIT_SCORETHRES_LOW, pThis->m_gopt.m_fScoreThresLow);
	}
	RefreshDecodeDialog(hwndDlg);
	return 0;
}
int CJuliSAPIEngineUI::InitCMNSSDialog(HWND hwndDlg)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);

	if (pThis)
	{
		SetDlgItemText(hwndDlg, IDC_EDIT_CMNLOADFILE, pThis->m_gopt.m_strCMNLoadFile.c_str());
		SetDlgItemText(hwndDlg, IDC_EDIT_CMNSAVEFILE, pThis->m_gopt.m_strCMNSaveFile.c_str());
		SetDlgItemText(hwndDlg, IDC_EDIT_SSLOADFILE, pThis->m_gopt.m_strSSLoadFile.c_str());
		if (pThis->m_gopt.m_bCMNCycle)
		{
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_CMNCYCLE), BST_CHECKED);
		} else {
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_CMNCYCLE), BST_UNCHECKED);
		}
		if (pThis->m_gopt.m_bCMNLoad)
		{
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_CMNLOAD), BST_CHECKED);
		} else {
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_CMNLOAD), BST_UNCHECKED);
		}
		if (pThis->m_gopt.m_bCMNSave)
		{
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_CMNSAVE), BST_CHECKED);
		} else {
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_CMNSAVE), BST_UNCHECKED);
		}
		switch(pThis->m_gopt.m_iSSMode)
		{
		case 0: Button_SetCheck(GetDlgItem(hwndDlg, IDC_RADIO_SS_NONE), BST_CHECKED);	break;
		case 1: Button_SetCheck(GetDlgItem(hwndDlg, IDC_RADIO_SS_CALC), BST_CHECKED);	break;
		case 2: Button_SetCheck(GetDlgItem(hwndDlg, IDC_RADIO_SS_LOAD), BST_CHECKED);	break;
		}
		SetDlgItemInt(hwndDlg, IDC_EDIT_SSCALCLEN, pThis->m_gopt.sscalc_len, TRUE);
		SetDlgItemFloat(hwndDlg, IDC_EDIT_SSALPHA, pThis->m_gopt.ssalpha);
		SetDlgItemFloat(hwndDlg, IDC_EDIT_SSFLOOR, pThis->m_gopt.ssfloor);
	}
	RefreshCMNSSDialog(hwndDlg);
	return 0;
}

int CJuliSAPIEngineUI::InitAmDialog(HWND hwndDlg)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);

	if (pThis)
	{
		SetDlgItemText(hwndDlg, IDC_EDIT_HMMFILE, pThis->m_gopt.m_strHmmFile.c_str());
		SetDlgItemText(hwndDlg, IDC_EDIT_MAPFILE, pThis->m_gopt.m_strMapFile.c_str());
		SetDlgItemText(hwndDlg, IDC_EDIT_GSHMMFILE, pThis->m_gopt.m_strGsHmmFile.c_str());

		SetDlgItemInt(hwndDlg, IDC_EDIT_GSHMM_STATE, pThis->m_gopt.GetOption().gs_statenum, TRUE);

		if (pThis->m_gopt.m_bUseMapFile)
		{
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_MAP), BST_CHECKED);
		} else {
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_MAP), BST_UNCHECKED);
		}
		if (pThis->m_gopt.m_bUseGsHmmFile)
		{
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_GSHMM), BST_CHECKED);
		} else {
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_GSHMM), BST_UNCHECKED);
		}
	}
	RefreshAmDialog(hwndDlg);
	return 0;
}
int CJuliSAPIEngineUI::InitLmDialog(HWND hwndDlg)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);

	if (pThis)
	{
		SetDlgItemText(hwndDlg, IDC_EDIT_NGRAMFILE,			pThis->m_gopt.GetOption().m_strNgramFile.c_str());
		SetDlgItemText(hwndDlg, IDC_EDIT_NGRAMARPALRFILE,	pThis->m_gopt.GetOption().m_strNgramArpaLRFile.c_str());
		SetDlgItemText(hwndDlg, IDC_EDIT_NGRAMARPARLFILE,	pThis->m_gopt.GetOption().m_strNgramArpaRLFile.c_str());
		SetDlgItemText(hwndDlg, IDC_EDIT_DICTFILE,			pThis->m_gopt.GetOption().m_strDictFile.c_str());

		SetDlgItemText(hwndDlg, IDC_EDIT_SILHEAD,			pThis->m_gopt.GetOption().m_strHeadSilentName.c_str());
		SetDlgItemText(hwndDlg, IDC_EDIT_SILTAIL,			pThis->m_gopt.GetOption().m_strTailSilentName.c_str());

		SetDlgItemText(hwndDlg, IDC_EDIT_IMEDLLFILE,		pThis->m_gopt.m_strIMEDllFile.c_str());
	}

	if (pThis->m_gopt.GetOption().m_bUseArpaFile == 0)
	{
		Button_SetCheck(GetDlgItem(hwndDlg, IDC_RADIO_NGRAM), BST_CHECKED);
	} else {
		Button_SetCheck(GetDlgItem(hwndDlg, IDC_RADIO_ARPA), BST_CHECKED);
	}

	Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USESILHEAD),
		(pThis->m_gopt.GetOption().m_bUseHeadSilName)?BST_CHECKED:BST_UNCHECKED);
	Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USESILTAIL),
		(pThis->m_gopt.GetOption().m_bUseTailSilName)?BST_CHECKED:BST_UNCHECKED);

	if (pThis->m_gopt.m_bNoUseSLM)
	{
		Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_NOUSESLM), BST_CHECKED);
	}
	if (pThis->m_gopt.m_bUseIME)
	{
		Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USEIME), BST_CHECKED);
	}
	if (pThis->m_gopt.m_bUseIMEDllFile)
	{
		Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USEIMEDLLFILE), BST_CHECKED);
	}

	RefreshLmDialog(hwndDlg);

	return 0;
}

int CJuliSAPIEngineUI::InitEx1Dialog(HWND hwndDlg)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);

	if (pThis)
	{
		SetDlgItemText(hwndDlg, IDC_EDIT_MFCCFILE, pThis->m_gopt.m_strMfccFile.c_str());
		SetDlgItemText(hwndDlg, IDC_EDIT_PALIGNFILE, pThis->m_gopt.m_strPhonemeAlignFile.c_str());
		if (pThis->m_gopt.m_bUsePhonemeAlignFile)
		{
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_PALIGN), BST_CHECKED);
		} else {
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_PALIGN), BST_UNCHECKED);
		}
		if (pThis->m_gopt.m_bUseMfccFile)
		{
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_MFCC), BST_CHECKED);
		} else {
			Button_SetCheck(GetDlgItem(hwndDlg, IDC_CHECK_MFCC), BST_UNCHECKED);
		}
	}

	return 0;
}
// =====================================================
// �_�C�A���O�̍X�V
// -----------------------------------------------------
int CJuliSAPIEngineUI::RefreshMainDialog(HWND hwndDlg)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);

	SyncEditEnable(hwndDlg, IDC_CHECK_ERRLOG, IDC_EDIT_ERRLOGFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_ERRLOG, IDC_BUTTON_REF_ERRLOGFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_OUTLOG, IDC_EDIT_OUTLOGFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_OUTLOG, IDC_BUTTON_REF_OUTLOGFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_DEBUGLOG, IDC_EDIT_DEBUGLOGFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_DEBUGLOG, IDC_BUTTON_REF_DEBUGLOGFILE);

	// �I�v�V����������̐ݒ�
	string str;
	pThis->m_gopt.GetOptionString(str);
	SetDlgItemText(hwndDlg, IDC_EDIT_OPTIONSTRING, str.c_str());
	return 0;
}

int CJuliSAPIEngineUI::RefreshAudioDialog(HWND hwndDlg)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);

	if (pThis)
	{
		DefaultCheckInt(hwndDlg, IDC_EDIT_LEVELTHRESHOLD, IDC_CHECK_DEF_LEVELTHRESHOLD, pThis->m_gopt.level_thres.GetDefault());
		DefaultCheckInt(hwndDlg, IDC_EDIT_HEADMARGIN, IDC_CHECK_DEF_HEADMARGIN, pThis->m_gopt.head_margin_msec.GetDefault());
		DefaultCheckInt(hwndDlg, IDC_EDIT_TAILMARGIN, IDC_CHECK_DEF_TAILMARGIN, pThis->m_gopt.tail_margin_msec.GetDefault());
		DefaultCheckInt(hwndDlg, IDC_EDIT_ZCTHRESHOLD, IDC_CHECK_DEF_ZCTHRESHOLD, pThis->m_gopt.zero_cross_num.GetDefault());
	}
	SyncEditEnable(hwndDlg, IDC_CHECK_WAVEOUTFILE, IDC_EDIT_WAVEOUTFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_WAVEOUTFILE, IDC_BUTTON_REF_WAVEOUTFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_NOSTRIP, IDC_CHECK_ADDNOISE, FALSE);
	return 0;
}

int CJuliSAPIEngineUI::RefreshAnalyzeDialog(HWND hwndDlg)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);

	if (pThis)
	{
		DefaultCheckInt(hwndDlg, IDC_EDIT_HIPASS, IDC_CHECK_DEF_HIPASS, pThis->m_gopt.hipass.GetDefault());
		DefaultCheckInt(hwndDlg, IDC_EDIT_LOPASS, IDC_CHECK_DEF_LOPASS, pThis->m_gopt.lopass.GetDefault());
		DefaultCheckInt(hwndDlg, IDC_EDIT_FRAMESIZE, IDC_CHECK_DEF_FRAMESIZE, pThis->m_gopt.fsize.GetDefault());
		DefaultCheckInt(hwndDlg, IDC_EDIT_FRAMESHIFT, IDC_CHECK_DEF_FRAMESHIFT, pThis->m_gopt.fshift.GetDefault());
	}
	return 0;
}

int CJuliSAPIEngineUI::RefreshDecodeDialog(HWND hwndDlg)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);

	SyncEditEnable(hwndDlg, IDC_CHECK_TRELLISBEAMWIDTH,	IDC_EDIT_TRELLISBEAMWIDTH);
	SyncEditEnable(hwndDlg, IDC_CHECK_LMPSPECIFIED,		IDC_EDIT_LMWEIGHT);
	SyncEditEnable(hwndDlg, IDC_CHECK_LMPSPECIFIED,		IDC_EDIT_WORDINSERTIONPENALTY);
	SyncEditEnable(hwndDlg, IDC_CHECK_LMP2SPECIFIED,	IDC_EDIT_LMWEIGHT2);
	SyncEditEnable(hwndDlg, IDC_CHECK_LMP2SPECIFIED,	IDC_EDIT_WORDINSERTIONPENALTY2);

	if (pThis)
	{
		DefaultCheckInt(hwndDlg, IDC_EDIT_STACKSIZE, IDC_CHECK_DEF_STACKSIZE, pThis->m_gopt.GetOption().stack_size.GetDefault());
		DefaultCheckInt(hwndDlg, IDC_EDIT_HYPOOVERFLOW, IDC_CHECK_DEF_HYPOOVERFLOW, pThis->m_gopt.GetOption().hypo_overflow.GetDefault());
		DefaultCheckLOGPROB(hwndDlg, IDC_EDIT_SCANBEAMTHRES, IDC_CHECK_DEF_SCANBEAMTHRES, pThis->m_gopt.GetOption().scan_beam_thres.GetDefault());
		DefaultCheckInt(hwndDlg, IDC_EDIT_ENVELOPEDBESTFIRSTWIDTH, IDC_CHECK_DEF_ENVELOPEDBESTFIRSTWIDTH, pThis->m_gopt.GetOption().enveloped_bestfirst_width.GetDefault());
		DefaultCheckInt(hwndDlg, IDC_EDIT_LOOKUPRANGE, IDC_CHECK_DEF_LOOKUPRANGE, pThis->m_gopt.GetOption().lookup_range.GetDefault());
		DefaultCheckLOGPROB(hwndDlg, IDC_EDIT_CMALPHA, IDC_CHECK_DEF_CMALPHA, pThis->m_gopt.m_fCMAlpha.GetDefault());
		DefaultCheckLOGPROB(hwndDlg, IDC_EDIT_FR_SCORE, IDC_CHECK_DEF_FR_SCORE, pThis->m_gopt.m_probFRScore.GetDefault());
		DefaultCheckInt(hwndDlg, IDC_EDIT_FR_MINLENGTH, IDC_CHECK_DEF_FR_MINLENGTH, pThis->m_gopt.m_iFRMinLength.GetDefault());
		DefaultCheckInt(hwndDlg, IDC_EDIT_FR_MAXLENGTH, IDC_CHECK_DEF_FR_MAXLENGTH, pThis->m_gopt.m_iFRMaxLength.GetDefault());
	}

	SyncEditEnable(hwndDlg, IDC_CHECK_NBEST,	IDC_EDIT_NBEST);
	SyncEditEnable(hwndDlg, IDC_CHECK_USE_FR,	IDC_EDIT_FR_SCORE);
	SyncEditEnable(hwndDlg, IDC_CHECK_USE_FR,	IDC_EDIT_FR_MINLENGTH);
	SyncEditEnable(hwndDlg, IDC_CHECK_USE_FR,	IDC_EDIT_FR_MAXLENGTH);
	SyncEditEnable(hwndDlg, IDC_CHECK_USE_FR,	IDC_CHECK_USE_FR_SCORE);
	SyncEditEnable(hwndDlg, IDC_CHECK_USE_FR,	IDC_CHECK_USE_FR_MINLENGTH);
	SyncEditEnable(hwndDlg, IDC_CHECK_USE_FR,	IDC_CHECK_USE_FR_MAXLENGTH);
	SyncEditEnable(hwndDlg, IDC_CHECK_USE_FR,	IDC_CHECK_USE_FR_FILLER);
	SyncEditEnable(hwndDlg, IDC_CHECK_NBEST,	IDC_CHECK_USECM);

	int nb = SetDlgTextToInt(hwndDlg, IDC_EDIT_NBEST);
	if (nb < 2) {
		SetDlgItemText(hwndDlg, IDC_EDIT_NBEST,"10");
	}
	return 0;
}

int CJuliSAPIEngineUI::RefreshCMNSSDialog(HWND hwndDlg)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);

	SyncEditEnable(hwndDlg, IDC_CHECK_CMNLOAD, IDC_EDIT_CMNLOADFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_CMNLOAD, IDC_BUTTON_REF_CMNLOADFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_CMNSAVE, IDC_EDIT_CMNSAVEFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_CMNSAVE, IDC_BUTTON_REF_CMNSAVEFILE);
	SyncEditEnable(hwndDlg, IDC_RADIO_SS_LOAD, IDC_EDIT_SSLOADFILE);
	SyncEditEnable(hwndDlg, IDC_RADIO_SS_LOAD, IDC_BUTTON_REF_SSLOADFILE);
	if (pThis)
	{
		DefaultCheckInt(hwndDlg, IDC_EDIT_SSCALCLEN, IDC_CHECK_DEF_SSCALCLEN, pThis->m_gopt.sscalc_len.GetDefault());
		DefaultCheckLOGPROB(hwndDlg, IDC_EDIT_SSALPHA, IDC_CHECK_DEF_SSALPHA, pThis->m_gopt.ssalpha.GetDefault());
		DefaultCheckLOGPROB(hwndDlg, IDC_EDIT_SSFLOOR, IDC_CHECK_DEF_SSFLOOR, pThis->m_gopt.ssfloor.GetDefault());
	}
	return 0;
}

int CJuliSAPIEngineUI::RefreshAmDialog(HWND hwndDlg)
{
	SyncEditEnable(hwndDlg, IDC_CHECK_USE_MAP, IDC_EDIT_MAPFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_USE_MAP, IDC_BUTTON_REF_MAPFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_USE_GSHMM, IDC_EDIT_GSHMMFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_USE_GSHMM, IDC_BUTTON_REF_GSHMMFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_USE_GSHMM, IDC_EDIT_GSHMM_STATE);
	return 0;
}

int CJuliSAPIEngineUI::RefreshLmDialog(HWND hwndDlg)
{
	if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_NOUSESLM)) == BST_CHECKED)
	{
		EnableWindow(GetDlgItem(hwndDlg, IDC_RADIO_NGRAM), FALSE);
		EnableWindow(GetDlgItem(hwndDlg, IDC_RADIO_ARPA), FALSE);
		EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_NGRAMFILE), FALSE);
		EnableWindow(GetDlgItem(hwndDlg, IDC_BUTTON_REF_NGRAMFILE), FALSE);
		EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_NGRAMARPALRFILE), FALSE);
		EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_NGRAMARPARLFILE), FALSE);
		EnableWindow(GetDlgItem(hwndDlg, IDC_BUTTON_REF_NGRAMARPALRFILE), FALSE);
		EnableWindow(GetDlgItem(hwndDlg, IDC_BUTTON_REF_NGRAMARPARLFILE), FALSE);
		EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_DICTFILE), FALSE);
		EnableWindow(GetDlgItem(hwndDlg, IDC_BUTTON_REF_DICTFILE), FALSE);
	} else {
		EnableWindow(GetDlgItem(hwndDlg, IDC_RADIO_NGRAM), TRUE);
		EnableWindow(GetDlgItem(hwndDlg, IDC_RADIO_ARPA), TRUE);
		EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_DICTFILE), TRUE);
		EnableWindow(GetDlgItem(hwndDlg, IDC_BUTTON_REF_DICTFILE), TRUE);
		if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_RADIO_NGRAM)) == BST_CHECKED)
		{
			EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_NGRAMFILE), TRUE);
			EnableWindow(GetDlgItem(hwndDlg, IDC_BUTTON_REF_NGRAMFILE), TRUE);
			EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_NGRAMARPALRFILE), FALSE);
			EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_NGRAMARPARLFILE), FALSE);
			EnableWindow(GetDlgItem(hwndDlg, IDC_BUTTON_REF_NGRAMARPALRFILE), FALSE);
			EnableWindow(GetDlgItem(hwndDlg, IDC_BUTTON_REF_NGRAMARPARLFILE), FALSE);
		} else {
			EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_NGRAMFILE), FALSE);
			EnableWindow(GetDlgItem(hwndDlg, IDC_BUTTON_REF_NGRAMFILE), FALSE);
			EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_NGRAMARPALRFILE), TRUE);
			EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_NGRAMARPARLFILE), TRUE);
			EnableWindow(GetDlgItem(hwndDlg, IDC_BUTTON_REF_NGRAMARPALRFILE), TRUE);
			EnableWindow(GetDlgItem(hwndDlg, IDC_BUTTON_REF_NGRAMARPARLFILE), TRUE);
		}
	}
	SyncEditEnable(hwndDlg, IDC_CHECK_USEIME, IDC_EDIT_IMEDLLFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_USEIME, IDC_CHECK_USEIMEDLLFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_USEIMEDLLFILE, IDC_EDIT_IMEDLLFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_USEIMEDLLFILE, IDC_BUTTON_REF_IMEDLLFILE);
	SyncEditEnable(hwndDlg, IDC_CHECK_USESILHEAD, IDC_EDIT_SILHEAD);
	SyncEditEnable(hwndDlg, IDC_CHECK_USESILTAIL, IDC_EDIT_SILTAIL);
	return 0;
}
// =====================================================
// �_�C�A���O�v���V�[�W��
// -----------------------------------------------------
BOOL CALLBACK CJuliSAPIEngineUI::EnginePropertiesMainProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);
	NMHDR *nmhdr;

	switch(uMsg) {
		case WM_INITDIALOG:
			{
				PROPSHEETPAGE *psp = (PROPSHEETPAGE *)lParam;
				pThis = (CJuliSAPIEngineUI *)psp->lParam;
			}
			::SetWindowLong(hwndDlg, GWL_USERDATA, (LONG)pThis);
			hwnddlg_main = hwndDlg;
			InitMainDialog(hwndDlg);

			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
			case IDC_CHECK_ERRLOG:
			case IDC_CHECK_OUTLOG:
			case IDC_CHECK_DEBUGLOG:
				if (HIWORD(wParam) == BN_CLICKED)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					RefreshMainDialog(hwndDlg);
				}
				break;
			case IDC_BUTTON_LOADCONF:
				// �I�v�V�����ɒ��ڏ�������
				if (LoadJConfFile(hwndDlg, &(pThis->m_gopt)) == 0)
				{
					//					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);

					// �I�v�V��������ʂɔ��f�����邽�߁A���������Ȃ���
					InitMainDialog(hwndDlg);
					if (hwnddlg_audio != 0) InitDecodeDialog(hwnddlg_audio);
					if (hwnddlg_decode != 0) InitDecodeDialog(hwnddlg_decode);
					if (hwnddlg_lm != 0) InitLmDialog(hwnddlg_lm);
					if (hwnddlg_am != 0) InitAmDialog(hwnddlg_am);
					if (hwnddlg_cmnss != 0) InitAmDialog(hwnddlg_cmnss);
				}
				break;
			case IDC_BUTTON_SAVECONF:
				// ���݂̓��e�𔽉f������
				PropSheet_Apply(GetParent(hwndDlg));

				SaveJConfFile(hwndDlg, &(pThis->m_gopt));
				RefreshMainDialog(hwndDlg);
				break;
			case IDC_BUTTON_REF_ERRLOGFILE:
				if (SelectLogFile(hwndDlg, "�G���[���O�t�@�C����I��", IDC_EDIT_ERRLOGFILE, pThis->m_gopt.m_strErrLogFile)==0)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					return TRUE;
				}
				break;
			case IDC_BUTTON_REF_OUTLOGFILE:
				if (SelectLogFile(hwndDlg, "�o�̓��O�t�@�C����I��", IDC_EDIT_OUTLOGFILE, pThis->m_gopt.m_strOutLogFile)==0)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					return TRUE;
				}
				break;
			case IDC_BUTTON_REF_DEBUGLOGFILE:
				if (SelectLogFile(hwndDlg, "�f�o�b�O���O�t�@�C����I��", IDC_EDIT_DEBUGLOGFILE, pThis->m_gopt.m_strDebugLogFile)==0)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					return TRUE;
				}
				break;
			case IDC_EDIT_ERRLOGFILE:
			case IDC_EDIT_OUTLOGFILE:
			case IDC_EDIT_DEBUGLOGFILE:
				if (HIWORD(wParam) == EN_CHANGE)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					return TRUE;
				}
				break;
			}
			break;
		case WM_NOTIFY:
			nmhdr = (NMHDR *)lParam;
			switch (nmhdr->code) {
		case PSN_SETACTIVE:
			//					InitMainDialog(hwndDlg);
			RefreshMainDialog(hwndDlg);
			break;
		case PSN_APPLY:
			if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_ERRLOG)) == BST_CHECKED)
				pThis->m_gopt.m_bUseErrLogFile = 1;
			else
				pThis->m_gopt.m_bUseErrLogFile = 0;
			if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_OUTLOG)) == BST_CHECKED)
				pThis->m_gopt.m_bUseOutLogFile = 1;
			else
				pThis->m_gopt.m_bUseOutLogFile = 0;
			if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_DEBUGLOG)) == BST_CHECKED)
				pThis->m_gopt.m_bUseDebugLogFile = 1;
			else
				pThis->m_gopt.m_bUseDebugLogFile = 0;
			if (SetDlgTextToString(hwndDlg, IDC_EDIT_ERRLOGFILE, pThis->m_gopt.m_strErrLogFile))
				return FALSE;
			if (SetDlgTextToString(hwndDlg, IDC_EDIT_OUTLOGFILE, pThis->m_gopt.m_strOutLogFile))
				return FALSE;
			if (SetDlgTextToString(hwndDlg, IDC_EDIT_DEBUGLOGFILE, pThis->m_gopt.m_strDebugLogFile))
				return FALSE;
			RefreshMainDialog(hwndDlg);
			return TRUE;
		default:
			return FALSE;
			}
			break;
	}
	return FALSE;
}

BOOL CALLBACK CJuliSAPIEngineUI::EnginePropertiesAudioProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);
	NMHDR *nmhdr;

	switch(uMsg) {
		case WM_INITDIALOG:
			{
				PROPSHEETPAGE *psp = (PROPSHEETPAGE *)lParam;
				pThis = (CJuliSAPIEngineUI *)psp->lParam;
			}
			::SetWindowLong(hwndDlg, GWL_USERDATA, (LONG)pThis);
			hwnddlg_audio = hwndDlg;
			InitAudioDialog(hwndDlg);
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
			case IDC_CHECK_DEF_LEVELTHRESHOLD:
				SetDlgItemInt(hwndDlg, IDC_EDIT_LEVELTHRESHOLD, pThis->m_gopt.level_thres.GetDefault(), TRUE);
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshAudioDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_HEADMARGIN:
				SetDlgItemInt(hwndDlg, IDC_EDIT_HEADMARGIN, pThis->m_gopt.head_margin_msec.GetDefault(), TRUE);
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshAudioDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_TAILMARGIN:
				SetDlgItemInt(hwndDlg, IDC_EDIT_TAILMARGIN, pThis->m_gopt.tail_margin_msec.GetDefault(), TRUE);
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshAudioDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_ZCTHRESHOLD:
				SetDlgItemInt(hwndDlg, IDC_EDIT_ZCTHRESHOLD, pThis->m_gopt.zero_cross_num.GetDefault(), TRUE);
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshAudioDialog(hwndDlg);
				break;

			case IDC_CHECK_NOSTRIP:
			case IDC_CHECK_ADDNOISE:
			case IDC_CHECK_WAVEOUTFILE:
				if (HIWORD(wParam) == BN_CLICKED)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					RefreshAudioDialog(hwndDlg);
				}
				break;
			case IDC_EDIT_LEVELTHRESHOLD:
			case IDC_EDIT_HEADMARGIN:
			case IDC_EDIT_TAILMARGIN:
			case IDC_EDIT_ZCTHRESHOLD:
			case IDC_EDIT_WAVEOUTFILE:
				if (HIWORD(wParam) == EN_CHANGE)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					RefreshAudioDialog(hwndDlg);
					return TRUE;
				}
				break;
			case IDC_COMBO_SEGMENT:
				if (HIWORD(wParam) == CBN_SELCHANGE)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					return TRUE;
				}
				break;
			case IDC_BUTTON_REF_WAVEOUTFILE:
				SelectModelFile(hwndDlg, "WAVE�o�̓t�@�C����I��", IDC_EDIT_WAVEOUTFILE, pThis->m_gopt.m_strWaveOutFile);
				break;
			}
			break;
		case WM_NOTIFY:
			nmhdr = (NMHDR *)lParam;
			switch (nmhdr->code)
			{
			case PSN_SETACTIVE:
				break;
			case PSN_APPLY:
				if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_WAVEOUTFILE)) == BST_CHECKED)
					pThis->m_gopt.m_bUseWaveOutFile = 1;
				else
					pThis->m_gopt.m_bUseWaveOutFile = 0;
				if (SetDlgTextToString(hwndDlg, IDC_EDIT_WAVEOUTFILE, pThis->m_gopt.m_strWaveOutFile))
					return FALSE;

				if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_NOSTRIP)) == BST_CHECKED)
					pThis->m_gopt.strip_zero_sample = 0;
				else
					pThis->m_gopt.strip_zero_sample = 1;
				if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_ADDNOISE)) == BST_CHECKED)
					pThis->m_gopt.m_bAddNoize = 0;
				else
					pThis->m_gopt.m_bAddNoize = 1;

				pThis->m_gopt.level_thres = SetDlgTextToInt(hwndDlg, IDC_EDIT_LEVELTHRESHOLD);
				pThis->m_gopt.head_margin_msec = SetDlgTextToInt(hwndDlg, IDC_EDIT_HEADMARGIN);
				pThis->m_gopt.tail_margin_msec = SetDlgTextToInt(hwndDlg, IDC_EDIT_TAILMARGIN);
				pThis->m_gopt.zero_cross_num = SetDlgTextToInt(hwndDlg, IDC_EDIT_ZCTHRESHOLD);
				pThis->m_gopt.pause_segment = ComboBox_GetCurSel(GetDlgItem(hwndDlg, IDC_COMBO_SEGMENT));
				return TRUE;
			default:
				return FALSE;
			}
			break;
	}
	return FALSE;
}

BOOL CALLBACK CJuliSAPIEngineUI::EnginePropertiesAnalyzeProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);
	NMHDR *nmhdr;

	switch(uMsg) {
		case WM_INITDIALOG:
			{
				PROPSHEETPAGE *psp = (PROPSHEETPAGE *)lParam;
				pThis = (CJuliSAPIEngineUI *)psp->lParam;
			}
			::SetWindowLong(hwndDlg, GWL_USERDATA, (LONG)pThis);
			hwnddlg_analyze = hwndDlg;
			InitAnalyzeDialog(hwndDlg);
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
			case IDC_CHECK_DEF_HIPASS:
				SetDlgItemInt(hwndDlg, IDC_EDIT_HIPASS, pThis->m_gopt.hipass.GetDefault(), TRUE);
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshAnalyzeDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_LOPASS:
				SetDlgItemInt(hwndDlg, IDC_EDIT_LOPASS, pThis->m_gopt.lopass.GetDefault(), TRUE);
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshAnalyzeDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_FRAMESIZE:
				SetDlgItemInt(hwndDlg, IDC_EDIT_FRAMESIZE, pThis->m_gopt.fsize.GetDefault(), TRUE);
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshAnalyzeDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_FRAMESHIFT:
				SetDlgItemInt(hwndDlg, IDC_EDIT_FRAMESHIFT, pThis->m_gopt.fshift.GetDefault(), TRUE);
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshAnalyzeDialog(hwndDlg);
				break;
			case IDC_EDIT_HIPASS:
			case IDC_EDIT_LOPASS:
			case IDC_EDIT_FRAMESIZE:
			case IDC_EDIT_FRAMESHIFT:
				if (HIWORD(wParam) == EN_CHANGE)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					RefreshAudioDialog(hwndDlg);
					return TRUE;
				}
				break;
			case IDC_COMBO_AUDIOFORMAT:
				if (HIWORD(wParam) == CBN_SELCHANGE)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					return TRUE;
				}
				break;
			}
			break;
		case WM_NOTIFY:
			nmhdr = (NMHDR *)lParam;
			switch (nmhdr->code)
			{
			case PSN_SETACTIVE:
				break;
			case PSN_APPLY:
				pThis->m_gopt.hipass = SetDlgTextToInt(hwndDlg, IDC_EDIT_HIPASS);
				pThis->m_gopt.lopass = SetDlgTextToInt(hwndDlg, IDC_EDIT_LOPASS);
				pThis->m_gopt.fsize = SetDlgTextToInt(hwndDlg, IDC_EDIT_FRAMESIZE);
				pThis->m_gopt.fshift = SetDlgTextToInt(hwndDlg, IDC_EDIT_FRAMESHIFT);
				pThis->m_gopt.SetWaveType(ComboBox_GetCurSel(GetDlgItem(hwndDlg, IDC_COMBO_AUDIOFORMAT)));
				return TRUE;
			default:
				return FALSE;
			}
			break;
	}
	return FALSE;
}

BOOL CALLBACK CJuliSAPIEngineUI::EnginePropertiesDecodeProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);
	NMHDR *nmhdr;

	switch(uMsg) {
		case WM_INITDIALOG:
			{
				PROPSHEETPAGE *psp = (PROPSHEETPAGE *)lParam;
				pThis = (CJuliSAPIEngineUI *)psp->lParam;
			}
			::SetWindowLong(hwndDlg, GWL_USERDATA, (LONG)pThis);
			hwnddlg_decode = hwndDlg;
			InitDecodeDialog(hwndDlg);
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
			case IDC_CHECK_DEF_STACKSIZE:
				SetDlgItemInt(hwndDlg, IDC_EDIT_STACKSIZE, pThis->m_gopt.GetOption().stack_size.GetDefault(), TRUE);
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshDecodeDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_HYPOOVERFLOW:
				SetDlgItemInt(hwndDlg, IDC_EDIT_HYPOOVERFLOW, pThis->m_gopt.GetOption().hypo_overflow.GetDefault(), TRUE);
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshDecodeDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_SCANBEAMTHRES:
				SetDlgItemFloat(hwndDlg, IDC_EDIT_SCANBEAMTHRES, pThis->m_gopt.GetOption().scan_beam_thres.GetDefault());
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshDecodeDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_ENVELOPEDBESTFIRSTWIDTH:
				SetDlgItemInt(hwndDlg, IDC_EDIT_ENVELOPEDBESTFIRSTWIDTH, pThis->m_gopt.GetOption().enveloped_bestfirst_width.GetDefault(), TRUE);
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshDecodeDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_LOOKUPRANGE:
				SetDlgItemInt(hwndDlg, IDC_EDIT_LOOKUPRANGE, pThis->m_gopt.GetOption().lookup_range.GetDefault(), TRUE);
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshDecodeDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_CMALPHA:
				SetDlgItemFloat(hwndDlg, IDC_EDIT_CMALPHA, pThis->m_gopt.m_fCMAlpha.GetDefault());
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshDecodeDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_FR_SCORE:
				SetDlgItemFloat(hwndDlg, IDC_EDIT_FR_SCORE, pThis->m_gopt.m_probFRScore.GetDefault());
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshDecodeDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_FR_MINLENGTH:
				SetDlgItemInt(hwndDlg, IDC_EDIT_FR_MINLENGTH, pThis->m_gopt.m_iFRMinLength.GetDefault(), TRUE);
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshDecodeDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_FR_MAXLENGTH:
				SetDlgItemInt(hwndDlg, IDC_EDIT_FR_MAXLENGTH, pThis->m_gopt.m_iFRMaxLength.GetDefault(), TRUE);
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshDecodeDialog(hwndDlg);
				break;

			case IDC_CHECK_TRELLISBEAMWIDTH:
			case IDC_CHECK_WORDALIGN:
			case IDC_CHECK_LMPSPECIFIED:
			case IDC_CHECK_LMP2SPECIFIED:
			case IDC_CHECK_USE_FR:
			case IDC_CHECK_USE_FR_MINLENGTH:
			case IDC_CHECK_USE_FR_MAXLENGTH:
			case IDC_CHECK_USE_FR_FILLER:
			case IDC_CHECK_NBEST:
			case IDC_CHECK_USECM:
				if (HIWORD(wParam) == BN_CLICKED)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					RefreshDecodeDialog(hwndDlg);
				}
				break;
			case IDC_EDIT_LMWEIGHT:
			case IDC_EDIT_LMWEIGHT2:
			case IDC_EDIT_WORDINSERTIONPENALTY:
			case IDC_EDIT_WORDINSERTIONPENALTY2:
			case IDC_EDIT_TRELLISBEAMWIDTH:
			case IDC_EDIT_FR_SCORE:
			case IDC_EDIT_FR_MINLENGTH:
			case IDC_EDIT_FR_MAXLENGTH:
			case IDC_EDIT_STACKSIZE:
			case IDC_EDIT_HYPOOVERFLOW:
			case IDC_EDIT_SCANBEAMTHRES:
			case IDC_EDIT_ENVELOPEDBESTFIRSTWIDTH:
			case IDC_EDIT_LOOKUPRANGE:
			case IDC_EDIT_NBEST:
			case IDC_EDIT_SCORETHRES_HIGH:
			case IDC_EDIT_SCORETHRES_LOW:
				if (HIWORD(wParam) == EN_CHANGE)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					RefreshDecodeDialog(hwndDlg);
					return TRUE;
				}
			}
			break;
		case WM_NOTIFY:
			nmhdr = (NMHDR *)lParam;
			switch (nmhdr->code) {
		case PSN_SETACTIVE:
			break;
		case PSN_APPLY:
			RefreshDecodeDialog(hwndDlg);

			if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_WORDALIGN)) == BST_CHECKED)
				pThis->m_gopt.align_result_word_flag = 1;
			else
				pThis->m_gopt.align_result_word_flag = 0;

			pThis->m_gopt.GetOption().lmp_specified =
				(Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_LMPSPECIFIED)) == BST_CHECKED)?TRUE:FALSE;
			pThis->m_gopt.GetOption().lmp2_specified =
				(Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_LMP2SPECIFIED)) == BST_CHECKED)?TRUE:FALSE;
			pThis->m_gopt.m_bUseFalseRecognition =
				(Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_FR)) == BST_CHECKED)?TRUE:FALSE;
			pThis->m_gopt.m_bUseFRScore =
				(Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_FR_SCORE)) == BST_CHECKED)?TRUE:FALSE;
			pThis->m_gopt.m_bUseFRMinLength =
				(Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_FR_MINLENGTH)) == BST_CHECKED)?TRUE:FALSE;
			pThis->m_gopt.m_bUseFRMaxLength =
				(Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_FR_MAXLENGTH)) == BST_CHECKED)?TRUE:FALSE;
			pThis->m_gopt.m_bUseFRFiller =
				(Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_FR_FILLER)) == BST_CHECKED)?TRUE:FALSE;
			pThis->m_gopt.m_bUseNbest =
				(Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_NBEST)) == BST_CHECKED)?TRUE:FALSE;
			pThis->m_gopt.m_bUseCM =
				(Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USECM)) == BST_CHECKED)?TRUE:FALSE;

			pThis->m_gopt.GetOption().lm_weight = SetDlgTextToLOGPROB(hwndDlg, IDC_EDIT_LMWEIGHT);
			pThis->m_gopt.GetOption().lm_penalty = SetDlgTextToLOGPROB(hwndDlg, IDC_EDIT_WORDINSERTIONPENALTY);
			pThis->m_gopt.GetOption().lm_weight2 = SetDlgTextToLOGPROB(hwndDlg, IDC_EDIT_LMWEIGHT2);
			pThis->m_gopt.GetOption().lm_penalty2 = SetDlgTextToLOGPROB(hwndDlg, IDC_EDIT_WORDINSERTIONPENALTY2);
			pThis->m_gopt.GetOption().trellis_beam_width = SetDlgTextToInt(hwndDlg, IDC_EDIT_TRELLISBEAMWIDTH);

			pThis->m_gopt.GetOption().stack_size = SetDlgTextToInt(hwndDlg, IDC_EDIT_STACKSIZE);
			pThis->m_gopt.GetOption().hypo_overflow = SetDlgTextToInt(hwndDlg, IDC_EDIT_HYPOOVERFLOW);
			pThis->m_gopt.GetOption().scan_beam_thres = SetDlgTextToLOGPROB(hwndDlg, IDC_EDIT_SCANBEAMTHRES);
			pThis->m_gopt.GetOption().enveloped_bestfirst_width = SetDlgTextToInt(hwndDlg, IDC_EDIT_ENVELOPEDBESTFIRSTWIDTH);
			pThis->m_gopt.GetOption().lookup_range = SetDlgTextToInt(hwndDlg, IDC_EDIT_LOOKUPRANGE);

			pThis->m_gopt.m_fCMAlpha = SetDlgTextToFloat(hwndDlg, IDC_EDIT_CMALPHA);
			pThis->m_gopt.m_iNbest = SetDlgTextToInt(hwndDlg, IDC_EDIT_NBEST);
			pThis->m_gopt.m_probFRScore = SetDlgTextToLOGPROB(hwndDlg, IDC_EDIT_FR_SCORE);
			pThis->m_gopt.m_iFRMinLength = SetDlgTextToInt(hwndDlg, IDC_EDIT_FR_MINLENGTH);
			pThis->m_gopt.m_iFRMaxLength = SetDlgTextToInt(hwndDlg, IDC_EDIT_FR_MAXLENGTH);
			pThis->m_gopt.m_fScoreThresHigh = SetDlgTextToFloat(hwndDlg, IDC_EDIT_SCORETHRES_HIGH);
			pThis->m_gopt.m_fScoreThresLow = SetDlgTextToFloat(hwndDlg, IDC_EDIT_SCORETHRES_LOW);
			return TRUE;
		default:
			return FALSE;
			}
			break;
	}
	return FALSE;
}

BOOL CALLBACK CJuliSAPIEngineUI::EnginePropertiesCMNSSProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);
	NMHDR *nmhdr;

	switch(uMsg) {
		case WM_INITDIALOG:
			{
				PROPSHEETPAGE *psp = (PROPSHEETPAGE *)lParam;
				pThis = (CJuliSAPIEngineUI *)psp->lParam;
			}
			::SetWindowLong(hwndDlg, GWL_USERDATA, (LONG)pThis);
			hwnddlg_cmnss = hwndDlg;
			InitCMNSSDialog(hwndDlg);
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
			case IDC_CHECK_DEF_SSCALCLEN:
				SetDlgItemInt(hwndDlg, IDC_EDIT_SSCALCLEN, pThis->m_gopt.sscalc_len.GetDefault(), TRUE);
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshCMNSSDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_SSALPHA:
				SetDlgItemFloat(hwndDlg, IDC_EDIT_SSALPHA, pThis->m_gopt.ssalpha.GetDefault());
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshCMNSSDialog(hwndDlg);
				break;
			case IDC_CHECK_DEF_SSFLOOR:
				SetDlgItemFloat(hwndDlg, IDC_EDIT_SSFLOOR, pThis->m_gopt.ssfloor.GetDefault());
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshCMNSSDialog(hwndDlg);
				break;
			case IDC_CHECK_CMNCYCLE:
			case IDC_CHECK_CMNLOAD:
			case IDC_CHECK_CMNSAVE:
			case IDC_RADIO_SS_NONE:
			case IDC_RADIO_SS_CALC:
			case IDC_RADIO_SS_LOAD:
				if (HIWORD(wParam) == BN_CLICKED)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					RefreshCMNSSDialog(hwndDlg);
				}
				break;
			case IDC_BUTTON_REF_CMNLOADFILE:
				SelectLogFile(hwndDlg, "CMN�ǂݍ��݃t�@�C����I��", IDC_EDIT_CMNLOADFILE, pThis->m_gopt.m_strCMNLoadFile);
				break;
			case IDC_BUTTON_REF_CMNSAVEFILE:
				SelectLogFile(hwndDlg, "CMN�ۑ��t�@�C����I��", IDC_EDIT_CMNSAVEFILE, pThis->m_gopt.m_strCMNSaveFile);
				break;
			case IDC_BUTTON_REF_SSLOADFILE:
				SelectModelFile(hwndDlg, "SS�ǂݍ��݃t�@�C����I��", IDC_EDIT_SSLOADFILE, pThis->m_gopt.m_strSSLoadFile);
				break;
			case IDC_EDIT_CMNLOADFILE:
			case IDC_EDIT_CMNSAVEFILE:
			case IDC_EDIT_SSLOADFILE:
			case IDC_EDIT_SSCALCLEN:
			case IDC_EDIT_SSALPHA:
			case IDC_EDIT_SSFLOOR:
				if (HIWORD(wParam) == EN_CHANGE)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					RefreshCMNSSDialog(hwndDlg);
					return TRUE;
				}
			}
			break;
		case WM_NOTIFY:
			nmhdr = (NMHDR *)lParam;
			switch (nmhdr->code) {
		case PSN_SETACTIVE:
			break;
		case PSN_APPLY:
			RefreshCMNSSDialog(hwndDlg);

			pThis->m_gopt.m_bCMNCycle =
				(Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_CMNCYCLE)) == BST_CHECKED)?TRUE:FALSE;
			pThis->m_gopt.m_bCMNLoad =
				(Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_CMNLOAD)) == BST_CHECKED)?TRUE:FALSE;
			pThis->m_gopt.m_bCMNSave =
				(Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_CMNSAVE)) == BST_CHECKED)?TRUE:FALSE;
			SetDlgTextToString(hwndDlg, IDC_EDIT_CMNLOADFILE, pThis->m_gopt.m_strCMNLoadFile);
			SetDlgTextToString(hwndDlg, IDC_EDIT_CMNSAVEFILE, pThis->m_gopt.m_strCMNSaveFile);
			SetDlgTextToString(hwndDlg, IDC_EDIT_SSLOADFILE, pThis->m_gopt.m_strSSLoadFile);
			pThis->m_gopt.sscalc_len = SetDlgTextToInt(hwndDlg, IDC_EDIT_SSCALCLEN);
			pThis->m_gopt.ssalpha = SetDlgTextToFloat(hwndDlg, IDC_EDIT_SSALPHA);
			pThis->m_gopt.ssfloor = SetDlgTextToFloat(hwndDlg, IDC_EDIT_SSFLOOR);
			pThis->m_gopt.m_iSSMode =
				(Button_GetCheck(GetDlgItem(hwndDlg, IDC_RADIO_SS_CALC)) == BST_CHECKED)?1:
			(Button_GetCheck(GetDlgItem(hwndDlg, IDC_RADIO_SS_LOAD)) == BST_CHECKED)?2:0;
			return TRUE;
		default:
			return FALSE;
			}
			break;
	}
	return FALSE;
}
BOOL CALLBACK CJuliSAPIEngineUI::EnginePropertiesAmProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);
	NMHDR *nmhdr;

	switch(uMsg) {
		case WM_INITDIALOG:
			{
				PROPSHEETPAGE *psp = (PROPSHEETPAGE *)lParam;
				pThis = (CJuliSAPIEngineUI *)psp->lParam;
			}
			::SetWindowLong(hwndDlg, GWL_USERDATA, (LONG)pThis);
			hwnddlg_am = hwndDlg;
			InitAmDialog(hwndDlg);
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
			case IDC_BUTTON_REF_HMMFILE:
				if (SelectModelFile(hwndDlg,"HMM �t�@�C����I��",IDC_EDIT_HMMFILE,pThis->m_gopt.m_strHmmFile)==0)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				}
				break;
			case IDC_BUTTON_REF_MAPFILE:
				if (SelectModelFile(hwndDlg,"MAP �t�@�C����I��",IDC_EDIT_MAPFILE,pThis->m_gopt.m_strMapFile)==0)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				}
				break;
			case IDC_BUTTON_REF_GSHMMFILE:
				if (SelectModelFile(hwndDlg,"GSHMM �t�@�C����I��",IDC_EDIT_GSHMMFILE,pThis->m_gopt.m_strGsHmmFile)==0)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				}
				break;
			case IDC_CHECK_USE_MAP:
				if (HIWORD(wParam) == BN_CLICKED)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					RefreshAmDialog(hwndDlg);
				}
				break;
			case IDC_CHECK_USE_GSHMM:
				if (HIWORD(wParam) == BN_CLICKED)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					RefreshAmDialog(hwndDlg);
				}
				break;
			case IDC_EDIT_HMMFILE:
			case IDC_EDIT_MAPFILE:
			case IDC_EDIT_GSHMMFILE:
			case IDC_EDIT_GSHMM_STATE:
				if (HIWORD(wParam) == EN_CHANGE)
				{
					PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
					return TRUE;
				}
				break;
			}
			break;
		case WM_NOTIFY:
			nmhdr = (NMHDR *)lParam;
			switch (nmhdr->code) {
		case PSN_SETACTIVE:
			break;
		case PSN_KILLACTIVE:
			/*
			if (CheckAndWarningEdit(hwndDlg, IDC_EDIT_HMMFILE))
			{
			SetWindowLong(hwndDlg, DWL_MSGRESULT, TRUE);	// �ύX��F�߂Ȃ�
			break;
			}
			if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_MAP)) == BST_CHECKED)
			{
			if (CheckAndWarningEdit(hwndDlg, IDC_EDIT_MAPFILE))
			{
			SetWindowLong(hwndDlg, DWL_MSGRESULT, TRUE);	// �ύX��F�߂Ȃ�
			break;
			}
			}
			if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_GSHMM)) == BST_CHECKED)
			{
			if (CheckAndWarningEdit(hwndDlg, IDC_EDIT_GSHMMFILE))
			{
			SetWindowLong(hwndDlg, DWL_MSGRESULT, TRUE);	// �ύX��F�߂Ȃ�
			break;
			}
			}
			SetWindowLong(hwndDlg, DWL_MSGRESULT, FALSE);	// �ύX��F�߂�
			*/
			break;
		case PSN_APPLY:
			{
				if (CheckAndWarningEdit(hwndDlg, IDC_EDIT_HMMFILE))	return FALSE;
				if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_MAP)) == BST_CHECKED)
				{
					if (CheckAndWarningEdit(hwndDlg, IDC_EDIT_MAPFILE))	return FALSE;
				}
				if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_GSHMM)) == BST_CHECKED)
				{
					if (CheckAndWarningEdit(hwndDlg, IDC_EDIT_GSHMMFILE))	return FALSE;
				}
			}
			if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_MAP)) == BST_CHECKED)
				pThis->m_gopt.m_bUseMapFile = 1;
			else
				pThis->m_gopt.m_bUseMapFile = 0;
			if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USE_GSHMM)) == BST_CHECKED)
				pThis->m_gopt.m_bUseGsHmmFile = 1;
			else
				pThis->m_gopt.m_bUseGsHmmFile = 0;
			if (SetDlgTextToString(hwndDlg, IDC_EDIT_HMMFILE, pThis->m_gopt.m_strHmmFile))
				return FALSE;
			if (SetDlgTextToString(hwndDlg, IDC_EDIT_MAPFILE, pThis->m_gopt.m_strMapFile))
				return FALSE;
			if (SetDlgTextToString(hwndDlg, IDC_EDIT_GSHMMFILE, pThis->m_gopt.m_strGsHmmFile))
				return FALSE;
			{
				string str;
				if (SetDlgTextToString(hwndDlg, IDC_EDIT_GSHMMFILE, str))
					return FALSE;
				pThis->m_gopt.GetOption().gs_statenum = atoi(str.c_str());
			}
			return TRUE;
		default:
			return FALSE;
			}
			break;
	}
	return FALSE;
}
BOOL CALLBACK CJuliSAPIEngineUI::EnginePropertiesLmProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);
	NMHDR *nmhdr;

	switch(uMsg)
	{
	case WM_INITDIALOG:
		{
			PROPSHEETPAGE *psp = (PROPSHEETPAGE *)lParam;
			pThis = (CJuliSAPIEngineUI *)psp->lParam;
		}
		::SetWindowLong(hwndDlg, GWL_USERDATA, (LONG)pThis);
		hwnddlg_lm = hwndDlg;
		InitLmDialog(hwndDlg);

		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDC_BUTTON_REF_NGRAMFILE:
			SelectModelFile(hwndDlg, "NGRAM �t�@�C����I��", IDC_EDIT_NGRAMFILE, pThis->m_gopt.GetOption().m_strNgramFile);
			break;
		case IDC_BUTTON_REF_NGRAMARPALRFILE:
			SelectModelFile(hwndDlg,"NGRAM LR �t�@�C����I��",IDC_EDIT_NGRAMARPALRFILE,pThis->m_gopt.GetOption().m_strNgramArpaLRFile);
			break;
		case IDC_BUTTON_REF_NGRAMARPARLFILE:
			SelectModelFile(hwndDlg,"NGRAM RL �t�@�C����I��",IDC_EDIT_NGRAMARPARLFILE,pThis->m_gopt.GetOption().m_strNgramArpaRLFile);
			break;
		case IDC_BUTTON_REF_DICTFILE:
			SelectModelFile(hwndDlg,"DICT �t�@�C����I��",IDC_EDIT_DICTFILE,pThis->m_gopt.GetOption().m_strDictFile);
			break;
		case IDC_BUTTON_REF_IMEDLLFILE:
			SelectModelFile(hwndDlg,"IME DLL �t�@�C����I��",IDC_EDIT_IMEDLLFILE,pThis->m_gopt.m_strIMEDllFile);
			break;
		case IDC_RADIO_NGRAM:
		case IDC_RADIO_ARPA:
		case IDC_CHECK_NOUSESLM:
		case IDC_CHECK_USEIME:
		case IDC_CHECK_USEIMEDLLFILE:
		case IDC_CHECK_USESILHEAD:
		case IDC_CHECK_USESILTAIL:
			if (HIWORD(wParam) == BN_CLICKED)
			{
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				RefreshLmDialog(hwndDlg);
			}
			break;
		case IDC_EDIT_NGRAMFILE:
		case IDC_EDIT_NGRAMARPALRFILE:
		case IDC_EDIT_NGRAMARPARLFILE:
		case IDC_EDIT_DICTFILE:
		case IDC_EDIT_IMEDLLFILE:
		case IDC_EDIT_SILHEAD:
		case IDC_EDIT_SILTAIL:
			if (HIWORD(wParam) == EN_CHANGE)
			{
				PropSheet_Changed(GetParent(hwndDlg), hwndDlg);
				return TRUE;
			}
			break;
		}
		break;
	case WM_NOTIFY:
		nmhdr = (NMHDR *)lParam;
		switch (nmhdr->code) {
	case PSN_SETACTIVE:
		break;
	case PSN_KILLACTIVE:
		/*
		if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_RADIO_NGRAM)) == BST_CHECKED)
		{
		if (CheckAndWarningEdit(hwndDlg, IDC_EDIT_NGRAMFILE))
		{
		SetWindowLong(hwndDlg, DWL_MSGRESULT, TRUE);	// �ύX��F�߂Ȃ�
		break;
		}
		} else {
		if (CheckAndWarningEdit(hwndDlg, IDC_EDIT_NGRAMARPALRFILE))
		{
		SetWindowLong(hwndDlg, DWL_MSGRESULT, TRUE);	// �ύX��F�߂Ȃ�
		break;
		}
		if (CheckAndWarningEdit(hwndDlg, IDC_EDIT_NGRAMARPARLFILE))
		{
		SetWindowLong(hwndDlg, DWL_MSGRESULT, TRUE);	// �ύX��F�߂Ȃ�
		break;
		}
		}
		if (CheckAndWarningEdit(hwndDlg, IDC_EDIT_DICTFILE))
		{
		SetWindowLong(hwndDlg, DWL_MSGRESULT, TRUE);	// �ύX��F�߂Ȃ�
		break;
		}
		#if 0
		if (CheckAndWarningEdit(hwndDlg, IDC_EDIT_DFAFILE))
		{
		SetWindowLong(hwndDlg, DWL_MSGRESULT, TRUE);	// �ύX��F�߂Ȃ�
		break;
		}
		#endif
		SetWindowLong(hwndDlg, DWL_MSGRESULT, FALSE);	// �ύX��F�߂�
		*/
		break;
	case PSN_APPLY:
		{
			if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_RADIO_NGRAM)) == BST_CHECKED)
			{
				if (CheckAndWarningEdit(hwndDlg, IDC_EDIT_NGRAMFILE))	return FALSE;
			} else {
				if (CheckAndWarningEdit(hwndDlg, IDC_EDIT_NGRAMARPALRFILE))	return FALSE;
				if (CheckAndWarningEdit(hwndDlg, IDC_EDIT_NGRAMARPARLFILE))	return FALSE;
			}
			if (CheckAndWarningEdit(hwndDlg, IDC_EDIT_DICTFILE))	return FALSE;
		}

		if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_NOUSESLM)) == BST_CHECKED)
			pThis->m_gopt.m_bNoUseSLM = 1;
		else
			pThis->m_gopt.m_bNoUseSLM = 0;
		if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_RADIO_NGRAM)) == BST_CHECKED)
			pThis->m_gopt.GetOption().m_bUseArpaFile = 0;
		else
			pThis->m_gopt.GetOption().m_bUseArpaFile = 1;

		if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USEIME)) == BST_CHECKED)
			pThis->m_gopt.m_bUseIME = 1;
		else
			pThis->m_gopt.m_bUseIME = 0;

		if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USEIMEDLLFILE)) == BST_CHECKED)
			pThis->m_gopt.m_bUseIMEDllFile = 1;
		else
			pThis->m_gopt.m_bUseIMEDllFile = 0;

		if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USESILHEAD)) == BST_CHECKED)
			pThis->m_gopt.GetOption().m_bUseHeadSilName = 1;
		else
			pThis->m_gopt.GetOption().m_bUseHeadSilName = 0;

		if (Button_GetCheck(GetDlgItem(hwndDlg, IDC_CHECK_USESILTAIL)) == BST_CHECKED)
			pThis->m_gopt.GetOption().m_bUseTailSilName = 1;
		else
			pThis->m_gopt.GetOption().m_bUseTailSilName = 0;

		if (SetDlgTextToString(hwndDlg, IDC_EDIT_NGRAMFILE, pThis->m_gopt.GetOption().m_strNgramFile))
			return FALSE;
		if (SetDlgTextToString(hwndDlg, IDC_EDIT_NGRAMARPALRFILE, pThis->m_gopt.GetOption().m_strNgramArpaLRFile))
			return FALSE;
		if (SetDlgTextToString(hwndDlg, IDC_EDIT_NGRAMARPARLFILE, pThis->m_gopt.GetOption().m_strNgramArpaRLFile))
			return FALSE;
		if (SetDlgTextToString(hwndDlg, IDC_EDIT_DICTFILE, pThis->m_gopt.GetOption().m_strDictFile))
			return FALSE;
		if (SetDlgTextToString(hwndDlg, IDC_EDIT_IMEDLLFILE, pThis->m_gopt.m_strIMEDllFile))
			return FALSE;
		if (SetDlgTextToString(hwndDlg, IDC_EDIT_SILHEAD, pThis->m_gopt.GetOption().m_strHeadSilentName))
			return FALSE;
		if (SetDlgTextToString(hwndDlg, IDC_EDIT_SILTAIL, pThis->m_gopt.GetOption().m_strTailSilentName))
			return FALSE;
		return TRUE;
	default:
		return FALSE;
		}
		break;
	}
	return FALSE;
}


BOOL CALLBACK CJuliSAPIEngineUI::EnginePropertiesEx1Proc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);
	NMHDR *nmhdr;

	switch(uMsg) {
		case WM_INITDIALOG:
			{
				PROPSHEETPAGE *psp = (PROPSHEETPAGE *)lParam;
				pThis = (CJuliSAPIEngineUI *)psp->lParam;
			}
			::SetWindowLong(hwndDlg, GWL_USERDATA, (LONG)pThis);
			hwnddlg_ex1 = hwndDlg;
			InitEx1Dialog(hwndDlg);

			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
			case IDC_BUTTON_REF_PALIGNFILE:
				SelectModelFile(hwndDlg, "PALIGN�o�̓t�@�C����I��", IDC_EDIT_PALIGNFILE, pThis->m_gopt.m_strPhonemeAlignFile);
				break;
			case IDC_BUTTON_REF_MFCCFILE:
				SelectModelFile(hwndDlg, "MFCC�o�̓t�@�C����I��", IDC_EDIT_MFCCFILE, pThis->m_gopt.m_strMfccFile);
				break;
			case IDC_BUTTON_REF_WAVEOUTFILE:
				SelectModelFile(hwndDlg, "WAVE�o�̓t�@�C����I��", IDC_EDIT_WAVEOUTFILE, pThis->m_gopt.m_strWaveOutFile);
				break;
			}
			break;
		case WM_NOTIFY:
			nmhdr = (NMHDR *)lParam;
			switch (nmhdr->code) {
		case PSN_SETACTIVE:
			break;
		case PSN_APPLY:
			return TRUE;
		default:
			return FALSE;
			}
			break;
	}
	return FALSE;
}

BOOL CALLBACK CJuliSAPIEngineUI::EnginePropertiesAboutProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	// WM_INITDIALOG �ɂ���Đݒ肳�ꂽ�A�Ăяo���C���X�^���X���擾
	CJuliSAPIEngineUI *pThis = (CJuliSAPIEngineUI *)::GetWindowLong(hwndDlg, GWL_USERDATA);
	NMHDR *nmhdr;

	switch(uMsg) {
		case WM_INITDIALOG:
			{
				PROPSHEETPAGE *psp = (PROPSHEETPAGE *)lParam;
				pThis = (CJuliSAPIEngineUI *)psp->lParam;
			}
			::SetWindowLong(hwndDlg, GWL_USERDATA, (LONG)pThis);
			SendDlgItemMessage(hwndDlg, IDC_EDIT_ABOUT, WM_SETTEXT, 0, (LPARAM)
				"Julius for SAPI ver 2.2"
#ifdef _DEBUG
				"   (���f�o�b�O�R���p�C��)"
#endif
				"\r\n\r\n"
				"Copyright (c) 2001-2003 Takashi Sumiyoshi\r\n"
				"Speech Media Lab. Kyoto University\r\n"
				"All rights reserved.\r\n"
				);

			hwnddlg_about = hwndDlg;
			//			InitDialog(hwndDlg);
			return TRUE;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
			case IDC_BUTTON_WWW_JULIUS:
				{
					char strurl[1024];
					GetDlgItemText(hwndDlg, IDC_BUTTON_WWW_JULIUS, strurl, 1024);
					::ShellExecute(NULL, NULL, strurl, NULL, NULL, SW_SHOWNORMAL);
				}
				break;
			}
			break;
		case WM_NOTIFY:
			nmhdr = (NMHDR *)lParam;
			switch (nmhdr->code) {
		case PSN_APPLY:
			return TRUE;
		default:
			return FALSE;
			}
			break;
	}
	return FALSE;
}


static void SetPropSheetPage(PROPSHEETPAGE *psp, CJuliSAPIEngineUI *j, HINSTANCE hInst, DLGPROC dlgProc, int resTmp, int resIcon, int resTitle)
{
	psp->dwSize			= sizeof(PROPSHEETPAGE);
	psp->dwFlags		= PSP_USEICONID | PSP_USETITLE;
	psp->hInstance		= hInst;
	psp->pszTemplate	= MAKEINTRESOURCE(resTmp);
	psp->pszIcon		= MAKEINTRESOURCE(resIcon);
	psp->pfnDlgProc		= dlgProc;
	psp->pszTitle		= MAKEINTRESOURCE(resTitle);
	psp->lParam			= (LPARAM) j;

	psp->pfnCallback	= NULL;
}

int CJuliSAPIEngineUI::DoEngineProperty(HWND hwndParent)
{
	// �v���p�e�B�y�[�W�̐ݒ�
	HINSTANCE hInst = g_hInst;
	PROPSHEETHEADER psh;
	PROPSHEETPAGE psp[8];	// �y�[�W��

	struct _JULI_PAGE_INFO_ {
		DLGPROC dproc;
		int resTmp, resIcon, resTitle;
	} dp[] = {
		{ EnginePropertiesMainProc,	IDD_ENGINE_PAGE_MAIN,	IDI_ENGINE_PAGE_MAIN,	IDS_ENGINE_PAGE_MAIN},
		{ EnginePropertiesAudioProc,	IDD_ENGINE_PAGE_AUDIO,	IDI_ENGINE_PAGE_AUDIO,	IDS_ENGINE_PAGE_AUDIO},
		{ EnginePropertiesAnalyzeProc,	IDD_ENGINE_PAGE_ANALYZE,	IDI_ENGINE_PAGE_ANALYZE,	IDS_ENGINE_PAGE_ANALYZE},
		{ EnginePropertiesLmProc,	IDD_ENGINE_PAGE_LM,	IDI_ENGINE_PAGE_LM,	IDS_ENGINE_PAGE_LM},
		{ EnginePropertiesAmProc,	IDD_ENGINE_PAGE_AM,	IDI_ENGINE_PAGE_AM,	IDS_ENGINE_PAGE_AM},
		{ EnginePropertiesDecodeProc,	IDD_ENGINE_PAGE_DECODE,	IDI_ENGINE_PAGE_DECODE,	IDS_ENGINE_PAGE_DECODE},
		{ EnginePropertiesCMNSSProc,	IDD_ENGINE_PAGE_CMNSS,	IDI_ENGINE_PAGE_CMNSS,	IDS_ENGINE_PAGE_CMNSS},
		{ EnginePropertiesAboutProc,	IDD_ENGINE_PAGE_ABOUT,	IDI_ENGINE_PAGE_ABOUT, IDS_ENGINE_PAGE_ABOUT},
		//		{ EnginePropertiesEx1Proc,	IDD_ENGINE_PAGE_EX1,	IDI_ENGINE_PAGE_EX1, IDS_ENGINE_PAGE_EX1},
		{ NULL, 0, 0, 0 }
	};
	for (int i=0;dp[i].dproc!=NULL;i++)
	{
		memset(&psp[i], 0, sizeof(PROPSHEETPAGE));
		SetPropSheetPage(&psp[i], this, hInst, dp[i].dproc, dp[i].resTmp, dp[i].resIcon, dp[i].resTitle);
	}
	memset(&psh, 0, sizeof(PROPSHEETHEADER));
	psh.dwSize = sizeof(PROPSHEETHEADER);
	psh.dwFlags = PSH_USEICONID | PSH_PROPSHEETPAGE;
	psh.hwndParent = hwndParent;
	psh.hInstance = hInst;
	//	psh.pszIcon = MAKEINTRESOURCE(IDI_ENGINE_SETTING);
	psh.pszCaption = MAKEINTRESOURCE(IDS_ENGINE_SETTING);
	psh.nPages = sizeof(psp) / sizeof(PROPSHEETPAGE);
	psh.nStartPage = 0;
	psh.ppsp = (LPCPROPSHEETPAGE) &psp;
	psh.pfnCallback = NULL;

	hwnddlg_main = 0;
	hwnddlg_am = 0;
	hwnddlg_lm = 0;
	hwnddlg_decode = 0;
	hwnddlg_about = 0;
	hwnddlg_ex1 = 0;
	hwnddlg_cmnss = 0;
	hwnddlg_audio = 0;
	hwnddlg_analyze = 0;
	return PropertySheet(&psh);
}

//====================================================================
// CJuliSAPIEngineUI::DisplayUI		�v�����ꂽ UI �̏������s��
//---- �Ԃ�l --------------------------------------------------------
// S_OK		����
//---- ���� ----------------------------------------------------------
// HWND hwndParent				�e�E�B���h�E�n���h��
// const WCHAR *pszTitle		�^�C�g��������
// const WCHAR * pszTypeOfUI	UI �̎�ނ�\��������
// void * pvExtraData			�G�L�X�g���f�[�^�ւ̃|�C���^
// ULONG cbExtraData			�G�L�X�g���f�[�^�̃T�C�Y
// ISpObjectToken * pToken		�g�[�N��
// IUnknown * punkObject		??
//====================================================================
STDMETHODIMP CJuliSAPIEngineUI::DisplayUI(
	HWND hwndParent, const WCHAR * pszTitle, const WCHAR * pszTypeOfUI,
	void * pvExtraData, ULONG cbExtraData, ISpObjectToken * pToken,
	IUnknown * punkObject)
{
	if (wcscmp(pszTypeOfUI, SPDUI_EngineProperties) == 0)
	{
		// ���G���W���̃v���p�e�B
		if (punkObject)
		{
			HRESULT hr;
			hr = ReadJuliOptions(pToken, &m_gopt);
			if (FAILED(hr))
			{
				MessageBoxW(hwndParent, L"ReadJuliOptions Failed", pszTitle, MB_OK);
			}
			int result = DoEngineProperty(hwndParent);

			switch (result)
			{
			case IDOK:
				//				MessageBoxW(hwndParent, L"���W�X�g���ɏ������݂܂�", pszTitle, MB_OK);
				WriteJuliOptions(pToken, &m_gopt);	// ���ʂ���������
				break;
			case ID_PSREBOOTSYSTEM:
				MessageBoxW(hwndParent, L"�V�X�e�������u�[�g���Ă�������", pszTitle, MB_OK);
				break;
			case ID_PSRESTARTWINDOWS:
				MessageBoxW(hwndParent, L"Windows ���ċN�����Ă�������", pszTitle, MB_OK);
				break;
			case 0:	// canceled
				//				MessageBoxW(hwndParent, L"�L�����Z��", pszTitle, MB_OK);
				break;
			case -1:
				MessageBoxW(hwndParent, L"�_�C�A���O�̍쐬�Ɏ��s", pszTitle, MB_OK);
				break;
			}
		}
	}
	if (wcscmp(pszTypeOfUI, SPDUI_UserTraining) == 0)
	{
		// �����[�U�g���[�j���O
		MessageBoxW(hwndParent, L"���[�U�g���[�j���O�͎�������Ă��܂���", pszTitle, MB_OK);
	}
	if (wcscmp(pszTypeOfUI, SPDUI_MicTraining) == 0)
	{
		// ���}�C�N�g���[�j���O
		MessageBoxW(hwndParent, L"�}�C�N�g���[�j���O�͎�������Ă��܂���", pszTitle, MB_OK);
	}
	if (wcscmp(pszTypeOfUI, SPDUI_AddRemoveWord) == 0)
	{
		// ���P��ǉ��폜
		MessageBoxW(hwndParent, L"�P��ǉ��폜�͎�������Ă��܂���", pszTitle, MB_OK);
	}
	return S_OK;
}

//====================================================================
// CJuliSAPIEngineUI::IsUISupported
//		�w�肳�ꂽ UI ���T�|�[�g����Ă��邩�𔻒肷��
//---- �Ԃ�l --------------------------------------------------------
// S_OK				����
// E_INVALIDARG		�����Ȉ���
//---- ���� ----------------------------------------------------------
// const WCHAR * pszTypeOfUI	UI �̎�ނ�\��������
// void * pvExtraData			�G�L�X�g���f�[�^�ւ̃|�C���^
// ULONG cbExtraData			�G�L�X�g���f�[�^�̃T�C�Y
// IUnknown * punkObject		UI �����C���^�[�t�F�[�X NULL:�f�t�H���g
// BOOL *pfSupported			[out] �T�|�[�g����Ă��邩��Ԃ�
//====================================================================
STDMETHODIMP CJuliSAPIEngineUI::IsUISupported(
	const WCHAR * pszTypeOfUI, void * pvExtraData, ULONG cbExtraData,
	IUnknown * punkObject, BOOL *pfSupported)
{
	*pfSupported = FALSE;

	if (wcscmp(pszTypeOfUI, SPDUI_AddRemoveWord) == 0)
		*pfSupported =TRUE;
	if (wcscmp(pszTypeOfUI, SPDUI_EngineProperties) == 0)
		*pfSupported =TRUE;
	if (wcscmp(pszTypeOfUI, SPDUI_UserTraining) == 0 && punkObject != NULL)
		*pfSupported = TRUE;
	if (wcscmp(pszTypeOfUI, SPDUI_MicTraining) == 0 && punkObject != NULL)
		*pfSupported = TRUE;

	return S_OK;
}

