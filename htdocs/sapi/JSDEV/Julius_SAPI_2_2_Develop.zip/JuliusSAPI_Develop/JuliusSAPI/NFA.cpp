//====================================================================
// NFA.cpp: NFA ���\�z����
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Speech Media Lab. Kyoto University     All rights reserved
//====================================================================

#include "NFA.h"
#include "DFA.h"
#include <algorithm>
#include <map>

#pragma warning (disable : 4786)


//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

CNFA::CNFA() : m_iNumStates(0), m_pStates(NULL)
{

}

CNFA::~CNFA()
{
	CreateStates(0);
}

ostream & operator<<(ostream &ost, CNFA &nfa)
{
	ost << "NFA : # of states: " << nfa.GetNumStates() << endl;
	for (int i=0;i<nfa.GetNumStates();i++)
	{
		if (nfa.GetState(i).IsInitial())
		{
			ost << ">";
		}
		if (nfa.GetState(i).IsAccept())
		{
			ost << "(" << i << "):";	// �󗝏��
		} else {
			ost << i << ":";
		}
		for (int a=0;a<nfa.GetState(i).GetNumArcs();a++)
		{
			if (nfa.GetState(i).GetArc(a).IsEpsillon())
				ost << " " << "��";
			else
				ost << " " << nfa.GetState(i).GetArc(a).GetSymbol();
			ost << "->" << nfa.GetState(i).GetArc(a).GetNextState();
		}
		ost << endl;
	}
	return ost;
}

int CNFA::CreateStates(int num)
{
	if (m_pStates != NULL) delete [] m_pStates;

	if (num>0)
	{
		m_pStates = new CNFAState[num];
		if (m_pStates == NULL) return 1;	// ���Ȃ�����
		m_iNumStates = num;
	} else {
		m_pStates = NULL;
	}
	return 0;
}

// s ����ÑJ�ڂŒH����Ԃ�S�����߂�
int CNFA::GetStatesForEpsillon(int s, STATESET *ss)
{
	ss->insert(s);
	for (int a=0;a<GetState(s).GetNumArcs();a++)
	{
		if (GetState(s).GetArc(a).IsEpsillon())	// �ÑJ��
		{
			int s2=GetState(s).GetArc(a).GetNextState();
			if (ss->count(s2) == 0)	// �J�ڐ悪�܂��܂܂�Ă��Ȃ��Ȃ�
			{
				GetStatesForEpsillon(s2, ss);
			}
		}
	}
	return 0;
}

void OutputStates(ostream &ost, STATESET &ss)
{
	int f=0;
	ost << "(";
	for (STATESET::iterator ssi = ss.begin(); ssi != ss.end(); ++ssi)
	{
		if (f) ost << ",";
		ost << *ssi;
		f=1;
	}
	ost << ")";
}


// DFA �ɕϊ��I
// (�Q�l����: �u�R���p�C���v���c��j�� �Y�Ɛ}�� pp.51-53)
int CNFA::Convert2DFA(CDFA *dfa)
{
	vector<STATESET> vStateSets;
	vector<map<short, STATESET > > vMap;	// �J�ڋL���ƁA����̎����
	// ������ԂƂ�������ÑJ�ڂł��ǂ���Ԃ̏W���𓾂�
	STATESET ss_init;
	for (int s=0;s<GetNumStates();s++)
	{
		if (GetState(s).IsInitial())
			GetStatesForEpsillon(s, &ss_init);
	}
	vStateSets.push_back(ss_init);

	{
		cout << "Initial States:";
		OutputStates(cout, ss_init);
		cout << endl;
	}

	// ���[�v
	for (int i=0;i<(int ) vStateSets.size();i++)
	{
		STATESET & ss = vStateSets[i];
		map<short, STATESET > m;
		// ��ԏW���̊e��Ԃɂ���
		for (STATESET::iterator ssi = ss.begin(); ssi != ss.end(); ++ssi)
		{
			// ��Ԃ̊e�J�ڂɂ���
			for (int a=0;a<GetState(*ssi).GetNumArcs();a++)
			{
				if (! GetState(*ssi).GetArc(a).IsEpsillon())
				{
					int sym = GetState(*ssi).GetArc(a).GetSymbol();
					STATESET ssp;
					GetStatesForEpsillon(GetState(*ssi).GetArc(a).GetNextState(), &ssp);
//					OutputStates(cout,ssp);
					for (STATESET::iterator ssi2 = ssp.begin(); ssi2 != ssp.end(); ++ssi2)
						m[sym].insert(*ssi2);
				}
			}
		}
		vMap.push_back(m);
		for (map<short, STATESET >::iterator mi = m.begin();mi != m.end(); ++mi)
		{
			// �������̏�Ԃ�������Ȃ���Ζ����ɒǉ�
			if (find(vStateSets.begin(), vStateSets.end(), mi->second) == vStateSets.end())
			{
				vStateSets.push_back(mi->second);
			}
		}
	}
	// �f�o�b�O�o��
	{
		for (i=0;i<(int ) vStateSets.size();i++)
		{
			STATESET & ss = vStateSets[i];
			OutputStates(cout, ss);
			cout << ":";
			for (map<short, STATESET >::iterator mi = vMap[i].begin();mi != vMap[i].end(); ++mi)
			{
				cout << " " << mi->first << "->";
				OutputStates(cout, mi->second);
			}
			cout << endl;
		}
	}

	// ��ԏW�����V������Ԃ̃e�[�u��
	map<STATESET, short> tbl;
	for (i=0;i<(int ) vStateSets.size();i++)
	{
		tbl[vStateSets[i]] = i;
	}

	// DFA �̍\�z
	dfa->CreateStates(vStateSets.size());
	for (i=0;i<(int ) vStateSets.size();i++)
	{
		for (map<short, STATESET >::iterator mi = vMap[i].begin();mi != vMap[i].end(); ++mi)
		{
			dfa->GetState(i).AddArc(mi->first, tbl[mi->second]);
		}
		// ��ԏW���̗v�f�Ɏ󗝏�Ԃ��܂܂�Ă���Ύ󗝏�Ԃ�
		for (set<short>::iterator si=vStateSets[i].begin();si!=vStateSets[i].end();++si)
		{
			if (GetState(*si).IsAccept())
				break;
		}
		if (si!=vStateSets[i].end())
			dfa->GetState(i).SetAccept(1);
	}

	return 0;
}


