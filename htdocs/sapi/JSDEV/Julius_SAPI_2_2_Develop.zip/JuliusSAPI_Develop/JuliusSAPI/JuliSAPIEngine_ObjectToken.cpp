//====================================================================
// JuliSAPIEngine_ObjectToken.cpp: CJuliSAPIEngine �̃C���v�������g
//     SetObjectToken, GetObjectToken
//--------------------------------------------------------------------
// Copyright (c) 2001-2003 Takashi Sumiyoshi
// Speech Media Lab. Kyoto University     All rights reserved
//====================================================================

#include "stdafx.h"
#include "JuliSAPIEngine.h"
#include "../j_modules/JuliGlobalOption.h"
#include "SpHelper.h"

// �g�[�N�����當����(string)�𓾂�
HRESULT GetStringFromObjectToken(ISpDataKey *key,string &str,const WCHAR *name)
{
	HRESULT hr;
	WCHAR *pszbuf = NULL;
	hr = key->GetStringValue(name, &pszbuf);
	//	key->GetDWORD();
	if(SUCCEEDED(hr))
	{
		char buf[300];
		::WideCharToMultiByte(CP_ACP,0,pszbuf,-1,buf,256,NULL,NULL);
		str = buf;
	}
	else if(hr == SPERR_NOT_FOUND)
	{
		str = "";
		hr = S_OK;
	}
	::CoTaskMemFree(pszbuf);
	return hr;
}    

// �g�[�N���ɕ�����(string)��ݒ肷��
HRESULT SetStringToObjectToken(ISpDataKey *key,string &str,const WCHAR *name)
{
	HRESULT hr;
	WCHAR buf[300];
	MultiByteToWideChar(CP_ACP,0,str.c_str(),-1,buf,256);
	hr = key->SetStringValue(name, buf);
	return hr;
}    

HRESULT WriteJuliOptions(ISpObjectToken * pToken, CJuliGlobalOption *gopt)
{
	HRESULT hr;
	// ���f���t�@�C�����̏��𓾂�
	CComPtr<ISpDataKey> cpModelKey;
	hr = pToken->CreateKey(L"Models", &cpModelKey);

	if (SUCCEEDED(hr))
	{
		SetStringToObjectToken(cpModelKey, gopt->GetOption().m_strNgramFile,L"NgramFile");
		SetStringToObjectToken(cpModelKey, gopt->GetOption().m_strNgramArpaLRFile,L"NgramArpaLRFile");
		SetStringToObjectToken(cpModelKey, gopt->GetOption().m_strNgramArpaRLFile,L"NgramArpaRLFile");
		SetStringToObjectToken(cpModelKey, gopt->GetOption().m_strDictFile,L"DictFile");
		SetStringToObjectToken(cpModelKey, gopt->m_strHmmFile,L"HmmFile");
		SetStringToObjectToken(cpModelKey, gopt->m_strMapFile,L"MapFile");
		SetStringToObjectToken(cpModelKey, gopt->m_strGsHmmFile,L"GsHmmFile");
		SetStringToObjectToken(cpModelKey, gopt->GetOption().m_strHeadSilentName,L"HeadSilentName");
		SetStringToObjectToken(cpModelKey, gopt->GetOption().m_strTailSilentName,L"TailSilentName");

		cpModelKey->SetDWORD(L"NoUseSLM", gopt->m_bNoUseSLM);
		cpModelKey->SetDWORD(L"UseMapFile", gopt->m_bUseMapFile);
		cpModelKey->SetDWORD(L"UseGsHmmFile", gopt->m_bUseGsHmmFile);
		cpModelKey->SetDWORD(L"UseArpaFile", gopt->GetOption().m_bUseArpaFile);
		cpModelKey->SetDWORD(L"UseHeadSilName", gopt->GetOption().m_bUseHeadSilName);
		cpModelKey->SetDWORD(L"UseTailSilName", gopt->GetOption().m_bUseTailSilName);
	}

	// ���O�t�@�C���̏��𓾂�
	CComPtr<ISpDataKey> cpLogFilesKey;
	hr = pToken->CreateKey(L"LogFiles", &cpLogFilesKey);

	if (SUCCEEDED(hr))
	{
		SetStringToObjectToken(cpLogFilesKey, gopt->m_strOutLogFile,L"OutLogFile");
		SetStringToObjectToken(cpLogFilesKey, gopt->m_strErrLogFile,L"ErrLogFile");
		SetStringToObjectToken(cpLogFilesKey, gopt->m_strDebugLogFile,L"DebugLogFile");

		cpLogFilesKey->SetDWORD(L"UseErrLogFile", gopt->m_bUseErrLogFile);
		cpLogFilesKey->SetDWORD(L"UseOutLogFile", gopt->m_bUseOutLogFile);
		cpLogFilesKey->SetDWORD(L"UseDebugLogFile", gopt->m_bUseDebugLogFile);
	}

	// IME�̏��𓾂�
	CComPtr<ISpDataKey> cpIMEKey;
	hr = pToken->CreateKey(L"IME", &cpIMEKey);

	if (SUCCEEDED(hr))
	{
		cpIMEKey->SetDWORD(L"UseIME", gopt->m_bUseIME);
		cpIMEKey->SetDWORD(L"UseIMEDllFile", gopt->m_bUseIMEDllFile);
		SetStringToObjectToken(cpIMEKey, gopt->m_strIMEDllFile,L"IMEDllFile");
	}

	// ���͉����̏��𓾂�
	CComPtr<ISpDataKey> cpAudioOptionsKey;
	hr = pToken->CreateKey(L"AudioOptions", &cpAudioOptionsKey);

	if (SUCCEEDED(hr))
	{
		cpAudioOptionsKey->SetDWORD(L"UseWaveOutFile", gopt->m_bUseWaveOutFile);

		cpAudioOptionsKey->SetDWORD(L"PauseSegment", gopt->pause_segment);
		cpAudioOptionsKey->SetDWORD(L"LevelThreshold", gopt->level_thres);
		cpAudioOptionsKey->SetDWORD(L"HeadMarginMsec", gopt->head_margin_msec);
		cpAudioOptionsKey->SetDWORD(L"TailMarginMsec", gopt->tail_margin_msec);
		cpAudioOptionsKey->SetDWORD(L"ZeroCross", gopt->zero_cross_num);
		cpAudioOptionsKey->SetDWORD(L"StripZeroSample", gopt->strip_zero_sample);
		cpAudioOptionsKey->SetDWORD(L"AddNoise", gopt->m_bAddNoize);
		cpAudioOptionsKey->SetDWORD(L"WaveFormat", gopt->m_iWaveType);
		cpAudioOptionsKey->SetDWORD(L"HiPassFreq", gopt->hipass);
		cpAudioOptionsKey->SetDWORD(L"LoPassFreq", gopt->lopass);
		cpAudioOptionsKey->SetDWORD(L"FrameSizeSample", gopt->fsize);
		cpAudioOptionsKey->SetDWORD(L"FrameShiftSample", gopt->fshift);
		SetStringToObjectToken(cpAudioOptionsKey, gopt->m_strWaveOutFile, L"WaveOutFile");
	}

	// ���͉����̏��𓾂�
	CComPtr<ISpDataKey> cpCMNSSOptionsKey;
	hr = pToken->CreateKey(L"CMNSSOptions", &cpCMNSSOptionsKey);

	if (SUCCEEDED(hr))
	{
		cpCMNSSOptionsKey->SetDWORD(L"CMNCycle", gopt->m_bCMNCycle);
		cpCMNSSOptionsKey->SetDWORD(L"CMNLoad", gopt->m_bCMNLoad);
		cpCMNSSOptionsKey->SetDWORD(L"CMNSave", gopt->m_bCMNSave);
		SetStringToObjectToken(cpCMNSSOptionsKey, gopt->m_strCMNLoadFile, L"CMNLoadFile");
		SetStringToObjectToken(cpCMNSSOptionsKey, gopt->m_strCMNSaveFile, L"CMNSaveFile");
		SetStringToObjectToken(cpCMNSSOptionsKey, gopt->m_strSSLoadFile, L"SSLoadFile");

		cpCMNSSOptionsKey->SetDWORD(L"SSCalcLen", gopt->sscalc_len);
		cpCMNSSOptionsKey->SetDWORD(L"SSMode", gopt->m_iSSMode);

		char buf[256];
		string str;
		sprintf(buf,"%f",gopt->ssalpha.GetValue());	str = buf;
		SetStringToObjectToken(cpCMNSSOptionsKey,str,L"SSAlpha");
		sprintf(buf,"%f",gopt->ssfloor.GetValue());	str = buf;
		SetStringToObjectToken(cpCMNSSOptionsKey,str,L"SSFloor");
	}

	// �f�R�[�h�I�v�V�����̏��𓾂�
	CComPtr<ISpDataKey> cpDecodeOptionsKey;
	hr = pToken->CreateKey(L"DecodeOptions", &cpDecodeOptionsKey);

	if (SUCCEEDED(hr))
	{
		SetStringToObjectToken(cpDecodeOptionsKey, gopt->m_strMfccFile,L"MfccFile");
		SetStringToObjectToken(cpDecodeOptionsKey, gopt->m_strPhonemeAlignFile,L"PhonemeAlignFile");
		cpDecodeOptionsKey->SetDWORD(L"UseMfccFile", gopt->m_bUseMfccFile);

		cpDecodeOptionsKey->SetDWORD(L"TrellisBeamWidth", gopt->GetOption().trellis_beam_width);
		cpDecodeOptionsKey->SetDWORD(L"GsStateNum", gopt->GetOption().gs_statenum);
		cpDecodeOptionsKey->SetDWORD(L"CalcWordAlign", gopt->align_result_word_flag);
		cpDecodeOptionsKey->SetDWORD(L"UsePhonemeAlign", gopt->m_bUsePhonemeAlignFile);
		cpDecodeOptionsKey->SetDWORD(L"UseFalseRecognition", gopt->m_bUseFalseRecognition);
		cpDecodeOptionsKey->SetDWORD(L"UseCM", gopt->m_bUseCM);

		cpDecodeOptionsKey->SetDWORD(L"StackSize", gopt->GetOption().stack_size);
		cpDecodeOptionsKey->SetDWORD(L"HypoOverflow", gopt->GetOption().hypo_overflow);
		cpDecodeOptionsKey->SetDWORD(L"EnvelopedBestFirstWidth", gopt->GetOption().enveloped_bestfirst_width);
		cpDecodeOptionsKey->SetDWORD(L"LookupRange", gopt->GetOption().lookup_range);

		cpDecodeOptionsKey->SetDWORD(L"UseNbest", gopt->m_bUseNbest);
		cpDecodeOptionsKey->SetDWORD(L"UseFRScore", gopt->m_bUseFRScore);
		cpDecodeOptionsKey->SetDWORD(L"UseFRMinLength", gopt->m_bUseFRMinLength);
		cpDecodeOptionsKey->SetDWORD(L"UseFRMaxLength", gopt->m_bUseFRMaxLength);
		cpDecodeOptionsKey->SetDWORD(L"UseFRFiller", gopt->m_bUseFRFiller);


		char buf[256];
		string str;

		sprintf(buf,"%f",gopt->m_fCMAlpha.GetValue());	str = buf;
		SetStringToObjectToken(cpDecodeOptionsKey,str,L"CMAlpha");
		sprintf(buf,"%f",gopt->GetOption().scan_beam_thres.GetValue());	str = buf;
		SetStringToObjectToken(cpDecodeOptionsKey,str,L"ScanBeamThres");
		sprintf(buf,"%d",gopt->m_iNbest);	str = buf;
		SetStringToObjectToken(cpDecodeOptionsKey,str,L"Nbest");
		sprintf(buf,"%f",gopt->m_probFRScore.GetValue());	str = buf;
		SetStringToObjectToken(cpDecodeOptionsKey,str,L"FRScore");
		cpDecodeOptionsKey->SetDWORD(L"FRMinLength", gopt->m_iFRMinLength);
		cpDecodeOptionsKey->SetDWORD(L"FRMaxLength", gopt->m_iFRMaxLength);
		sprintf(buf,"%f",gopt->m_fScoreThresHigh);	str = buf;
		SetStringToObjectToken(cpDecodeOptionsKey,str,L"ScoreThresHigh");
		sprintf(buf,"%f",gopt->m_fScoreThresLow);	str = buf;
		SetStringToObjectToken(cpDecodeOptionsKey,str,L"ScoreThresLow");

		// NGRAM �p
		sprintf(buf,"%f",gopt->GetOption().lm_weight);	str = buf;
		SetStringToObjectToken(cpDecodeOptionsKey,str,L"LmWeight");
		sprintf(buf,"%f",gopt->GetOption().lm_weight2);	str = buf;
		SetStringToObjectToken(cpDecodeOptionsKey,str,L"LmWeight2");
		sprintf(buf,"%f",gopt->GetOption().lm_penalty);	str = buf;
		SetStringToObjectToken(cpDecodeOptionsKey,str,L"LmPenalty");
		sprintf(buf,"%f",gopt->GetOption().lm_penalty2);	str = buf;
		SetStringToObjectToken(cpDecodeOptionsKey,str,L"LmPenalty2");

		cpDecodeOptionsKey->SetDWORD(L"LmpSpecified", gopt->GetOption().lmp_specified);
		cpDecodeOptionsKey->SetDWORD(L"Lmp2Specified", gopt->GetOption().lmp2_specified);

		// DFA �p(�g��Ȃ�����)
		sprintf(buf,"%f",gopt->GetOption().penalty1);	str = buf;
		SetStringToObjectToken(cpDecodeOptionsKey,str,L"Penalty1");
		sprintf(buf,"%f",gopt->GetOption().penalty2);	str = buf;
		SetStringToObjectToken(cpDecodeOptionsKey,str,L"Penalty2");
	}
	return hr;
}

HRESULT ReadJuliOptions(ISpObjectToken * pToken, CJuliGlobalOption *gopt)
{
	HRESULT hr;
	// ���f���t�@�C�����̏��𓾂�
	CComPtr<ISpDataKey> cpModelKey;
	hr = pToken->OpenKey(L"Models", &cpModelKey);

	if (SUCCEEDED(hr))
	{
		GetStringFromObjectToken(cpModelKey, gopt->GetOption().m_strNgramFile, L"NgramFile");
		GetStringFromObjectToken(cpModelKey, gopt->GetOption().m_strNgramArpaLRFile,L"NgramArpaLRFile");
		GetStringFromObjectToken(cpModelKey, gopt->GetOption().m_strNgramArpaRLFile,L"NgramArpaRLFile");
		GetStringFromObjectToken(cpModelKey, gopt->GetOption().m_strDictFile,L"DictFile");
		GetStringFromObjectToken(cpModelKey, gopt->m_strHmmFile,L"HmmFile");
		GetStringFromObjectToken(cpModelKey, gopt->m_strMapFile,L"MapFile");
		GetStringFromObjectToken(cpModelKey, gopt->m_strGsHmmFile,L"GsHmmFile");
		GetStringFromObjectToken(cpModelKey, gopt->GetOption().m_strHeadSilentName,L"HeadSilentName");
		GetStringFromObjectToken(cpModelKey, gopt->GetOption().m_strTailSilentName,L"TailSilentName");
		DWORD v;
		if (cpModelKey->GetDWORD(L"NoUseSLM", &v) == S_OK)	gopt->m_bNoUseSLM = (boolean ) v;
		if (cpModelKey->GetDWORD(L"UseMapFile", &v) == S_OK)	gopt->m_bUseMapFile = (boolean ) v;
		if (cpModelKey->GetDWORD(L"UseGsHmmFile", &v) == S_OK)	gopt->m_bUseGsHmmFile = (boolean ) v;
		if (cpModelKey->GetDWORD(L"UseArpaFile", &v) == S_OK)	gopt->GetOption().m_bUseArpaFile = v;
		if (cpModelKey->GetDWORD(L"UseHeadSilName", &v) == S_OK)	gopt->GetOption().m_bUseHeadSilName = v;
		if (cpModelKey->GetDWORD(L"UseTailSilName", &v) == S_OK)	gopt->GetOption().m_bUseTailSilName = v;
	}

	// ���O�t�@�C���̏��𓾂�
	CComPtr<ISpDataKey> cpLogFilesKey;
	hr = pToken->OpenKey(L"LogFiles", &cpLogFilesKey);

	if (SUCCEEDED(hr))
	{
		GetStringFromObjectToken(cpLogFilesKey, gopt->m_strOutLogFile,L"OutLogFile");
		GetStringFromObjectToken(cpLogFilesKey, gopt->m_strErrLogFile,L"ErrLogFile");
		GetStringFromObjectToken(cpLogFilesKey, gopt->m_strDebugLogFile,L"DebugLogFile");

		DWORD v;
		if (cpLogFilesKey->GetDWORD(L"UseErrLogFile", &v) == S_OK)	gopt->m_bUseErrLogFile = (boolean ) v;
		if (cpLogFilesKey->GetDWORD(L"UseOutLogFile", &v) == S_OK)	gopt->m_bUseOutLogFile = (boolean ) v;
		if (cpLogFilesKey->GetDWORD(L"UseDebugLogFile", &v) == S_OK)	gopt->m_bUseDebugLogFile = (boolean ) v;
	}

	// IME�̏��𓾂�
	CComPtr<ISpDataKey> cpIMEKey;
	hr = pToken->OpenKey(L"IME", &cpIMEKey);

	if (SUCCEEDED(hr))
	{
		DWORD v;
		if (cpIMEKey->GetDWORD(L"UseIME", &v) == S_OK)	gopt->m_bUseIME = (boolean ) v;
		if (cpIMEKey->GetDWORD(L"UseIMEDllFile", &v) == S_OK)	gopt->m_bUseIMEDllFile = (boolean ) v;
		GetStringFromObjectToken(cpIMEKey, gopt->m_strIMEDllFile, L"IMEDllFile");
	}

	// ���͉����̏��𓾂�
	CComPtr<ISpDataKey> cpAudioOptionsKey;
	hr = pToken->OpenKey(L"AudioOptions", &cpAudioOptionsKey);

	if (SUCCEEDED(hr))
	{
		DWORD v;
		if (cpAudioOptionsKey->GetDWORD(L"UseWaveOutFile", &v) == S_OK)			gopt->m_bUseWaveOutFile = (boolean )v;

		if (cpAudioOptionsKey->GetDWORD(L"PauseSegment", &v) == S_OK)	gopt->pause_segment = v;
		if (cpAudioOptionsKey->GetDWORD(L"LevelThreshold", &v) == S_OK)
				gopt->level_thres = v;
		if (cpAudioOptionsKey->GetDWORD(L"HeadMarginMsec", &v) == S_OK)
				gopt->head_margin_msec = v;
		if (cpAudioOptionsKey->GetDWORD(L"TailMarginMsec", &v) == S_OK)
				gopt->tail_margin_msec = v;
		if (cpAudioOptionsKey->GetDWORD(L"ZeroCross", &v) == S_OK)
				gopt->zero_cross_num = v;
		if (cpAudioOptionsKey->GetDWORD(L"StripZeroSample", &v) == S_OK) gopt->strip_zero_sample = (boolean )v;
		if (cpAudioOptionsKey->GetDWORD(L"AddNoise", &v) == S_OK) gopt->m_bAddNoize = (boolean )v;
		if (cpAudioOptionsKey->GetDWORD(L"WaveFormat", &v) == S_OK) gopt->SetWaveType(v);
		if (cpAudioOptionsKey->GetDWORD(L"HiPassFreq", &v) == S_OK) gopt->hipass = v;
		if (cpAudioOptionsKey->GetDWORD(L"LoPassFreq", &v) == S_OK) gopt->lopass = v;
		if (cpAudioOptionsKey->GetDWORD(L"FrameSizeSample", &v) == S_OK)
			gopt->fsize = v;
		if (cpAudioOptionsKey->GetDWORD(L"FrameShiftSample", &v) == S_OK)
				gopt->fshift = v;
		GetStringFromObjectToken(cpAudioOptionsKey, gopt->m_strWaveOutFile, L"WaveOutFile");
	}

	// ���͉����̏��𓾂�
	CComPtr<ISpDataKey> cpCMNSSOptionsKey;
	hr = pToken->OpenKey(L"CMNSSOptions", &cpCMNSSOptionsKey);

	if (SUCCEEDED(hr))
	{
		DWORD v;
		if (cpCMNSSOptionsKey->GetDWORD(L"CMNCycle", &v) == S_OK)		gopt->m_bCMNCycle = (boolean )v;
		if (cpCMNSSOptionsKey->GetDWORD(L"CMNLoad", &v) == S_OK)		gopt->m_bCMNLoad = (boolean )v;
		if (cpCMNSSOptionsKey->GetDWORD(L"CMNSave", &v) == S_OK)		gopt->m_bCMNSave = (boolean )v;
		GetStringFromObjectToken(cpCMNSSOptionsKey, gopt->m_strCMNLoadFile,L"CMNLoadFile");
		GetStringFromObjectToken(cpCMNSSOptionsKey, gopt->m_strCMNSaveFile,L"CMNSaveFile");
		GetStringFromObjectToken(cpCMNSSOptionsKey, gopt->m_strSSLoadFile,L"SSLoadFile");

		if (cpCMNSSOptionsKey->GetDWORD(L"SSCalcLen", &v) == S_OK)		gopt->sscalc_len = v;
		if (cpCMNSSOptionsKey->GetDWORD(L"SSMode", &v) == S_OK)		gopt->m_iSSMode = v;

		string tmp;
		if (SUCCEEDED(GetStringFromObjectToken(cpCMNSSOptionsKey,tmp,L"SSAlpha")))
			gopt->ssalpha = (LOGPROB ) atof(tmp.c_str());
		if (SUCCEEDED(GetStringFromObjectToken(cpCMNSSOptionsKey,tmp,L"SSFloor")))
			gopt->ssfloor = (LOGPROB ) atof(tmp.c_str());
	}

	// �f�R�[�h�I�v�V�����̏��𓾂�
	CComPtr<ISpDataKey> cpDecodeOptionsKey;
	hr = pToken->OpenKey(L"DecodeOptions", &cpDecodeOptionsKey);
	if (SUCCEEDED(hr))
	{
		GetStringFromObjectToken(cpDecodeOptionsKey, gopt->m_strMfccFile,L"MfccFile");
		GetStringFromObjectToken(cpDecodeOptionsKey, gopt->m_strPhonemeAlignFile,L"PhonemeAlignFile");

		DWORD v;
		if (cpDecodeOptionsKey->GetDWORD(L"TrellisBeamWidth", &v) == S_OK)		gopt->GetOption().trellis_beam_width = v;
		if (cpDecodeOptionsKey->GetDWORD(L"GsStateNum", &v) == S_OK)			gopt->GetOption().gs_statenum = v;
		if (cpDecodeOptionsKey->GetDWORD(L"CalcWordAlign", &v) == S_OK)			gopt->align_result_word_flag = (boolean ) v;
		if (cpDecodeOptionsKey->GetDWORD(L"UseMfccFile", &v) == S_OK)			gopt->m_bUseMfccFile = (boolean ) v;
		if (cpDecodeOptionsKey->GetDWORD(L"UsePhonemeAlign", &v) == S_OK)		gopt->m_bUsePhonemeAlignFile = (boolean ) v;
		if (cpDecodeOptionsKey->GetDWORD(L"UseFalseRecognition", &v) == S_OK)	gopt->m_bUseFalseRecognition = (boolean ) v;

		if (cpDecodeOptionsKey->GetDWORD(L"StackSize", &v) == S_OK)					gopt->GetOption().stack_size = v;
		if (cpDecodeOptionsKey->GetDWORD(L"HypoOverflow", &v) == S_OK)				gopt->GetOption().hypo_overflow = v;
		if (cpDecodeOptionsKey->GetDWORD(L"EnvelopedBestFirstWidth", &v) == S_OK)	gopt->GetOption().enveloped_bestfirst_width = v;
		if (cpDecodeOptionsKey->GetDWORD(L"LookupRange", &v) == S_OK)				gopt->GetOption().lookup_range = v;

		if (cpDecodeOptionsKey->GetDWORD(L"UseNbest", &v) == S_OK)			gopt->m_bUseNbest = (boolean ) v;
		if (cpDecodeOptionsKey->GetDWORD(L"UseCM", &v) == S_OK)				gopt->m_bUseCM = (boolean ) v;
		if (cpDecodeOptionsKey->GetDWORD(L"UseFRScore", &v) == S_OK)		gopt->m_bUseFRScore = (boolean ) v;
		if (cpDecodeOptionsKey->GetDWORD(L"UseFRMinLength", &v) == S_OK)	gopt->m_bUseFRMinLength = (boolean ) v;
		if (cpDecodeOptionsKey->GetDWORD(L"UseFRMaxLength", &v) == S_OK)	gopt->m_bUseFRMaxLength = (boolean ) v;
		if (cpDecodeOptionsKey->GetDWORD(L"UseFRFiller", &v) == S_OK)		gopt->m_bUseFRFiller = (boolean ) v;

		string tmp;
		if (SUCCEEDED(GetStringFromObjectToken(cpDecodeOptionsKey,tmp,L"Nbest")))
			gopt->m_iNbest = atoi(tmp.c_str());
		if (SUCCEEDED(GetStringFromObjectToken(cpDecodeOptionsKey,tmp,L"ScanBeamThres")))
			gopt->GetOption().scan_beam_thres = (LOGPROB ) atof(tmp.c_str());
		if (SUCCEEDED(GetStringFromObjectToken(cpDecodeOptionsKey,tmp,L"CMAlpha")))
			gopt->m_fCMAlpha = (LOGPROB ) atof(tmp.c_str());
		if (SUCCEEDED(GetStringFromObjectToken(cpDecodeOptionsKey,tmp,L"FRScore")))
			gopt->m_probFRScore = (LOGPROB ) atof(tmp.c_str());
		if (cpDecodeOptionsKey->GetDWORD(L"FRMinLength", &v) == S_OK)
			gopt->m_iFRMinLength = v;
		if (cpDecodeOptionsKey->GetDWORD(L"FRMaxLength", &v) == S_OK)
			gopt->m_iFRMaxLength = v;
		if (SUCCEEDED(GetStringFromObjectToken(cpDecodeOptionsKey,tmp,L"ScoreThresHigh")))
			gopt->m_fScoreThresHigh = (LOGPROB ) atof(tmp.c_str());
		if (SUCCEEDED(GetStringFromObjectToken(cpDecodeOptionsKey,tmp,L"ScoreThresLow")))
			gopt->m_fScoreThresLow = (LOGPROB ) atof(tmp.c_str());

		// NGRAM �p
		GetStringFromObjectToken(cpDecodeOptionsKey,tmp,L"LmWeight");
		gopt->GetOption().lm_weight = (LOGPROB ) atof(tmp.c_str());
		GetStringFromObjectToken(cpDecodeOptionsKey,tmp,L"LmWeight2");
		gopt->GetOption().lm_weight2 = (LOGPROB ) atof(tmp.c_str());
		GetStringFromObjectToken(cpDecodeOptionsKey,tmp,L"LmPenalty");
		gopt->GetOption().lm_penalty = (LOGPROB ) atof(tmp.c_str());
		GetStringFromObjectToken(cpDecodeOptionsKey,tmp,L"LmPenalty2");
		gopt->GetOption().lm_penalty2 = (LOGPROB ) atof(tmp.c_str());

		if (cpDecodeOptionsKey->GetDWORD(L"LmpSpecified", &v) == S_OK)	gopt->GetOption().lmp_specified = (boolean ) v;
		if (cpDecodeOptionsKey->GetDWORD(L"Lmp2Specified", &v) == S_OK)	gopt->GetOption().lmp2_specified = (boolean ) v;

		// DFA �p(�g��Ȃ�����)
		GetStringFromObjectToken(cpDecodeOptionsKey,tmp,L"Penalty1");
		gopt->GetOption().penalty1 = (LOGPROB ) atof(tmp.c_str());
		GetStringFromObjectToken(cpDecodeOptionsKey,tmp,L"Penalty2");
		gopt->GetOption().penalty2 = (LOGPROB ) atof(tmp.c_str());
	}
	return hr;
}


//====================================================================
// CJuliSAPIEngine::GetObjectToken
//		SAPI����G���W���쐬�シ���ɌĂ΂��
//		�G���W�����L�̃��W�X�g�����𓾂�̂ɗ��p�����
//*       The engine can recover from the token file paths stored there during installation.
//*       The engine also can recover user set defaults for accuracy, rejection etc.
//*       Also could have different engines sharing the same code base (CLSID) but having different registry info
//*       e.g. if engine supports different languages
//---- �Ԃ�l --------------------------------------------------------
// S_OK / FAILED(hr)
//---- ���� ----------------------------------------------------------
// ISpObjectToken * pToken	�g�[�N���ւ̃|�C���^
//====================================================================
STDMETHODIMP CJuliSAPIEngine::SetObjectToken(ISpObjectToken * pToken)
{
	SPDBG_FUNC("��SETOBJECTTOKEN");
	J_DEBUGMESSAGE("��SetObjectToken\n");
	HRESULT hr = S_OK;

	// Helper function that copies the token reference.
	hr = SpGenericSetObjectToken(pToken, m_cpEngineObjectToken);
	if(FAILED(hr))
	{
		return hr;
	}

	// Read attribute information from the token in the registry
	CComPtr<ISpDataKey> cpAttribKey;
	hr = pToken->OpenKey(L"Attributes", &cpAttribKey);

#if 0
	if(SUCCEEDED(hr))
	{
		WCHAR *psz = NULL;
		hr = cpAttribKey->GetStringValue(L"Desktop", &psz);
		::CoTaskMemFree(psz);
		if(SUCCEEDED(hr))
		{
			// This instance of the engine is for doing desktop recognition
		}
		else if(hr == SPERR_NOT_FOUND)
		{
			hr = cpAttribKey->GetStringValue(L"Telephony", &psz);
			::CoTaskMemFree(psz);
			if(SUCCEEDED(hr))
			{
				// This instance of the engine is for doing telephony recognition
			}
		}
	}
#endif

	// Read what language is set in the registry
	if(SUCCEEDED(hr))
	{
		WCHAR *pszLangID = NULL;
		hr = cpAttribKey->GetStringValue(L"Language", &pszLangID);
		if(SUCCEEDED(hr))
		{
			// We could use this language id in recognition.
		}
		else if(hr == SPERR_NOT_FOUND)
		{
			//            pszLangID = L"409"; // Default language (US English)
			pszLangID = L"411"; // Default language (���{��)
			hr = S_OK;
		}
		//		j_wprinterr(L"LANG=%s\n",pszLangID);
		m_LangID = (unsigned short)wcstol(pszLangID, NULL, 16);
		::CoTaskMemFree(pszLangID);
	}    

	ReadJuliOptions(pToken, &theOpt);

#if 0
	// �f�[�^�t�@�C���̈ʒu��ǂݎ��
	WCHAR *pszPath = NULL;
	//	char buf[256];

	hr = pToken->GetStorageFileName(CLSID_JuliSAPIEngine, L"SampleEngDataFile", NULL, 0, &pszPath);
	//	WideCharToMultiByte(CP_ACP,0,pszPath,-1,buf,-1,NULL,NULL);
	//  J_DEBUGMESSAGE("StorageFileName:%s\n",buf);

	::CoTaskMemFree(pszPath);
#endif

	return hr;
}

//====================================================================
// CJuliSAPIEngine::GetObjectToken
//		SAPI����I�u�W�F�N�g�g�[�N����v�����ꂽ�Ƃ��ɌĂ΂��
//---- �Ԃ�l --------------------------------------------------------
// S_OK / FAILED(hr)
//---- ���� ----------------------------------------------------------
// ISpObjectToken ** ppToken	[out] �g�[�N���ւ̃|�C���^���i�[����
//====================================================================
STDMETHODIMP CJuliSAPIEngine::GetObjectToken(ISpObjectToken ** ppToken)
{
	SPDBG_FUNC("��GETOBJECTTOKEN");
	J_DEBUGMESSAGE("��GetObjectToken\n");

	return SpGenericGetObjectToken(ppToken, m_cpEngineObjectToken);
}
